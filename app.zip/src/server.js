const express = require('express');
const path = require('path');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const cfg = require('./config');
const db = require('./db');
const auth = require('./auth');
const { AppError, wrap } = require('./util');
const { audit } = require('./audit');

const app = express();
app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(helmet({
  contentSecurityPolicy: { directives: {
    defaultSrc: ["'self'"], scriptSrc: ["'self'", 'https://telegram.org'], styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'], fontSrc: ["'self'", 'https://fonts.gstatic.com', 'data:'], imgSrc: ["'self'", 'data:', 'https:'],
    connectSrc: ["'self'"], frameAncestors: ["'self'", 'https://web.telegram.org', 'https://*.telegram.org'], objectSrc: ["'none'"], baseUri: ["'self'"],
  } },
  frameguard: false, crossOriginEmbedderPolicy: false,
}));
app.use(compression());
app.use(express.json({ limit: '200kb' }));

// Kirish va auth uchun qattiq limit, qolgan API uchun umumiy limit
const strict = rateLimit({ windowMs: 15 * 60e3, limit: 30, standardHeaders: true, legacyHeaders: false, message: { error: "Juda ko'p urinish. Birozdan so'ng qayta urinib ko'ring" } });
const general = rateLimit({ windowMs: 60e3, limit: 300, standardHeaders: true, legacyHeaders: false, message: { error: "So'rovlar juda ko'p. Biroz kuting" } });
app.use('/api', general);

// CSRF himoyasi: cookie SameSite=Strict + o'zgartiruvchi so'rovlarda maxsus header talab qilinadi
app.use('/api', (req, res, next) => {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  if (req.path.startsWith('/mini/') || req.path.startsWith('/gps/')) return next();   // Mini App: Bearer token (cookie ishlatilmaydi)
  if (req.headers['x-requested-with'] !== 'rac') return next(new AppError(403, "So'rov manbasi tekshiruvdan o'tmadi", 'CSRF'));
  next();
});

const bootAt = Date.now();
app.get('/healthz', async (req, res) => {   // monitoring / platforma health-check: baza va fon ishlari tirikligini tekshiradi
  try {
    await db.query('SELECT 1');
    const jobs = require('./services/jobs'); const age = jobs.lastTickAt ? Date.now() - jobs.lastTickAt : Date.now() - bootAt;
    if (age > 5 * 60e3) return res.status(503).json({ ok: false, reason: 'jobs_stalled', age_sec: Math.round(age / 1000) });
    res.json({ ok: true, tz: cfg.tz, uptime_sec: Math.round(process.uptime()), jobs_age_sec: Math.round(age / 1000) });
  } catch (e) { res.status(503).json({ ok: false, reason: 'db_down' }); }
});

// ----- Auth -----
const cookieOpts = { httpOnly: true, sameSite: 'strict', secure: cfg.isProd, maxAge: 12 * 3600e3, path: '/' };
app.post('/api/auth/login', strict, wrap(async (req, res) => {
  const { username, password } = req.body || {};
  const { token, user } = await auth.login(username, password);
  res.cookie('rac_session', token, cookieOpts);
  await audit({ id: user.id, full_name: user.full_name }, 'LOGIN', 'user', user.id, null, null, req);
  res.json({ user });
}));
app.post('/api/auth/logout', (req, res) => { res.clearCookie('rac_session', { ...cookieOpts, maxAge: undefined }); res.json({ ok: true }); });
app.get('/api/auth/me', auth.requireAuth, (req, res) => res.json({ user: { id: req.user.id, full_name: req.user.full_name, username: req.user.username, role: req.user.role, permissions: req.user.permissions } }));

app.use('/api/gps', rateLimit({ windowMs: 60e3, limit: 240, standardHeaders: true, legacyHeaders: false }), require('./routes/gps'));
app.use('/api/mini', rateLimit({ windowMs: 60e3, limit: 120, standardHeaders: true, legacyHeaders: false }), require('./routes/mini').router);
app.use('/api', auth.requireAuth, require('./routes/admin'));
app.use('/api', (req, res, next) => next(new AppError(404, 'Manzil topilmadi', 'NOT_FOUND')));

// Faol ijara shartnomasi (PDF) — ochiq havola: mijoz Mini App/botdan o'qiydi
app.get('/contract.pdf', wrap(async (req, res) => {
  const t = await require('./services/contract').getActive();
  if (!t || t.kind !== 'PDF' || !t.file_path) throw new AppError(404, 'Shartnoma PDF topilmadi');
  res.setHeader('Content-Type', 'application/pdf'); res.setHeader('Content-Disposition', `inline; filename="${t.file_name || 'shartnoma.pdf'}"`); res.setHeader('Cache-Control', 'no-cache');
  require('fs').createReadStream(t.file_path).pipe(res);
}));

// ----- Statik fayllar -----
app.use('/uploads/public', express.static(path.join(__dirname, '..', 'uploads', 'public'), { maxAge: '7d', index: false, dotfiles: 'deny', setHeaders: r => r.setHeader('X-Content-Type-Options', 'nosniff') }));
// PDF ko'rsatgich (pdf.js): shartnomani sahifa-ma-sahifa chizish uchun, tashqi CDN siz (CSP: faqat 'self')
try { app.use('/app/vendor/pdfjs', express.static(path.join(path.dirname(require.resolve('pdfjs-dist/package.json')), 'legacy', 'build'), { maxAge: '7d', index: false, dotfiles: 'deny' })); } catch (e) { console.error('pdfjs-dist topilmadi (npm install):', e.message); }
app.use('/app', express.static(path.join(__dirname, '..', 'public', 'app'), { etag: true, maxAge: 0, setHeaders: (r, f) => { if (/\.(html|js|css)$/.test(f)) r.setHeader('Cache-Control', 'no-cache, must-revalidate'); } }));
app.use('/admin', express.static(path.join(__dirname, '..', 'public', 'admin')));
app.get('/', (req, res) => res.redirect('/admin/'));

// ----- Global xato ishlovchi: foydalanuvchiga stack trace ko'rsatilmaydi, log serverda -----
app.use((err, req, res, next) => { // eslint-disable-line
  if (err.type === 'entity.parse.failed') err = new AppError(400, "So'rov formati noto'g'ri");
  if (err.code === 'LIMIT_FILE_SIZE') err = new AppError(413, 'Rasm hajmi juda katta. Iltimos, kichikroq rasm tanlang.', 'FILE_TOO_LARGE');
  if (err.type === 'entity.too.large') err = new AppError(413, "So'rov hajmi juda katta");
  if (err.code === '23P01') err = new AppError(409, 'Bu mashina tanlangan vaqtda band', 'DOUBLE_BOOKING');
  if (err.code === '23503') err = new AppError(409, "Bog'langan ma'lumot mavjud yoki topilmadi");
  if (err.code === '22P02' || err.code === '22003' || err.code === '22007' || err.code === '22008') err = new AppError(400, "Kiritilgan qiymat noto'g'ri");
  if (!(err instanceof AppError)) {
    console.error(`[${new Date().toISOString()}] ${req.method} ${req.originalUrl}`, err);
    return res.status(500).json({ error: "Serverda xatolik yuz berdi. Keyinroq urinib ko'ring.", code: 'SERVER_ERROR' });
  }
  // Mijozga (Mini App) sozlama/texnik xabarlar ko'rsatilmaydi — faqat admin ko'radi
  if (req.originalUrl.startsWith('/api/mini') && ['NO_CONTRACT', 'NO_BOT'].includes(err.code)) return res.status(err.status || 400).json({ error: 'Bu xizmat hozircha mavjud emas.', code: err.code });
  res.status(err.status || 400).json({ error: err.message, code: err.code });
});

async function waitForDb(tries = 60) {   // baza hali ishga tushmagan bo'lsa ham server yiqilmaydi — kutadi
  for (let i = 1; i <= tries; i++) {
    try { await db.query('SELECT 1'); return; } catch (e) { console.log(`Baza kutilmoqda (${i}/${tries}): ${e.message}`); await new Promise(r => setTimeout(r, 2000)); }
  }
  throw new Error('Bazaga ulanib bo\'lmadi');
}
let server = null;
async function start() {
  await waitForDb();
  const seed = require('../scripts/seed');
  await seed.run();
  const bot = require('./bot');
  await bot.init(app).catch(e => console.error('Bot ishga tushmadi (server davom etadi):', e.message));
  require('./services/jobs').start();
  return new Promise(res => { server = app.listen(cfg.port, () => { console.log(`RENT A CAR ishga tushdi: http://localhost:${cfg.port}  (Asia/Tashkent)`); res(server); }); });
}
// ---- Doimiy ishlash: kutilmagan xatolar jurnalga yoziladi; og'ir holatda jarayon qayta ishga tushiriladi (supervisor/Railway) ----
process.on('unhandledRejection', e => console.error('[unhandledRejection]', e));
process.on('uncaughtException', e => { console.error('[uncaughtException]', e); setTimeout(() => process.exit(1), 200); });
const shutdown = sig => { console.log(`${sig}: to'xtatilmoqda…`); try { require('./bot').stop(); } catch {} const done = () => db.pool.end().finally(() => process.exit(0)); server ? server.close(done) : done(); setTimeout(() => process.exit(0), 8000).unref(); };
['SIGTERM', 'SIGINT'].forEach(s => process.on(s, () => shutdown(s)));
module.exports = { app, start };
if (require.main === module) start().catch(e => { console.error('Ishga tushmadi:', e); process.exit(1); });
