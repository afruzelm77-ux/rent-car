const crypto = require('crypto');
const cfg = require('./config');

class AppError extends Error {
  constructor(status, message, code) { super(message); this.status = status; this.code = code; }
}
const wrap = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

function encrypt(text) {
  if (!text) return null;
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', cfg.encKey, iv);
  const enc = Buffer.concat([c.update(String(text), 'utf8'), c.final()]);
  return [iv, c.getAuthTag(), enc].map(b => b.toString('base64')).join('.');
}
function decrypt(s) {
  if (!s) return null;
  try {
    const [iv, tag, enc] = s.split('.').map(x => Buffer.from(x, 'base64'));
    const d = crypto.createDecipheriv('aes-256-gcm', cfg.encKey, iv); d.setAuthTag(tag);
    return Buffer.concat([d.update(enc), d.final()]).toString('utf8');
  } catch { return null; }
}

const pad = n => String(n).padStart(2, '0');
// Toshkent vaqti = UTC+5 (DST yo'q)
const tkt = d => new Date(new Date(d).getTime() + 5 * 3600e3);
const fmtDate = d => { const t = tkt(d); return `${pad(t.getUTCDate())}.${pad(t.getUTCMonth() + 1)}.${t.getUTCFullYear()}`; };
const fmtTime = d => { const t = tkt(d); return `${pad(t.getUTCHours())}:${pad(t.getUTCMinutes())}`; };
const fmtDT = d => `${fmtDate(d)} ${fmtTime(d)}`;
const money = n => String(Math.round(Number(n) || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + " so'm";

function parseTkt(date, time = '00:00') {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date || '') || !/^\d{2}:\d{2}$/.test(time || '')) throw new AppError(400, "Sana yoki vaqt noto'g'ri formatda");
  const d = new Date(`${date}T${time}:00+05:00`);
  if (isNaN(d)) throw new AppError(400, "Sana yoki vaqt noto'g'ri");
  return d;
}
function todayStr() { const t = tkt(new Date()); return `${t.getUTCFullYear()}-${pad(t.getUTCMonth() + 1)}-${pad(t.getUTCDate())}`; }
function addDays(dateStr, n) { const d = new Date(dateStr + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); }
function dayRange(dateStr) { const from = parseTkt(dateStr, '00:00'); return [from, new Date(from.getTime() + 864e5)]; }

module.exports = { AppError, wrap, encrypt, decrypt, fmtDate, fmtTime, fmtDT, money, parseTkt, todayStr, addDays, dayRange };
