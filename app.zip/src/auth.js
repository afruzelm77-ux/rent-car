const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const cfg = require('./config');
const db = require('./db');
const { AppError, wrap } = require('./util');

function sign(payload, hours = 12) { return jwt.sign(payload, cfg.jwtSecret, { expiresIn: hours + 'h' }); }
function readToken(req) {
  const h = req.headers.authorization;
  if (h && h.startsWith('Bearer ')) return h.slice(7);
  const m = /(?:^|;\s*)rac_session=([^;]+)/.exec(req.headers.cookie || '');
  return m ? decodeURIComponent(m[1]) : null;
}
// Admin autentifikatsiyasi: har so'rovda foydalanuvchi bazadan tekshiriladi (faolsizlantirilgan darrov chiqadi)
const requireAuth = wrap(async (req, res, next) => {
  const t = readToken(req);
  if (!t) throw new AppError(401, 'Tizimga kiring', 'UNAUTH');
  let p; try { p = jwt.verify(t, cfg.jwtSecret); } catch { throw new AppError(401, 'Sessiya tugagan, qayta kiring', 'UNAUTH'); }
  if (p.typ !== 'staff') throw new AppError(401, 'Ruxsat yo\'q', 'UNAUTH');
  const { rows } = await db.query(`SELECT u.id,u.full_name,u.username,u.is_active,r.code role,r.permissions
    FROM users u JOIN roles r ON r.id=u.role_id WHERE u.id=$1 AND u.deleted_at IS NULL`, [p.uid]);
  if (!rows[0] || !rows[0].is_active) throw new AppError(401, 'Hisob faol emas', 'UNAUTH');
  req.user = rows[0];
  next();
});
const requirePerm = (...perms) => (req, res, next) => {
  if (perms.some(p => (req.user.permissions || []).includes(p))) return next();
  next(new AppError(403, "Bu amal uchun sizda ruxsat yo'q", 'FORBIDDEN'));
};
async function login(username, password) {
  const { rows } = await db.query(`SELECT u.*,r.code role,r.permissions FROM users u JOIN roles r ON r.id=u.role_id
    WHERE lower(u.username)=lower($1) AND u.deleted_at IS NULL`, [String(username || '')]);
  const u = rows[0];
  const bad = new AppError(401, "Login yoki parol noto'g'ri", 'BAD_CREDENTIALS');
  if (!u || !u.is_active) { await bcrypt.compare('x', '$2a$10$abcdefghijklmnopqrstuuABCDEFGHIJKLMNOPQRSTUVWXYZ01234'); throw bad; }
  if (u.locked_until && u.locked_until > new Date()) throw new AppError(429, "Hisob vaqtincha bloklandi. 15 daqiqadan so'ng urinib ko'ring", 'LOCKED');
  const ok = await bcrypt.compare(String(password || ''), u.password_hash);
  if (!ok) {
    await db.query(`UPDATE users SET failed_logins=failed_logins+1,
      locked_until=CASE WHEN failed_logins+1>=5 THEN now()+interval '15 minutes' ELSE locked_until END WHERE id=$1`, [u.id]);
    throw bad;
  }
  await db.query('UPDATE users SET failed_logins=0,locked_until=NULL,last_login_at=now() WHERE id=$1', [u.id]);
  return { token: sign({ typ: 'staff', uid: u.id }), user: { id: u.id, full_name: u.full_name, username: u.username, role: u.role, permissions: u.permissions } };
}
const hash = pw => bcrypt.hash(pw, 10);
module.exports = { sign, readToken, requireAuth, requirePerm, login, hash };
