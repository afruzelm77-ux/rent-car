const db = require('./db');
// Muhim harakatlar: kim, nima qildi, qachon, oldingi/yangi qiymat
async function audit(user, action, entity, entityId, oldValue, newValue, req, client) {
  const q = (client || db).query.bind(client || db);
  try {
    await q(`INSERT INTO audit_logs(user_id,user_name,action,entity,entity_id,old_value,new_value,ip) VALUES($1,$2,$3,$4,$5,$6,$7,$8)`,
      [user?.id || null, user?.full_name || user?.name || 'Tizim', action, entity, entityId == null ? null : String(entityId),
        oldValue == null ? null : JSON.stringify(oldValue), newValue == null ? null : JSON.stringify(newValue), req?.ip || null]);
  } catch (e) { console.error('audit xato', e.message); }
}
module.exports = { audit };
