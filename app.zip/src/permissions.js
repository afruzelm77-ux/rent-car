// Rol -> huquqlar. OWNER har doim hamma narsaga ega. Boshqa rollar huquqlarini OWNER admin paneldan o'zgartira oladi.
const LABELS = {
  'cars.read': "Mashinalarni ko'rish", 'cars.write': "Mashina qo'shish/tahrirlash/o'chirish",
  'customers.read': "Mijozlarni ko'rish", 'customers.write': "Mijoz qo'shish/tahrirlash", 'customers.pii': "Passport va hujjatlarni ochib ko'rish",
  'bookings.read': "Buyurtmalarni ko'rish", 'bookings.write': 'Buyurtma yaratish/tasdiqlash/bekor qilish', 'handover': 'Mashina berish va qabul qilish',
  'payments.write': "To'lov qabul qilish va to'lov so'rovlarini tasdiqlash", 'finance.read': "Moliya: daromad, foyda, xarajatlarni ko'rish", 'expenses.write': "Xarajat kiritish",
  'maintenance.read': "Texnik xizmatni ko'rish", 'maintenance.write': "Texnik xizmat qo'shish", 'contracts.read': 'Shartnomalarni yuklab olish',
  'reports.read': "Hisobotlar", 'notifications.read': 'Bildirishnomalar', 'promo.write': 'Promo kodlar', 'ai.use': 'AI yordamchi',
  'users.manage': 'Xodimlarni boshqarish', 'settings.manage': 'Sozlamalar va Funksiyalar markazi', 'audit.read': 'Audit logni ko\'rish', 'backup.manage': 'Zaxira nusxa',
  'contract.manage': "Shartnoma, to'lov kartalari va aloqa raqamlarini boshqarish", 'messages.send': 'Mijozlarga xabar yuborish',
};
const ALL = Object.keys(LABELS);
const ROLES = {
  OWNER: { name: 'Egasi', permissions: ALL },
  // Administrator: Egasidan faqat Egasi hisobini o'zgartira olmasligi bilan farq qiladi (users route'ida himoyalangan)
  ADMIN: { name: 'Administrator', permissions: ALL },
  MANAGER: { name: 'Menejer', permissions: ['cars.read','customers.read','customers.write','customers.pii','bookings.read','bookings.write','handover',
    'payments.write','maintenance.read','contracts.read','notifications.read','ai.use','messages.send'] },
  ACCOUNTANT: { name: 'Buxgalter', permissions: ['cars.read','customers.read','bookings.read','payments.write','finance.read','expenses.write',
    'reports.read','contracts.read','notifications.read','ai.use'] },
};
module.exports = { ALL, LABELS, ROLES, can: (user, perm) => !!user && (user.permissions || []).includes(perm) };
