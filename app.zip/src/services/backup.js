const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const cfg = require('../config');
const settings = require('./settings');
const DIR = path.join(__dirname, '..', '..', 'backups');
const db = require('../db');

// pg_dump versiyasi baza versiyasidan eski bo'lsa yoki topilmasa — zaxira baribir Node orqali olinadi (ma'lumotlar INSERT ko'rinishida; sxema db/schema.sql da)
const lit = v => {
  if (v === null || v === undefined) return 'NULL';
  if (typeof v === 'number' || typeof v === 'bigint') return String(v);
  if (typeof v === 'boolean') return v ? 'true' : 'false';
  if (v instanceof Date) return `'${v.toISOString()}'`;
  const t = typeof v === 'object' ? JSON.stringify(v) : String(v);
  return `'${t.replace(/'/g, "''")}'`;
};
async function nodeDump(file) {
  const out = fs.createWriteStream(file);
  const w = t => new Promise(r => (out.write(t) ? r() : out.once('drain', r)));
  await w(`-- RENT A CAR ma'lumotlar zaxirasi (Node) ${new Date().toISOString()}\n-- Tiklash: avval db/schema.sql, so'ng shu fayl.\nBEGIN;\nSET session_replication_role = replica;\n`);
  const tables = (await db.query(`SELECT table_name FROM information_schema.tables WHERE table_schema='public' AND table_type='BASE TABLE' ORDER BY table_name`)).rows;
  for (const { table_name: t } of tables) {
    const { rows } = await db.query(`SELECT * FROM "${t}"`);
    for (const r of rows) { const cols = Object.keys(r); await w(`INSERT INTO "${t}" (${cols.map(c => `"${c}"`).join(',')}) VALUES (${cols.map(c => lit(r[c])).join(',')});\n`); }
  }
  await w('SET session_replication_role = DEFAULT;\nCOMMIT;\n');
  await new Promise(r => out.end(r));
}

function pgDump(file) {
  return new Promise((resolve, reject) => {
    const out = fs.createWriteStream(file);
    const p = spawn('pg_dump', ['--no-owner', '--dbname', cfg.databaseUrl]);
    let err = '';
    p.stdout.pipe(out); p.stderr.on('data', d => err += d);
    p.on('error', e => reject(new Error('pg_dump topilmadi: ' + e.message)));
    p.on('close', code => code === 0 ? resolve() : reject(new Error('pg_dump xatosi: ' + err.slice(0, 160))));
  });
}
async function run() {
  fs.mkdirSync(DIR, { recursive: true });
  const name = `rentacar-${new Date().toISOString().replace(/[:.]/g, '-')}.sql`;
  const file = path.join(DIR, name);
  try { await pgDump(file); }
  catch (e) { console.error('Backup: pg_dump ishlamadi, Node usuli ishlatiladi —', e.message); fs.rmSync(file, { force: true }); await nodeDump(file); }
  const keep = await settings.getNum('backup_keep');
  const files = fs.readdirSync(DIR).filter(f => f.endsWith('.sql')).sort();
  files.slice(0, Math.max(0, files.length - (keep || 14))).forEach(f => fs.rmSync(path.join(DIR, f), { force: true }));
  return { name, size: fs.statSync(file).size };
}
function list() {
  if (!fs.existsSync(DIR)) return [];
  return fs.readdirSync(DIR).filter(f => f.endsWith('.sql')).sort().reverse().map(f => ({ name: f, size: fs.statSync(path.join(DIR, f)).size, at: fs.statSync(path.join(DIR, f)).mtime }));
}
module.exports = { run, list, DIR, nodeDump };
