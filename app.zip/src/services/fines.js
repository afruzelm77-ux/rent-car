const db = require('../db');
const { notify } = require('./notify');
const { audit } = require('../audit');
const { AppError, money, fmtDT } = require('../util');

async function list({ status, car_id, q } = {}) {
  const w = ['1=1'], p = [];
  if (status) { p.push(status); w.push(`f.status=$${p.length}`); }
  if (car_id) { p.push(car_id); w.push(`f.car_id=$${p.length}`); }
  if (q) { p.push('%' + q + '%'); w.push(`(car.plate ILIKE $${p.length} OR car.model ILIKE $${p.length} OR cu.first_name ILIKE $${p.length} OR cu.last_name ILIKE $${p.length} OR f.doc_no ILIKE $${p.length})`); }
  const { rows } = await db.query(`SELECT f.*,car.brand,car.model,car.plate,cu.first_name,cu.last_name,cu.phone,b.code booking_code
    FROM fines f JOIN cars car ON car.id=f.car_id LEFT JOIN customers cu ON cu.id=f.customer_id LEFT JOIN bookings b ON b.id=f.booking_id
    WHERE ${w.join(' AND ')} ORDER BY f.fine_date DESC LIMIT 300`, p);
  return rows;
}
// Jarima sanasida mashina kimda bo'lgan bo'lsa — avtomatik shu mijozga biriktiriladi
async function findHolder(carId, at) {
  return (await db.query(`SELECT b.id,b.customer_id,b.code FROM bookings b WHERE b.car_id=$1 AND b.deleted_at IS NULL AND b.status IN ('ACTIVE','OVERDUE','COMPLETED')
    AND COALESCE(b.actual_pickup_at,b.pickup_at) <= $2 AND COALESCE(b.actual_return_at,b.return_at) >= $2 ORDER BY b.id DESC LIMIT 1`, [carId, at])).rows[0] || null;
}
async function create(d, user, req) {
  const at = new Date(d.fine_date); if (isNaN(at)) throw new AppError(400, "Jarima sanasi noto'g'ri");
  const amount = Number(d.amount); if (!Number.isInteger(amount) || amount <= 0) throw new AppError(400, "Jarima summasi musbat butun son bo'lishi kerak");
  const car = (await db.query('SELECT id,brand,model,plate FROM cars WHERE id=$1 AND deleted_at IS NULL', [d.car_id])).rows[0];
  if (!car) throw new AppError(404, 'Mashina topilmadi');
  const holder = await findHolder(car.id, at);
  const { rows } = await db.query(`INSERT INTO fines(car_id,booking_id,customer_id,fine_date,amount,reason,doc_no,note,created_by) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
    [car.id, holder?.id || null, holder?.customer_id || null, at, amount, d.reason || null, d.doc_no || null, d.note || null, user?.id || null]);
  await audit(user, 'CREATE', 'fine', rows[0].id, null, { car_id: car.id, amount, booking: holder?.code || null }, req);
  if (holder) await notify({ audience: 'CUSTOMER', customer_id: holder.customer_id, type: 'FINE', title: '🚨 Jarima qayd etildi', ref_key: `fine:${rows[0].id}`,
    body: `${car.brand} ${car.model} (${car.plate})\nSana: ${fmtDT(at)}\nSumma: ${money(amount)}${d.reason ? '\nSabab: ' + d.reason : ''}\n\nIltimos, operator bilan bog'laning.`,
    keyboard: [[{ text: '☎️ Operator', callback_data: 'm:op' }]] });
  return { ...rows[0], assigned: !!holder, booking_code: holder?.code || null };
}
async function setStatus(id, status, user, req) {
  if (!['NEW', 'PAID', 'CANCELLED'].includes(status)) throw new AppError(400, 'Holat noto\'g\'ri');
  const { rows } = await db.query('UPDATE fines SET status=$2 WHERE id=$1 RETURNING *', [id, status]);
  if (!rows[0]) throw new AppError(404, 'Jarima topilmadi');
  await audit(user, 'STATUS', 'fine', id, null, { status }, req); return rows[0];
}
module.exports = { list, create, setStatus };
