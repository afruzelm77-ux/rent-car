// Online to'lov uchun alohida xizmat qatlami. Har bir provayder (Payme, Click, Uzum) shu interfeysni amalga oshiradi.
// Hozir "manual" ishlaydi; qolganlari kalit kiritilganda ulanadi — biznes mantiq (bookings.addPayment) o'zgarmaydi.
const { AppError } = require('../util');
const bookings = require('./bookings');

const providers = {
  manual: {
    configured: () => true,
    async createInvoice() { return { url: null, note: "Kassada to'lov qilinadi" }; },
  },
  payme: { configured: () => !!process.env.PAYME_MERCHANT_ID,
    async createInvoice() { throw new AppError(501, 'Payme hali sozlanmagan (PAYME_MERCHANT_ID)', 'NOT_CONFIGURED'); } },
  click: { configured: () => !!process.env.CLICK_SERVICE_ID,
    async createInvoice() { throw new AppError(501, 'Click hali sozlanmagan (CLICK_SERVICE_ID)', 'NOT_CONFIGURED'); } },
};
function get(name) {
  const p = providers[name || 'manual'];
  if (!p) throw new AppError(400, "Noma'lum to'lov provayderi");
  return p;
}
// Provayder webhooki tasdiqlagach shu funksiya chaqiriladi (idempotent: provider_txn_id bo'yicha)
async function settle({ booking_id, amount, provider, provider_txn_id }) {
  const db = require('../db');
  const dup = await db.query('SELECT id FROM payments WHERE provider=$1 AND provider_txn_id=$2', [provider, provider_txn_id]);
  if (dup.rows[0]) return { duplicate: true };
  return bookings.addPayment({ booking_id, amount, kind: 'RENTAL', method: 'ONLINE', provider, provider_txn_id }, { name: provider });
}
module.exports = { get, settle, providers };
