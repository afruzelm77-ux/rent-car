const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const PDFDocument = require('pdfkit');
const { PDFDocument: PDFLib } = require('pdf-lib');
const db = require('../db');
const settings = require('./settings');
const { tg } = require('./notify');
const { audit } = require('../audit');
const { decrypt, fmtDate, fmtDT, money, AppError } = require('../util');

const FDIR = path.dirname(require.resolve('dejavu-fonts-ttf/package.json'));
const FONT = path.join(FDIR, 'ttf', 'DejaVuSans.ttf');
const FONT_B = path.join(FDIR, 'ttf', 'DejaVuSans-Bold.ttf');
const DIR = path.join(__dirname, '..', '..', 'uploads', 'contracts');
const TDIR = path.join(__dirname, '..', '..', 'uploads', 'contract-templates');
const sha = t => crypto.createHash('sha256').update(t, 'utf8').digest('hex');
const esc = v => String(v ?? '').replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));

/* ---------- Shablon (versiyalanadi) ---------- */
async function getActive(client = db) {
  const { rows } = await client.query('SELECT id,version,title,body,body_hash,kind,file_path,file_name,created_at FROM contract_templates WHERE is_active');
  return rows[0] || null;
}
async function requireActive(client = db) {
  const t = await getActive(client);
  if (!t) throw new AppError(409, "Ijara shartnomasi hali yuklanmagan, hozircha bron qilib bo'lmaydi. Operator bilan bog'laning.", 'NO_CONTRACT');
  return t;
}
async function listTemplates() {
  const { rows } = await db.query(`SELECT t.id,t.version,t.title,t.kind,t.file_name,t.is_active,t.created_at,u.full_name created_by_name,length(t.body) len,
    (SELECT COUNT(*)::int FROM contract_consents c WHERE c.template_id=t.id) consents FROM contract_templates t LEFT JOIN users u ON u.id=t.created_by ORDER BY t.version DESC`);
  return rows;
}
// Har bir saqlash — yangi versiya. Eski versiya o'zgarmaydi (mijozlar rozi bo'lgan matn saqlanib qoladi).
async function saveTemplate({ title, body }, user, req) {
  title = String(title || '').trim(); body = String(body || '').replace(/\r\n/g, '\n').trim();
  if (title.length < 3) throw new AppError(400, 'Shartnoma sarlavhasini kiriting');
  if (body.length < 50) throw new AppError(400, "Shartnoma matni juda qisqa (kamida 50 belgi). To'liq matnni kiriting.");
  if (body.length > 60000) throw new AppError(400, 'Shartnoma matni juda uzun (60 000 belgigacha)');
  const cur = await getActive();
  if (cur && cur.body_hash === sha(body) && cur.title === title) throw new AppError(409, "Matn o'zgarmagan");
  return db.tx(async c => {
    const v = (await c.query('SELECT COALESCE(MAX(version),0)+1 v FROM contract_templates')).rows[0].v;
    await c.query('UPDATE contract_templates SET is_active=false WHERE is_active');
    const r = await c.query(`INSERT INTO contract_templates(version,title,body,body_hash,is_active,created_by) VALUES($1,$2,$3,$4,true,$5) RETURNING id,version`, [v, title, body, sha(body), user?.id || null]);
    await audit(user, 'CONTRACT_VERSION', 'contract_template', r.rows[0].id, cur ? { version: cur.version } : null, { version: v, length: body.length }, req, c);
    return r.rows[0];
  });
}

// Admin tayyor shartnoma PDF faylini yuklaydi (yangi versiya)
async function savePdfTemplate({ title, buffer, filename }, user, req) {
  title = String(title || '').trim();
  if (title.length < 3) throw new AppError(400, 'Shartnoma sarlavhasini kiriting');
  if (!buffer || buffer.length < 200 || buffer.slice(0, 4).toString() !== '%PDF') throw new AppError(400, 'Faqat PDF fayl yuklash mumkin');
  if (buffer.length > 15 * 1024 * 1024) throw new AppError(400, 'PDF hajmi 15 MB dan oshmasligi kerak');
  let pages;
  try { pages = (await PDFLib.load(buffer, { ignoreEncryption: false })).getPageCount(); } catch { throw new AppError(400, "PDF faylni o'qib bo'lmadi (shikastlangan yoki parol bilan himoyalangan)"); }
  const hash = crypto.createHash('sha256').update(buffer).digest('hex');
  const cur = await getActive();
  if (cur && cur.body_hash === hash) throw new AppError(409, 'Bu fayl allaqachon faol shartnoma sifatida yuklangan');
  fs.mkdirSync(TDIR, { recursive: true });
  const file = path.join(TDIR, `${hash.slice(0, 24)}.pdf`);
  fs.writeFileSync(file, buffer, { mode: 0o640 });
  const safeName = String(filename || 'shartnoma.pdf').replace(/[^\w.\- ]+/g, '_').slice(0, 120);
  return db.tx(async c => {
    const v = (await c.query('SELECT COALESCE(MAX(version),0)+1 v FROM contract_templates')).rows[0].v;
    await c.query('UPDATE contract_templates SET is_active=false WHERE is_active');
    const r = await c.query(`INSERT INTO contract_templates(version,title,body,body_hash,kind,file_path,file_name,is_active,created_by) VALUES($1,$2,'',$3,'PDF',$4,$5,true,$6) RETURNING id,version`, [v, title, hash, file, safeName, user?.id || null]);
    await audit(user, 'CONTRACT_VERSION', 'contract_template', r.rows[0].id, cur ? { version: cur.version } : null, { version: v, kind: 'PDF', pages, file: safeName }, req, c);
    return { ...r.rows[0], pages };
  });
}

/* ---------- Rozilik ---------- */
async function getConsent(bookingId, client = db) {
  const { rows } = await client.query(`SELECT c.*,t.version,t.title,u.full_name recorded_by_name FROM contract_consents c JOIN contract_templates t ON t.id=c.template_id
    LEFT JOIN users u ON u.id=c.recorded_by WHERE c.booking_id=$1`, [bookingId]);
  return rows[0] || null;
}
// Mijoz (yoki PAPER bo'lsa — xodim) shartlar bilan rozi bo'lganini yozadi. Faqat FAOL versiyaga rozilik qabul qilinadi.
async function recordConsent(client, { booking_id, customer_id, template_id, channel, telegram_id = null, recorded_by = null, ip = null, ua = null }) {
  const t = await requireActive(client);
  if (template_id && Number(template_id) !== t.id) throw new AppError(409, "Shartnoma matni yangilangan. Iltimos, yangi shartlarni o'qib chiqing.", 'CONTRACT_CHANGED');
  const r = await client.query(`INSERT INTO contract_consents(booking_id,customer_id,template_id,body_hash,channel,telegram_id,recorded_by,ip,user_agent)
    VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) ON CONFLICT (booking_id) DO NOTHING RETURNING id`,
  [booking_id, customer_id, t.id, t.body_hash, channel, telegram_id, recorded_by, ip, (ua || '').slice(0, 300)]);
  return { created: !!r.rows[0], template: t };
}
// Admin yaratgan buyurtma uchun: mijozga Telegram orqali shartlarni o'qib rozilik berish so'rovi yuboriladi
async function sendConsentRequest(bookingId) {
  const t = await requireActive();
  const { rows } = await db.query(`SELECT b.id,b.code,c.telegram_id,c.id customer_id FROM bookings b JOIN customers c ON c.id=b.customer_id WHERE b.id=$1`, [bookingId]);
  const b = rows[0]; if (!b) throw new AppError(404, 'Buyurtma topilmadi');
  if (!b.telegram_id) throw new AppError(409, "Mijoz Telegram botga ulanmagan. «Qog'ozda imzolandi» tugmasidan foydalaning.");
  const kb = { reply_markup: { inline_keyboard: [[{ text: "✅ O'qidim, roziman", callback_data: `cs:${b.id}:${t.id}` }]] } };
  let last;
  if (t.kind === 'PDF') last = await tg.sendDocument(b.telegram_id, t.file_path, `📄 <b>${esc(t.title)}</b>\nBuyurtma: ${esc(b.code)}\n\nShartnomani diqqat bilan o'qib chiqing. Rozi bo'lsangiz, pastdagi tugmani bosing.`, kb);
  else {
    await tg.send(b.telegram_id, `📄 <b>${esc(t.title)}</b>\nBuyurtma: ${esc(b.code)}\n\nIltimos, quyidagi shartlarni diqqat bilan o'qing:`);
    last = await tg.sendLong(b.telegram_id, esc(t.body), kb);
  }
  if (!last.ok && !last.skipped) throw new AppError(502, "Telegram xabarni yubormadi. Mijoz botni bloklagan bo'lishi mumkin.");
  return { sent: !!last.ok };
}

/* ---------- PDF ---------- */
async function load(id) {
  const { rows } = await db.query(`SELECT b.*, c.first_name,c.last_name,c.phone,c.passport_enc,c.license_enc,
    car.brand,car.model,car.plate,car.vin,car.year,car.color FROM bookings b JOIN customers c ON c.id=b.customer_id
    JOIN cars car ON car.id=b.car_id WHERE b.id=$1`, [id]);
  if (!rows[0]) throw new AppError(404, 'Buyurtma topilmadi');
  const items = (await db.query('SELECT * FROM booking_items WHERE booking_id=$1', [id])).rows;
  return { b: rows[0], items };
}
function render(doc, b, items, S, tpl, consent) {
  const L = 50, W = 495;
  doc.font(FONT_B).fontSize(16).text(S.company_name, L, 50, { width: W, align: 'center' });
  if (S.company_address || S.company_phone) doc.font(FONT).fontSize(9).fillColor('#555').text([S.company_address, S.company_phone].filter(Boolean).join('  •  '), { width: W, align: 'center' });
  doc.moveDown(1).fillColor('#000').font(FONT_B).fontSize(13).text(`${tpl.title} № ${b.contract_no}`, { width: W, align: 'center' });
  doc.font(FONT).fontSize(9).text(`Sana: ${fmtDate(b.contract_date)}  •  Buyurtma: ${b.code}  •  Shartnoma versiyasi: ${tpl.version}`, { width: W, align: 'center' });
  doc.moveDown(1);
  const row = (k, v) => { const y = doc.y; doc.font(FONT).fontSize(9).fillColor('#555').text(k, L, y, { width: 150 }); doc.fillColor('#000').font(FONT_B).text(String(v ?? '—'), L + 155, y, { width: W - 155 }); doc.moveDown(0.3); };
  const h = t => { doc.moveDown(0.5).font(FONT_B).fontSize(11).fillColor('#101826').text(t, L); doc.moveTo(L, doc.y + 1).lineTo(L + W, doc.y + 1).strokeColor('#C9A227').lineWidth(1.5).stroke(); doc.moveDown(0.5); };
  h('1. Tomonlar');
  row('Ijaraga beruvchi', S.company_name); row('Ijarachi (mijoz)', `${b.first_name} ${b.last_name}`); row('Telefon', b.phone);
  row('Passport / ID', decrypt(b.passport_enc) || "ko'rsatilmagan"); row('Haydovchilik guvohnomasi', decrypt(b.license_enc) || "ko'rsatilmagan");
  h('2. Avtomobil');
  row('Marka / model', `${b.brand} ${b.model}`); row('Davlat raqami', b.plate); row('VIN', b.vin); row('Yil / rang', `${b.year || '—'} / ${b.color || '—'}`);
  h('3. Ijara muddati va narx');
  row('Olish', fmtDT(b.pickup_at)); row('Qaytarish', fmtDT(b.return_at)); row('Joy', b.pickup_location);
  row('Kunlar × tarif', `${b.days} × ${money(b.daily_rate)} = ${money(b.rental_amount)}`);
  if (Number(b.discount) > 0) row('Chegirma', '− ' + money(b.discount));
  items.forEach(i => row(i.name, `${i.qty} × ${money(i.unit_price)} = ${money(i.total)}`));
  row('Jami ijara summasi', money(b.total_amount)); row('Depozit (alohida)', money(b.deposit_amount));
  if (Number(S.late_fee_per_hour) > 0) row('Kechikish tarifi', `${money(S.late_fee_per_hour)} / soat (${S.late_grace_minutes} daqiqa imtiyoz)`);
  h('4. Shartlar');
  if (tpl.kind === 'PDF') doc.font(FONT).fontSize(9).fillColor('#000').text(`Ijara shartlari ilova qilingan shartnoma matnida bayon etilgan: «${tpl.title}» (versiya ${tpl.version}). Ushbu varaq shartnomaning ajralmas qismidir.`, L, doc.y, { width: W });
  else tpl.body.split('\n').forEach(line => { if (!line.trim()) return doc.moveDown(0.3); doc.font(FONT).fontSize(8.5).fillColor('#000').text(line, L, doc.y, { width: W }).moveDown(0.2); });
  doc.moveDown(1.2);
  if (doc.y > 640) doc.addPage();
  h('5. Rozilik va imzolar');
  if (consent) doc.font(FONT).fontSize(9).fillColor('#0f6b43').text(`✓ Mijoz shartlarni o'qib, ${consent.channel === 'PAPER' ? "qog'ozda imzolab" : 'elektron'} rozilik bergan: ${fmtDT(consent.accepted_at)} (${{ MINIAPP: 'Telegram Mini App', BOT: 'Telegram bot', PAPER: "qog'oz imzo" }[consent.channel]}), shartnoma v${tpl.version}`, L, doc.y, { width: W }).fillColor('#000').moveDown(0.8);
  else doc.font(FONT).fontSize(9).fillColor('#a32626').text('Mijoz roziligi hali olinmagan.', L).fillColor('#000').moveDown(0.8);
  const y = doc.y + 6;
  doc.font(FONT).fontSize(9).text('Ijaraga beruvchi: ______________________', L, y).text('Ijarachi: ______________________', L + 270, y);
  doc.fontSize(7.5).fillColor('#777').text('imzo / M.O.', L, y + 14).text('imzo', L + 270, y + 14);
}
async function generate(bookingId) {
  const { b, items } = await load(bookingId);
  const consent = await getConsent(bookingId);
  const tpl = consent ? (await db.query('SELECT version,title,body,kind,file_path FROM contract_templates WHERE id=$1', [consent.template_id])).rows[0] : await requireActive();
  const S = await settings.all();
  const ex = (await db.query('SELECT * FROM rental_contracts WHERE booking_id=$1', [bookingId])).rows[0];
  const number = ex?.number || `SH-${new Date().getFullYear()}-${String(bookingId).padStart(5, '0')}`;
  b.contract_no = number; b.contract_date = new Date();
  fs.mkdirSync(DIR, { recursive: true });
  const file = path.join(DIR, `${number}.pdf`);
  const detail = await new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: 'A4', margin: 50, info: { Title: `Shartnoma ${number}`, Author: S.company_name } });
    const chunks = []; doc.on('data', c => chunks.push(c)); doc.on('end', () => resolve(Buffer.concat(chunks))); doc.on('error', reject);
    render(doc, b, items, S, tpl, consent); doc.end();
  });
  if (tpl.kind === 'PDF' && tpl.file_path && fs.existsSync(tpl.file_path)) {
    // Kompaniya shartnomasi (admin yuklagan PDF) + buyurtma varag'i va rozilik tamg'asi — bitta hujjat
    const out = await PDFLib.create();
    const base = await PDFLib.load(fs.readFileSync(tpl.file_path)); const app = await PDFLib.load(detail);
    for (const pg of await out.copyPages(base, base.getPageIndices())) out.addPage(pg);
    for (const pg of await out.copyPages(app, app.getPageIndices())) out.addPage(pg);
    fs.writeFileSync(file, await out.save());
  } else fs.writeFileSync(file, detail);
  await db.query(`INSERT INTO rental_contracts(booking_id,number,file_path) VALUES($1,$2,$3) ON CONFLICT (booking_id) DO UPDATE SET file_path=EXCLUDED.file_path, generated_at=now()`, [bookingId, number, file]);
  return { number, file };
}
async function getFile(bookingId) {
  let c = (await db.query('SELECT * FROM rental_contracts WHERE booking_id=$1', [bookingId])).rows[0];
  if (!c || !c.file_path || !fs.existsSync(c.file_path)) {
    const st = (await db.query('SELECT status FROM bookings WHERE id=$1', [bookingId])).rows[0];
    if (!st) throw new AppError(404, 'Buyurtma topilmadi');
    if (st.status === 'PENDING' || st.status === 'CANCELLED') throw new AppError(409, 'Shartnoma tasdiqlangan buyurtma uchun yaratiladi');
    const g = await generate(bookingId); c = { number: g.number, file_path: g.file };
  }
  return c;
}
module.exports = { getActive, requireActive, listTemplates, saveTemplate, savePdfTemplate, getConsent, recordConsent, sendConsentRequest, generate, getFile };
