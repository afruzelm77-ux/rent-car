const db = require('../db');
const settings = require('./settings');
const { tg, notify } = require('./notify');
const { audit } = require('../audit');
const { AppError } = require('../util');

const esc = v => String(v ?? '').replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
const sleep = ms => new Promise(r => setTimeout(r, ms));
const clean = t => {
  t = String(t || '').trim();
  if (!t) throw new AppError(400, 'Xabar matnini kiriting');
  if (t.length > 3500) throw new AppError(400, 'Xabar juda uzun (3500 belgigacha)');
  return t;
};
async function frame(text) { return `📩 <b>${esc(await settings.get('company_name'))}</b>\n\n${esc(text)}`; }
const log = (customerId, kind, body, user, status, error) => db.query(
  `INSERT INTO customer_messages(customer_id,direction,kind,body,sent_by,sent_by_name,status,error) VALUES($1,'OUT',$2,$3,$4,$5,$6,$7)`,
  [customerId, kind, body, user?.id || null, user?.full_name || user?.name || null, status, error || null]);

// Bitta mijozga alohida xabar
async function sendToCustomer(customerId, text, user, kind = 'DIRECT', req) {
  text = clean(text);
  const c = (await db.query('SELECT id,first_name,last_name,telegram_id FROM customers WHERE id=$1 AND deleted_at IS NULL', [customerId])).rows[0];
  if (!c) throw new AppError(404, 'Mijoz topilmadi');
  if (!c.telegram_id) throw new AppError(409, "Bu mijoz hali Telegram botga ulanmagan — xabar yuborib bo'lmaydi");
  const r = await tg.send(c.telegram_id, await frame(text));
  if (!r.ok) {
    await log(c.id, kind, text, user, 'FAILED', r.description || r.error || 'noma\'lum xato');
    throw new AppError(502, r.skipped ? 'Bot sozlanmagan (BOT_TOKEN yo\'q)' : `Telegram xabarni yubormadi${r.description ? ': ' + r.description : ''}. Mijoz botni bloklagan bo'lishi mumkin.`);
  }
  await log(c.id, kind, text, user, 'SENT');
  await audit(user, 'MESSAGE', 'customer', c.id, null, { kind, length: text.length }, req);
  return { ok: true, customer: `${c.first_name} ${c.last_name}` };
}

async function recipients() {
  return (await db.query(`SELECT id,telegram_id FROM customers WHERE telegram_id IS NOT NULL AND NOT is_blocked AND deleted_at IS NULL ORDER BY id`)).rows;
}
async function countRecipients() { return (await recipients()).length; }

// Hammaga xabar. Telegram limitiga rioya qilib sekin yuboriladi (~25 xabar/soniya).
async function broadcast(text, user, req) {
  text = clean(text);
  const list = await recipients();
  if (!list.length) throw new AppError(409, "Botga ulangan mijoz yo'q — yuboriladigan odam topilmadi");
  await audit(user, 'BROADCAST', 'customer', null, null, { recipients: list.length, length: text.length }, req);
  const body = await frame(text);
  const run = async () => {
    let sent = 0, failed = 0;
    for (const c of list) {
      const r = await tg.send(c.telegram_id, body);
      if (r.ok) { sent++; await log(c.id, 'BROADCAST', text, user, 'SENT'); }
      else { failed++; await log(c.id, 'BROADCAST', text, user, 'FAILED', r.description || r.error); }
      await sleep(40);
    }
    return { total: list.length, sent, failed };
  };
  if (list.length <= 150) return { ...(await run()), done: true };
  run().then(res => notify({ audience: 'ADMIN', type: 'BROADCAST', title: '📣 Ommaviy xabar yakunlandi', body: `Yuborildi: ${res.sent}, xato: ${res.failed}` }))
    .catch(e => console.error('Broadcast xato:', e.message));
  return { total: list.length, done: false };
}

// Mijozdan kelgan xabar (bot orqali) — jurnalga yoziladi
async function logInbound(customerId, text) {
  await db.query(`INSERT INTO customer_messages(customer_id,direction,kind,body) VALUES($1,'IN','INBOUND',$2)`, [customerId, String(text).slice(0, 3500)]);
}
async function history(customerId, limit = 100) {
  const p = []; let w = '1=1';
  if (customerId) { p.push(customerId); w = 'm.customer_id=$1'; }
  const { rows } = await db.query(`SELECT m.id,m.customer_id,m.direction,m.kind,m.body,m.status,m.error,m.sent_by_name,m.created_at,c.first_name||' '||c.last_name customer
    FROM customer_messages m JOIN customers c ON c.id=m.customer_id WHERE ${w} ORDER BY m.id DESC LIMIT ${Math.min(300, limit)}`, p);
  return rows;
}
// ---- Suhbat (admin panelda ikki tomonlama chat) ----
async function threads() {
  const { rows } = await db.query(`SELECT c.id customer_id,c.first_name||' '||c.last_name name,c.phone,l.body,l.direction,l.created_at,
      (SELECT COUNT(*)::int FROM customer_messages x WHERE x.customer_id=c.id AND x.direction='IN' AND x.read_at IS NULL) unread
    FROM customers c JOIN LATERAL (SELECT body,direction,created_at FROM customer_messages WHERE customer_id=c.id ORDER BY id DESC LIMIT 1) l ON true
    WHERE c.deleted_at IS NULL ORDER BY l.created_at DESC LIMIT 100`);
  return rows;
}
async function unreadTotal() { return (await db.query(`SELECT COUNT(*)::int n FROM customer_messages WHERE direction='IN' AND read_at IS NULL`)).rows[0].n; }
async function thread(customerId) {
  const c = (await db.query('SELECT id,first_name,last_name,phone,telegram_id FROM customers WHERE id=$1 AND deleted_at IS NULL', [customerId])).rows[0];
  if (!c) throw new AppError(404, 'Mijoz topilmadi');
  await db.query(`UPDATE customer_messages SET read_at=now() WHERE customer_id=$1 AND direction='IN' AND read_at IS NULL`, [customerId]);
  const items = (await db.query(`SELECT id,direction,body,status,error,sent_by_name,created_at FROM customer_messages WHERE customer_id=$1 ORDER BY id DESC LIMIT 200`, [customerId])).rows.reverse();
  return { customer: { id: c.id, name: `${c.first_name} ${c.last_name || ''}`.trim(), phone: c.phone, connected: !!c.telegram_id }, items };
}
module.exports = { threads, unreadTotal, thread, sendToCustomer, broadcast, countRecipients, logInbound, history };
