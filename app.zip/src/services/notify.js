const fs = require('fs');
const path = require('path');
const db = require('../db');
const cfg = require('../config');

// Telegram Bot API klienti (test uchun call() almashtirilishi mumkin)
const esc = v => String(v ?? '').replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
const tg = {
  enabled: () => !!cfg.botToken,
  async call(method, body) {
    if (!cfg.botToken) return { ok: false, skipped: true };
    try {
      const r = await fetch(`${cfg.tgApi}/bot${cfg.botToken}/${method}`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
      });
      const j = await r.json();
      if (!j.ok) console.error('Telegram xato:', method, j.description);
      return j;
    } catch (e) { console.error('Telegram tarmoq xatosi:', e.message); return { ok: false, error: e.message }; }
  },
  send(chat_id, text, extra = {}) { return tg.call('sendMessage', { chat_id, text, parse_mode: 'HTML', ...extra }); },
  // Fayl (PDF) yuborish
  async sendDocument(chat_id, filePath, caption = '', extra = {}) {
    if (!cfg.botToken) return { ok: false, skipped: true };
    try {
      const fd = new FormData();
      fd.append('chat_id', String(chat_id)); fd.append('caption', caption); fd.append('parse_mode', 'HTML');
      if (extra.reply_markup) fd.append('reply_markup', JSON.stringify(extra.reply_markup));
      fd.append('document', new Blob([fs.readFileSync(filePath)], { type: 'application/pdf' }), path.basename(filePath));
      const r = await fetch(`${cfg.tgApi}/bot${cfg.botToken}/sendDocument`, { method: 'POST', body: fd });
      const j = await r.json(); if (!j.ok) console.error('Telegram sendDocument xato:', j.description); return j;
    } catch (e) { console.error('Telegram sendDocument tarmoq xatosi:', e.message); return { ok: false, error: e.message }; }
  },
  // Uzun matnni 4000 belgilik bo'laklarga bo'lib yuborish
  async sendLong(chat_id, text, extra = {}) {
    const parts = []; let rest = String(text);
    while (rest.length > 3800) { let cut = rest.lastIndexOf('\n', 3800); if (cut < 1000) cut = 3800; parts.push(rest.slice(0, cut)); rest = rest.slice(cut); }
    parts.push(rest); let last;
    for (let i = 0; i < parts.length; i++) last = await tg.send(chat_id, parts[i], i === parts.length - 1 ? extra : {});
    return last;
  },
};

async function adminChatIds() {
  const { rows } = await db.query(`SELECT telegram_id FROM users WHERE telegram_id IS NOT NULL AND is_active AND deleted_at IS NULL`);
  return [...new Set([...cfg.adminChatIds, ...rows.map(r => String(r.telegram_id))])];
}

// Bildirishnomani bazaga yozadi va (mumkin bo'lsa) Telegramga yuboradi. ref_key takrorni oldini oladi.
async function notify({ audience, customer_id = null, type, title, body = '', ref_key = null, keyboard = null }) {
  let id;
  try {
    const r = await db.query(`INSERT INTO notifications(audience,customer_id,type,title,body,ref_key) VALUES($1,$2,$3,$4,$5,$6)
      ON CONFLICT (ref_key) WHERE ref_key IS NOT NULL DO NOTHING RETURNING id`, [audience, customer_id, type, title, body, ref_key]);
    if (!r.rows[0]) return null; // allaqachon yuborilgan
    id = r.rows[0].id;
  } catch (e) { console.error('notify xato', e.message); return null; }
  const text = `<b>${esc(title)}</b>${body ? '\n' + esc(body) : ''}`;
  const extra = keyboard ? { reply_markup: { inline_keyboard: keyboard } } : {};
  let sent = false;
  if (audience === 'ADMIN') {
    for (const chat of await adminChatIds()) { const r = await tg.send(chat, text, extra); sent = sent || r.ok; }
  } else if (customer_id) {
    const { rows } = await db.query('SELECT telegram_id FROM customers WHERE id=$1', [customer_id]);
    if (rows[0]?.telegram_id) { const r = await tg.send(rows[0].telegram_id, text, extra); sent = r.ok; }
  }
  if (sent) await db.query('UPDATE notifications SET sent_telegram=true WHERE id=$1', [id]);
  return id;
}

// Mijozga PDF yuborish (masalan, tasdiqlangan shartnoma). ref_key takrorni oldini oladi.
async function notifyDocument({ customer_id, filePath, caption, ref_key, type = 'CONTRACT' }) {
  const r = await db.query(`INSERT INTO notifications(audience,customer_id,type,title,body,ref_key) VALUES('CUSTOMER',$1,$2,$3,$4,$5) ON CONFLICT (ref_key) WHERE ref_key IS NOT NULL DO NOTHING RETURNING id`,
    [customer_id, type, 'Hujjat yuborildi', caption, ref_key]);
  if (!r.rows[0]) return false;
  const { rows } = await db.query('SELECT telegram_id FROM customers WHERE id=$1', [customer_id]);
  if (!rows[0]?.telegram_id) return false;
  const res = await tg.sendDocument(rows[0].telegram_id, filePath, esc(caption));
  if (res.ok) await db.query('UPDATE notifications SET sent_telegram=true WHERE id=$1', [r.rows[0].id]);
  return !!res.ok;
}

module.exports = { tg, notify, notifyDocument, adminChatIds, esc };
