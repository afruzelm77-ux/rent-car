// To'lov qabul qiladigan joylar (karta/bank) va mijozlarning "to'ladim" so'rovlari
const db = require('../db');
const features = require('./features');
const bookings = require('./bookings');
const { notify } = require('./notify');
const { audit } = require('../audit');
const { AppError, money } = require('../util');

const digits = s => String(s || '').replace(/\D/g, '');
const fmtCard = n => digits(n).replace(/(\d{4})(?=\d)/g, '$1 ');
const PUB = 'id,kind,title,card_number,holder_name,bank_name,account_number,note,sort_order';

async function listAccounts(onlyActive = false) {
  return (await db.query(`SELECT ${PUB},is_active FROM payment_accounts WHERE deleted_at IS NULL ${onlyActive ? 'AND is_active' : ''} ORDER BY sort_order,id`)).rows;
}
function cleanAccount(d) {
  const kind = d.kind === 'BANK' ? 'BANK' : 'CARD';
  const title = String(d.title || '').trim(); if (!title) throw new AppError(400, "To'lov joyi nomini kiriting (masalan: Humo, Uzcard)");
  const holder = String(d.holder_name || '').trim() || null;
  let card = null, acc = null;
  if (kind === 'CARD') {
    card = digits(d.card_number);
    if (card.length < 16 || card.length > 19) throw new AppError(400, "Karta raqami 16 ta raqamdan iborat bo'lishi kerak");
    // Luhn tekshiruvi — xato kiritilgan raqamni darrov aniqlash
    let sum = 0; [...card].reverse().forEach((ch, i) => { let n = +ch; if (i % 2) { n *= 2; if (n > 9) n -= 9; } sum += n; });
    if (sum % 10 !== 0) throw new AppError(400, "Karta raqami noto'g'ri (tekshiruvdan o'tmadi). Raqamni qayta tekshiring.");
    if (!holder) throw new AppError(400, 'Karta egasining ismini kiriting');
  } else {
    acc = digits(d.account_number); if (acc.length < 10) throw new AppError(400, "Hisob raqamini to'liq kiriting");
  }
  return { kind, title: title.slice(0, 60), card_number: card, holder_name: holder && holder.slice(0, 80), bank_name: d.bank_name ? String(d.bank_name).trim().slice(0, 80) : null,
    account_number: acc, note: d.note ? String(d.note).trim().slice(0, 300) : null, is_active: d.is_active !== false };
}
async function saveAccount(d, id, user, req) {
  const a = cleanAccount(d);
  if (id) {
    const r = await db.query(`UPDATE payment_accounts SET kind=$2,title=$3,card_number=$4,holder_name=$5,bank_name=$6,account_number=$7,note=$8,is_active=$9 WHERE id=$1 AND deleted_at IS NULL RETURNING id`,
      [id, a.kind, a.title, a.card_number, a.holder_name, a.bank_name, a.account_number, a.note, a.is_active]);
    if (!r.rows[0]) throw new AppError(404, "To'lov joyi topilmadi");
    await audit(user, 'UPDATE', 'payment_account', id, null, { title: a.title, active: a.is_active }, req); return { id };
  }
  const r = await db.query(`INSERT INTO payment_accounts(kind,title,card_number,holder_name,bank_name,account_number,note,is_active,sort_order)
    VALUES($1,$2,$3,$4,$5,$6,$7,$8,COALESCE((SELECT MAX(sort_order)+1 FROM payment_accounts),0)) RETURNING id`, [a.kind, a.title, a.card_number, a.holder_name, a.bank_name, a.account_number, a.note, a.is_active]);
  await audit(user, 'CREATE', 'payment_account', r.rows[0].id, null, { title: a.title, kind: a.kind }, req); return r.rows[0];
}
async function deleteAccount(id, user, req) {
  const r = await db.query(`UPDATE payment_accounts SET deleted_at=now(), is_active=false WHERE id=$1 AND deleted_at IS NULL RETURNING title`, [id]);
  if (!r.rows[0]) throw new AppError(404, "To'lov joyi topilmadi");
  await audit(user, 'DELETE', 'payment_account', id, { title: r.rows[0].title }, null, req);
}
const accountText = a => a.kind === 'CARD' ? `${a.title}: ${fmtCard(a.card_number)}\n${a.holder_name}${a.bank_name ? ' · ' + a.bank_name : ''}` : `${a.title}${a.bank_name ? ' (' + a.bank_name + ')' : ''}\nHisob: ${a.account_number}${a.holder_name ? '\n' + a.holder_name : ''}`;

/* ---- Mijoz so'rovi ---- */
async function createClaim(c, d) {
  await features.requireEnabled('pay_claims');
  const amount = Number(d.amount);
  if (!Number.isInteger(amount) || amount <= 0) throw new AppError(400, "To'lov summasini kiriting");
  const kind = d.kind === 'DEPOSIT' ? 'DEPOSIT' : 'RENTAL';
  const b = (await db.query(`SELECT b.*,dep.amount dep_amount,dep.held_amount dep_held FROM bookings b LEFT JOIN deposits dep ON dep.booking_id=b.id WHERE b.id=$1 AND b.customer_id=$2 AND b.deleted_at IS NULL`, [d.booking_id, c.id])).rows[0];
  if (!b) throw new AppError(404, 'Buyurtma topilmadi');
  if (b.status === 'CANCELLED') throw new AppError(409, 'Bekor qilingan buyurtma uchun to\'lov qabul qilinmaydi');
  const acc = d.account_id ? (await db.query('SELECT * FROM payment_accounts WHERE id=$1 AND is_active AND deleted_at IS NULL', [d.account_id])).rows[0] : null;
  if (d.account_id && !acc) throw new AppError(400, "To'lov joyi topilmadi");
  const left = kind === 'DEPOSIT' ? Number(b.dep_amount) - Number(b.dep_held) : Number(b.total_amount) - Number(b.paid_amount);
  if (left <= 0) throw new AppError(409, kind === 'DEPOSIT' ? "Depozit to'liq to'langan" : "Bu buyurtma bo'yicha qarz yo'q");
  if (amount > left) throw new AppError(400, `Summa qolgan qarzdan oshib ketdi (${money(left)})`);
  const pend = (await db.query(`SELECT COUNT(*)::int n FROM payment_claims WHERE booking_id=$1 AND status='PENDING'`, [b.id])).rows[0].n;
  if (pend >= 3) throw new AppError(429, "Tasdiqlanmagan so'rovlar ko'p. Operator javobini kuting");
  if (!d.receipt_file && !d.receipt_tg_file_id) throw new AppError(400, "To'lov chekining rasmini yuboring");
  const r = await db.query(`INSERT INTO payment_claims(booking_id,customer_id,account_id,kind,amount,receipt_file,receipt_tg_file_id,note) VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
    [b.id, c.id, acc?.id || null, kind, amount, d.receipt_file || null, d.receipt_tg_file_id || null, d.note ? String(d.note).slice(0, 300) : null]);
  await notify({ audience: 'ADMIN', type: 'PAY_CLAIM', title: "💳 To'lov so'rovi", ref_key: `claim:${r.rows[0].id}`,
    body: `${b.code} — ${c.first_name} ${c.last_name} (${c.phone || '—'})\nSumma: ${money(amount)} (${kind === 'DEPOSIT' ? 'depozit' : 'ijara'})${acc ? '\nQayerga: ' + acc.title : ''}\nChekni admin panelda tekshiring.`,
    keyboard: [[{ text: '✅ Tasdiqlash', callback_data: `pc:ok:${r.rows[0].id}` }, { text: '❌ Rad etish', callback_data: `pc:no:${r.rows[0].id}` }]] });
  return r.rows[0];
}
async function listClaims(status) {
  const p = []; let w = '1=1'; if (status) { p.push(status); w = 'pc.status=$1'; }
  return (await db.query(`SELECT pc.id,pc.booking_id,pc.kind,pc.amount,pc.status,pc.note,pc.reject_reason,pc.created_at,pc.decided_at,(pc.receipt_file IS NOT NULL OR pc.receipt_tg_file_id IS NOT NULL) has_receipt,
      b.code,c.first_name||' '||c.last_name customer,c.phone,pa.title account,u.full_name decided_by_name
    FROM payment_claims pc JOIN bookings b ON b.id=pc.booking_id JOIN customers c ON c.id=pc.customer_id LEFT JOIN payment_accounts pa ON pa.id=pc.account_id LEFT JOIN users u ON u.id=pc.decided_by
    WHERE ${w} ORDER BY (pc.status='PENDING') DESC, pc.id DESC LIMIT 200`, p)).rows;
}
async function confirmClaim(id, user, req) {
  const cl = (await db.query(`SELECT pc.*,pa.kind acc_kind FROM payment_claims pc LEFT JOIN payment_accounts pa ON pa.id=pc.account_id WHERE pc.id=$1`, [id])).rows[0];
  if (!cl) throw new AppError(404, "So'rov topilmadi");
  if (cl.status !== 'PENDING') throw new AppError(409, "Bu so'rov allaqachon ko'rib chiqilgan");
  const upd = await db.query(`UPDATE payment_claims SET status='CONFIRMED', decided_by=$2, decided_at=now() WHERE id=$1 AND status='PENDING' RETURNING id`, [id, user?.id || null]);
  if (!upd.rows[0]) throw new AppError(409, "So'rov allaqachon ko'rib chiqilgan");
  try {
    const r = await bookings.addPayment({ booking_id: cl.booking_id, amount: Number(cl.amount), kind: cl.kind, method: cl.acc_kind === 'BANK' ? 'BANK_TRANSFER' : 'CARD' }, user, req);
    await db.query('UPDATE payment_claims SET payment_id=$2 WHERE id=$1', [id, r.payment_id]);
    await audit(user, 'CLAIM_CONFIRM', 'payment_claim', id, { status: 'PENDING' }, { status: 'CONFIRMED', amount: Number(cl.amount) }, req);
    return r;
  } catch (e) { await db.query(`UPDATE payment_claims SET status='PENDING', decided_by=NULL, decided_at=NULL WHERE id=$1`, [id]); throw e; }
}
async function rejectClaim(id, reason, user, req) {
  const upd = await db.query(`UPDATE payment_claims SET status='REJECTED', reject_reason=$2, decided_by=$3, decided_at=now() WHERE id=$1 AND status='PENDING' RETURNING customer_id,booking_id,amount`, [id, reason || null, user?.id || null]);
  if (!upd.rows[0]) throw new AppError(409, "So'rov topilmadi yoki allaqachon ko'rib chiqilgan");
  const x = upd.rows[0]; const b = await bookings.getBooking(x.booking_id);
  await audit(user, 'CLAIM_REJECT', 'payment_claim', id, null, { reason }, req);
  await notify({ audience: 'CUSTOMER', customer_id: x.customer_id, type: 'PAY_REJECTED', title: "To'lov tasdiqlanmadi ❌", ref_key: `claimno:${id}`, body: `${b.code}: ${money(x.amount)}${reason ? '\nSabab: ' + reason : ''}\nSavollar bo'lsa operator bilan bog'laning.` });
}
module.exports = { listAccounts, saveAccount, deleteAccount, accountText, createClaim, listClaims, confirmClaim, rejectClaim, fmtCard };
