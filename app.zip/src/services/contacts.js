// Mijozlarga ko'rsatiladigan aloqa raqamlari — admin panelda o'zi qo'shadi/o'chiradi
const db = require('../db');
const { AppError } = require('../util');
const { audit } = require('../audit');

const normPhone = p => { const d = String(p || '').replace(/\D/g, ''); if (!d) return null; return d.length === 9 ? '+998' + d : '+' + d; };
async function list(onlyActive = false) {
  return (await db.query(`SELECT id,label,phone,telegram,hours,note,is_active,sort_order FROM contact_numbers WHERE deleted_at IS NULL ${onlyActive ? 'AND is_active' : ''} ORDER BY sort_order,id`)).rows;
}
function clean(d) {
  const label = String(d.label || '').trim(); if (!label) throw new AppError(400, "Nomini kiriting (masalan: Operator)");
  const phone = d.phone ? normPhone(d.phone) : null;
  if (phone && (phone.length < 10 || phone.length > 16)) throw new AppError(400, "Telefon raqami noto'g'ri");
  let tg = d.telegram ? String(d.telegram).trim().replace(/^https?:\/\/t\.me\//, '').replace(/^@/, '') : null;
  if (tg && !/^[A-Za-z0-9_]{4,32}$/.test(tg)) throw new AppError(400, "Telegram username noto'g'ri (masalan: @operator_bot)");
  if (!phone && !tg) throw new AppError(400, 'Telefon raqami yoki Telegram username kiriting');
  return { label: label.slice(0, 60), phone, telegram: tg ? '@' + tg : null, hours: d.hours ? String(d.hours).trim().slice(0, 60) : null, note: d.note ? String(d.note).trim().slice(0, 200) : null, is_active: d.is_active !== false };
}
async function save(d, id, user, req) {
  const c = clean(d);
  if (id) {
    const r = await db.query(`UPDATE contact_numbers SET label=$2,phone=$3,telegram=$4,hours=$5,note=$6,is_active=$7 WHERE id=$1 AND deleted_at IS NULL RETURNING id`, [id, c.label, c.phone, c.telegram, c.hours, c.note, c.is_active]);
    if (!r.rows[0]) throw new AppError(404, 'Topilmadi'); await audit(user, 'UPDATE', 'contact', id, null, c, req); return { id };
  }
  const r = await db.query(`INSERT INTO contact_numbers(label,phone,telegram,hours,note,is_active,sort_order) VALUES($1,$2,$3,$4,$5,$6,COALESCE((SELECT MAX(sort_order)+1 FROM contact_numbers),0)) RETURNING id`,
    [c.label, c.phone, c.telegram, c.hours, c.note, c.is_active]);
  await audit(user, 'CREATE', 'contact', r.rows[0].id, null, c, req); return r.rows[0];
}
async function remove(id, user, req) {
  const r = await db.query('UPDATE contact_numbers SET deleted_at=now(), is_active=false WHERE id=$1 AND deleted_at IS NULL RETURNING label', [id]);
  if (!r.rows[0]) throw new AppError(404, 'Topilmadi'); await audit(user, 'DELETE', 'contact', id, r.rows[0], null, req);
}
const esc = v => String(v ?? '').replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
// Telegram uchun matn
const asText = rows => rows.map(c => `<b>${esc(c.label)}</b>${c.phone ? '\n📞 ' + esc(c.phone) : ''}${c.telegram ? '\n✈️ ' + esc(c.telegram) : ''}${c.hours ? '\n🕘 ' + esc(c.hours) : ''}${c.note ? '\n' + esc(c.note) : ''}`).join('\n\n');
module.exports = { list, save, remove, asText, normPhone };
