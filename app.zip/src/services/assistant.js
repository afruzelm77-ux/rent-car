// AI yordamchi: savolni tushunadi (mavzu, davr, mashina) va FAQAT bazadagi haqiqiy ma'lumotdan javob beradi.
// Ma'lumot topilmasa — taxmin qilmaydi.
const db = require('../db');
const reports = require('./reports');
const { money, todayStr, addDays, fmtDT, fmtTime, dayRange } = require('../util');

const norm = s => String(s || '').toLowerCase().replace(/[ʻʼ`´‘’]/g, "'").replace(/o'/g, 'o').replace(/g'/g, 'g').replace(/\s+/g, ' ');
const has = (q, ...w) => w.some(x => q.includes(x));

function detectPeriod(q) {
  const t = todayStr();
  if (has(q, 'ertaga')) return { key: 'tomorrow', label: 'ertaga', range: [addDays(t, 1), addDays(t, 2)] };
  if (has(q, 'kecha')) return { key: 'yesterday', label: 'kecha', range: [addDays(t, -1), t] };
  if (has(q, 'oxirgi oy', "o'tgan oy", 'otgan oy')) return { key: 'last_month', label: "o'tgan oy", range: reports.period('last_month') };
  if (has(q, 'oxirgi 30', 'oxirgi oy')) return { key: 'd30', label: 'oxirgi 30 kun', range: [addDays(t, -29), addDays(t, 1)] };
  if (has(q, 'hafta')) return { key: 'week', label: 'oxirgi 7 kun', range: reports.period('week') };
  if (has(q, 'bu oy', 'oy ')) return { key: 'month', label: 'bu oy', range: reports.period('month') };
  if (has(q, 'bugun', 'hozir')) return { key: 'today', label: 'bugun', range: reports.period('today') };
  return null;
}

async function findCar(q) {
  const { rows } = await db.query(`SELECT id,brand,model,plate FROM cars WHERE deleted_at IS NULL`);
  const hit = rows.find(c => q.includes(norm(c.model)) || q.includes(norm(c.plate).replace(/\s/g, '')) || q.includes(norm(`${c.brand} ${c.model}`)));
  return hit || null;
}

const EXAMPLES = ['Bugun qancha foyda qildik?', 'Qaysi mashinalar bo\'sh?', 'Ertaga nechta mashina qaytadi?', 'Bu oy eng ko\'p daromad qilgan mashina qaysi?', 'Malibu oxirgi oy qancha foyda qildi?'];

async function ask(text) {
  const q = norm(text);
  if (!q.trim()) return { answer: 'Savolingizni yozing.', examples: EXAMPLES };
  const p = detectPeriod(q);
  const car = await findCar(q);

  // 1) Bo'sh mashinalar
  if (has(q, "bo'sh", 'bosh', 'available', 'band emas') && has(q, 'mashina', 'avto', 'qaysi') && !has(q, 'foyda', 'daromad')) {
    const { rows } = await db.query(`SELECT brand,model,plate,price_day FROM cars WHERE status='AVAILABLE' AND deleted_at IS NULL ORDER BY brand,model`);
    if (!rows.length) return { answer: "Hozir bo'sh mashina yo'q." };
    return { answer: `Hozir bo'sh mashinalar (${rows.length} ta):\n` + rows.map(r => `• ${r.brand} ${r.model} (${r.plate}) — ${money(r.price_day)}/kun`).join('\n') };
  }
  // 2) Qaytadigan / beriladigan mashinalar
  if (has(q, 'qaytadi', 'qaytish', 'qaytar', 'beriladi', 'beriladigan')) {
    const [fromS, toS] = p ? p.range : [todayStr(), addDays(todayStr(), 1)];
    const [from, to] = [dayRange(fromS)[0], dayRange(toS)[0]];
    const ret = has(q, 'qayt');
    const { rows } = ret
      ? await db.query(`SELECT b.code,b.return_at at,car.brand||' '||car.model car,c.first_name||' '||c.last_name customer FROM bookings b JOIN cars car ON car.id=b.car_id JOIN customers c ON c.id=b.customer_id
         WHERE b.status IN ('ACTIVE','OVERDUE') AND b.return_at>=$1 AND b.return_at<$2 AND b.deleted_at IS NULL ORDER BY b.return_at`, [from, to])
      : await db.query(`SELECT b.code,b.pickup_at at,car.brand||' '||car.model car,c.first_name||' '||c.last_name customer FROM bookings b JOIN cars car ON car.id=b.car_id JOIN customers c ON c.id=b.customer_id
         WHERE b.status IN ('CONFIRMED') AND b.pickup_at>=$1 AND b.pickup_at<$2 AND b.deleted_at IS NULL ORDER BY b.pickup_at`, [from, to]);
    const lbl = p ? p.label : 'bugun';
    if (!rows.length) return { answer: `${lbl[0].toUpperCase() + lbl.slice(1)} ${ret ? 'qaytadigan' : 'beriladigan'} mashina yo'q.` };
    return { answer: `${lbl[0].toUpperCase() + lbl.slice(1)} ${ret ? 'qaytadigan' : 'beriladigan'} mashinalar: ${rows.length} ta\n` + rows.map(r => `• ${fmtTime(r.at)} — ${r.car} (${r.customer})`).join('\n') };
  }
  // 3) Kechikayotganlar
  if (has(q, 'kechik')) {
    const { rows } = await db.query(`SELECT b.code,b.return_at,car.brand||' '||car.model car,c.first_name||' '||c.last_name customer,c.phone FROM bookings b JOIN cars car ON car.id=b.car_id
      JOIN customers c ON c.id=b.customer_id WHERE b.status IN ('ACTIVE','OVERDUE') AND b.return_at<now() AND b.deleted_at IS NULL`);
    if (!rows.length) return { answer: "Hozir kechikayotgan mashina yo'q." };
    return { answer: `Kechikayotgan mashinalar (${rows.length} ta):\n` + rows.map(r => `• ${r.car} — ${r.customer} (${r.phone}), qaytish vaqti: ${fmtDT(r.return_at)}`).join('\n') };
  }
  // 4) Eng ko'p daromad
  if (has(q, "eng ko'p", 'eng kop', 'top', 'eng yaxshi') && has(q, 'daromad', 'foyda')) {
    const [f, t] = p ? p.range : reports.period('month');
    const s = await reports.summary(f, addDays(t, -1));
    const best = [...s.cars].sort((a, b) => (has(q, 'foyda') ? b.profit - a.profit : b.revenue - a.revenue))[0];
    if (!best || (best.revenue === 0 && best.profit === 0)) return { answer: "Bu davr uchun ma'lumot topilmadi." };
    return { answer: `${p ? p.label : 'Bu oy'} eng ko'p ${has(q, 'foyda') ? 'foyda' : 'daromad'} qilgan mashina: ${best.name} (${best.plate})\nDaromad: ${money(best.revenue)}, xarajat: ${money(best.expenses)}, sof foyda: ${money(best.profit)}` };
  }
  // 5) Daromad/xarajat/foyda (umumiy yoki mashina bo'yicha)
  if (has(q, 'foyda', 'daromad', 'xarajat', 'tushum')) {
    const per = p || { label: 'bugun', range: reports.period('today') };
    const [f, t] = per.range;
    const s = await reports.summary(f, addDays(t, -1));
    if (car) {
      const c = s.cars.find(x => x.id === car.id);
      if (!c) return { answer: "Bu mashina bo'yicha ma'lumot topilmadi." };
      return { answer: `${car.brand} ${car.model} — ${per.label}:\nDaromad: ${money(c.revenue)}\nXarajat: ${money(c.expenses)}\nSof foyda: ${money(c.profit)}\nBandlik: ${c.utilization}%` };
    }
    return { answer: `${per.label[0].toUpperCase() + per.label.slice(1)}:\nDaromad: ${money(s.revenue)}\nXarajat: ${money(s.expenses)}\nSof foyda: ${money(s.profit)}\nIjaralar soni: ${s.rentals}` };
  }
  // 6) Mashina holati / kimda
  if (car && has(q, 'kimda', 'qayerda', 'holat', 'status')) {
    const st = await reports.carStats(car.id);
    const c = (await db.query('SELECT status,mileage FROM cars WHERE id=$1', [car.id])).rows[0];
    return { answer: st.current ? `${car.brand} ${car.model} hozir ${st.current.customer} da (${st.current.phone}). Qaytish vaqti: ${fmtDT(st.current.return_at)}.` : `${car.brand} ${car.model} hozir ijarada emas (holat: ${c.status}, ${c.mileage} km).` };
  }
  // 7) Texnik xizmat
  if (has(q, 'moy', 'texnik', 'servis', 'ogohlantir')) {
    const a = (await reports.alerts()).filter(x => x.type === 'MAINTENANCE');
    return { answer: a.length ? 'Texnik xizmat ogohlantirishlari:\n' + a.map(x => `• ${x.title} — ${x.text}`).join('\n') : "Hozir texnik xizmat bo'yicha ogohlantirish yo'q." };
  }
  // 8) Mashinalar soni
  if (has(q, 'nechta mashina', 'jami mashina', 'mashinalar soni')) {
    const d = await reports.dashboard();
    return { answer: `Jami ${d.cars.total} ta mashina: bo'sh ${d.cars.available}, bron ${d.cars.reserved}, ijarada ${d.cars.rented}, ta'mirda ${d.cars.maintenance}, faol emas ${d.cars.inactive}.` };
  }
  return { answer: "Bu savolga bazadan aniq javob topa olmadim. Taxmin qilmayman — quyidagi kabi so'rang:", examples: EXAMPLES };
}

module.exports = { ask, EXAMPLES };
