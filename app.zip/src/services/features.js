// Funksiyalar markazi: modullarni yoqish/o'chirish va admin qo'shadigan maxsus maydonlar
const db = require('../db');
const settings = require('./settings');
const { AppError } = require('../util');

const FEATURES = {
  promo: { name: 'Promo kodlar', desc: "Buyurtmada chegirma kodlari ishlaydi" },
  referral: { name: 'Referral dasturi', desc: "Do'stini taklif qilgan mijozga bonus yoziladi" },
  extras: { name: "Qo'shimcha xizmatlar", desc: "Bolalar o'rindig'i, GPS, haydovchi kabi xizmatlar buyurtmaga qo'shiladi" },
  messages: { name: 'Mijozlarga xabar', desc: "Admin botdan alohida mijozga yoki hammaga xabar yuboradi" },
  ai: { name: 'AI yordamchi', desc: "Admin savol beradi, javob faqat bazadan olinadi" },
  pay_claims: { name: "Mijoz to'lovni botdan yuborishi", desc: "Mijoz karta orqali to'lab, chekni Mini App/botdan yuboradi, admin tasdiqlaydi" },
};
const defaultFlags = () => Object.fromEntries(Object.keys(FEATURES).map(k => [k, true]));
async function flags() {
  let saved = {}; try { saved = JSON.parse(await settings.get('features')) || {}; } catch {}
  return { ...defaultFlags(), ...saved };
}
async function enabled(name) { return !!(await flags())[name]; }
async function requireEnabled(name) { if (!(await enabled(name))) throw new AppError(403, `«${FEATURES[name].name}» funksiyasi o'chirilgan`, 'FEATURE_OFF'); }
async function setFlags(obj) {
  const cur = await flags();
  for (const k of Object.keys(obj || {})) if (k in FEATURES) cur[k] = !!obj[k];
  await settings.set('features', JSON.stringify(cur)); return cur;
}

/* ---- Maxsus maydonlar ---- */
const slug = s => String(s).toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 40);
async function listFields(entity) {
  const p = []; let w = 'deleted_at IS NULL';
  if (entity) { p.push(entity); w += ' AND entity=$1'; }
  return (await db.query(`SELECT id,entity,key,label,type,options,required,sort_order FROM custom_fields WHERE ${w} ORDER BY entity,sort_order,id`, p)).rows;
}
async function saveField(d) {
  const label = String(d.label || '').trim();
  if (!label || label.length > 60) throw new AppError(400, "Maydon nomini kiriting (60 belgigacha)");
  if (!['customer', 'car'].includes(d.entity)) throw new AppError(400, "Maydon turi noto'g'ri");
  if (!['text', 'number', 'date', 'select'].includes(d.type)) throw new AppError(400, "Maydon tipi noto'g'ri");
  const options = d.type === 'select' ? String(d.options || '').split(',').map(x => x.trim()).filter(Boolean).slice(0, 30) : [];
  if (d.type === 'select' && options.length < 2) throw new AppError(400, "Tanlov uchun kamida 2 ta variant kiriting (vergul bilan)");
  const key = slug(label) || 'field';
  try {
    const r = await db.query(`INSERT INTO custom_fields(entity,key,label,type,options,required,sort_order) VALUES($1,$2,$3,$4,$5,$6,COALESCE((SELECT MAX(sort_order)+1 FROM custom_fields WHERE entity=$1),0)) RETURNING *`,
      [d.entity, key, label, d.type, JSON.stringify(options), !!d.required]);
    return r.rows[0];
  } catch (e) { if (e.code === '23505') throw new AppError(409, 'Bunday nomli maydon allaqachon mavjud'); throw e; }
}
async function deleteField(id) {
  const r = await db.query('UPDATE custom_fields SET deleted_at=now(), key=key||\'#del\'||id WHERE id=$1 AND deleted_at IS NULL RETURNING id', [id]);
  if (!r.rows[0]) throw new AppError(404, 'Maydon topilmadi');
}
// Kiritilgan qiymatlarni maydon ta'riflariga ko'ra tekshiradi; faqat ta'riflangan kalitlar saqlanadi
async function cleanCustom(entity, values, existing = {}, { partial = false } = {}) {
  const defs = await listFields(entity); const out = { ...existing };
  for (const d of defs) {
    if (!(d.key in (values || {}))) { if (d.required && !partial && out[d.key] == null) throw new AppError(400, `«${d.label}» maydonini to'ldiring`); continue; }
    let v = values[d.key];
    if (v === '' || v == null) { if (d.required) throw new AppError(400, `«${d.label}» maydonini to'ldiring`); delete out[d.key]; continue; }
    if (d.type === 'number') { v = Number(v); if (!Number.isFinite(v)) throw new AppError(400, `«${d.label}» son bo'lishi kerak`); }
    else if (d.type === 'date') { if (!/^\d{4}-\d{2}-\d{2}$/.test(String(v))) throw new AppError(400, `«${d.label}»: sana noto'g'ri`); }
    else if (d.type === 'select') { if (!d.options.includes(String(v))) throw new AppError(400, `«${d.label}»: variant noto'g'ri`); v = String(v); }
    else v = String(v).slice(0, 300);
    out[d.key] = v;
  }
  return out;
}
module.exports = { FEATURES, flags, enabled, requireEnabled, setFlags, listFields, saveField, deleteField, cleanCustom };
