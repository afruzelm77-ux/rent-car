const crypto = require('crypto');
const db = require('../db');
const settings = require('./settings');
const { notify } = require('./notify');
const { AppError } = require('../util');

const km = (a, b, c, d) => { const R = 6371, t = x => x * Math.PI / 180; const dLat = t(c - a), dLng = t(d - b);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(t(a)) * Math.cos(t(c)) * Math.sin(dLng / 2) ** 2; return 2 * R * Math.asin(Math.sqrt(h)); };

// Joylashuvni yozish + tezlik / hudud ogohlantirishlari (takrorlanmaydi: 10 daqiqada / 1 soatda bir marta)
async function record(carId, { lat, lng, speed }, source = 'DEVICE') {
  lat = Number(lat); lng = Number(lng); speed = speed == null || speed === '' ? null : Math.max(0, Number(speed));
  if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) throw new AppError(400, "Koordinata noto'g'ri");
  if (speed != null && !Number.isFinite(speed)) speed = null;
  const car = (await db.query('SELECT id,brand,model,plate FROM cars WHERE id=$1 AND deleted_at IS NULL', [carId])).rows[0];
  if (!car) throw new AppError(404, 'Mashina topilmadi');
  const bk = (await db.query(`SELECT b.id,c.first_name,c.last_name,c.phone FROM bookings b JOIN customers c ON c.id=b.customer_id WHERE b.car_id=$1 AND b.status IN ('ACTIVE','OVERDUE') AND b.deleted_at IS NULL ORDER BY b.id DESC LIMIT 1`, [carId])).rows[0];
  await db.query('INSERT INTO car_positions(car_id,booking_id,lat,lng,speed_kmh,source) VALUES($1,$2,$3,$4,$5,$6)', [carId, bk?.id || null, lat, lng, speed, source]);
  const who = `${car.brand} ${car.model} (${car.plate})${bk ? '\nMijoz: ' + bk.first_name + ' ' + (bk.last_name || '') + (bk.phone ? ' · ' + bk.phone : '') : ''}`;
  const link = `https://maps.google.com/?q=${lat},${lng}`;
  const limit = await settings.getNum('gps_speed_limit');
  if (limit > 0 && speed != null && speed > limit)
    await notify({ audience: 'ADMIN', type: 'GPS_SPEED', title: '🚨 Tezlik oshdi', body: `${who}\nTezlik: ${Math.round(speed)} km/soat (limit ${limit})\n${link}`, ref_key: `gps-speed:${carId}:${Math.floor(Date.now() / 600000)}` });
  const zone = await settings.getNum('gps_zone_km'), oLat = Number(await settings.get('office_lat')), oLng = Number(await settings.get('office_lng'));
  if (zone > 0 && oLat && oLng) { const d = km(oLat, oLng, lat, lng);
    if (d > zone) await notify({ audience: 'ADMIN', type: 'GPS_ZONE', title: '🚨 Ruxsat etilgan hududdan chiqdi', body: `${who}\nOfisdan ${Math.round(d)} km (limit ${zone} km)\n${link}`, ref_key: `gps-zone:${carId}:${Math.floor(Date.now() / 3600000)}` }); }
  return { ok: true };
}
async function ensureToken(carId) {
  const car = (await db.query('SELECT gps_token FROM cars WHERE id=$1 AND deleted_at IS NULL', [carId])).rows[0];
  if (!car) throw new AppError(404, 'Mashina topilmadi');
  if (car.gps_token) return car.gps_token;
  const t = crypto.randomBytes(18).toString('hex');
  await db.query('UPDATE cars SET gps_token=$2 WHERE id=$1', [carId, t]); return t;
}
async function resetToken(carId) { await db.query('UPDATE cars SET gps_token=NULL WHERE id=$1', [carId]); return ensureToken(carId); }
async function byToken(token) { return (await db.query('SELECT id FROM cars WHERE gps_token=$1 AND deleted_at IS NULL', [String(token || '')])).rows[0]?.id || null; }
async function overview() {
  const { rows } = await db.query(`SELECT c.id,c.brand,c.model,c.plate,c.status,c.image_url,(c.gps_token IS NOT NULL) has_token,
      p.lat,p.lng,p.speed_kmh,p.source,p.created_at seen_at,
      (SELECT cu.first_name||' '||cu.last_name FROM bookings b JOIN customers cu ON cu.id=b.customer_id WHERE b.car_id=c.id AND b.status IN ('ACTIVE','OVERDUE') AND b.deleted_at IS NULL ORDER BY b.id DESC LIMIT 1) customer
    FROM cars c LEFT JOIN LATERAL (SELECT lat,lng,speed_kmh,source,created_at FROM car_positions WHERE car_id=c.id ORDER BY id DESC LIMIT 1) p ON true
    WHERE c.deleted_at IS NULL AND c.status<>'INACTIVE' ORDER BY (p.created_at IS NULL), p.created_at DESC, c.brand`);
  return rows;
}
async function track(carId, hours = 24) {
  const h = Math.min(168, Math.max(1, Number(hours) || 24));
  return (await db.query(`SELECT lat,lng,speed_kmh,source,created_at FROM car_positions WHERE car_id=$1 AND created_at > now() - ($2 || ' hours')::interval ORDER BY id DESC LIMIT 300`, [carId, String(h)])).rows.reverse();
}
module.exports = { record, ensureToken, resetToken, byToken, overview, track };
