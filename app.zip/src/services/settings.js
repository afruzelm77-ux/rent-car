const db = require('../db');
const cfg = require('../config');
const DEFAULTS = {
  late_fee_per_hour: String(cfg.lateFeePerHour || 0),   // 0 = kechikish haqi olinmaydi (admin o'zi belgilaydi)
  late_grace_minutes: '30',
  backup_every_hours: '24',
  backup_keep: '14',
  company_name: cfg.company.name,
  company_phone: cfg.company.phone,
  company_address: cfg.company.address,
  maintenance_warn_km: '500',
  alert_days: '14',
  referral_bonus: '0',
  locations: '[]',
  features: '{}',
  office_lat: '',
  office_lng: '',
  extras_catalog: '[]',
};
async function get(key) {
  const { rows } = await db.query('SELECT value FROM settings WHERE key=$1', [key]);
  return rows[0] ? rows[0].value : DEFAULTS[key];
}
async function getNum(key) { return Number(await get(key)) || 0; }
async function all() {
  const { rows } = await db.query('SELECT key,value FROM settings');
  const out = { ...DEFAULTS }; rows.forEach(r => out[r.key] = r.value); return out;
}
async function set(key, value) {
  if (!(key in DEFAULTS)) throw Object.assign(new Error("Noma'lum sozlama"), { status: 400 });
  await db.query(`INSERT INTO settings(key,value) VALUES($1,$2) ON CONFLICT (key) DO UPDATE SET value=EXCLUDED.value`, [key, String(value)]);
}
module.exports = { get, getNum, all, set, DEFAULTS };
