const db = require('../db');
const settings = require('./settings');
const { todayStr, addDays, parseTkt, dayRange, fmtDT, fmtDate, fmtTime, AppError } = require('../util');

const REV = `CASE WHEN p.kind IN ('RENTAL','EXTRA','DEPOSIT_DEDUCTION') THEN p.amount WHEN p.kind='RENTAL_REFUND' THEN -p.amount ELSE 0 END`;
const TZ = `'Asia/Tashkent'`;
const n = v => Number(v || 0);

function period(name, from, to) {
  const t = todayStr();
  switch (name) {
    case 'today': return [t, addDays(t, 1)];
    case 'yesterday': return [addDays(t, -1), t];
    case 'week': return [addDays(t, -6), addDays(t, 1)];
    case 'month': return [t.slice(0, 8) + '01', addDays(t, 1)];
    case 'last_month': { const d = new Date(t.slice(0, 8) + '01T00:00:00Z'); d.setUTCMonth(d.getUTCMonth() - 1); return [d.toISOString().slice(0, 10), t.slice(0, 8) + '01']; }
    case 'tomorrow': return [addDays(t, 1), addDays(t, 2)];
    default:
      if (!from || !to) throw new AppError(400, 'Sana oralig\'ini kiriting');
      parseTkt(from); parseTkt(to);
      if (to < from) throw new AppError(400, "Tugash sanasi boshlanishidan oldin bo'lishi mumkin emas");
      return [from, addDays(to, 1)];
  }
}

async function summary(fromStr, toStr) {
  // toStr — oraliqning OXIRGI kuni (kiritilgan); ichkarida [from, to) yarim ochiq oraliqqa o'tkaziladi
  const from = dayRange(fromStr)[0], to = dayRange(toStr)[1], toExcl = addDays(toStr, 1);
  const q = (t, p) => db.query(t, p).then(r => r.rows);
  const [rev] = await q(`SELECT COALESCE(SUM(${REV}),0) v FROM payments p WHERE p.status='PAID' AND p.paid_at>=$1 AND p.paid_at<$2`, [from, to]);
  const [exp] = await q(`SELECT COALESCE(SUM(amount),0) v FROM expenses WHERE deleted_at IS NULL AND spent_on>=$1 AND spent_on<$2`, [fromStr, toExcl]);
  const [cnt] = await q(`SELECT COUNT(*)::int v FROM bookings WHERE deleted_at IS NULL AND status IN ('ACTIVE','COMPLETED','OVERDUE') AND COALESCE(actual_pickup_at,pickup_at)>=$1 AND COALESCE(actual_pickup_at,pickup_at)<$2`, [from, to]);
  const util = await q(`SELECT c.id,c.brand,c.model,c.plate,
      COALESCE((SELECT SUM(GREATEST(0, EXTRACT(EPOCH FROM (LEAST(CASE WHEN b.status IN ('ACTIVE','OVERDUE') THEN now() ELSE COALESCE(b.actual_return_at,b.return_at) END, LEAST($2::timestamptz, now())) - GREATEST(COALESCE(b.actual_pickup_at,b.pickup_at), $1::timestamptz))))) / 86400.0
        FROM bookings b WHERE b.car_id=c.id AND b.deleted_at IS NULL AND b.status IN ('ACTIVE','COMPLETED','OVERDUE')),0) days,
      COALESCE((SELECT SUM(${REV}) FROM payments p JOIN bookings b ON b.id=p.booking_id WHERE b.car_id=c.id AND p.status='PAID' AND p.paid_at>=$1 AND p.paid_at<$2),0) revenue,
      COALESCE((SELECT SUM(e.amount) FROM expenses e WHERE e.car_id=c.id AND e.deleted_at IS NULL AND e.spent_on>=$3 AND e.spent_on<$4),0) expenses
    FROM cars c WHERE c.deleted_at IS NULL AND c.status<>'INACTIVE' ORDER BY revenue DESC`, [from, to, fromStr, toExcl]);
  const spanDays = Math.max(0.0001, (Math.min(to.getTime(), Date.now()) - from.getTime()) / 864e5);
  const cars = util.map(c => ({ id: c.id, name: `${c.brand} ${c.model}`, plate: c.plate, revenue: n(c.revenue), expenses: n(c.expenses), profit: n(c.revenue) - n(c.expenses),
    utilization: Math.min(100, Math.round(n(c.days) / spanDays * 100)) }));
  const utilAvg = cars.length ? Math.round(cars.reduce((s, c) => s + c.utilization, 0) / cars.length) : 0;
  const cats = await q(`SELECT ec.name, COALESCE(SUM(e.amount),0)::bigint v FROM expenses e JOIN expense_categories ec ON ec.id=e.category_id
    WHERE e.deleted_at IS NULL AND e.spent_on>=$1 AND e.spent_on<$2 GROUP BY ec.name ORDER BY v DESC`, [fromStr, toExcl]);
  const daily = await q(`SELECT to_char(d,'YYYY-MM-DD') AS day, COALESCE(r.rev,0)::bigint revenue, COALESCE(e.exp,0)::bigint expenses
    FROM generate_series($1::timestamp,$2::timestamp - interval '1 day','1 day') d
    LEFT JOIN (SELECT (p.paid_at AT TIME ZONE ${TZ})::date AS day, SUM(${REV}) rev FROM payments p WHERE p.status='PAID' AND p.paid_at>=$3 AND p.paid_at<$4 GROUP BY 1) r ON r.day=d::date
    LEFT JOIN (SELECT spent_on AS day, SUM(amount) exp FROM expenses WHERE deleted_at IS NULL AND spent_on>=$1::date AND spent_on<$2::date GROUP BY 1) e ON e.day=d::date ORDER BY d`, [fromStr, toExcl, from, to]);
  return { from: fromStr, to: toStr, revenue: n(rev.v), expenses: n(exp.v), profit: n(rev.v) - n(exp.v), rentals: cnt.v, utilization: utilAvg,
    top_cars: cars.slice(0, 5), cars, expense_categories: cats.map(c => ({ name: c.name, amount: n(c.v) })),
    daily: daily.map(d => ({ day: d.day, revenue: n(d.revenue), expenses: n(d.expenses), profit: n(d.revenue) - n(d.expenses) })) };
}

async function alerts() {
  const warnKm = await settings.getNum('maintenance_warn_km');
  const days = await settings.getNum('alert_days');
  const out = [];
  const m = await db.query(`SELECT DISTINCT ON (m.car_id, m.kind) m.car_id, m.kind, m.next_due_km, m.next_due_date, c.brand, c.model, c.plate, c.mileage
    FROM maintenance m JOIN cars c ON c.id=m.car_id WHERE c.deleted_at IS NULL AND c.status<>'INACTIVE' AND (m.next_due_km IS NOT NULL OR m.next_due_date IS NOT NULL)
    ORDER BY m.car_id, m.kind, m.done_at DESC, m.id DESC`);
  const KIND = { OIL: 'Moy almashtirish', FILTER: 'Filtr', BRAKE_PADS: 'Kolodka', TIRES: 'Shina', BATTERY: 'Akkumulyator', REPAIR: 'Remont', INSPECTION: "Texnik ko'rik", INSURANCE: "Sug'urta" };
  for (const r of m.rows) {
    const name = `${r.brand} ${r.model}`;
    if (r.next_due_km != null) {
      const left = r.next_due_km - r.mileage;
      if (left <= warnKm) out.push({ level: left <= 0 ? 'danger' : 'warn', type: 'MAINTENANCE', car_id: r.car_id, title: `${name}: ${KIND[r.kind]}`,
        text: left <= 0 ? `${-left} km ga o'tib ketgan` : `Hozir: ${r.mileage} km, qolgan: ${left} km` });
    }
    if (r.next_due_date) {
      const left = Math.round((new Date(r.next_due_date) - Date.now()) / 864e5);
      if (left <= days) out.push({ level: left < 0 ? 'danger' : 'warn', type: 'MAINTENANCE', car_id: r.car_id, title: `${name}: ${KIND[r.kind]}`, text: left < 0 ? `${-left} kun o'tib ketgan` : `${left} kun qoldi` });
    }
  }
  const ins = await db.query(`SELECT id,brand,model,insurance_until,inspection_until FROM cars WHERE deleted_at IS NULL AND status<>'INACTIVE'
    AND (insurance_until <= CURRENT_DATE + $1::int OR inspection_until <= CURRENT_DATE + $1::int)`, [days]);
  for (const c of ins.rows) {
    for (const [f, label] of [['insurance_until', "Sug'urta"], ['inspection_until', "Texnik ko'rik"]]) {
      if (!c[f]) continue; const left = Math.round((new Date(c[f]) - Date.now()) / 864e5);
      if (left <= days) out.push({ level: left < 0 ? 'danger' : 'warn', type: 'EXPIRY', car_id: c.id, title: `${c.brand} ${c.model}: ${label} muddati`, text: left < 0 ? `${-left} kun oldin tugagan` : `${left} kun qoldi (${fmtDate(c[f])})` });
    }
  }
  const docs = await db.query(`SELECT d.doc_type,d.expires_at,c.first_name,c.last_name FROM customer_documents d JOIN customers c ON c.id=d.customer_id
    WHERE d.deleted_at IS NULL AND d.expires_at <= CURRENT_DATE + $1::int AND EXISTS (SELECT 1 FROM bookings b WHERE b.customer_id=c.id AND b.status IN ('CONFIRMED','ACTIVE','PENDING'))`, [days]);
  for (const d of docs.rows) out.push({ level: 'warn', type: 'DOC', title: `${d.first_name} ${d.last_name}: hujjat muddati`, text: `${d.doc_type} — ${fmtDate(d.expires_at)}` });
  return out.sort((a, b) => (a.level === 'danger' ? 0 : 1) - (b.level === 'danger' ? 0 : 1));
}

async function dashboard() {
  const t = todayStr();
  const [from, to] = dayRange(t);
  const q = (s, p) => db.query(s, p).then(r => r.rows);
  const st = await q(`SELECT status, COUNT(*)::int c FROM cars WHERE deleted_at IS NULL GROUP BY status`);
  const by = Object.fromEntries(st.map(r => [r.status, r.c]));
  const total = st.reduce((s, r) => s + r.c, 0);
  const today = await summary(t, t);
  const month = await summary(t.slice(0, 8) + '01', t);
  const d30 = await summary(addDays(t, -29), t);
  const sched = await q(`SELECT * FROM (
      SELECT 'PICKUP' kind, b.pickup_at at, b.id, b.code, car.brand||' '||car.model car, c.first_name||' '||c.last_name customer, (b.total_amount-b.paid_amount) remaining, b.status
        FROM bookings b JOIN cars car ON car.id=b.car_id JOIN customers c ON c.id=b.customer_id WHERE b.deleted_at IS NULL AND b.status IN ('CONFIRMED','PENDING') AND b.pickup_at>=$1 AND b.pickup_at<$2
      UNION ALL
      SELECT 'RETURN', b.return_at, b.id, b.code, car.brand||' '||car.model, c.first_name||' '||c.last_name, (b.total_amount-b.paid_amount), b.status
        FROM bookings b JOIN cars car ON car.id=b.car_id JOIN customers c ON c.id=b.customer_id WHERE b.deleted_at IS NULL AND b.status IN ('ACTIVE','OVERDUE') AND b.return_at>=$1 AND b.return_at<$2) x ORDER BY at`, [from, to]);
  const overdue = await q(`SELECT b.id,b.code,b.return_at,car.brand||' '||car.model car,car.plate,c.first_name||' '||c.last_name customer,c.phone
    FROM bookings b JOIN cars car ON car.id=b.car_id JOIN customers c ON c.id=b.customer_id WHERE b.deleted_at IS NULL AND b.status IN ('ACTIVE','OVERDUE') AND b.return_at<now() ORDER BY b.return_at`);
  const [exp] = await q(`SELECT COALESCE(SUM(b.total_amount-b.paid_amount),0)::bigint v FROM bookings b WHERE b.deleted_at IS NULL AND
    ((b.status IN ('CONFIRMED','PENDING') AND b.pickup_at>=$1 AND b.pickup_at<$2) OR (b.status IN ('ACTIVE','OVERDUE') AND b.return_at>=$1 AND b.return_at<$2))`, [from, to]);
  const [dep] = await q(`SELECT COALESCE(SUM(d.held_amount),0)::bigint v FROM deposits d JOIN bookings b ON b.id=d.booking_id WHERE b.status IN ('ACTIVE','OVERDUE') AND b.return_at>=$1 AND b.return_at<$2`, [from, to]);
  const monthly = await q(`SELECT to_char(m,'YYYY-MM') AS month,
      COALESCE((SELECT SUM(${REV}) FROM payments p WHERE p.status='PAID' AND date_trunc('month', p.paid_at AT TIME ZONE ${TZ})=m),0)::bigint revenue,
      COALESCE((SELECT SUM(amount) FROM expenses e WHERE e.deleted_at IS NULL AND date_trunc('month', e.spent_on)=m),0)::bigint expenses
    FROM generate_series(date_trunc('month', now() AT TIME ZONE ${TZ}) - interval '5 months', date_trunc('month', now() AT TIME ZONE ${TZ}), '1 month') m ORDER BY m`);
  const pending = (await q(`SELECT COUNT(*)::int c FROM bookings WHERE status='PENDING' AND deleted_at IS NULL`))[0].c;
  return {
    cars: { total, available: by.AVAILABLE || 0, reserved: by.RESERVED || 0, rented: by.RENTED || 0, maintenance: by.MAINTENANCE || 0, inactive: by.INACTIVE || 0 },
    today: { revenue: today.revenue, expenses: today.expenses, profit: today.profit, returns: sched.filter(s => s.kind === 'RETURN').length, pickups: sched.filter(s => s.kind === 'PICKUP').length,
      expected_income: n(exp.v), deposits_to_return: n(dep.v) },
    pending_bookings: pending,
    schedule: sched.map(s => ({ ...s, time: fmtTime(s.at), remaining: n(s.remaining) })),
    overdue: overdue.map(o => ({ ...o, return_label: fmtDT(o.return_at) })),
    month: { revenue: month.revenue, expenses: month.expenses, profit: month.profit },
    charts: { daily: d30.daily, monthly: monthly.map(m => ({ month: m.month, revenue: n(m.revenue), expenses: n(m.expenses), profit: n(m.revenue) - n(m.expenses) })),
      revenue_per_car: d30.cars.map(c => ({ name: c.name, value: c.revenue })).filter(c => c.value > 0).slice(0, 8),
      expense_categories: d30.expense_categories, utilization: d30.cars.map(c => ({ name: c.name, value: c.utilization })).sort((a, b) => b.value - a.value), utilization_avg: d30.utilization },
    alerts: await alerts(),
  };
}

async function carStats(carId) {
  const q = (s, p) => db.query(s, p).then(r => r.rows);
  const cur = (await q(`SELECT b.id,b.code,b.status,b.pickup_at,b.return_at,b.actual_pickup_at,c.first_name||' '||c.last_name customer,c.phone,c.id customer_id
    FROM bookings b JOIN customers c ON c.id=b.customer_id WHERE b.car_id=$1 AND b.status IN ('ACTIVE','OVERDUE') AND b.deleted_at IS NULL ORDER BY b.pickup_at LIMIT 1`, [carId]))[0] || null;
  const next = (await q(`SELECT b.id,b.code,b.pickup_at,b.return_at,c.first_name||' '||c.last_name customer FROM bookings b JOIN customers c ON c.id=b.customer_id
    WHERE b.car_id=$1 AND b.status IN ('PENDING','CONFIRMED') AND b.return_at>now() AND b.deleted_at IS NULL ORDER BY b.pickup_at LIMIT 1`, [carId]))[0] || null;
  const [tot] = await q(`SELECT COALESCE(SUM(${REV}),0)::bigint revenue FROM payments p JOIN bookings b ON b.id=p.booking_id WHERE b.car_id=$1 AND p.status='PAID'`, [carId]);
  const [ex] = await q(`SELECT COALESCE(SUM(amount),0)::bigint v FROM expenses WHERE car_id=$1 AND deleted_at IS NULL`, [carId]);
  const [days] = await q(`SELECT COALESCE(SUM(CASE WHEN status='COMPLETED' THEN GREATEST(1, CEIL(EXTRACT(EPOCH FROM (COALESCE(actual_return_at,return_at)-COALESCE(actual_pickup_at,pickup_at)))/86400)) ELSE 0 END),0)::int d,
      COUNT(*) FILTER (WHERE status='COMPLETED')::int rentals FROM bookings WHERE car_id=$1 AND deleted_at IS NULL`, [carId]);
  const t = todayStr();
  const s30 = await summary(addDays(t, -29), t);
  const me = s30.cars.find(c => c.id === Number(carId));
  const calFrom = parseTkt(t.slice(0, 8) + '01');
  const bookings = await q(`SELECT b.id,b.code,b.status,b.pickup_at,b.return_at,c.first_name||' '||c.last_name customer FROM bookings b JOIN customers c ON c.id=b.customer_id
    WHERE b.car_id=$1 AND b.deleted_at IS NULL AND b.status IN ('PENDING','CONFIRMED','ACTIVE','OVERDUE','COMPLETED') AND b.return_at>=$2::timestamptz - interval '1 day' ORDER BY b.pickup_at`, [carId, calFrom]);
  const maint = await q(`SELECT * FROM maintenance WHERE car_id=$1 ORDER BY done_at DESC,id DESC LIMIT 30`, [carId]);
  const revenue = n(tot.revenue), expenses = n(ex.v);
  return { current: cur && { ...cur, days_out: Math.max(1, Math.ceil((Date.now() - new Date(cur.actual_pickup_at || cur.pickup_at)) / 864e5)) }, next,
    days_rented: days.d, rentals: days.rentals, revenue, expenses, profit: revenue - expenses, utilization: me ? me.utilization : 0, bookings, maintenance: maint };
}

function csv(rows, cols) {
  const esc = v => { const s = v == null ? '' : String(v); return /[",\n;]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
  return '\ufeff' + [cols.map(c => esc(c.label)).join(';'), ...rows.map(r => cols.map(c => esc(r[c.key])).join(';'))].join('\r\n');
}

module.exports = { REV, period, summary, dashboard, alerts, carStats, csv };
