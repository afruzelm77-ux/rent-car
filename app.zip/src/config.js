try { require('dotenv').config(); } catch {}
const crypto = require('crypto');
const env = process.env;
const cfg = {
  port: +env.PORT || 3000,
  databaseUrl: env.DATABASE_URL || 'postgres://rac:rac@localhost:5432/rentacar',
  jwtSecret: env.JWT_SECRET || 'dev-secret-change',
  encKey: crypto.createHash('sha256').update(env.DATA_ENC_KEY || 'dev-key').digest(),
  botToken: env.BOT_TOKEN || '',
  tgApi: (env.TELEGRAM_API || 'https://api.telegram.org').replace(/\/$/, ''),
  webhookUrl: env.WEBHOOK_URL || '',
  // PUBLIC_URL bo'sh bo'lsa Railway bergan domen avtomatik olinadi
  publicUrl: (env.PUBLIC_URL || env.WEBHOOK_URL || (env.RAILWAY_PUBLIC_DOMAIN ? 'https://' + env.RAILWAY_PUBLIC_DOMAIN : '')).replace(/\/$/, ''),
  adminChatIds: (env.ADMIN_CHAT_IDS || '').split(',').map(s => s.trim()).filter(Boolean),
  company: { name: env.COMPANY_NAME || 'LIDER RENT A CAR', phone: env.COMPANY_PHONE || '', address: env.COMPANY_ADDRESS || '' },
  lateFeePerHour: +env.LATE_FEE_PER_HOUR || 0,
  tz: 'Asia/Tashkent',
  seedDemo: env.SEED_DEMO === 'true',   // demo ma'lumot faqat ochiq so'ralganda (real mahsulotda soxta ma'lumot yo'q)
  isProd: env.NODE_ENV === 'production',
};
if (cfg.isProd) {
  const weak = [];
  if (!env.JWT_SECRET || env.JWT_SECRET.length < 24) weak.push('JWT_SECRET (kamida 24 belgi)');
  if (!env.DATA_ENC_KEY || env.DATA_ENC_KEY.length < 24) weak.push('DATA_ENC_KEY (kamida 24 belgi)');
  if (weak.length) { console.error('Production uchun majburiy sozlamalar yetishmaydi: ' + weak.join(', ')); process.exit(1); }
}
module.exports = cfg;
