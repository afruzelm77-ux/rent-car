const crypto = require('crypto');
const cfg = require('../config');
const db = require('../db');
const { tg, esc } = require('../services/notify');
const bookings = require('../services/bookings');
const reports = require('../services/reports');
const settings = require('../services/settings');
const assistant = require('../services/assistant');
const contracts = require('../services/contract');
const messages = require('../services/messages');
const gps = require('../services/gps');
const payacc = require('../services/payacc');
const features = require('../services/features');
const contactsSvc = require('../services/contacts');
const { ensureCustomer } = require('../routes/mini');
const { money, fmtDate, fmtDT, parseTkt, todayStr, addDays, AppError } = require('../util');
const { ROLES } = require('../permissions');

const baseUrl = () => cfg.publicUrl;
const webhookSecret = () => crypto.createHash('sha256').update('wh' + (cfg.botToken || 'x')).digest('hex').slice(0, 32);

const miniBtn = (text, q = '') => (baseUrl().startsWith('https://') ? { text, web_app: { url: `${baseUrl()}/app/${q}` } } : null);
// Asosiy menyu — faqat INLINE tugmalar (xabar tagida). Doimiy pastki klaviatura ishlatilmaydi.
// style: 'primary' (ko'k) | 'success' (yashil) | 'danger' (qizil) — Telegram Bot API 9.4+ da rangli inline tugmalar
const B = (text, data, style) => ({ text, callback_data: data, ...(style ? { style } : {}) });
const homeRow = [B('🏠 Bosh sahifa', 'm:home')];
const menuKb = () => {
  const kb = []; const mb = miniBtn('📱 ILOVANI OCHISH'); if (mb) kb.push([{ ...mb, style: 'primary' }]);
  kb.push([B('🚗 MASHINALAR', 'm:cars', 'primary')], [B('📅 BRON QILISH', 'm:book', 'success')], [B('📋 BUYURTMALARIM', 'm:orders', 'primary')], [B("💳 TO'LOV", 'm:pay', 'success')],
    [B('💰 TARIFLAR', 'm:tariff'), B('📍 MANZIL', 'm:addr')], [B('☎️ OPERATOR', 'm:op', 'danger')]);
  return { inline_keyboard: kb };
};
const HOME_KB = { inline_keyboard: [homeRow] };
const UNAVAILABLE = 'Bu xizmat hozircha mavjud emas.';
const unavailKb = () => ({ inline_keyboard: [[{ text: '☎️ Operator', callback_data: 'm:op' }], homeRow] });
const LINE = '━━━━━━━━━━━━━━━━';
const MON = ['Yan', 'Fev', 'Mar', 'Apr', 'May', 'Iyn', 'Iyl', 'Avg', 'Sen', 'Okt', 'Noy', 'Dek'];
const dShort = d => { const x = String(d).slice(0, 10).split('-'); return `${+x[2]} ${MON[+x[1] - 1]}`; };
const fmtShort = d => dShort(new Date(new Date(d).getTime() + 5 * 3600e3).toISOString());
// Xabarni tahrirlash (callbackdan kelganda) yoki yangi yuborish — xabar to'planib ketmasligi uchun
async function show(chat, cb, text, kb = HOME_KB) {
  const extra = { reply_markup: kb, disable_web_page_preview: true };
  const m = cb && cb.message;
  if (m && m.message_id && !m.photo && !m.document) {
    const r = await tg.call('editMessageText', { chat_id: chat, message_id: m.message_id, text, parse_mode: 'HTML', ...extra });
    if (r.ok || r.skipped || /not modified/i.test(r.description || '')) return r;
  } else if (m && m.message_id) await tg.call('deleteMessage', { chat_id: chat, message_id: m.message_id });
  return tg.send(chat, text, extra);
}
// Texnik/sozlama xatolari mijozga ko'rsatilmaydi
const showErr = (chat, cb, e) => (e && (e.code === 'NO_CONTRACT' || !(e instanceof AppError)) ? show(chat, cb, `🛠 <b>${UNAVAILABLE}</b>`, unavailKb()) : show(chat, cb, '⚠️ ' + esc(e.message), { inline_keyboard: [homeRow] }));
const STATUS = { AVAILABLE: "🟢 Bo'sh", RESERVED: '🟡 Bron qilingan', RENTED: '🔴 Ijarada', MAINTENANCE: "🔧 Ta'mirda", INACTIVE: '⚫ Faol emas' };
const TR = { AUTOMATIC: 'Avtomat', MANUAL: 'Mexanika' }, FUEL = { PETROL: 'Benzin', GAS: 'Gaz', DIESEL: 'Dizel', HYBRID: 'Gibrid', ELECTRIC: 'Elektr' };
const BST = { PENDING: '⏳ Kutilmoqda', CONFIRMED: '✅ Tasdiqlangan', ACTIVE: '🚗 Ijarada', COMPLETED: '🏁 Yakunlangan', CANCELLED: '❌ Bekor', OVERDUE: '⚠️ Kechikkan' };

/* ---------- Suhbat holati: bazada (server qayta ishga tushsa ham yo'qolmaydi) ---------- */
async function getState(chat) {
  const r = await db.query('SELECT state FROM bot_state WHERE chat_id=$1', [chat]); const s = r.rows[0]?.state;
  if (!s) return null;
  if (Date.now() - (s.ts || 0) > 30 * 60e3) { await clearState(chat); return null; }
  return s;
}
async function setState(chat, s) { s.ts = Date.now(); await db.query(`INSERT INTO bot_state(chat_id,state) VALUES($1,$2) ON CONFLICT (chat_id) DO UPDATE SET state=$2`, [chat, JSON.stringify(s)]); }
const clearState = chat => db.query('DELETE FROM bot_state WHERE chat_id=$1', [chat]);
// Holatni atomik "olib qo'yish": bir vaqtda ikki marta bosilgan tugma ikkita buyurtma yaratmasligi uchun
async function takeState(chat) {
  const r = await db.query('DELETE FROM bot_state WHERE chat_id=$1 RETURNING state', [chat]); const s = r.rows[0]?.state;
  return s && Date.now() - (s.ts || 0) <= 30 * 60e3 ? s : null;
}
const EXPIRED = "⏱ Sessiya tugagan. «📅 BRON QILISH» tugmasidan qaytadan boshlang.";
const validDate = d => { if (!d) return false; const x = new Date(d + 'T00:00:00Z'); return !isNaN(x) && x.toISOString().slice(0, 10) === d; };

async function resolveStaff(tgId) {
  if (cfg.adminChatIds.includes(String(tgId))) return { id: null, full_name: 'Admin (Telegram)', role: 'OWNER', permissions: ROLES.OWNER.permissions };
  const { rows } = await db.query(`SELECT u.id,u.full_name,r.code role,r.permissions FROM users u JOIN roles r ON r.id=u.role_id WHERE u.telegram_id=$1 AND u.is_active AND u.deleted_at IS NULL`, [tgId]);
  return rows[0] || null;
}
const can = (s, p) => !!s && s.permissions.includes(p);
const actor = s => (s.id ? s : { full_name: s.full_name });

const carText = c => `<b>${esc(c.brand)} ${esc(c.model)}</b>${c.year ? ' · ' + c.year : ''}${c.body_type ? '\n<i>' + esc(c.body_type) + '</i>' : ''}\n\n⚙ ${TR[c.transmission]}  ·  👤 ${c.seats} o'rin  ·  ⛽ ${FUEL[c.fuel_type]}\n\n💰 <b>${money(c.price_day)}</b> / kun\n${STATUS[c.status]}`;
const photoUrl = u => (u && /^https?:/.test(u) ? u : (u && baseUrl() ? baseUrl() + u : null));

// Mashinalar — bitta xabar, ◀ ▶ bilan almashtiriladi (xabar to'planib ketmaydi)
async function sendCars(chat, cb, idx = 0) {
  const { rows } = await db.query(`SELECT * FROM cars WHERE deleted_at IS NULL AND status<>'INACTIVE' ORDER BY (status='AVAILABLE') DESC,brand,model`);
  if (!rows.length) return show(chat, cb, "🚗 <b>Hozircha mavjud avtomobillar yo'q.</b>\n\nTez orada yangi avtomobillar qo'shiladi.", { inline_keyboard: [[{ text: '🔄 Qayta tekshirish', callback_data: 'm:cars' }], homeRow] });
  const n = rows.length; idx = Math.max(0, Math.min(+idx || 0, n - 1)); const c = rows[idx]; const mb = miniBtn('📱 Batafsil', `?car=${c.id}`);
  const kb = [...(n > 1 ? [[{ text: '◀', callback_data: `cv:${(idx - 1 + n) % n}` }, { text: `${idx + 1} / ${n}`, callback_data: 'noop' }, { text: '▶', callback_data: `cv:${(idx + 1) % n}` }]] : []),
    ...(c.status === 'AVAILABLE' ? [[B('📅 BRON QILISH', `car:${c.id}`, 'success')]] : []), ...(mb ? [[mb]] : []), homeRow];
  const url = photoUrl(c.image_url);
  if (!url) return show(chat, cb, carText(c), { inline_keyboard: kb });
  if (cb && cb.message && cb.message.message_id) await tg.call('deleteMessage', { chat_id: chat, message_id: cb.message.message_id });
  const r = await tg.call('sendPhoto', { chat_id: chat, photo: url, caption: carText(c), parse_mode: 'HTML', reply_markup: { inline_keyboard: kb } });
  if (r.ok || r.skipped) return r;
  return tg.send(chat, carText(c), { reply_markup: { inline_keyboard: kb } });   // rasm yuklanmasa — matn bilan
}
async function sendTariffs(chat, cb) {
  const { rows } = await db.query(`SELECT brand,model,price_day,price_3d,price_7d,deposit FROM cars WHERE deleted_at IS NULL AND status<>'INACTIVE' ORDER BY brand,model`);
  if (!rows.length) return show(chat, cb, "💰 Tariflar hozircha kiritilmagan.");
  const fee = await settings.getNum('late_fee_per_hour');
  return show(chat, cb, `💰 <b>TARIFLAR</b> (kunlik)\n${LINE}\n\n` + rows.map(c => `🚗 <b>${esc(c.brand)} ${esc(c.model)}</b>\n1+ kun: ${money(c.price_day)}\n3+ kun: ${money(c.price_3d)}\n7+ kun: ${money(c.price_7d)}\nDepozit: ${money(c.deposit)}`).join('\n\n') + (fee ? `\n\n⏱ Kechikish: ${money(fee)} / soat` : ''),
    { inline_keyboard: [[B('📅 BRON QILISH', 'm:book', 'success')], homeRow] });
}
async function sendMyBookings(chat, customer, cb) {
  const { rows } = await db.query(`SELECT b.*,car.brand,car.model FROM bookings b JOIN cars car ON car.id=b.car_id WHERE b.customer_id=$1 AND b.deleted_at IS NULL ORDER BY b.id DESC LIMIT 8`, [customer.id]);
  if (!rows.length) return show(chat, cb, "📋 <b>Sizda hozircha buyurtmalar yo'q.</b>", { inline_keyboard: [[{ text: "🚗 Mashinalarni ko'rish", callback_data: 'm:cars' }], homeRow] });
  return show(chat, cb, `📋 <b>MENING BUYURTMALARIM</b>\n${LINE}\n\n` + rows.map(b => `🆔 <b>#${esc(b.code)}</b>  ${BST[b.status]}\n🚗 ${esc(b.brand)} ${esc(b.model)}\n📅 ${fmtDate(b.pickup_at)} — ${fmtDate(b.return_at)}\n💰 ${money(b.total_amount)}`).join('\n\n'),
    { inline_keyboard: [[{ text: "💳 To'lov", callback_data: 'm:pay' }], homeRow] });
}
async function sendAddress(chat, cb) {
  const S = await settings.all();
  if (S.office_lat && S.office_lng) await tg.call('sendLocation', { chat_id: chat, latitude: +S.office_lat, longitude: +S.office_lng });
  return show(chat, S.office_lat && S.office_lng ? null : cb, `📍 <b>MANZIL</b>\n\n${esc(S.company_address || 'Manzil tez orada e\'lon qilinadi')}`);
}
async function sendOperator(chat, cb) {
  const list = await contactsSvc.list(true); const S = await settings.all();
  const urls = list.filter(c => c.telegram).map(c => [{ text: `✈️ ${c.label} (${c.telegram})`, url: `https://t.me/${c.telegram.replace('@', '')}` }]);
  const text = list.length ? '☎️ <b>OPERATOR</b>\n\n' + contactsSvc.asText(list) + '\n\nYoki shu yerga savolingizni yozing — operator javob beradi.' : `☎️ <b>OPERATOR</b>\n\n${S.company_phone ? esc(S.company_phone) + '\n' : ''}Savolingizni shu yerga yozing — operator javob beradi.`;
  return show(chat, cb, text, { inline_keyboard: [...urls, homeRow] });
}
async function welcomeText(name) {
  const S = await settings.all();
  return `🚘 <b>${esc((S.company_name || 'LIDER RENT A CAR').toUpperCase())}</b>\n${LINE}\n\nAssalomu alaykum${name ? ', <b>' + esc(name) + '</b>' : ''}! Xush kelibsiz.\n\nPremium avtomobillarni qulay va tez ijaraga oling.\n\n🚗 Avtomobil tanlash\n📅 Bron qilish\n💳 To'lov\n🛡 Ishonchli xizmat`;
}
// Eski pastki (reply) klaviatura bo'lsa — olib tashlanadi
async function clearOldKeyboard(chat) {
  const rm = await tg.send(chat, '🚘', { reply_markup: { remove_keyboard: true } });
  if (rm && rm.result && rm.result.message_id) tg.call('deleteMessage', { chat_id: chat, message_id: rm.result.message_id });
}
const bannerUrl = () => (baseUrl().startsWith('https://') ? `${baseUrl()}/app/brand/welcome.png` : null);
// Brend rasmi + xush kelibsiz matni + inline menyu (rasm yuklanmasa — oddiy matn)
const INTRO_DEFAULT = `🚘 <b>LIDER RENT A CAR</b>
${'━━━━━━━━━━━━━━━━'}

<b>Rent a car nima?</b>
Bu — avtomobilni sotib olmasdan, kerakli muddatga (kunlab yoki haftalab) ijaraga olish xizmati.

<b>Nega bu sizga kerak?</b>
✅ Xohlagan paytda <b>premium avtomobilda</b> yuring — katta xarajatsiz
✅ Safar, to'y, tadbir, biznes uchrashuv yoki shaxsiy ehtiyoj uchun qulay
✅ Narxlar <b>aniq</b> — yashirin to'lovlar yo'q
✅ Bron qilish bor-yo'g'i <b>1 daqiqa</b>, to'g'ridan-to'g'ri Telegramdan
✅ Rasmiy <b>shartnoma</b> va qaytariladigan depozit — xavfsiz
✅ Texnik holati tekshirilgan, toza va tayyor mashinalar
✅ Operator doim aloqada

Davom etish tugmasini bosing 👇`;
async function sendIntro(chat) {
  const text = (await settings.get('bot_intro')) || INTRO_DEFAULT;
  return tg.send(chat, text, { reply_markup: { inline_keyboard: [[B('▶️ DAVOM ETISH', 'intro:go', 'success')]] } });
}
async function sendWelcome(chat, name, keepKb) {
  if (!keepKb) await clearOldKeyboard(chat);
  const text = await welcomeText(name), url = bannerUrl();
  if (url) { const r = await tg.call('sendPhoto', { chat_id: chat, photo: url, caption: text, parse_mode: 'HTML', reply_markup: menuKb() }); if (r.ok || r.skipped) return r; }
  return tg.send(chat, text, { reply_markup: menuKb() });
}

/* ---------- Mijoz: bron oqimi (inline tugmalar bilan) ---------- */
const parseDate = s => { const m = /^(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{4})$/.exec((s || '').trim()); return m ? `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}` : null; };
const parseTime = s => { const m = /^(\d{1,2})[:.](\d{2})$/.exec((s || '').trim()); return !m || +m[1] > 23 || +m[2] > 59 ? null : `${m[1].padStart(2, '0')}:${m[2]}`; };
const chunk = (a, n) => { const o = []; for (let i = 0; i < a.length; i += n) o.push(a.slice(i, i + n)); return o; };
async function startBookingFlow(chat, cb) {
  await contracts.requireActive();
  const { rows } = await db.query(`SELECT id,brand,model,price_day FROM cars WHERE deleted_at IS NULL AND status IN ('AVAILABLE','RESERVED','RENTED') ORDER BY brand,model`);
  if (!rows.length) return show(chat, cb, "🚗 <b>Hozircha mavjud avtomobillar yo'q.</b>\n\nTez orada yangi avtomobillar qo'shiladi.", { inline_keyboard: [[{ text: '🔄 Qayta tekshirish', callback_data: 'm:book' }], homeRow] });
  await setState(chat, { kind: 'book', step: 'car', data: {} });
  return show(chat, cb, '🚗 <b>Avtomobilni tanlang</b>\n\n<i>1 / 5</i>', { inline_keyboard: [...rows.map(c => [{ text: `${c.brand} ${c.model} — ${money(c.price_day)}`, callback_data: `car:${c.id}` }]), [{ text: '◀ Orqaga', callback_data: 'm:home' }]] });
}
// Qadamlar: har biri alohida toza xabar + inline tugmalar
async function stepDate(chat, cb, st) {
  st.step = 'pickup_date'; await setState(chat, st);
  const t = todayStr(); const days = Array.from({ length: 9 }, (_, i) => addDays(t, i));
  const lab = (d, i) => (i === 0 ? 'Bugun' : i === 1 ? 'Ertaga' : dShort(d));
  return show(chat, cb, '📅 <b>Olish sanasini tanlang</b>\n\n<i>2 / 5</i>', { inline_keyboard: [...chunk(days.map((d, i) => ({ text: lab(d, i), callback_data: `bd:${d}` })), 3), [{ text: '✍️ Boshqa sana', callback_data: 'bd:x' }], [{ text: '◀ Orqaga', callback_data: 'bk:back' }]] });
}
async function stepTime(chat, cb, st) {
  st.step = 'pickup_time'; await setState(chat, st);
  const times = ['08:00', '09:00', '10:00', '12:00', '14:00', '16:00', '18:00', '20:00'];
  return show(chat, cb, `🕒 <b>Olish vaqtini tanlang</b>\n📅 ${dShort(st.data.pickup_date)}\n\n<i>3 / 5</i>`, { inline_keyboard: [...chunk(times.map(x => ({ text: x, callback_data: 'bt:' + x.replace(':', '') })), 4), [{ text: '✍️ Boshqa vaqt', callback_data: 'bt:x' }], [{ text: '◀ Orqaga', callback_data: 'bk:back' }]] });
}
async function stepDuration(chat, cb, st) {
  st.step = 'duration'; await setState(chat, st);
  const ns = [1, 2, 3, 5, 7, 10, 14, 30];
  return show(chat, cb, `⏳ <b>Necha kunga ijaraga olasiz?</b>\n📅 ${dShort(st.data.pickup_date)}, ${st.data.pickup_time}\n\n<i>4 / 5</i>`, { inline_keyboard: [...chunk(ns.map(n => ({ text: `${n} kun`, callback_data: 'bn:' + n })), 4), [{ text: '✍️ Qaytarish sanasini yozish', callback_data: 'bn:x' }], [{ text: '◀ Orqaga', callback_data: 'bk:back' }]] });
}
async function askLocationOrPhone(chat, st, customer, cb) {
  const locs = JSON.parse(await settings.get('locations') || '[]'); const fee = await bookings.deliveryFee();
  if (locs.length || fee != null) {
    st.step = 'location'; await setState(chat, st);
    const dl = fee != null ? [[{ text: `🚚 Manzilga yetkazish${fee ? ' (+' + money(fee) + ')' : ' (bepul)'}`, callback_data: 'dl:1' }]] : [];
    return show(chat, cb, '📍 <b>Mashinani qayerdan olasiz?</b>\n\n<i>5 / 5</i>', { inline_keyboard: [...locs.map((l, i) => [{ text: l, callback_data: `loc:${i}` }]), ...dl, [{ text: '◀ Orqaga', callback_data: 'bk:back' }]] });
  }
  st.data.location = null; return askPhone(chat, st, customer, cb);
}
async function askPhone(chat, st, customer, cb) {
  const c = (await db.query('SELECT phone FROM customers WHERE id=$1', [customer.id])).rows[0];
  if (c?.phone) return quoteStep(chat, st, cb);
  st.step = 'phone'; await setState(chat, st);
  return tg.send(chat, '📱 <b>Telefon raqamingizni yuboring</b>\n\nPastdagi tugmani bosing yoki raqamni yozing.', { reply_markup: { keyboard: [[{ text: '📱 Raqamni yuborish', request_contact: true }]], resize_keyboard: true, one_time_keyboard: true } });
}
async function quoteStep(chat, st, cb) {
  try {
    const car = (await db.query('SELECT * FROM cars WHERE id=$1', [st.data.car_id])).rows[0];
    const q = await db.tx(c => bookings.quote(c, { car, pickup: parseTkt(st.data.pickup_date, st.data.pickup_time), ret: parseTkt(st.data.return_date, st.data.return_time), trusted: false, delivery: !!st.data.delivery_address }));
    const t = await contracts.requireActive();
    st.step = 'confirm'; st.data.template_id = t.id; await setState(chat, st);
    await show(chat, cb, `🧾 <b>BUYURTMA</b>\n${LINE}\n🚗 <b>${esc(car.brand)} ${esc(car.model)}</b>\n📅 ${fmtDate(parseTkt(st.data.pickup_date))} ${st.data.pickup_time} — ${fmtDate(parseTkt(st.data.return_date))} ${st.data.return_time}${st.data.location ? '\n📍 ' + esc(st.data.location) : ''}${st.data.delivery_address ? '\n🚚 Yetkazish: ' + esc(st.data.delivery_address) + (q.delivery_fee ? ' (+' + money(q.delivery_fee) + ')' : '') : ''}\n\n💵 ${q.days} kun × ${money(q.rate)} = ${money(q.rental)}\n🔐 Depozit: ${money(q.deposit)}\n${LINE}\n<b>Jami: ${money(q.grand_total)}</b>`, { inline_keyboard: [] });
    const kb = { reply_markup: { inline_keyboard: [[B("✅ O'qidim, roziman — buyurtma berish", 'bk:go', 'success')], [B('❌ Bekor qilish', 'bk:x', 'danger')]] } };
    if (t.kind === 'PDF') await tg.sendDocument(chat, t.file_path, `📄 <b>${esc(t.title)}</b>\n\nBuyurtma berishdan oldin shartnomani to'liq o'qib chiqing. Rozi bo'lsangiz, pastdagi tugmani bosing.`, kb);
    else { await tg.send(chat, `📄 <b>${esc(t.title)}</b>\nBuyurtma berishdan oldin shartlarni o'qib chiqing:`); await tg.sendLong(chat, esc(t.body), kb); }
  } catch (e) { await clearState(chat); await showErr(chat, cb, e); }
}

/* ---------- Mijoz: to'lov ---------- */
async function startPayment(chat, customer, cb) {
  if (!(await features.enabled('pay_claims'))) return show(chat, cb, `🛠 <b>${UNAVAILABLE}</b>`, unavailKb());
  const accs = await payacc.listAccounts(true);
  if (!accs.length) return show(chat, cb, `🛠 <b>${UNAVAILABLE}</b>`, unavailKb());
  const { rows } = await db.query(`SELECT b.id,b.code,b.total_amount,b.paid_amount,b.status,car.brand,car.model,COALESCE(d.amount-d.held_amount,0) dep_left FROM bookings b JOIN cars car ON car.id=b.car_id LEFT JOIN deposits d ON d.booking_id=b.id
    WHERE b.customer_id=$1 AND b.deleted_at IS NULL AND b.status IN ('PENDING','CONFIRMED','ACTIVE','OVERDUE','COMPLETED') ORDER BY b.id DESC LIMIT 10`, [customer.id]);
  const due = rows.filter(b => Number(b.total_amount) > Number(b.paid_amount) || (['PENDING', 'CONFIRMED'].includes(b.status) && Number(b.dep_left) > 0));
  if (!due.length) return show(chat, cb, "💳 <b>To'lanishi kerak bo'lgan buyurtma yo'q</b> ✅", { inline_keyboard: [[{ text: '📋 Buyurtmalarim', callback_data: 'm:orders' }], homeRow] });
  const kb = [];
  for (const b of due) {
    const rem = Number(b.total_amount) - Number(b.paid_amount);
    if (rem > 0) kb.push([{ text: `${b.code} ${b.brand} ${b.model} — ijara ${money(rem)}`, callback_data: `pk:${b.id}:R` }]);
    if (['PENDING', 'CONFIRMED'].includes(b.status) && Number(b.dep_left) > 0) kb.push([{ text: `${b.code} — depozit ${money(b.dep_left)}`, callback_data: `pk:${b.id}:D` }]);
  }
  return show(chat, cb, "💳 <b>TO'LOV</b>\n\nQaysi to'lovni amalga oshirmoqchisiz?", { inline_keyboard: [...kb, homeRow] });
}
async function payChosen(chat, customer, bookingId, kindCode, cb) {
  const b = (await db.query(`SELECT b.id,b.code,b.total_amount,b.paid_amount,COALESCE(d.amount-d.held_amount,0) dep_left FROM bookings b LEFT JOIN deposits d ON d.booking_id=b.id WHERE b.id=$1 AND b.customer_id=$2`, [bookingId, customer.id])).rows[0];
  if (!b) return show(chat, cb, 'Buyurtma topilmadi.');
  const kind = kindCode === 'D' ? 'DEPOSIT' : 'RENTAL'; const amount = kind === 'DEPOSIT' ? Number(b.dep_left) : Number(b.total_amount) - Number(b.paid_amount);
  if (amount <= 0) return show(chat, cb, "Bu bo'yicha qarz yo'q ✅");
  const accs = await payacc.listAccounts(true);
  await setState(chat, { kind: 'pay', step: 'receipt', data: { booking_id: b.id, pay_kind: kind, amount, account_id: accs.length === 1 ? accs[0].id : null } });
  return show(chat, cb, `💳 <b>#${esc(b.code)} — ${kind === 'DEPOSIT' ? 'depozit' : "ijara to'lovi"}</b>\n${LINE}\nTo'lanadigan summa: <b>${money(amount)}</b>\n\n` + accs.map(a => `<code>${esc(payacc.accountText(a))}</code>`).join('\n\n') +
    `\n\nShu rekvizitga to'lang va <b>to'lov chekining rasmini (screenshot)</b> shu yerga yuboring. Admin tekshirib tasdiqlaydi.`, { inline_keyboard: [[{ text: '❌ Bekor qilish', callback_data: 'bk:x' }]] });
}

/* ---------- Admin: xabar yuborish ---------- */
async function adminCommand(chat, cmd, staff) {
  const fin = can(staff, 'finance.read');
  const deny = () => tg.send(chat, "Bu ma'lumot uchun ruxsatingiz yo'q.");
  if (cmd === '/xabar' || cmd === '/hammaga') {
    if (!can(staff, 'messages.send')) return deny();
    if (!(await features.enabled('messages'))) return tg.send(chat, "«Mijozlarga xabar» funksiyasi o'chirilgan (Funksiyalar sahifasida yoqing).");
    if (cmd === '/xabar') { await setState(chat, { kind: 'admin', step: 'search' }); return tg.send(chat, "Qaysi mijozga yozmoqchisiz? Ism yoki telefon raqamini yozing.\n(Bekor qilish: /cancel)"); }
    const n = await messages.countRecipients();
    await setState(chat, { kind: 'admin', step: 'bc_text' });
    return tg.send(chat, `📣 Botga ulangan <b>${n}</b> ta mijozga xabar yuboriladi. Xabar matnini yozing.\n(Bekor qilish: /cancel)`);
  }
  if (cmd === '/dashboard') {
    const d = await reports.dashboard();
    return tg.send(chat, `<b>📊 Dashboard</b>\nJami: ${d.cars.total} | Bo'sh: ${d.cars.available} | Bron: ${d.cars.reserved} | Ijarada: ${d.cars.rented} | Ta'mirda: ${d.cars.maintenance}\n` +
      (fin ? `\nBugungi daromad: ${money(d.today.revenue)}\nXarajat: ${money(d.today.expenses)}\nSof foyda: ${money(d.today.profit)}\n` : '') + `\nBugun qaytadi: ${d.today.returns}\nBugun beriladi: ${d.today.pickups}\nKutilayotgan buyurtmalar: ${d.pending_bookings}`);
  }
  if (cmd === '/cars') {
    const { rows } = await db.query(`SELECT brand,model,plate,status FROM cars WHERE deleted_at IS NULL ORDER BY status,brand`);
    return tg.send(chat, '<b>🚗 Mashinalar</b>\n' + (rows.map(c => `${STATUS[c.status].split(' ')[0]} ${esc(c.brand)} ${esc(c.model)} (${esc(c.plate)})`).join('\n') || "Yo'q"));
  }
  if (cmd === '/bookings') {
    const { rows } = await db.query(`SELECT b.id,b.code,b.status,b.pickup_at,b.return_at,c.first_name||' '||c.last_name cu,car.brand||' '||car.model car FROM bookings b JOIN customers c ON c.id=b.customer_id JOIN cars car ON car.id=b.car_id
      WHERE b.deleted_at IS NULL AND b.status IN ('PENDING','CONFIRMED','ACTIVE','OVERDUE') ORDER BY b.pickup_at LIMIT 12`);
    return tg.send(chat, '<b>📅 Faol buyurtmalar</b>\n' + (rows.map(b => `${b.code} ${BST[b.status]}\n${esc(b.car)} — ${esc(b.cu)}\n${fmtDT(b.pickup_at)} → ${fmtDT(b.return_at)}`).join('\n\n') || "Yo'q"));
  }
  if (cmd === '/users') {
    const { rows } = await db.query(`SELECT first_name,last_name,phone,tg_username,telegram_id,created_at FROM customers WHERE telegram_id IS NOT NULL AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 15`);
    const n = (await db.query('SELECT COUNT(*)::int n FROM customers WHERE telegram_id IS NOT NULL AND deleted_at IS NULL')).rows[0].n;
    return tg.send(chat, `<b>👤 Botga qo'shilganlar</b> (jami ${n})\n\n` + (rows.map(c => `${esc(c.first_name)} ${esc(c.last_name || '')} ${c.tg_username ? '@' + esc(c.tg_username) : ''}\n📞 ${esc(c.phone || "raqam yubormagan")} · ID ${c.telegram_id}`).join('\n\n') || "Yo'q"));
  }
  if (cmd === '/customers') {
    const { rows } = await db.query(`SELECT first_name,last_name,phone FROM customers WHERE deleted_at IS NULL ORDER BY id DESC LIMIT 10`);
    const n = (await db.query('SELECT COUNT(*)::int n FROM customers WHERE deleted_at IS NULL')).rows[0].n;
    return tg.send(chat, `<b>👥 Mijozlar</b> (jami ${n})\n` + rows.map(c => `${esc(c.first_name)} ${esc(c.last_name)} — ${esc(c.phone || '—')}`).join('\n'));
  }
  if (cmd === '/revenue' || cmd === '/expenses' || cmd === '/reports') {
    if (!fin) return deny();
    const t = todayStr(); const m = await reports.summary(t.slice(0, 8) + '01', t); const d = await reports.summary(t, t);
    if (cmd === '/revenue') return tg.send(chat, `<b>💰 Daromad</b>\nBugun: ${money(d.revenue)}\nBu oy: ${money(m.revenue)}`);
    if (cmd === '/expenses') return tg.send(chat, `<b>🧾 Xarajat</b>\nBugun: ${money(d.expenses)}\nBu oy: ${money(m.expenses)}\n\n` + m.expense_categories.map(c => `${esc(c.name)}: ${money(c.amount)}`).join('\n'));
    return tg.send(chat, `<b>📊 Bu oy</b>\nDaromad: ${money(m.revenue)}\nXarajat: ${money(m.expenses)}\nSof foyda: ${money(m.profit)}\nIjaralar: ${m.rentals}\nBandlik: ${m.utilization}%\n\nTop mashinalar:\n` + m.top_cars.map(c => `• ${esc(c.name)}: ${money(c.revenue)}`).join('\n'));
  }
  if (cmd === '/today') {
    const d = await reports.dashboard();
    return tg.send(chat, `<b>📌 Bugungi ishlar</b>\n` + (d.schedule.map(s => `${s.time} — ${esc(s.car)} ${s.kind === 'PICKUP' ? 'berish' : 'qaytishi'} (${esc(s.customer)})`).join('\n') || "Reja yo'q") +
      (d.overdue.length ? `\n\n⚠️ Kechikayotgan:\n` + d.overdue.map(o => `${esc(o.car)} — ${esc(o.customer)}, ${esc(o.phone)}`).join('\n') : ''));
  }
  return false;
}
// Admin holatlari: mijoz qidirish / xabar matni / ommaviy xabar
async function adminState(chat, text, staff, st) {
  if (st.step === 'search') {
    const like = `%${text.replace(/[%_]/g, '')}%`;
    const { rows } = await db.query(`SELECT id,first_name,last_name,phone FROM customers WHERE deleted_at IS NULL AND telegram_id IS NOT NULL AND (first_name||' '||last_name ILIKE $1 OR phone ILIKE $1) ORDER BY id DESC LIMIT 8`, [like]);
    if (!rows.length) return tg.send(chat, "Botga ulangan bunday mijoz topilmadi (mijoz botni ishga tushirgan bo'lishi kerak). Boshqa ism/raqam yozing yoki /cancel.");
    return tg.send(chat, 'Mijozni tanlang:', { reply_markup: { inline_keyboard: rows.map(c => [{ text: `${c.first_name} ${c.last_name} · ${c.phone || '—'}`, callback_data: `wm:${c.id}` }]) } });
  }
  if (st.step === 'msg') {
    const r = await messages.sendToCustomer(st.data.customer_id, text, actor(staff), st.data.reply ? 'REPLY' : 'DIRECT');
    await clearState(chat); return tg.send(chat, `✅ ${esc(r.customer)} ga yuborildi.`);
  }
  if (st.step === 'bc_text') {
    if (text.length > 3500) return tg.send(chat, 'Matn juda uzun (3500 belgigacha).');
    st.step = 'bc_confirm'; st.data = { text }; await setState(chat, st);
    const n = await messages.countRecipients();
    return tg.send(chat, `<b>Ko'rib chiqing</b> — ${n} ta mijozga yuboriladi:\n\n${esc(text)}`, { reply_markup: { inline_keyboard: [[{ text: `✅ ${n} ta mijozga yuborish`, callback_data: 'bc:go' }], [{ text: '❌ Bekor qilish', callback_data: 'bc:x' }]] } });
  }
  return false;
}

/* ---------- Asosiy handler ---------- */
const seen = new Set();
async function handleUpdate(u) {
  if (u.update_id != null) { if (seen.has(u.update_id)) return; seen.add(u.update_id); if (seen.size > 500) seen.delete(seen.values().next().value); }
  try {
    if (u.callback_query) return await onCallback(u.callback_query);
    if (u.edited_message && u.edited_message.location) return await onLocation(u.edited_message, true);   // jonli joylashuv yangilanishi
    if (u.message && u.message.location) return await onLocation(u.message, false);
    if (u.message) return await onMessage(u.message);
  } catch (e) {
    if (!(e instanceof AppError)) console.error('Bot xatosi:', e);
    const chat = u.message?.chat?.id || u.callback_query?.message?.chat?.id;
    if (chat) await (e instanceof AppError && e.code !== 'NO_CONTRACT' ? tg.send(chat, '⚠️ ' + esc(e.message), { reply_markup: { inline_keyboard: [homeRow] } }) : tg.send(chat, `🛠 <b>${UNAVAILABLE}</b>`, { reply_markup: unavailKb() })).catch(() => {});
  }
}

// Mijoz Telegramda «Jonli joylashuv»ni ulashsa — uning faol ijarasidagi mashina joylashuvi sifatida yoziladi
async function onLocation(m, edited) {
  if (!m.chat || m.chat.type !== 'private' || !m.location) return;
  const c = (await db.query('SELECT id FROM customers WHERE telegram_id=$1', [m.from.id])).rows[0];
  const bk = c && (await db.query(`SELECT car_id FROM bookings WHERE customer_id=$1 AND status IN ('ACTIVE','OVERDUE') AND deleted_at IS NULL ORDER BY id DESC LIMIT 1`, [c.id])).rows[0];
  if (!bk) { if (!edited) await tg.send(m.chat.id, "📍 Joylashuv faqat faol ijara paytida qabul qilinadi.", { reply_markup: menuKb() }); return; }
  await gps.record(bk.car_id, { lat: m.location.latitude, lng: m.location.longitude, speed: m.location.speed != null ? m.location.speed * 3.6 : null }, 'TELEGRAM');
  if (!edited) await tg.send(m.chat.id, '📍 <b>Joylashuv qabul qilindi</b> ✅\nIjara davomida «Jonli joylashuv»ni yoqib qo\'ysangiz, xavfsizlik uchun yaxshi.', { reply_markup: { inline_keyboard: [homeRow] } });
}

async function onMessage(m) {
  const chat = m.chat.id; const text = (m.text || '').trim();
  if (m.chat.type !== 'private') return;
  const staff = await resolveStaff(m.from.id);
  const customer = await ensureCustomer(m.from, /^\/start\s+(\S+)/.exec(text)?.[1]);
  if (text === '/cancel') { await clearState(chat); return tg.send(chat, 'Bekor qilindi.', { reply_markup: menuKb() }); }
  if (text.startsWith('/start')) {
    await clearState(chat);
    if (staff) { await clearOldKeyboard(chat); return tg.send(chat, `<b>LIDER RENT A CAR — admin</b>\nSalom, ${esc(staff.full_name)}!\n/dashboard /cars /bookings /customers /users /revenue /expenses /today /reports\n\n✉️ /xabar — mijozga alohida xabar\n📣 /hammaga — barcha mijozlarga xabar\n\nYoki savol yozing: «Bugungi foyda», «Bo'sh mashinalar»...`, { reply_markup: menuKb() }); }
    if (!customer.intro_seen) { await clearOldKeyboard(chat); return sendIntro(chat); }
    return sendWelcome(chat, customer.first_name);
  }
  const st = await getState(chat);
  if (staff && text.startsWith('/')) { const r = await adminCommand(chat, text.split(/[@\s]/)[0], staff); if (r !== false) return; }
  if (st) {
    if (st.kind === 'admin' && staff && text) { const r = await adminState(chat, text, staff, st); if (r !== false) return; }
    if (st.kind === 'pay' && st.step === 'receipt') {
      const photo = m.photo?.length ? m.photo[m.photo.length - 1].file_id : (m.document?.mime_type?.startsWith('image/') ? m.document.file_id : null);
      if (!photo) return tg.send(chat, "Iltimos, to'lov chekining <b>rasmini</b> yuboring (screenshot). Bekor qilish: /cancel");
      await payacc.createClaim(customer, { booking_id: st.data.booking_id, amount: st.data.amount, kind: st.data.pay_kind, account_id: st.data.account_id, receipt_tg_file_id: photo, note: m.caption });
      await clearState(chat); return tg.send(chat, `✅ <b>SO'ROV YUBORILDI</b>\n${LINE}\nAdmin chekni tekshirib tasdiqlaydi. Natijani shu yerda olasiz.`, { reply_markup: menuKb() });
    }
    if (st.kind === 'book') {
      const ask = t => tg.send(chat, t);
      if (st.step === 'pickup_date') { const d = parseDate(text); if (!d || !validDate(d)) return ask("Sanani DD.MM.YYYY ko'rinishida to'g'ri yozing. Masalan: " + fmtDate(new Date(Date.now() + 864e5))); if (d < todayStr()) return ask("Bu sana o'tib ketgan. Bugundan keyingi sanani yozing."); st.data.pickup_date = d; return stepTime(chat, null, st); }
      if (st.step === 'pickup_time') { const t = parseTime(text); if (!t) return ask("Vaqtni HH:MM ko'rinishida yozing. Masalan: 10:00"); if (parseTkt(st.data.pickup_date, t) < new Date()) return ask("Bu vaqt o'tib ketgan. Keyingi vaqtni yozing."); st.data.pickup_time = t; return stepDuration(chat, null, st); }
      if (st.step === 'return_date') { const d = parseDate(text); if (!d || !validDate(d)) return ask("Sanani DD.MM.YYYY ko'rinishida to'g'ri yozing."); if (d < st.data.pickup_date) return ask("Qaytarish sanasi olish sanasidan oldin bo'lishi mumkin emas. Qaytadan yozing."); st.data.return_date = d; st.step = 'return_time'; await setState(chat, st); return ask('🕒 Qaytarish vaqtini yozing (masalan 18:00):'); }
      if (st.step === 'return_time') { const t = parseTime(text); if (!t) return ask("Vaqtni HH:MM ko'rinishida yozing."); if (parseTkt(st.data.return_date, t) <= parseTkt(st.data.pickup_date, st.data.pickup_time)) return ask("Qaytarish vaqti olish vaqtidan keyin bo'lishi kerak. Qaytarish vaqtini qayta yozing."); st.data.return_time = t; return askLocationOrPhone(chat, st, customer, null); }
      if (st.step === 'delivery_addr') { if (text.length < 5) return ask('Manzilni to\'liqroq yozing (ko\'cha, uy, mo\'ljal):'); st.data.delivery_address = text.slice(0, 250); st.data.location = null; return askPhone(chat, st, customer, null); }
      if (st.step === 'phone') {
        const phone = m.contact ? m.contact.phone_number : text;
        if (!/^\+?[0-9 ()-]{7,20}$/.test(phone || '')) return tg.send(chat, "Telefon raqamini yuboring (masalan +998901234567) yoki «Raqamni yuborish» tugmasini bosing.");
        const d = String(phone).replace(/\D/g, ''); await db.query('UPDATE customers SET phone=$2 WHERE id=$1', [customer.id, d.length === 9 ? '+998' + d : '+' + d]);
        return quoteStep(chat, st, null);
      }
    }
  }
  if (m.contact) {
    if (m.contact.user_id && m.contact.user_id !== m.from.id) return tg.send(chat, "Iltimos, o'zingizning raqamingizni yuboring.", { reply_markup: menuKb() });
    const ph = contactsSvc.normPhone(m.contact.phone_number);
    await db.query('UPDATE customers SET phone=$2 WHERE id=$1', [customer.id, ph]);
    const { notify } = require('../services/notify');
    if (!staff) await notify({ audience: 'ADMIN', type: 'NEW_USER', title: '📞 Mijoz telefon raqamini yubordi', ref_key: `phone:${customer.id}:${ph}`, body: `${customer.first_name} ${customer.last_name || ''}${customer.tg_username ? ' @' + customer.tg_username : ''}\n${ph}` }).catch(() => {});
    return tg.send(chat, 'Telefon raqamingiz saqlandi ✅', { reply_markup: menuKb() });
  }
  switch (text) {
    case '🚗 Mashinalar': return sendCars(chat);
    case '📅 Bron qilish': return startBookingFlow(chat);
    case '📋 Mening buyurtmalarim': return sendMyBookings(chat, customer);
    case "💳 To'lov": return startPayment(chat, customer);
    case '💰 Tariflar': return sendTariffs(chat);
    case '📍 Manzil': return sendAddress(chat);
    case '☎️ Operator': return sendOperator(chat);
  }
  if (staff && can(staff, 'ai.use') && text && (await features.enabled('ai'))) {
    const a = await assistant.ask(text);
    if (!can(staff, 'finance.read') && /foyda|daromad|xarajat/i.test(text)) return tg.send(chat, "Moliyaviy ma'lumot uchun ruxsatingiz yo'q.");
    return tg.send(chat, esc(a.answer) + (a.examples ? '\n\n' + a.examples.map(x => '• ' + esc(x)).join('\n') : ''));
  }
  // Mijozning erkin yozgan xabari — adminlarga yetkaziladi (javob berish tugmasi bilan)
  if (text && !staff) {
    await messages.logInbound(customer.id, text);
    const { adminChatIds } = require('../services/notify');
    const kb = { reply_markup: { inline_keyboard: [[{ text: '✉️ Javob berish', callback_data: `rp:${customer.id}` }]] } };
    for (const a of await adminChatIds()) await tg.send(a, `💬 <b>Mijozdan xabar</b>\n${esc(customer.first_name)} ${esc(customer.last_name || '')}${customer.phone ? ' · ' + esc(customer.phone) : ''}\n\n${esc(text)}`, kb);
    return tg.send(chat, 'Xabaringiz operatorga yuborildi ✅ Tez orada javob beramiz.', { reply_markup: menuKb() });
  }
  return tg.send(chat, 'Menyudan tanlang 👇', { reply_markup: menuKb() });
}

async function onCallback(cb) {
  const chat = cb.message.chat.id; const data = cb.data || '';
  const answer = (t, alert = false) => tg.call('answerCallbackQuery', { callback_query_id: cb.id, text: t, show_alert: alert });
  const staff = await resolveStaff(cb.from.id);

  // ---- Admin tugmalari ----
  if (/^bk:(ok|no|ct):\d+$/.test(data)) {
    if (!can(staff, 'bookings.write')) return answer("Ruxsat yo'q", true);
    const [, act, id] = data.split(':');
    if (act === 'ok') { await bookings.confirmBooking(+id, actor(staff), null); await answer('Tasdiqlandi ✅'); return tg.send(chat, `✅ Buyurtma ${id} tasdiqlandi. Mijozga xabar va shartnoma yuborildi.`); }
    if (act === 'no') { await bookings.cancelBooking(+id, actor(staff), null, { reason: 'Admin rad etdi' }); await answer('Rad etildi'); return tg.send(chat, `❌ Buyurtma ${id} rad etildi. Mijozga xabar yuborildi.`); }
    const b = await bookings.getBooking(+id); await answer(); return tg.send(chat, `💬 ${esc(b.first_name)} ${esc(b.last_name)}\n☎️ ${esc(b.phone)}${b.customer_tg ? `\n<a href="tg://user?id=${b.customer_tg}">Telegramda yozish</a>` : ''}`);
  }
  if (/^pc:(ok|no):\d+$/.test(data)) {
    if (!can(staff, 'payments.write')) return answer("Ruxsat yo'q", true);
    const [, act, id] = data.split(':');
    if (act === 'ok') { await payacc.confirmClaim(+id, actor(staff), null); await answer('Tasdiqlandi ✅'); return tg.send(chat, `✅ To'lov so'rovi #${id} tasdiqlandi, mijozga xabar yuborildi.`); }
    await payacc.rejectClaim(+id, 'Admin rad etdi', actor(staff), null); await answer('Rad etildi'); return tg.send(chat, `❌ To'lov so'rovi #${id} rad etildi.`);
  }
  if (/^(wm|rp):\d+$/.test(data)) {
    if (!can(staff, 'messages.send')) return answer("Ruxsat yo'q", true);
    const [k, id] = data.split(':'); const c = (await db.query('SELECT first_name,last_name FROM customers WHERE id=$1', [id])).rows[0];
    if (!c) return answer('Mijoz topilmadi', true);
    await setState(chat, { kind: 'admin', step: 'msg', data: { customer_id: +id, reply: k === 'rp' } }); await answer();
    return tg.send(chat, `✉️ <b>${esc(c.first_name)} ${esc(c.last_name)}</b> ga yoziladigan xabar matnini yuboring.\n(Bekor qilish: /cancel)`);
  }
  if (data === 'bc:go' || data === 'bc:x') {
    if (!can(staff, 'messages.send')) return answer("Ruxsat yo'q", true);
    const st = await getState(chat);
    if (data === 'bc:x' || !st || st.step !== 'bc_confirm') { await clearState(chat); return answer('Bekor qilindi'); }
    await answer('Yuborilmoqda...'); await clearState(chat);
    const r = await messages.broadcast(st.data.text, actor(staff), null);
    return tg.send(chat, r.done ? `✅ Yuborildi: ${r.sent} ta, xato: ${r.failed} ta.` : `📣 ${r.total} ta mijozga yuborish boshlandi. Tugagach xabar beraman.`);
  }

  // ---- Mijoz tugmalari ----
  if (/^cs:\d+:\d+$/.test(data)) {   // shartnomaga rozilik (admin yaratgan buyurtma uchun)
    const [, bid, tid] = data.split(':'); await answer();
    try {
      const created = await bookings.acceptViaBot(+bid, +tid, cb.from.id);
      return tg.send(chat, created ? "✅ Rahmat! Shartnoma shartlari bilan roziligingiz qabul qilindi." : "Roziligingiz avval qabul qilingan ✅");
    } catch (e) { return tg.send(chat, '⚠️ ' + esc(e.message)); }
  }
  const customer = await ensureCustomer(cb.from);
  if (data === 'noop') return answer();
  if (data === 'intro:go') {
    await answer(); await db.query('UPDATE customers SET intro_seen=true WHERE id=$1', [customer.id]);
    if (cb.message && cb.message.message_id) await tg.call('editMessageReplyMarkup', { chat_id: chat, message_id: cb.message.message_id, reply_markup: { inline_keyboard: [] } });
    return sendWelcome(chat, customer.first_name, true);
  }
  // ---- Asosiy inline menyu ----
  const mm = /^m:(\w+)$/.exec(data);
  if (mm) {
    await answer(); const k = mm[1]; if (k !== 'pay') await clearState(chat);
    if (k === 'home') { if (cb.message && cb.message.message_id) await tg.call('deleteMessage', { chat_id: chat, message_id: cb.message.message_id }); return sendWelcome(chat, customer.first_name, true); }
    if (k === 'cars') return sendCars(chat, cb, 0);
    if (k === 'book') return startBookingFlow(chat, cb).catch(e => showErr(chat, cb, e));
    if (k === 'orders') return sendMyBookings(chat, customer, cb);
    if (k === 'pay') return startPayment(chat, customer, cb);
    if (k === 'tariff') return sendTariffs(chat, cb);
    if (k === 'addr') return sendAddress(chat, cb);
    if (k === 'op') return sendOperator(chat, cb);
    return;
  }
  if (/^cv:\d+$/.test(data)) { await answer(); return sendCars(chat, cb, +data.slice(3)); }
  if (data.startsWith('car:')) {
    try { await contracts.requireActive(); } catch (e) { await answer(); return showErr(chat, cb, e); }
    await answer(); const st0 = { kind: 'book', step: 'pickup_date', data: { car_id: +data.slice(4) } };
    return stepDate(chat, cb, st0);
  }
  if (/^pk:\d+:[RD]$/.test(data)) { await answer(); const [, id, k] = data.split(':'); return payChosen(chat, customer, +id, k, cb); }
  const st = await getState(chat);
  // ---- Bron qadamlari (inline) ----
  const inBook = st && st.kind === 'book';
  if (/^(bd|bt|bn):/.test(data) || data === 'bk:back') {
    if (!inBook) { await answer(); return show(chat, cb, EXPIRED, menuKb()); }
    const v = data.slice(3);
    if (data === 'bk:back') {
      await answer();
      if (st.step === 'pickup_time') return stepDate(chat, cb, st);
      if (st.step === 'duration' || st.step === 'return_date' || st.step === 'return_time') return stepTime(chat, cb, st);
      if (st.step === 'location') return stepDuration(chat, cb, st);
      if (st.step === 'delivery_addr') return askLocationOrPhone(chat, st, customer, cb);
      return startBookingFlow(chat, cb).catch(e => showErr(chat, cb, e));
    }
    if (data.startsWith('bd:')) {
      if (v === 'x') { await answer(); return show(chat, cb, '✍️ <b>Olish sanasini yozing</b>\n\nDD.MM.YYYY ko\'rinishida. Masalan: ' + fmtDate(new Date(Date.now() + 864e5)), { inline_keyboard: [[{ text: '◀ Orqaga', callback_data: 'bk:back' }]] }); }
      if (!validDate(v) || v < todayStr()) return answer("Bu sana o'tib ketgan", true);
      await answer(); st.data.pickup_date = v; return stepTime(chat, cb, st);
    }
    if (data.startsWith('bt:')) {
      if (v === 'x') { await answer(); st.step = 'pickup_time'; await setState(chat, st); return show(chat, cb, '✍️ <b>Olish vaqtini yozing</b>\n\nSoat:daqiqa, masalan 10:00', { inline_keyboard: [[{ text: '◀ Orqaga', callback_data: 'bk:back' }]] }); }
      const t = `${v.slice(0, 2)}:${v.slice(2)}`;
      if (!parseTime(t) || parseTkt(st.data.pickup_date, t) < new Date()) return answer("Bu vaqt o'tib ketgan. Boshqasini tanlang", true);
      await answer(); st.data.pickup_time = t; return stepDuration(chat, cb, st);
    }
    if (data.startsWith('bn:')) {
      if (v === 'x') { await answer(); st.step = 'return_date'; await setState(chat, st); return show(chat, cb, '✍️ <b>Qaytarish sanasini yozing</b>\n\nDD.MM.YYYY ko\'rinishida', { inline_keyboard: [[{ text: '◀ Orqaga', callback_data: 'bk:back' }]] }); }
      const n = Math.max(1, Math.min(60, +v || 1)); await answer();
      st.data.return_date = addDays(st.data.pickup_date, n); st.data.return_time = st.data.pickup_time; return askLocationOrPhone(chat, st, customer, cb);
    }
  }
  if (data === 'dl:1' && inBook && st.step === 'location') {
    await answer(); st.step = 'delivery_addr'; await setState(chat, st);
    return show(chat, cb, "🚚 <b>Yetkazib berish manzilini yozing</b>\n\nKo'cha, uy raqami va mo'ljalni kiriting.", { inline_keyboard: [[{ text: '◀ Orqaga', callback_data: 'bk:back' }]] });
  }
  if (data.startsWith('loc:') && !(inBook && st.step === 'location')) { await answer(); return show(chat, cb, EXPIRED, menuKb()); }
  if (data.startsWith('loc:') && inBook && st.step === 'location') {
    const locs = JSON.parse(await settings.get('locations') || '[]'); st.data.location = locs[+data.slice(4)] || locs[0]; await answer();
    return askPhone(chat, st, customer, cb);
  }
  if (data === 'bk:x') { await clearState(chat); await answer('Bekor qilindi'); if (cb.message && cb.message.message_id) await tg.call('deleteMessage', { chat_id: chat, message_id: cb.message.message_id }); return sendWelcome(chat, customer.first_name, true); }
  if (data === 'bk:go') {
    const st2 = await takeState(chat);   // atomik: ikki marta bosilsa ikkinchisi o'tmaydi
    if (!st2 || st2.kind !== 'book' || st2.step !== 'confirm') { await answer(); return show(chat, cb, EXPIRED, menuKb()); }
    await answer('Yuborilmoqda...');
    try {
      const b = await bookings.createBooking({ customer_id: customer.id, car_id: st2.data.car_id, pickup_at: parseTkt(st2.data.pickup_date, st2.data.pickup_time), return_at: parseTkt(st2.data.return_date, st2.data.return_time),
        location: st2.data.location, delivery_address: st2.data.delivery_address, source: 'BOT', consent: { accepted: true, template_id: st2.data.template_id, ua: 'telegram-bot' } }, null, null);
      const f = await bookings.getBooking(b.id).catch(() => null);
      const ok = f || b;
      return show(chat, cb, `${LINE}\n\n✅ <b>BUYURTMA QABUL QILINDI</b>\n\n🚗 ${esc(ok.brand || '')} ${esc(ok.model || '')}\n\n📅 ${fmtShort(ok.pickup_at || parseTkt(st2.data.pickup_date, st2.data.pickup_time))} — ${fmtShort(ok.return_at || parseTkt(st2.data.return_date, st2.data.return_time))}\n\n💰 Jami:\n<b>${money(Number(ok.total_amount || 0) + Number(ok.deposit_amount || 0))}</b>\n\n🆔 <b>#${esc(b.code)}</b>\n\n${LINE}\nOperator tez orada tasdiqlaydi — natijani shu yerda olasiz.`,
        { inline_keyboard: [[{ text: "📋 Buyurtmani ko'rish", callback_data: 'm:orders' }], [{ text: "💳 To'lov", callback_data: 'm:pay' }], homeRow] });
    } catch (e) { return showErr(chat, cb, e); }
  }
  return answer();
}

/* ---------- Ishga tushirish ---------- */
let pollStop = false;
async function init(app) {
  if (!cfg.botToken) { console.log("Bot: BOT_TOKEN yo'q — bot o'chiq (admin panel va API ishlaydi)"); return; }
  app.post(`/bot/webhook/${webhookSecret()}`, require('express').json({ limit: '1mb' }), (req, res) => {
    if (req.headers['x-telegram-bot-api-secret-token'] !== webhookSecret()) return res.sendStatus(403);
    res.sendStatus(200); handleUpdate(req.body).catch(e => console.error('Bot handler:', e.message));
  });
  if (baseUrl().startsWith('https://')) {
    const r = await tg.call('setWebhook', { url: `${baseUrl()}/bot/webhook/${webhookSecret()}`, secret_token: webhookSecret(), allowed_updates: ['message', 'callback_query'], drop_pending_updates: false });
    console.log('Bot webhook:', r.ok ? "o'rnatildi" : r.description);
    await tg.call('setChatMenuButton', { menu_button: { type: 'web_app', text: 'Ochish', web_app: { url: `${baseUrl()}/app/` } } });
  } else {
    await tg.call('deleteWebhook', {});
    let offset = 0;
    (async function poll() { while (!pollStop) { try { const r = await tg.call('getUpdates', { offset, timeout: 25 }); if (r.ok) for (const u of r.result) { offset = u.update_id + 1; await handleUpdate(u); } else await new Promise(s => setTimeout(s, 3000)); } catch (e) { console.error('Polling:', e.message); await new Promise(s => setTimeout(s, 3000)); } } })();
    console.log('Bot: long polling rejimi');
  }
}
module.exports = { init, handleUpdate, resolveStaff, stop: () => { pollStop = true; } };
