const crypto = require('crypto');
const cfg = require('../config');
const db = require('../db');
const { tg, esc } = require('../services/notify');
const bookings = require('../services/bookings');
const reports = require('../services/reports');
const settings = require('../services/settings');
const assistant = require('../services/assistant');
const contracts = require('../services/contract');
const messages = require('../services/messages');
const payacc = require('../services/payacc');
const features = require('../services/features');
const contactsSvc = require('../services/contacts');
const { ensureCustomer } = require('../routes/mini');
const { money, fmtDate, fmtDT, parseTkt, todayStr, AppError } = require('../util');
const { ROLES } = require('../permissions');

const baseUrl = () => cfg.publicUrl;
const webhookSecret = () => crypto.createHash('sha256').update('wh' + (cfg.botToken || 'x')).digest('hex').slice(0, 32);

const MENU = { keyboard: [[{ text: '🚗 Mashinalar' }, { text: '📅 Bron qilish' }], [{ text: '📋 Mening buyurtmalarim' }, { text: '💳 To\'lov' }], [{ text: '💰 Tariflar' }, { text: '📍 Manzil' }], [{ text: '☎️ Operator' }]], resize_keyboard: true };
const STATUS = { AVAILABLE: "🟢 Bo'sh", RESERVED: '🟡 Bron qilingan', RENTED: '🔴 Ijarada', MAINTENANCE: "🔧 Ta'mirda", INACTIVE: '⚫ Faol emas' };
const TR = { AUTOMATIC: 'Avtomat', MANUAL: 'Mexanika' }, FUEL = { PETROL: 'Benzin', GAS: 'Gaz', DIESEL: 'Dizel', HYBRID: 'Gibrid', ELECTRIC: 'Elektr' };
const BST = { PENDING: '⏳ Kutilmoqda', CONFIRMED: '✅ Tasdiqlangan', ACTIVE: '🚗 Ijarada', COMPLETED: '🏁 Yakunlangan', CANCELLED: '❌ Bekor', OVERDUE: '⚠️ Kechikkan' };

/* ---------- Suhbat holati: bazada (server qayta ishga tushsa ham yo'qolmaydi) ---------- */
async function getState(chat) {
  const r = await db.query('SELECT state FROM bot_state WHERE chat_id=$1', [chat]); const s = r.rows[0]?.state;
  if (!s) return null;
  if (Date.now() - (s.ts || 0) > 30 * 60e3) { await clearState(chat); return null; }
  return s;
}
async function setState(chat, s) { s.ts = Date.now(); await db.query(`INSERT INTO bot_state(chat_id,state) VALUES($1,$2) ON CONFLICT (chat_id) DO UPDATE SET state=$2`, [chat, JSON.stringify(s)]); }
const clearState = chat => db.query('DELETE FROM bot_state WHERE chat_id=$1', [chat]);
// Holatni atomik "olib qo'yish": bir vaqtda ikki marta bosilgan tugma ikkita buyurtma yaratmasligi uchun
async function takeState(chat) {
  const r = await db.query('DELETE FROM bot_state WHERE chat_id=$1 RETURNING state', [chat]); const s = r.rows[0]?.state;
  return s && Date.now() - (s.ts || 0) <= 30 * 60e3 ? s : null;
}
const EXPIRED = "⏱ Sessiya tugagan. «📅 Bron qilish» tugmasidan qaytadan boshlang.";
const validDate = d => { if (!d) return false; const x = new Date(d + 'T00:00:00Z'); return !isNaN(x) && x.toISOString().slice(0, 10) === d; };

async function resolveStaff(tgId) {
  if (cfg.adminChatIds.includes(String(tgId))) return { id: null, full_name: 'Admin (Telegram)', role: 'OWNER', permissions: ROLES.OWNER.permissions };
  const { rows } = await db.query(`SELECT u.id,u.full_name,r.code role,r.permissions FROM users u JOIN roles r ON r.id=u.role_id WHERE u.telegram_id=$1 AND u.is_active AND u.deleted_at IS NULL`, [tgId]);
  return rows[0] || null;
}
const can = (s, p) => !!s && s.permissions.includes(p);
const actor = s => (s.id ? s : { full_name: s.full_name });

const carText = c => `<b>${esc(c.brand)} ${esc(c.model)}</b>\n${money(c.price_day)} / kun\n${TR[c.transmission]}\n${c.seats} o'rin\n${FUEL[c.fuel_type]}\n${STATUS[c.status]}`;
const miniBtn = (text, q = '') => (baseUrl().startsWith('https://') ? { text, web_app: { url: `${baseUrl()}/app/${q}` } } : null);

async function sendCars(chat) {
  const { rows } = await db.query(`SELECT * FROM cars WHERE deleted_at IS NULL AND status<>'INACTIVE' ORDER BY (status='AVAILABLE') DESC,brand,model`);
  if (!rows.length) return tg.send(chat, "Hozircha mashinalar yo'q.");
  for (const c of rows) {
    const mb = miniBtn('📱 Mini App', `?car=${c.id}`);
    const kb = c.status === 'AVAILABLE' ? [[{ text: 'Bron qilish', callback_data: `car:${c.id}` }, ...(mb ? [mb] : [])]] : [];
    const photo = c.image_url && /^https?:/.test(c.image_url) ? c.image_url : (c.image_url && baseUrl() ? baseUrl() + c.image_url : null);
    if (photo) await tg.call('sendPhoto', { chat_id: chat, photo, caption: carText(c), parse_mode: 'HTML', reply_markup: { inline_keyboard: kb } });
    else await tg.send(chat, carText(c), { reply_markup: { inline_keyboard: kb } });
  }
}
async function sendTariffs(chat) {
  const { rows } = await db.query(`SELECT brand,model,price_day,price_3d,price_7d,deposit FROM cars WHERE deleted_at IS NULL AND status<>'INACTIVE' ORDER BY brand,model`);
  if (!rows.length) return tg.send(chat, "Tariflar hozircha kiritilmagan.");
  const fee = await settings.getNum('late_fee_per_hour');
  await tg.send(chat, '<b>💰 Tariflar</b> (kunlik)\n\n' + rows.map(c => `<b>${esc(c.brand)} ${esc(c.model)}</b>\n1+ kun: ${money(c.price_day)}\n3+ kun: ${money(c.price_3d)}\n7+ kun: ${money(c.price_7d)}\nDepozit: ${money(c.deposit)}`).join('\n\n') + (fee ? `\n\nKechikish: ${money(fee)} / soat` : ''));
}
async function sendMyBookings(chat, customer) {
  const { rows } = await db.query(`SELECT b.*,car.brand,car.model FROM bookings b JOIN cars car ON car.id=b.car_id WHERE b.customer_id=$1 AND b.deleted_at IS NULL ORDER BY b.id DESC LIMIT 8`, [customer.id]);
  if (!rows.length) return tg.send(chat, "Sizda hali buyurtmalar yo'q. «📅 Bron qilish» tugmasini bosing.");
  await tg.send(chat, '<b>📋 Buyurtmalarim</b>\n\n' + rows.map(b => `${b.code} — ${esc(b.brand)} ${esc(b.model)}\n${fmtDate(b.pickup_at)} — ${fmtDate(b.return_at)}\n${BST[b.status]}\nJami: ${money(b.total_amount)}`).join('\n\n'));
}

/* ---------- Mijoz: bron oqimi ---------- */
const parseDate = s => { const m = /^(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{4})$/.exec((s || '').trim()); return m ? `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}` : null; };
const parseTime = s => { const m = /^(\d{1,2})[:.](\d{2})$/.exec((s || '').trim()); return !m || +m[1] > 23 || +m[2] > 59 ? null : `${m[1].padStart(2, '0')}:${m[2]}`; };
async function startBookingFlow(chat) {
  await contracts.requireActive().catch(async e => { throw e; });
  const { rows } = await db.query(`SELECT id,brand,model,price_day FROM cars WHERE deleted_at IS NULL AND status IN ('AVAILABLE','RESERVED','RENTED') ORDER BY brand,model`);
  if (!rows.length) return tg.send(chat, "Hozircha bron qilish uchun mashina yo'q.");
  await setState(chat, { kind: 'book', step: 'car', data: {} });
  await tg.send(chat, '1/7 — Mashinani tanlang:', { reply_markup: { inline_keyboard: rows.map(c => [{ text: `${c.brand} ${c.model} — ${money(c.price_day)}`, callback_data: `car:${c.id}` }]) } });
}
async function askLocationOrPhone(chat, st, customer) {
  const locs = JSON.parse(await settings.get('locations') || '[]');
  if (locs.length) { st.step = 'location'; await setState(chat, st); return tg.send(chat, '6/7 — Olib ketish joyini tanlang:', { reply_markup: { inline_keyboard: locs.map((l, i) => [{ text: l, callback_data: `loc:${i}` }]) } }); }
  st.data.location = null; return askPhone(chat, st, customer);
}
async function askPhone(chat, st, customer) {
  const c = (await db.query('SELECT phone FROM customers WHERE id=$1', [customer.id])).rows[0];
  if (c?.phone) return quoteStep(chat, st);
  st.step = 'phone'; await setState(chat, st);
  return tg.send(chat, '7/7 — Telefon raqamingizni yuboring:', { reply_markup: { keyboard: [[{ text: '📱 Raqamni yuborish', request_contact: true }]], resize_keyboard: true, one_time_keyboard: true } });
}
async function quoteStep(chat, st) {
  try {
    const car = (await db.query('SELECT * FROM cars WHERE id=$1', [st.data.car_id])).rows[0];
    const q = await db.tx(c => bookings.quote(c, { car, pickup: parseTkt(st.data.pickup_date, st.data.pickup_time), ret: parseTkt(st.data.return_date, st.data.return_time), trusted: false }));
    const t = await contracts.requireActive();
    st.step = 'confirm'; st.data.template_id = t.id; await setState(chat, st);
    await tg.send(chat, `<b>Buyurtma</b>\n${esc(car.brand)} ${esc(car.model)}\n${fmtDate(parseTkt(st.data.pickup_date))} ${st.data.pickup_time} — ${fmtDate(parseTkt(st.data.return_date))} ${st.data.return_time}${st.data.location ? '\nJoy: ' + esc(st.data.location) : ''}\n\n${q.days} kun × ${money(q.rate)} = ${money(q.rental)}\nDepozit: ${money(q.deposit)}\n<b>Jami: ${money(q.grand_total)}</b>`);
    const kb = { reply_markup: { inline_keyboard: [[{ text: "✅ O'qidim, roziman — buyurtma berish", callback_data: 'bk:go' }], [{ text: '❌ Bekor qilish', callback_data: 'bk:x' }]] } };
    if (t.kind === 'PDF') await tg.sendDocument(chat, t.file_path, `📄 <b>${esc(t.title)}</b>\n\nBuyurtma berishdan oldin shartnomani to'liq o'qib chiqing. Rozi bo'lsangiz, pastdagi tugmani bosing.`, kb);
    else { await tg.send(chat, `📄 <b>${esc(t.title)}</b>\nBuyurtma berishdan oldin shartlarni o'qib chiqing:`); await tg.sendLong(chat, esc(t.body), kb); }
  } catch (e) { await clearState(chat); await tg.send(chat, '⚠️ ' + esc(e.message), { reply_markup: MENU }); }
}

/* ---------- Mijoz: to'lov ---------- */
async function startPayment(chat, customer) {
  if (!(await features.enabled('pay_claims'))) return tg.send(chat, "To'lov hozircha botdan qabul qilinmaydi. Operator bilan bog'laning.");
  const accs = await payacc.listAccounts(true);
  if (!accs.length) return tg.send(chat, "To'lov rekvizitlari hali kiritilmagan. Operator bilan bog'laning.");
  const { rows } = await db.query(`SELECT b.id,b.code,b.total_amount,b.paid_amount,b.status,car.brand,car.model,COALESCE(d.amount-d.held_amount,0) dep_left FROM bookings b JOIN cars car ON car.id=b.car_id LEFT JOIN deposits d ON d.booking_id=b.id
    WHERE b.customer_id=$1 AND b.deleted_at IS NULL AND b.status IN ('PENDING','CONFIRMED','ACTIVE','OVERDUE','COMPLETED') ORDER BY b.id DESC LIMIT 10`, [customer.id]);
  const due = rows.filter(b => Number(b.total_amount) > Number(b.paid_amount) || (['PENDING', 'CONFIRMED'].includes(b.status) && Number(b.dep_left) > 0));
  if (!due.length) return tg.send(chat, "To'lanishi kerak bo'lgan buyurtma yo'q ✅");
  const kb = [];
  for (const b of due) {
    const rem = Number(b.total_amount) - Number(b.paid_amount);
    if (rem > 0) kb.push([{ text: `${b.code} ${b.brand} ${b.model} — ijara ${money(rem)}`, callback_data: `pk:${b.id}:R` }]);
    if (['PENDING', 'CONFIRMED'].includes(b.status) && Number(b.dep_left) > 0) kb.push([{ text: `${b.code} — depozit ${money(b.dep_left)}`, callback_data: `pk:${b.id}:D` }]);
  }
  await tg.send(chat, "Qaysi to'lovni amalga oshirmoqchisiz?", { reply_markup: { inline_keyboard: kb } });
}
async function payChosen(chat, customer, bookingId, kindCode) {
  const b = (await db.query(`SELECT b.id,b.code,b.total_amount,b.paid_amount,COALESCE(d.amount-d.held_amount,0) dep_left FROM bookings b LEFT JOIN deposits d ON d.booking_id=b.id WHERE b.id=$1 AND b.customer_id=$2`, [bookingId, customer.id])).rows[0];
  if (!b) return tg.send(chat, 'Buyurtma topilmadi.');
  const kind = kindCode === 'D' ? 'DEPOSIT' : 'RENTAL'; const amount = kind === 'DEPOSIT' ? Number(b.dep_left) : Number(b.total_amount) - Number(b.paid_amount);
  if (amount <= 0) return tg.send(chat, "Bu bo'yicha qarz yo'q ✅");
  const accs = await payacc.listAccounts(true);
  await setState(chat, { kind: 'pay', step: 'receipt', data: { booking_id: b.id, pay_kind: kind, amount, account_id: accs.length === 1 ? accs[0].id : null } });
  await tg.send(chat, `<b>${esc(b.code)} — ${kind === 'DEPOSIT' ? 'depozit' : "ijara to'lovi"}</b>\nTo'lanadigan summa: <b>${money(amount)}</b>\n\n` + accs.map(a => `<code>${esc(payacc.accountText(a))}</code>`).join('\n\n') +
    `\n\nShu rekvizitga to'lang va <b>to'lov chekining rasmini (screenshot)</b> shu yerga yuboring. Admin tekshirib tasdiqlaydi.\n(Bekor qilish: /cancel)`);
}

/* ---------- Admin: xabar yuborish ---------- */
async function adminCommand(chat, cmd, staff) {
  const fin = can(staff, 'finance.read');
  const deny = () => tg.send(chat, "Bu ma'lumot uchun ruxsatingiz yo'q.");
  if (cmd === '/xabar' || cmd === '/hammaga') {
    if (!can(staff, 'messages.send')) return deny();
    if (!(await features.enabled('messages'))) return tg.send(chat, "«Mijozlarga xabar» funksiyasi o'chirilgan (Funksiyalar sahifasida yoqing).");
    if (cmd === '/xabar') { await setState(chat, { kind: 'admin', step: 'search' }); return tg.send(chat, "Qaysi mijozga yozmoqchisiz? Ism yoki telefon raqamini yozing.\n(Bekor qilish: /cancel)"); }
    const n = await messages.countRecipients();
    await setState(chat, { kind: 'admin', step: 'bc_text' });
    return tg.send(chat, `📣 Botga ulangan <b>${n}</b> ta mijozga xabar yuboriladi. Xabar matnini yozing.\n(Bekor qilish: /cancel)`);
  }
  if (cmd === '/dashboard') {
    const d = await reports.dashboard();
    return tg.send(chat, `<b>📊 Dashboard</b>\nJami: ${d.cars.total} | Bo'sh: ${d.cars.available} | Bron: ${d.cars.reserved} | Ijarada: ${d.cars.rented} | Ta'mirda: ${d.cars.maintenance}\n` +
      (fin ? `\nBugungi daromad: ${money(d.today.revenue)}\nXarajat: ${money(d.today.expenses)}\nSof foyda: ${money(d.today.profit)}\n` : '') + `\nBugun qaytadi: ${d.today.returns}\nBugun beriladi: ${d.today.pickups}\nKutilayotgan buyurtmalar: ${d.pending_bookings}`);
  }
  if (cmd === '/cars') {
    const { rows } = await db.query(`SELECT brand,model,plate,status FROM cars WHERE deleted_at IS NULL ORDER BY status,brand`);
    return tg.send(chat, '<b>🚗 Mashinalar</b>\n' + (rows.map(c => `${STATUS[c.status].split(' ')[0]} ${esc(c.brand)} ${esc(c.model)} (${esc(c.plate)})`).join('\n') || "Yo'q"));
  }
  if (cmd === '/bookings') {
    const { rows } = await db.query(`SELECT b.id,b.code,b.status,b.pickup_at,b.return_at,c.first_name||' '||c.last_name cu,car.brand||' '||car.model car FROM bookings b JOIN customers c ON c.id=b.customer_id JOIN cars car ON car.id=b.car_id
      WHERE b.deleted_at IS NULL AND b.status IN ('PENDING','CONFIRMED','ACTIVE','OVERDUE') ORDER BY b.pickup_at LIMIT 12`);
    return tg.send(chat, '<b>📅 Faol buyurtmalar</b>\n' + (rows.map(b => `${b.code} ${BST[b.status]}\n${esc(b.car)} — ${esc(b.cu)}\n${fmtDT(b.pickup_at)} → ${fmtDT(b.return_at)}`).join('\n\n') || "Yo'q"));
  }
  if (cmd === '/users') {
    const { rows } = await db.query(`SELECT first_name,last_name,phone,tg_username,telegram_id,created_at FROM customers WHERE telegram_id IS NOT NULL AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 15`);
    const n = (await db.query('SELECT COUNT(*)::int n FROM customers WHERE telegram_id IS NOT NULL AND deleted_at IS NULL')).rows[0].n;
    return tg.send(chat, `<b>👤 Botga qo'shilganlar</b> (jami ${n})\n\n` + (rows.map(c => `${esc(c.first_name)} ${esc(c.last_name || '')} ${c.tg_username ? '@' + esc(c.tg_username) : ''}\n📞 ${esc(c.phone || "raqam yubormagan")} · ID ${c.telegram_id}`).join('\n\n') || "Yo'q"));
  }
  if (cmd === '/customers') {
    const { rows } = await db.query(`SELECT first_name,last_name,phone FROM customers WHERE deleted_at IS NULL ORDER BY id DESC LIMIT 10`);
    const n = (await db.query('SELECT COUNT(*)::int n FROM customers WHERE deleted_at IS NULL')).rows[0].n;
    return tg.send(chat, `<b>👥 Mijozlar</b> (jami ${n})\n` + rows.map(c => `${esc(c.first_name)} ${esc(c.last_name)} — ${esc(c.phone || '—')}`).join('\n'));
  }
  if (cmd === '/revenue' || cmd === '/expenses' || cmd === '/reports') {
    if (!fin) return deny();
    const t = todayStr(); const m = await reports.summary(t.slice(0, 8) + '01', t); const d = await reports.summary(t, t);
    if (cmd === '/revenue') return tg.send(chat, `<b>💰 Daromad</b>\nBugun: ${money(d.revenue)}\nBu oy: ${money(m.revenue)}`);
    if (cmd === '/expenses') return tg.send(chat, `<b>🧾 Xarajat</b>\nBugun: ${money(d.expenses)}\nBu oy: ${money(m.expenses)}\n\n` + m.expense_categories.map(c => `${esc(c.name)}: ${money(c.amount)}`).join('\n'));
    return tg.send(chat, `<b>📊 Bu oy</b>\nDaromad: ${money(m.revenue)}\nXarajat: ${money(m.expenses)}\nSof foyda: ${money(m.profit)}\nIjaralar: ${m.rentals}\nBandlik: ${m.utilization}%\n\nTop mashinalar:\n` + m.top_cars.map(c => `• ${esc(c.name)}: ${money(c.revenue)}`).join('\n'));
  }
  if (cmd === '/today') {
    const d = await reports.dashboard();
    return tg.send(chat, `<b>📌 Bugungi ishlar</b>\n` + (d.schedule.map(s => `${s.time} — ${esc(s.car)} ${s.kind === 'PICKUP' ? 'berish' : 'qaytishi'} (${esc(s.customer)})`).join('\n') || "Reja yo'q") +
      (d.overdue.length ? `\n\n⚠️ Kechikayotgan:\n` + d.overdue.map(o => `${esc(o.car)} — ${esc(o.customer)}, ${esc(o.phone)}`).join('\n') : ''));
  }
  return false;
}
// Admin holatlari: mijoz qidirish / xabar matni / ommaviy xabar
async function adminState(chat, text, staff, st) {
  if (st.step === 'search') {
    const like = `%${text.replace(/[%_]/g, '')}%`;
    const { rows } = await db.query(`SELECT id,first_name,last_name,phone FROM customers WHERE deleted_at IS NULL AND telegram_id IS NOT NULL AND (first_name||' '||last_name ILIKE $1 OR phone ILIKE $1) ORDER BY id DESC LIMIT 8`, [like]);
    if (!rows.length) return tg.send(chat, "Botga ulangan bunday mijoz topilmadi (mijoz botni ishga tushirgan bo'lishi kerak). Boshqa ism/raqam yozing yoki /cancel.");
    return tg.send(chat, 'Mijozni tanlang:', { reply_markup: { inline_keyboard: rows.map(c => [{ text: `${c.first_name} ${c.last_name} · ${c.phone || '—'}`, callback_data: `wm:${c.id}` }]) } });
  }
  if (st.step === 'msg') {
    const r = await messages.sendToCustomer(st.data.customer_id, text, actor(staff), st.data.reply ? 'REPLY' : 'DIRECT');
    await clearState(chat); return tg.send(chat, `✅ ${esc(r.customer)} ga yuborildi.`);
  }
  if (st.step === 'bc_text') {
    if (text.length > 3500) return tg.send(chat, 'Matn juda uzun (3500 belgigacha).');
    st.step = 'bc_confirm'; st.data = { text }; await setState(chat, st);
    const n = await messages.countRecipients();
    return tg.send(chat, `<b>Ko'rib chiqing</b> — ${n} ta mijozga yuboriladi:\n\n${esc(text)}`, { reply_markup: { inline_keyboard: [[{ text: `✅ ${n} ta mijozga yuborish`, callback_data: 'bc:go' }], [{ text: '❌ Bekor qilish', callback_data: 'bc:x' }]] } });
  }
  return false;
}

/* ---------- Asosiy handler ---------- */
const seen = new Set();
async function handleUpdate(u) {
  if (u.update_id != null) { if (seen.has(u.update_id)) return; seen.add(u.update_id); if (seen.size > 500) seen.delete(seen.values().next().value); }
  try {
    if (u.callback_query) return await onCallback(u.callback_query);
    if (u.message) return await onMessage(u.message);
  } catch (e) {
    if (!(e instanceof AppError)) console.error('Bot xatosi:', e);
    const chat = u.message?.chat?.id || u.callback_query?.message?.chat?.id;
    if (chat) await tg.send(chat, e instanceof AppError ? '⚠️ ' + esc(e.message) : "Xatolik yuz berdi. Keyinroq urinib ko'ring.").catch(() => {});
  }
}

async function onMessage(m) {
  const chat = m.chat.id; const text = (m.text || '').trim();
  if (m.chat.type !== 'private') return;
  const staff = await resolveStaff(m.from.id);
  const customer = await ensureCustomer(m.from, /^\/start\s+(\S+)/.exec(text)?.[1]);
  if (text === '/cancel') { await clearState(chat); return tg.send(chat, 'Bekor qilindi.', { reply_markup: MENU }); }
  if (text.startsWith('/start')) {
    await clearState(chat);
    if (staff) return tg.send(chat, `<b>RENT A CAR — admin</b>\nSalom, ${esc(staff.full_name)}!\n/dashboard /cars /bookings /customers /users /revenue /expenses /today /reports\n\n✉️ /xabar — mijozga alohida xabar\n📣 /hammaga — barcha mijozlarga xabar\n\nYoki savol yozing: «Bugungi foyda», «Bo'sh mashinalar»...`, { reply_markup: MENU });
    const S = await settings.all();
    await tg.send(chat, `<b>${esc(S.company_name)}</b>\nAvtomobil ijarasi — oddiy va tez.`, { reply_markup: MENU });
    if (!customer.phone) await tg.send(chat, "📱 Siz bilan bog'lanish uchun telefon raqamingizni yuboring:", { reply_markup: { keyboard: [[{ text: '📱 Raqamni yuborish', request_contact: true }], [{ text: '⏭ Keyinroq' }]], resize_keyboard: true, one_time_keyboard: true } });
    return;
  }
  const st = await getState(chat);
  if (staff && text.startsWith('/')) { const r = await adminCommand(chat, text.split(/[@\s]/)[0], staff); if (r !== false) return; }
  if (st) {
    if (st.kind === 'admin' && staff && text) { const r = await adminState(chat, text, staff, st); if (r !== false) return; }
    if (st.kind === 'pay' && st.step === 'receipt') {
      const photo = m.photo?.length ? m.photo[m.photo.length - 1].file_id : (m.document?.mime_type?.startsWith('image/') ? m.document.file_id : null);
      if (!photo) return tg.send(chat, "Iltimos, to'lov chekining <b>rasmini</b> yuboring (screenshot). Bekor qilish: /cancel");
      await payacc.createClaim(customer, { booking_id: st.data.booking_id, amount: st.data.amount, kind: st.data.pay_kind, account_id: st.data.account_id, receipt_tg_file_id: photo, note: m.caption });
      await clearState(chat); return tg.send(chat, "✅ To'lov so'rovingiz yuborildi. Admin chekni tekshirib tasdiqlaydi, natija haqida xabar olasiz.", { reply_markup: MENU });
    }
    if (st.kind === 'book') {
      const ask = t => tg.send(chat, t, { reply_markup: { remove_keyboard: true } });
      if (st.step === 'pickup_date') { const d = parseDate(text); if (!d || !validDate(d)) return ask("Sanani DD.MM.YYYY ko'rinishida to'g'ri yozing. Masalan: " + fmtDate(new Date(Date.now() + 864e5))); if (d < todayStr()) return ask("Bu sana o'tib ketgan. Bugundan keyingi sanani yozing."); st.data.pickup_date = d; st.step = 'pickup_time'; await setState(chat, st); return ask('3/7 — Olish vaqtini yozing (24 soatlik, masalan 10:00):'); }
      if (st.step === 'pickup_time') { const t = parseTime(text); if (!t) return ask("Vaqtni HH:MM ko'rinishida yozing. Masalan: 10:00"); if (parseTkt(st.data.pickup_date, t) < new Date()) return ask("Bu vaqt o'tib ketgan. Keyingi vaqtni yozing."); st.data.pickup_time = t; st.step = 'return_date'; await setState(chat, st); return ask('4/7 — Qaytarish sanasini yozing (DD.MM.YYYY):'); }
      if (st.step === 'return_date') { const d = parseDate(text); if (!d || !validDate(d)) return ask("Sanani DD.MM.YYYY ko'rinishida to'g'ri yozing."); if (d < st.data.pickup_date) return ask("Qaytarish sanasi olish sanasidan oldin bo'lishi mumkin emas. Qaytadan yozing."); st.data.return_date = d; st.step = 'return_time'; await setState(chat, st); return ask('5/7 — Qaytarish vaqtini yozing (masalan 18:00):'); }
      if (st.step === 'return_time') { const t = parseTime(text); if (!t) return ask("Vaqtni HH:MM ko'rinishida yozing."); if (parseTkt(st.data.return_date, t) <= parseTkt(st.data.pickup_date, st.data.pickup_time)) return ask("Qaytarish vaqti olish vaqtidan keyin bo'lishi kerak. Qaytarish vaqtini qayta yozing."); st.data.return_time = t; return askLocationOrPhone(chat, st, customer); }
      if (st.step === 'phone') {
        const phone = m.contact ? m.contact.phone_number : text;
        if (!/^\+?[0-9 ()-]{7,20}$/.test(phone || '')) return tg.send(chat, "Telefon raqamini yuboring (masalan +998901234567) yoki «Raqamni yuborish» tugmasini bosing.");
        const d = String(phone).replace(/\D/g, ''); await db.query('UPDATE customers SET phone=$2 WHERE id=$1', [customer.id, d.length === 9 ? '+998' + d : '+' + d]);
        return quoteStep(chat, st);
      }
    }
  }
  if (m.contact) {
    if (m.contact.user_id && m.contact.user_id !== m.from.id) return tg.send(chat, "Iltimos, o'zingizning raqamingizni yuboring.", { reply_markup: MENU });
    const ph = contactsSvc.normPhone(m.contact.phone_number);
    await db.query('UPDATE customers SET phone=$2 WHERE id=$1', [customer.id, ph]);
    const { notify } = require('../services/notify');
    if (!staff) await notify({ audience: 'ADMIN', type: 'NEW_USER', title: '📞 Mijoz telefon raqamini yubordi', ref_key: `phone:${customer.id}:${ph}`, body: `${customer.first_name} ${customer.last_name || ''}${customer.tg_username ? ' @' + customer.tg_username : ''}\n${ph}` }).catch(() => {});
    return tg.send(chat, 'Telefon raqamingiz saqlandi ✅', { reply_markup: MENU });
  }
  switch (text) {
    case '🚗 Mashinalar': return sendCars(chat);
    case '📅 Bron qilish': return startBookingFlow(chat);
    case '📋 Mening buyurtmalarim': return sendMyBookings(chat, customer);
    case "💳 To'lov": return startPayment(chat, customer);
    case '💰 Tariflar': return sendTariffs(chat);
    case '📍 Manzil': { const S = await settings.all(); if (S.office_lat && S.office_lng) await tg.call('sendLocation', { chat_id: chat, latitude: +S.office_lat, longitude: +S.office_lng }); return tg.send(chat, `📍 ${esc(S.company_address || 'Manzil kiritilmagan')}`); }
    case '⏭ Keyinroq': return tg.send(chat, 'Xo\'p, menyudan tanlang 👇', { reply_markup: MENU });
    case '☎️ Operator': {
      const list = await contactsSvc.list(true); const S = await settings.all();
      if (list.length) return tg.send(chat, '<b>☎️ Aloqa</b>\n\n' + contactsSvc.asText(list) + '\n\nYoki shu yerga savolingizni yozing — operator javob beradi.');
      return tg.send(chat, `${S.company_phone ? '☎️ ' + esc(S.company_phone) + '\n' : ''}Savolingizni shu yerga yozing — operator javob beradi.`);
    }
  }
  if (staff && can(staff, 'ai.use') && text && (await features.enabled('ai'))) {
    const a = await assistant.ask(text);
    if (!can(staff, 'finance.read') && /foyda|daromad|xarajat/i.test(text)) return tg.send(chat, "Moliyaviy ma'lumot uchun ruxsatingiz yo'q.");
    return tg.send(chat, esc(a.answer) + (a.examples ? '\n\n' + a.examples.map(x => '• ' + esc(x)).join('\n') : ''));
  }
  // Mijozning erkin yozgan xabari — adminlarga yetkaziladi (javob berish tugmasi bilan)
  if (text && !staff) {
    await messages.logInbound(customer.id, text);
    const { adminChatIds } = require('../services/notify');
    const kb = { reply_markup: { inline_keyboard: [[{ text: '✉️ Javob berish', callback_data: `rp:${customer.id}` }]] } };
    for (const a of await adminChatIds()) await tg.send(a, `💬 <b>Mijozdan xabar</b>\n${esc(customer.first_name)} ${esc(customer.last_name || '')}${customer.phone ? ' · ' + esc(customer.phone) : ''}\n\n${esc(text)}`, kb);
    return tg.send(chat, 'Xabaringiz operatorga yuborildi ✅ Tez orada javob beramiz.', { reply_markup: MENU });
  }
  return tg.send(chat, 'Menyudan tanlang 👇', { reply_markup: MENU });
}

async function onCallback(cb) {
  const chat = cb.message.chat.id; const data = cb.data || '';
  const answer = (t, alert = false) => tg.call('answerCallbackQuery', { callback_query_id: cb.id, text: t, show_alert: alert });
  const staff = await resolveStaff(cb.from.id);

  // ---- Admin tugmalari ----
  if (/^bk:(ok|no|ct):\d+$/.test(data)) {
    if (!can(staff, 'bookings.write')) return answer("Ruxsat yo'q", true);
    const [, act, id] = data.split(':');
    if (act === 'ok') { await bookings.confirmBooking(+id, actor(staff), null); await answer('Tasdiqlandi ✅'); return tg.send(chat, `✅ Buyurtma ${id} tasdiqlandi. Mijozga xabar va shartnoma yuborildi.`); }
    if (act === 'no') { await bookings.cancelBooking(+id, actor(staff), null, { reason: 'Admin rad etdi' }); await answer('Rad etildi'); return tg.send(chat, `❌ Buyurtma ${id} rad etildi. Mijozga xabar yuborildi.`); }
    const b = await bookings.getBooking(+id); await answer(); return tg.send(chat, `💬 ${esc(b.first_name)} ${esc(b.last_name)}\n☎️ ${esc(b.phone)}${b.customer_tg ? `\n<a href="tg://user?id=${b.customer_tg}">Telegramda yozish</a>` : ''}`);
  }
  if (/^pc:(ok|no):\d+$/.test(data)) {
    if (!can(staff, 'payments.write')) return answer("Ruxsat yo'q", true);
    const [, act, id] = data.split(':');
    if (act === 'ok') { await payacc.confirmClaim(+id, actor(staff), null); await answer('Tasdiqlandi ✅'); return tg.send(chat, `✅ To'lov so'rovi #${id} tasdiqlandi, mijozga xabar yuborildi.`); }
    await payacc.rejectClaim(+id, 'Admin rad etdi', actor(staff), null); await answer('Rad etildi'); return tg.send(chat, `❌ To'lov so'rovi #${id} rad etildi.`);
  }
  if (/^(wm|rp):\d+$/.test(data)) {
    if (!can(staff, 'messages.send')) return answer("Ruxsat yo'q", true);
    const [k, id] = data.split(':'); const c = (await db.query('SELECT first_name,last_name FROM customers WHERE id=$1', [id])).rows[0];
    if (!c) return answer('Mijoz topilmadi', true);
    await setState(chat, { kind: 'admin', step: 'msg', data: { customer_id: +id, reply: k === 'rp' } }); await answer();
    return tg.send(chat, `✉️ <b>${esc(c.first_name)} ${esc(c.last_name)}</b> ga yoziladigan xabar matnini yuboring.\n(Bekor qilish: /cancel)`);
  }
  if (data === 'bc:go' || data === 'bc:x') {
    if (!can(staff, 'messages.send')) return answer("Ruxsat yo'q", true);
    const st = await getState(chat);
    if (data === 'bc:x' || !st || st.step !== 'bc_confirm') { await clearState(chat); return answer('Bekor qilindi'); }
    await answer('Yuborilmoqda...'); await clearState(chat);
    const r = await messages.broadcast(st.data.text, actor(staff), null);
    return tg.send(chat, r.done ? `✅ Yuborildi: ${r.sent} ta, xato: ${r.failed} ta.` : `📣 ${r.total} ta mijozga yuborish boshlandi. Tugagach xabar beraman.`);
  }

  // ---- Mijoz tugmalari ----
  if (/^cs:\d+:\d+$/.test(data)) {   // shartnomaga rozilik (admin yaratgan buyurtma uchun)
    const [, bid, tid] = data.split(':'); await answer();
    try {
      const created = await bookings.acceptViaBot(+bid, +tid, cb.from.id);
      return tg.send(chat, created ? "✅ Rahmat! Shartnoma shartlari bilan roziligingiz qabul qilindi." : "Roziligingiz avval qabul qilingan ✅");
    } catch (e) { return tg.send(chat, '⚠️ ' + esc(e.message)); }
  }
  const customer = await ensureCustomer(cb.from);
  if (data.startsWith('car:')) {
    try { await contracts.requireActive(); } catch (e) { await answer(); return tg.send(chat, '⚠️ ' + esc(e.message)); }
    await setState(chat, { kind: 'book', step: 'pickup_date', data: { car_id: +data.slice(4) } }); await answer();
    return tg.send(chat, '2/7 — Olish sanasini yozing (DD.MM.YYYY). Masalan: ' + fmtDate(new Date(Date.now() + 864e5)));
  }
  if (/^pk:\d+:[RD]$/.test(data)) { await answer(); const [, id, k] = data.split(':'); return payChosen(chat, customer, +id, k); }
  const st = await getState(chat);
  if (data.startsWith('loc:') && !(st?.kind === 'book' && st.step === 'location')) { await answer(); return tg.send(chat, EXPIRED, { reply_markup: MENU }); }
  if (data.startsWith('loc:') && st?.kind === 'book' && st.step === 'location') {
    const locs = JSON.parse(await settings.get('locations') || '[]'); st.data.location = locs[+data.slice(4)] || locs[0]; await answer();
    return askPhone(chat, st, customer);
  }
  if (data === 'bk:x') { await clearState(chat); await answer('Bekor qilindi'); return tg.send(chat, 'Bekor qilindi.', { reply_markup: MENU }); }
  if (data === 'bk:go') {
    const st2 = await takeState(chat);   // atomik: ikki marta bosilsa ikkinchisi o'tmaydi
    if (!st2 || st2.kind !== 'book' || st2.step !== 'confirm') { await answer(); return tg.send(chat, EXPIRED, { reply_markup: MENU }); }
    await answer('Yuborilmoqda...');
    try {
      const b = await bookings.createBooking({ customer_id: customer.id, car_id: st2.data.car_id, pickup_at: parseTkt(st2.data.pickup_date, st2.data.pickup_time), return_at: parseTkt(st2.data.return_date, st2.data.return_time),
        location: st2.data.location, source: 'BOT', consent: { accepted: true, template_id: st2.data.template_id, ua: 'telegram-bot' } }, null, null);
      return tg.send(chat, `✅ Buyurtmangiz qabul qilindi: <b>${esc(b.code)}</b>\nShartnoma shartlariga rozilik bergansiz. Operator tez orada tasdiqlaydi — natijani shu yerda olasiz.`, { reply_markup: MENU });
    } catch (e) { return tg.send(chat, '⚠️ ' + esc(e.message), { reply_markup: MENU }); }
  }
  return answer();
}

/* ---------- Ishga tushirish ---------- */
let pollStop = false;
async function init(app) {
  if (!cfg.botToken) { console.log("Bot: BOT_TOKEN yo'q — bot o'chiq (admin panel va API ishlaydi)"); return; }
  app.post(`/bot/webhook/${webhookSecret()}`, require('express').json({ limit: '1mb' }), (req, res) => {
    if (req.headers['x-telegram-bot-api-secret-token'] !== webhookSecret()) return res.sendStatus(403);
    res.sendStatus(200); handleUpdate(req.body).catch(e => console.error('Bot handler:', e.message));
  });
  if (baseUrl().startsWith('https://')) {
    const r = await tg.call('setWebhook', { url: `${baseUrl()}/bot/webhook/${webhookSecret()}`, secret_token: webhookSecret(), allowed_updates: ['message', 'callback_query'], drop_pending_updates: false });
    console.log('Bot webhook:', r.ok ? "o'rnatildi" : r.description);
    await tg.call('setChatMenuButton', { menu_button: { type: 'web_app', text: 'Ochish', web_app: { url: `${baseUrl()}/app/` } } });
  } else {
    await tg.call('deleteWebhook', {});
    let offset = 0;
    (async function poll() { while (!pollStop) { try { const r = await tg.call('getUpdates', { offset, timeout: 25 }); if (r.ok) for (const u of r.result) { offset = u.update_id + 1; await handleUpdate(u); } else await new Promise(s => setTimeout(s, 3000)); } catch (e) { console.error('Polling:', e.message); await new Promise(s => setTimeout(s, 3000)); } } })();
    console.log('Bot: long polling rejimi');
  }
}
module.exports = { init, handleUpdate, resolveStaff, stop: () => { pollStop = true; } };
