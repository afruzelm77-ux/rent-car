const express = require('express');
const { wrap, AppError } = require('../util');
const gps = require('../services/gps');
const r = express.Router();
// GPS qurilma / tracker shu manzilga yuboradi: POST yoki GET /api/gps/<maxfiy_kalit>?lat=..&lng=..&speed=..
r.all('/:token', wrap(async (req, res) => {
  const carId = await gps.byToken(req.params.token);
  if (!carId) throw new AppError(404, 'Topilmadi');
  const d = { ...req.query, ...(req.body || {}) };
  await gps.record(carId, { lat: d.lat, lng: d.lng ?? d.lon, speed: d.speed }, 'DEVICE');
  res.json({ ok: true });
}));
module.exports = r;
