const express = require('express');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const { z } = require('zod');
const cfg = require('../config');
const db = require('../db');
const { AppError, wrap, encrypt, parseTkt, todayStr, addDays } = require('../util');
const bookings = require('../services/bookings');
const settings = require('../services/settings');
const { notify } = require('../services/notify');
const { audit } = require('../audit');
const contract = require('../services/contract');
const contactsSvc = require('../services/contacts');
const payacc = require('../services/payacc');
const features = require('../services/features');
const up = require('../upload');
const econtract = require('../services/econtract');

const r = express.Router();

// Telegram WebApp initData ni HMAC bilan xavfsiz tekshirish (https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app)
function verifyInitData(initData, token, maxAgeSec = 86400) {
  const params = new URLSearchParams(initData || '');
  const hash = params.get('hash');
  if (!hash) throw new AppError(401, "Telegram ma'lumoti yo'q", 'UNAUTH');
  params.delete('hash');
  const dcs = [...params.entries()].map(([k, v]) => `${k}=${v}`).sort().join('\n');
  const secret = crypto.createHmac('sha256', 'WebAppData').update(token).digest();
  const calc = crypto.createHmac('sha256', secret).update(dcs).digest('hex');
  const a = Buffer.from(calc, 'hex'), b = Buffer.from(hash, 'hex');
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) throw new AppError(401, "Telegram imzosi noto'g'ri", 'UNAUTH');
  if (Date.now() / 1000 - Number(params.get('auth_date') || 0) > maxAgeSec) throw new AppError(401, 'Sessiya eskirgan, Mini App ni qayta oching', 'UNAUTH');
  try { return { user: JSON.parse(params.get('user')), start_param: params.get('start_param') }; } catch { throw new AppError(401, "Foydalanuvchi ma'lumoti noto'g'ri", 'UNAUTH'); }
}

async function ensureCustomer(tgUser, startParam, via = 'BOT') {
  let c = (await db.query('SELECT * FROM customers WHERE telegram_id=$1 AND deleted_at IS NULL', [tgUser.id])).rows[0];
  const uname = tgUser.username ? String(tgUser.username).slice(0, 40) : null;
  if (c) {   // username o'zgargan bo'lsa yoki 1 daqiqadan beri ko'rinmagan bo'lsa yangilanadi
    if ((uname && uname !== c.tg_username) || !c.last_seen_at || Date.now() - new Date(c.last_seen_at) > 60e3) {
      c = (await db.query('UPDATE customers SET tg_username=COALESCE($2,tg_username), last_seen_at=now() WHERE id=$1 RETURNING *', [c.id, uname])).rows[0];
    }
    return c;
  }
  const code = 'C' + crypto.randomBytes(4).toString('hex').toUpperCase().slice(0, 6);
  let refBy = null;
  const m = /^ref_([A-Za-z0-9]+)$/.exec(startParam || '');
  if (m) refBy = (await db.query('SELECT id FROM customers WHERE referral_code=$1', [m[1]])).rows[0]?.id || null;
  c = (await db.query(`INSERT INTO customers(first_name,last_name,phone,telegram_id,tg_username,referral_code,referred_by,joined_via,last_seen_at) VALUES($1,$2,'',$3,$4,$5,$6,$7,now()) RETURNING *`,
    [String(tgUser.first_name || 'Mijoz').slice(0, 60), String(tgUser.last_name || '').slice(0, 60), tgUser.id, uname, code, refBy, via])).rows[0];
  if (refBy) await rewardReferral(refBy, c.id);
  if (!cfg.adminChatIds.includes(String(tgUser.id))) {   // adminga: yangi foydalanuvchi qo'shildi
    await notify({ audience: 'ADMIN', type: 'NEW_USER', title: "🆕 Yangi foydalanuvchi", ref_key: `newuser:${c.id}`,
      body: `${c.first_name} ${c.last_name || ''}\n${uname ? '@' + uname : 'username yo\'q'}\nTelegram ID: ${tgUser.id}\nManba: ${via === 'MINIAPP' ? 'Mini App' : 'Bot'}${refBy ? '\n(taklif havolasi orqali)' : ''}` }).catch(() => {});
  }
  return c;
}
// Referral: yangi mijoz havola orqali kelganda eski mijozga bonus yoziladi
async function rewardReferral(referrerId, referredId) {
  const bonus = await settings.getNum('referral_bonus');
  if (!bonus || !(await require('../services/features').enabled('referral'))) return;
  const ins = await db.query(`INSERT INTO referrals(referrer_id,referred_id,bonus_amount) VALUES($1,$2,$3) ON CONFLICT (referred_id) DO NOTHING RETURNING id`, [referrerId, referredId, bonus]);
  if (ins.rows[0]) {
    await db.query('UPDATE customers SET bonus_balance=bonus_balance+$2 WHERE id=$1', [referrerId, bonus]);
    await notify({ audience: 'CUSTOMER', customer_id: referrerId, type: 'REFERRAL_BONUS', title: 'Referral bonus 🎁', body: `Siz taklif qilgan do'st qo'shildi. Bonus: ${bonus} so'm`, ref_key: `ref:${referredId}` });
  }
}

r.post('/auth', wrap(async (req, res) => {
  let tgUser, start;
  if (req.body.initData && cfg.botToken) ({ user: tgUser, start_param: start } = verifyInitData(req.body.initData, cfg.botToken));
  else if (process.env.ALLOW_DEV_AUTH === 'true' && !cfg.isProd && req.body.dev_user) { tgUser = { id: Number(req.body.dev_user.id), first_name: String(req.body.dev_user.first_name || 'Demo') }; start = req.body.start_param; }
  else if (!cfg.botToken) throw new AppError(503, "Bot sozlanmagan: BOT_TOKEN kiriting", 'NO_BOT');
  else throw new AppError(401, "Telegram orqali oching", 'UNAUTH');
  if (!tgUser?.id) throw new AppError(401, "Foydalanuvchi aniqlanmadi", 'UNAUTH');
  const c = await ensureCustomer(tgUser, start, 'MINIAPP');
  const token = jwt.sign({ typ: 'customer', cid: c.id }, cfg.jwtSecret, { expiresIn: '12h' });
  res.json({ token, customer: pub(c) });
}));

const pub = c => ({ id: c.id, first_name: c.first_name, last_name: c.last_name, phone: c.phone, address: c.address || '', referral_code: c.referral_code, bonus_balance: Number(c.bonus_balance), has_documents: !!(c.passport_enc && c.license_enc) });

const auth = wrap(async (req, res, next) => {
  const h = req.headers.authorization || '';
  let p; try { p = jwt.verify(h.replace('Bearer ', ''), cfg.jwtSecret); } catch { throw new AppError(401, 'Sessiya tugagan', 'UNAUTH'); }
  if (p.typ !== 'customer') throw new AppError(401, "Ruxsat yo'q", 'UNAUTH');
  const c = (await db.query('SELECT * FROM customers WHERE id=$1 AND deleted_at IS NULL', [p.cid])).rows[0];
  if (!c) throw new AppError(401, 'Mijoz topilmadi', 'UNAUTH');
  if (c.is_blocked) throw new AppError(403, 'Hisobingiz bloklangan. Operator bilan bog\'laning');
  req.customer = c; next();
});

let botUsername = null;
r.get('/config', wrap(async (req, res) => {
  const S = await settings.all();
  if (!botUsername && cfg.botToken) { const { tg } = require('../services/notify'); const me = await tg.call('getMe', {}); botUsername = me?.result?.username || null; }
  res.json({ contacts: await contactsSvc.list(true), features: await features.flags(), bot_username: botUsername, company: { name: S.company_name, phone: S.company_phone, address: S.company_address }, locations: JSON.parse(S.locations), extras: JSON.parse(S.extras_catalog),
    delivery: await (async () => { const f = await bookings.deliveryFee(); return { enabled: f != null, fee: f || 0 }; })(), late_fee_per_hour: Number(S.late_fee_per_hour), late_grace_minutes: Number(S.late_grace_minutes) });
}));
r.get('/contract', auth, wrap(async (req, res) => {
  const t = await contract.requireActive();
  res.json({ id: t.id, version: t.version, title: t.title, kind: t.kind, body: t.kind === 'PDF' ? '' : t.body, pdf_url: t.kind === 'PDF' ? '/contract.pdf' : null, file_name: t.file_name });
}));

// To'lov joylari (karta/bank) — faqat faol bo'lganlari, mijozga ko'rsatiladi
r.get('/payment-accounts', auth, wrap(async (req, res) => {
  const on = await features.enabled('pay_claims');
  res.json({ enabled: on, accounts: on ? (await payacc.listAccounts(true)).map(a => ({ id: a.id, kind: a.kind, title: a.title, card_number: a.card_number, holder_name: a.holder_name, bank_name: a.bank_name, account_number: a.account_number, note: a.note })) : [] });
}));
r.post('/receipt', auth, up.mem.single('file'), wrap(async (req, res) => { const f = up.save(req.file, 'private'); res.json({ file: f.name }); }));
r.post('/payment-claims', auth, wrap(async (req, res) => {
  const d = vp(z.object({ booking_id: z.coerce.number().int().positive(), amount: z.coerce.number().int().positive(), kind: z.enum(['RENTAL', 'DEPOSIT']).default('RENTAL'),
    account_id: z.coerce.number().int().positive().optional(), receipt_file: z.string().regex(/^[a-f0-9]{32}\.(jpg|png|webp)$/).optional(), note: z.string().max(300).optional() }), req.body);
  res.status(201).json(await payacc.createClaim(req.customer, d));
}));
r.get('/payment-claims', auth, wrap(async (req, res) => {
  const { rows } = await db.query(`SELECT pc.id,pc.booking_id,pc.kind,pc.amount,pc.status,pc.reject_reason,pc.created_at,b.code FROM payment_claims pc JOIN bookings b ON b.id=pc.booking_id WHERE pc.customer_id=$1 ORDER BY pc.id DESC LIMIT 30`, [req.customer.id]);
  res.json(rows);
}));
r.get('/cars', auth, wrap(async (req, res) => {
  const { rows } = await db.query(`SELECT id,brand,model,plate,year,color,transmission,fuel_type,seats,price_day,price_3d,price_7d,deposit,status,image_url,body_type,description,
      (SELECT COALESCE(json_agg(url ORDER BY sort_order,id),'[]') FROM car_images WHERE car_id=cars.id) images
    FROM cars WHERE deleted_at IS NULL AND status<>'INACTIVE' ORDER BY (status='AVAILABLE') DESC, brand, model`);
  res.json(rows);
}));
r.get('/cars/:id', auth, wrap(async (req, res) => {
  const car = (await db.query(`SELECT id,brand,model,year,color,transmission,fuel_type,seats,price_day,price_3d,price_7d,deposit,status,image_url,body_type,description,
      (SELECT COALESCE(json_agg(url ORDER BY sort_order,id),'[]') FROM car_images WHERE car_id=cars.id) images FROM cars WHERE id=$1 AND deleted_at IS NULL AND status<>'INACTIVE'`, [req.params.id])).rows[0];
  if (!car) throw new AppError(404, 'Mashina topilmadi');
  // Kalendar: faqat band vaqt oralig'i (shaxsiy ma'lumotsiz)
  const busy = (await db.query(`SELECT pickup_at,return_at FROM bookings WHERE car_id=$1 AND deleted_at IS NULL AND status IN ('PENDING','CONFIRMED','ACTIVE','OVERDUE') AND return_at>now() ORDER BY pickup_at`, [req.params.id])).rows;
  const days = [];
  for (let i = 0; i < 60; i++) {
    const d = addDays(todayStr(), i), s = parseTkt(d).getTime(), e = s + 864e5;
    days.push({ date: d, busy: busy.some(b => new Date(b.pickup_at).getTime() < e && new Date(b.return_at).getTime() > s) || (car.status === 'MAINTENANCE' && i < 3) });
  }
  res.json({ ...car, calendar: days });
}));
const consentSchema = { accept_terms: z.boolean().optional(), template_id: z.coerce.number().int().positive().optional() };
const qSchema = z.object({ car_id: z.coerce.number().int().positive(), pickup_date: z.string(), pickup_time: z.string(), return_date: z.string(), return_time: z.string(),
  delivery_address: z.string().max(250).optional().nullable(), promo_code: z.string().max(40).optional().nullable(), extras: z.array(z.object({ name: z.string().max(80), qty: z.coerce.number().int().min(1).max(5).default(1) })).max(6).optional() });
const vp = (schema, data) => { const x = schema.safeParse(data); if (!x.success) throw new AppError(400, `Noto'g'ri maydon: ${x.error.issues[0].path.join('.')}`); return x.data; };

r.post('/quote', auth, wrap(async (req, res) => {
  const d = vp(qSchema, req.body);
  const car = (await db.query('SELECT * FROM cars WHERE id=$1 AND deleted_at IS NULL', [d.car_id])).rows[0];
  if (!car) throw new AppError(404, 'Mashina topilmadi');
  const q = await db.tx(c => bookings.quote(c, { car, pickup: parseTkt(d.pickup_date, d.pickup_time), ret: parseTkt(d.return_date, d.return_time), promo_code: d.promo_code, extras: d.extras, trusted: false, delivery: !!d.delivery_address }));
  delete q.promo; res.json(q);
}));
r.post('/bookings', auth, wrap(async (req, res) => {
  const d = vp(qSchema.extend({ location: z.string().max(120).optional().nullable(), phone: z.string().regex(/^\+?[0-9 ()-]{7,20}$/, "Telefon noto'g'ri").optional(),
    passport: z.string().max(30).optional(), license: z.string().max(30).optional(), address: z.string().max(250).optional(), ...consentSchema }), req.body);
  const c = req.customer;
  const phone = d.phone ? normPhone(d.phone) : c.phone;
  if (!phone) throw new AppError(400, 'Telefon raqamingizni kiriting');
  await db.query(`UPDATE customers SET phone=$2, passport_enc=COALESCE($3,passport_enc), license_enc=COALESCE($4,license_enc), passport_last4=COALESCE($5,passport_last4), address=COALESCE($6,address) WHERE id=$1`,
    [c.id, phone, d.passport ? encrypt(d.passport) : null, d.license ? encrypt(d.license) : null, d.passport ? d.passport.slice(-3) : null, d.address || null]);
  const active = (await db.query(`SELECT COUNT(*)::int n FROM bookings WHERE customer_id=$1 AND status='PENDING' AND deleted_at IS NULL`, [c.id])).rows[0].n;
  if (active >= 3) throw new AppError(429, "Sizda tasdiqlanmagan 3 ta buyurtma bor. Operator javobini kuting");
  const b = await bookings.createBooking({ customer_id: c.id, car_id: d.car_id, pickup_at: parseTkt(d.pickup_date, d.pickup_time), return_at: parseTkt(d.return_date, d.return_time),
    location: d.location, delivery_address: d.delivery_address, promo_code: d.promo_code, extras: d.extras, source: 'MINIAPP',
    consent: { accepted: d.accept_terms === true, template_id: d.template_id, ip: req.ip, ua: req.headers['user-agent'] } }, null, req);
  res.status(201).json(brief(b));
}));
const normPhone = p => { const x = String(p).replace(/\D/g, ''); return x.length === 9 ? '+998' + x : '+' + x; };
const brief = b => ({ contract_id: b.contract_id ?? (b.econtract ? b.econtract.id : null), contract_status: b.contract_status ?? (b.econtract ? b.econtract.status : null), dep_left: Math.max(0, Number(b.deposit_amount || 0) - Number(b.dep_held || 0)), id: b.id, code: b.code, status: b.status, car: `${b.brand} ${b.model}`, plate: b.plate, image: b.car_image || null, pickup_at: b.pickup_at, return_at: b.return_at, days: b.days, pickup_location: b.pickup_location,
  rental: Number(b.rental_amount), discount: Number(b.discount), extras: Number(b.extras_amount), total: Number(b.total_amount), paid: Number(b.paid_amount), deposit: Number(b.deposit_amount), remaining: Number(b.total_amount) - Number(b.paid_amount) });
r.get('/bookings', auth, wrap(async (req, res) => {
  const { rows } = await db.query(`SELECT b.id,b.code,b.status,b.pickup_at,b.return_at,b.days,b.pickup_location,b.rental_amount,b.discount,b.extras_amount,b.total_amount,b.paid_amount,b.deposit_amount,
      car.brand,car.model,car.plate,car.image_url car_image,dep.held_amount dep_held,ec.id contract_id,ec.status contract_status FROM bookings b JOIN cars car ON car.id=b.car_id LEFT JOIN deposits dep ON dep.booking_id=b.id LEFT JOIN econtracts ec ON ec.booking_id=b.id WHERE b.customer_id=$1 AND b.deleted_at IS NULL ORDER BY b.id DESC LIMIT 50`, [req.customer.id]);
  res.json(rows.map(brief));
}));
r.post('/bookings/:id/cancel', auth, wrap(async (req, res) => {
  const b = (await db.query('SELECT id,status FROM bookings WHERE id=$1 AND customer_id=$2', [req.params.id, req.customer.id])).rows[0];
  if (!b) throw new AppError(404, 'Buyurtma topilmadi');
  if (b.status !== 'PENDING') throw new AppError(409, "Faqat tasdiqlanmagan buyurtmani bekor qilish mumkin. Operator bilan bog'laning");
  res.json(brief(await bookings.cancelBooking(b.id, { name: `Mijoz #${req.customer.id}` }, req, { reason: 'Mijoz bekor qildi' })));
}));
r.get('/me', auth, wrap(async (req, res) => {
  const refs = (await db.query('SELECT COUNT(*)::int n FROM referrals WHERE referrer_id=$1', [req.customer.id])).rows[0].n;
  res.json({ ...pub(req.customer), referrals: refs });
}));
r.patch('/me', auth, wrap(async (req, res) => {
  const d = vp(z.object({ first_name: z.string().min(1).max(60).optional(), last_name: z.string().max(60).optional(), phone: z.string().regex(/^\+?[0-9 ()-]{7,20}$/).optional(),
    passport: z.string().max(30).optional(), license: z.string().max(30).optional(), address: z.string().max(250).optional() }), req.body);
  await db.query(`UPDATE customers SET first_name=COALESCE($2,first_name), last_name=COALESCE($3,last_name), phone=COALESCE($4,phone), passport_enc=COALESCE($5,passport_enc), license_enc=COALESCE($6,license_enc),
    passport_last4=COALESCE($7,passport_last4), address=COALESCE($8,address) WHERE id=$1`, [req.customer.id, d.first_name, d.last_name, d.phone && normPhone(d.phone), d.passport ? encrypt(d.passport) : null, d.license ? encrypt(d.license) : null, d.passport ? d.passport.slice(-3) : null, d.address || null]);
  const c = (await db.query('SELECT * FROM customers WHERE id=$1', [req.customer.id])).rows[0];
  res.json(pub(c));
}));

/* ---------- Elektron shartnomalar (har bir mijoz FAQAT o'zinikini ko'radi) ---------- */
const sendPdf = (res, f, dl) => { res.setHeader('Content-Type', 'application/pdf'); res.setHeader('Content-Disposition', `${dl ? 'attachment' : 'inline'}; filename="${f.name}"`); res.setHeader('Cache-Control', 'no-store'); res.setHeader('X-Content-Type-Options', 'nosniff'); res.send(f.bytes); };
const usedTokens = new Set();
r.get('/contracts/file/:token', wrap(async (req, res) => {   // bir martalik, 2 daqiqalik havola (faqat tasdiqlangan shartnoma uchun, auth orqali olingan)
  let p; try { p = jwt.verify(req.params.token, cfg.jwtSecret); } catch { throw new AppError(401, 'Havola eskirgan. Mini App dan qayta oching', 'UNAUTH'); }
  if (p.typ !== 'pdf' || usedTokens.has(p.jti)) throw new AppError(401, 'Havola allaqachon ishlatilgan', 'UNAUTH');
  usedTokens.add(p.jti); setTimeout(() => usedTokens.delete(p.jti), 5 * 60e3).unref();
  const c = await econtract.mine(p.id, p.cid);
  await econtract.logEvent(db, c.id, 'PDF_DOWNLOAD', 'mijoz', { via: 'link' }, req.ip);
  sendPdf(res, await econtract.pdfFor(c), req.query.dl === '1');
}));
r.get('/contracts', auth, wrap(async (req, res) => res.json(await econtract.listForCustomer(req.customer.id))));
r.get('/contracts/:id', auth, wrap(async (req, res) => { const { v } = await econtract.customerView(+req.params.id, req.customer.id); res.json(v); }));
r.get('/contracts/:id/pdf', auth, wrap(async (req, res) => {
  const { c } = await econtract.customerView(+req.params.id, req.customer.id);
  if (c.frozen) await econtract.logEvent(db, c.id, 'PDF_VIEW', 'mijoz', null, req.ip);
  sendPdf(res, await econtract.pdfFor(c), false);
}));
r.post('/contracts/:id/progress', auth, wrap(async (req, res) => res.json((await econtract.progress(+req.params.id, req.customer.id, req.body && req.body.page)) || { ok: true })));
r.post('/contracts/:id/otp', auth, wrap(async (req, res) => res.json(await econtract.sendOtp(+req.params.id, req.customer, req.ip))));
r.post('/contracts/:id/approve', auth, wrap(async (req, res) => {
  const d = vp(z.object({ code: z.string().regex(/^\d{6}$/, 'Kod 6 ta raqamdan iborat'), data_hash: z.string().min(16).max(80), consents: z.record(z.string(), z.boolean()) }), req.body);
  const out = await econtract.approve(+req.params.id, req.customer, { ...d, ip: req.ip, ua: req.headers['user-agent'] });
  res.json(out.v);
}));
r.post('/contracts/:id/pdf-link', auth, wrap(async (req, res) => {
  const { c } = await econtract.customerView(+req.params.id, req.customer.id);
  if (!c.frozen) throw new AppError(409, 'Shartnoma hali tasdiqlanmagan');
  const t = jwt.sign({ typ: 'pdf', cid: req.customer.id, id: c.id, jti: crypto.randomUUID() }, cfg.jwtSecret, { expiresIn: '2m' });
  res.json({ url: `${cfg.publicUrl || ''}/api/mini/contracts/file/${t}` });
}));
r.post('/contracts/:id/telegram', auth, wrap(async (req, res) => { const { c } = await econtract.customerView(+req.params.id, req.customer.id); await econtract.sendToTelegram(c, req.customer); res.json({ ok: true }); }));
r.post('/contracts/:id/renew', auth, wrap(async (req, res) => { const out = await econtract.renew(+req.params.id, req.customer.id); res.json(out.v); }));
r.get('/contracts/:id/acts/:kind/pdf', auth, wrap(async (req, res) => {
  const { c } = await econtract.customerView(+req.params.id, req.customer.id);
  const kind = String(req.params.kind).toUpperCase(); if (!['HANDOVER', 'RETURN'].includes(kind)) throw new AppError(400, 'Dalolatnoma turi noto‘g‘ri');
  sendPdf(res, await econtract.actPdf(c.booking_id, kind), false);
}));

module.exports = { router: r, verifyInitData, ensureCustomer, rewardReferral };
