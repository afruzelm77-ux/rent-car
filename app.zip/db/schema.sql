-- RENT A CAR — PostgreSQL schema
-- Pul: BIGINT (so'm, butun son). Floating point ishlatilmaydi.
CREATE EXTENSION IF NOT EXISTS btree_gist;

CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$ LANGUAGE plpgsql;

CREATE TABLE IF NOT EXISTS roles (
  id SERIAL PRIMARY KEY,
  code TEXT UNIQUE NOT NULL,            -- OWNER, ADMIN, MANAGER, ACCOUNTANT
  name TEXT NOT NULL,
  permissions JSONB NOT NULL DEFAULT '[]',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  role_id INT NOT NULL REFERENCES roles(id),
  full_name TEXT NOT NULL,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  telegram_id BIGINT UNIQUE,
  is_active BOOLEAN NOT NULL DEFAULT true,
  failed_logins INT NOT NULL DEFAULT 0,
  locked_until TIMESTAMPTZ,
  last_login_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS cars (
  id SERIAL PRIMARY KEY,
  brand TEXT NOT NULL,
  model TEXT NOT NULL,
  plate TEXT UNIQUE NOT NULL,
  vin TEXT UNIQUE,
  year INT,
  color TEXT,
  transmission TEXT NOT NULL DEFAULT 'AUTOMATIC' CHECK (transmission IN ('AUTOMATIC','MANUAL')),
  fuel_type TEXT NOT NULL DEFAULT 'PETROL' CHECK (fuel_type IN ('PETROL','GAS','DIESEL','HYBRID','ELECTRIC')),
  seats INT NOT NULL DEFAULT 5,
  price_day BIGINT NOT NULL CHECK (price_day >= 0),
  price_3d BIGINT NOT NULL CHECK (price_3d >= 0),
  price_7d BIGINT NOT NULL CHECK (price_7d >= 0),
  deposit BIGINT NOT NULL DEFAULT 0 CHECK (deposit >= 0),
  mileage INT NOT NULL DEFAULT 0 CHECK (mileage >= 0),
  fuel_level INT NOT NULL DEFAULT 100 CHECK (fuel_level BETWEEN 0 AND 100),
  status TEXT NOT NULL DEFAULT 'AVAILABLE' CHECK (status IN ('AVAILABLE','RESERVED','RENTED','MAINTENANCE','INACTIVE')),
  image_url TEXT,
  insurance_until DATE,
  inspection_until DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_cars_status ON cars(status) WHERE deleted_at IS NULL;

CREATE TABLE IF NOT EXISTS car_images (
  id SERIAL PRIMARY KEY,
  car_id INT NOT NULL REFERENCES cars(id) ON DELETE CASCADE,
  url TEXT NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_car_images_car ON car_images(car_id);

CREATE TABLE IF NOT EXISTS car_status_history (
  id SERIAL PRIMARY KEY,
  car_id INT NOT NULL REFERENCES cars(id) ON DELETE CASCADE,
  old_status TEXT,
  new_status TEXT NOT NULL,
  changed_by INT REFERENCES users(id),
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_csh_car ON car_status_history(car_id, created_at DESC);

CREATE TABLE IF NOT EXISTS customers (
  id SERIAL PRIMARY KEY,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  telegram_id BIGINT UNIQUE,
  passport_enc TEXT,                    -- shifrlangan (AES-256-GCM)
  license_enc TEXT,                     -- shifrlangan
  passport_last4 TEXT,                  -- ko'rsatish uchun maskalangan
  referral_code TEXT UNIQUE,
  referred_by INT REFERENCES customers(id),
  bonus_balance BIGINT NOT NULL DEFAULT 0,
  late_count INT NOT NULL DEFAULT 0,
  damage_total BIGINT NOT NULL DEFAULT 0,
  is_blocked BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_customers_phone ON customers(phone);

CREATE TABLE IF NOT EXISTS customer_documents (
  id SERIAL PRIMARY KEY,
  customer_id INT NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  doc_type TEXT NOT NULL CHECK (doc_type IN ('PASSPORT','LICENSE','OTHER')),
  file_path TEXT NOT NULL,
  expires_at DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS promo_codes (
  id SERIAL PRIMARY KEY,
  code TEXT UNIQUE NOT NULL,
  percent INT CHECK (percent BETWEEN 1 AND 100),
  fixed_amount BIGINT CHECK (fixed_amount >= 0),
  min_days INT NOT NULL DEFAULT 1,
  valid_from DATE,
  valid_until DATE,
  usage_limit INT,
  used_count INT NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (percent IS NOT NULL OR fixed_amount IS NOT NULL)
);

CREATE TABLE IF NOT EXISTS bookings (
  id SERIAL PRIMARY KEY,
  code TEXT UNIQUE NOT NULL,            -- BK-000123
  customer_id INT NOT NULL REFERENCES customers(id),
  car_id INT NOT NULL REFERENCES cars(id),
  pickup_at TIMESTAMPTZ NOT NULL,
  return_at TIMESTAMPTZ NOT NULL,
  pickup_location TEXT,
  days INT NOT NULL CHECK (days >= 1),
  daily_rate BIGINT NOT NULL,
  rental_amount BIGINT NOT NULL,        -- days * rate
  discount BIGINT NOT NULL DEFAULT 0,
  extras_amount BIGINT NOT NULL DEFAULT 0,
  deposit_amount BIGINT NOT NULL DEFAULT 0,
  late_fee BIGINT NOT NULL DEFAULT 0,
  damage_fee BIGINT NOT NULL DEFAULT 0,
  total_amount BIGINT NOT NULL,         -- rental - discount + extras + late_fee + damage_fee (depozitsiz)
  paid_amount BIGINT NOT NULL DEFAULT 0,
  promo_id INT REFERENCES promo_codes(id),
  status TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','CONFIRMED','ACTIVE','COMPLETED','CANCELLED','OVERDUE')),
  source TEXT NOT NULL DEFAULT 'ADMIN' CHECK (source IN ('ADMIN','BOT','MINIAPP')),
  actual_pickup_at TIMESTAMPTZ,
  actual_return_at TIMESTAMPTZ,
  created_by INT REFERENCES users(id),
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at TIMESTAMPTZ,
  CHECK (return_at > pickup_at),
  -- DOUBLE BOOKING TAQIQI (DB darajasi): faol bronlar vaqti kesishmaydi
  CONSTRAINT no_double_booking EXCLUDE USING gist (
    car_id WITH =,
    tstzrange(pickup_at, return_at, '[)') WITH &&
  ) WHERE (status IN ('PENDING','CONFIRMED','ACTIVE','OVERDUE'))
);
CREATE INDEX IF NOT EXISTS idx_bookings_car ON bookings(car_id, pickup_at);
CREATE INDEX IF NOT EXISTS idx_bookings_customer ON bookings(customer_id);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status);

CREATE TABLE IF NOT EXISTS booking_items (
  id SERIAL PRIMARY KEY,
  booking_id INT NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  name TEXT NOT NULL,                   -- Bolalar o'rindig'i, GPS, haydovchi ...
  qty INT NOT NULL DEFAULT 1,
  unit_price BIGINT NOT NULL,
  total BIGINT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS payments (
  id SERIAL PRIMARY KEY,
  booking_id INT NOT NULL REFERENCES bookings(id),
  customer_id INT NOT NULL REFERENCES customers(id),
  amount BIGINT NOT NULL CHECK (amount > 0),
  kind TEXT NOT NULL DEFAULT 'RENTAL' CHECK (kind IN ('RENTAL','DEPOSIT','EXTRA','DEPOSIT_DEDUCTION','REFUND','RENTAL_REFUND')),
  method TEXT NOT NULL CHECK (method IN ('CASH','CARD','ONLINE','BANK_TRANSFER')),
  status TEXT NOT NULL DEFAULT 'PAID' CHECK (status IN ('PENDING','PAID','FAILED','REFUNDED')),
  provider TEXT,                        -- payme / click / uzum (kelajak)
  provider_txn_id TEXT,
  paid_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by INT REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_payments_booking ON payments(booking_id);
CREATE INDEX IF NOT EXISTS idx_payments_paid_at ON payments(paid_at);

CREATE TABLE IF NOT EXISTS deposits (
  id SERIAL PRIMARY KEY,
  booking_id INT UNIQUE NOT NULL REFERENCES bookings(id),
  amount BIGINT NOT NULL,
  held_amount BIGINT NOT NULL DEFAULT 0,     -- qabul qilingan
  deducted_amount BIGINT NOT NULL DEFAULT 0, -- zarar uchun ushlangan
  returned_amount BIGINT NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','HELD','RETURNED','PARTIALLY_RETURNED','FORFEITED')),
  deduction_reason TEXT,
  returned_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS expense_categories (
  id SERIAL PRIMARY KEY,
  code TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS expenses (
  id SERIAL PRIMARY KEY,
  car_id INT REFERENCES cars(id),
  category_id INT NOT NULL REFERENCES expense_categories(id),
  amount BIGINT NOT NULL CHECK (amount > 0),
  spent_on DATE NOT NULL DEFAULT CURRENT_DATE,
  note TEXT,
  created_by INT REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(spent_on);
CREATE INDEX IF NOT EXISTS idx_expenses_car ON expenses(car_id);

CREATE TABLE IF NOT EXISTS maintenance (
  id SERIAL PRIMARY KEY,
  car_id INT NOT NULL REFERENCES cars(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK (kind IN ('OIL','FILTER','BRAKE_PADS','TIRES','BATTERY','REPAIR','INSPECTION','INSURANCE')),
  done_at DATE NOT NULL DEFAULT CURRENT_DATE,
  mileage_at INT,
  next_due_km INT,                      -- keyingi xizmat kilometri
  next_due_date DATE,
  cost BIGINT NOT NULL DEFAULT 0,
  note TEXT,
  expense_id INT REFERENCES expenses(id),
  created_by INT REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_maint_car ON maintenance(car_id, done_at DESC);

CREATE TABLE IF NOT EXISTS maintenance_items (
  id SERIAL PRIMARY KEY,
  maintenance_id INT NOT NULL REFERENCES maintenance(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  qty INT NOT NULL DEFAULT 1,
  price BIGINT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS car_inspections (
  id SERIAL PRIMARY KEY,
  booking_id INT NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  car_id INT NOT NULL REFERENCES cars(id),
  stage TEXT NOT NULL CHECK (stage IN ('HANDOVER','RETURN')),
  mileage INT NOT NULL,
  fuel_level INT NOT NULL CHECK (fuel_level BETWEEN 0 AND 100),
  body_condition TEXT,
  interior_condition TEXT,
  damages TEXT,
  photos JSONB NOT NULL DEFAULT '[]',
  video_url TEXT,
  staff_id INT REFERENCES users(id),
  inspected_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (booking_id, stage)
);

CREATE TABLE IF NOT EXISTS rental_contracts (
  id SERIAL PRIMARY KEY,
  booking_id INT UNIQUE NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  number TEXT UNIQUE NOT NULL,
  file_path TEXT,
  generated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS referrals (
  id SERIAL PRIMARY KEY,
  referrer_id INT NOT NULL REFERENCES customers(id),
  referred_id INT UNIQUE NOT NULL REFERENCES customers(id),
  bonus_amount BIGINT NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'PAID',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS notifications (
  id SERIAL PRIMARY KEY,
  audience TEXT NOT NULL CHECK (audience IN ('ADMIN','CUSTOMER')),
  customer_id INT REFERENCES customers(id),
  type TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT,
  ref_key TEXT,                         -- takror yuborishni oldini olish uchun
  is_read BOOLEAN NOT NULL DEFAULT false,
  sent_telegram BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_notif_refkey ON notifications(ref_key) WHERE ref_key IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_notif_aud ON notifications(audience, is_read, created_at DESC);

CREATE TABLE IF NOT EXISTS audit_logs (
  id BIGSERIAL PRIMARY KEY,
  user_id INT REFERENCES users(id),
  user_name TEXT,
  action TEXT NOT NULL,
  entity TEXT NOT NULL,
  entity_id TEXT,
  old_value JSONB,
  new_value JSONB,
  ip TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_logs(entity, entity_id);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at DESC);

CREATE TABLE IF NOT EXISTS settings (
  id SERIAL PRIMARY KEY,
  key TEXT UNIQUE NOT NULL,
  value TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);


-- Shartnoma shabloni (versiyalanadi) va mijoz roziligi
CREATE TABLE IF NOT EXISTS contract_templates (
  id SERIAL PRIMARY KEY,
  version INT NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  body_hash TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT false,
  created_by INT REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_contract_active ON contract_templates(is_active) WHERE is_active;

CREATE TABLE IF NOT EXISTS contract_consents (
  id SERIAL PRIMARY KEY,
  booking_id INT UNIQUE NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  customer_id INT NOT NULL REFERENCES customers(id),
  template_id INT NOT NULL REFERENCES contract_templates(id),
  body_hash TEXT NOT NULL,
  channel TEXT NOT NULL CHECK (channel IN ('MINIAPP','BOT','PAPER')),
  telegram_id BIGINT,
  recorded_by INT REFERENCES users(id),     -- PAPER bo'lsa: qaysi xodim qayd etgan
  ip TEXT,
  user_agent TEXT,
  accepted_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Admin <-> mijoz xabarlari jurnali
CREATE TABLE IF NOT EXISTS customer_messages (
  id BIGSERIAL PRIMARY KEY,
  customer_id INT NOT NULL REFERENCES customers(id),
  direction TEXT NOT NULL CHECK (direction IN ('OUT','IN')),
  kind TEXT NOT NULL DEFAULT 'DIRECT' CHECK (kind IN ('DIRECT','BROADCAST','REPLY','INBOUND')),
  body TEXT NOT NULL,
  sent_by INT REFERENCES users(id),
  sent_by_name TEXT,
  status TEXT NOT NULL DEFAULT 'SENT' CHECK (status IN ('SENT','FAILED')),
  error TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_msgs_customer ON customer_messages(customer_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_msgs_created ON customer_messages(created_at DESC);

-- Bot suhbat holati bazada saqlanadi: server qayta ishga tushsa ham yo'qolmaydi
CREATE TABLE IF NOT EXISTS bot_state (
  chat_id BIGINT PRIMARY KEY,
  state JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);


-- Shartnoma: matn yoki admin yuklagan PDF
ALTER TABLE contract_templates ADD COLUMN IF NOT EXISTS kind TEXT NOT NULL DEFAULT 'TEXT';
ALTER TABLE contract_templates ADD COLUMN IF NOT EXISTS file_path TEXT;
ALTER TABLE contract_templates ADD COLUMN IF NOT EXISTS file_name TEXT;
ALTER TABLE contract_templates ALTER COLUMN body SET DEFAULT '';

-- Kompaniyaning to'lov qabul qiladigan joylari (karta / bank hisobi)
CREATE TABLE IF NOT EXISTS payment_accounts (
  id SERIAL PRIMARY KEY,
  kind TEXT NOT NULL DEFAULT 'CARD' CHECK (kind IN ('CARD','BANK')),
  title TEXT NOT NULL,                 -- Humo, Uzcard, Visa, Bank nomi ...
  card_number TEXT,
  holder_name TEXT,
  bank_name TEXT,
  account_number TEXT,                 -- BANK uchun hisob raqami
  note TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at TIMESTAMPTZ
);

-- Mijoz "to'ladim" deb yuborgan to'lov so'rovi; admin chekni tekshirib tasdiqlaydi
CREATE TABLE IF NOT EXISTS payment_claims (
  id SERIAL PRIMARY KEY,
  booking_id INT NOT NULL REFERENCES bookings(id),
  customer_id INT NOT NULL REFERENCES customers(id),
  account_id INT REFERENCES payment_accounts(id),
  kind TEXT NOT NULL DEFAULT 'RENTAL' CHECK (kind IN ('RENTAL','DEPOSIT')),
  amount BIGINT NOT NULL CHECK (amount > 0),
  receipt_file TEXT,                   -- yopiq papkadagi fayl nomi
  receipt_tg_file_id TEXT,             -- botdan kelgan chek rasmi
  note TEXT,
  status TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','CONFIRMED','REJECTED')),
  reject_reason TEXT,
  payment_id INT REFERENCES payments(id),
  decided_by INT REFERENCES users(id),
  decided_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_claims_status ON payment_claims(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_claims_booking ON payment_claims(booking_id);

-- Admin o'zi qo'shadigan maxsus maydonlar (mijoz / mashina uchun)
CREATE TABLE IF NOT EXISTS custom_fields (
  id SERIAL PRIMARY KEY,
  entity TEXT NOT NULL CHECK (entity IN ('customer','car')),
  key TEXT NOT NULL,
  label TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'text' CHECK (type IN ('text','number','date','select')),
  options JSONB NOT NULL DEFAULT '[]',
  required BOOLEAN NOT NULL DEFAULT false,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at TIMESTAMPTZ,
  UNIQUE (entity, key)
);
ALTER TABLE customers ADD COLUMN IF NOT EXISTS custom JSONB NOT NULL DEFAULT '{}';
ALTER TABLE cars ADD COLUMN IF NOT EXISTS custom JSONB NOT NULL DEFAULT '{}';
ALTER TABLE cars ADD COLUMN IF NOT EXISTS body_type TEXT;       -- kuzov turi: Sedan, SUV, Xetchbek ...
ALTER TABLE cars ADD COLUMN IF NOT EXISTS description TEXT;     -- izoh (mijozga "Haqida" tabida ko'rinadi)
ALTER TABLE cars ADD COLUMN IF NOT EXISTS gps_token TEXT UNIQUE; -- GPS qurilma/ilova yuboradigan maxfiy kalit
ALTER TABLE customer_messages ADD COLUMN IF NOT EXISTS read_at TIMESTAMPTZ;  -- suhbat: o'qilmagan kiruvchi xabarlar
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS delivery_address TEXT;         -- mashinani manzilga yetkazish
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS delivery_fee BIGINT NOT NULL DEFAULT 0;
CREATE TABLE IF NOT EXISTS fines (
  id SERIAL PRIMARY KEY,
  car_id INT NOT NULL REFERENCES cars(id),
  booking_id INT REFERENCES bookings(id),
  customer_id INT REFERENCES customers(id),
  fine_date TIMESTAMPTZ NOT NULL,
  amount BIGINT NOT NULL CHECK (amount > 0),
  reason TEXT,
  doc_no TEXT,
  status TEXT NOT NULL DEFAULT 'NEW' CHECK (status IN ('NEW','PAID','CANCELLED')),
  note TEXT,
  created_by INT REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_fines_car ON fines(car_id, fine_date DESC);
CREATE INDEX IF NOT EXISTS idx_fines_customer ON fines(customer_id);
CREATE TABLE IF NOT EXISTS car_positions (
  id BIGSERIAL PRIMARY KEY,
  car_id INT NOT NULL REFERENCES cars(id),
  booking_id INT REFERENCES bookings(id),
  lat DOUBLE PRECISION NOT NULL,
  lng DOUBLE PRECISION NOT NULL,
  speed_kmh REAL,
  source TEXT NOT NULL DEFAULT 'DEVICE',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_pos_car ON car_positions(car_id, created_at DESC);


-- Aloqa raqamlari (mijozlarga botda va Mini App da ko'rsatiladi) — admin o'zi boshqaradi
CREATE TABLE IF NOT EXISTS contact_numbers (
  id SERIAL PRIMARY KEY,
  label TEXT NOT NULL,                 -- Operator, Menejer, Texnik yordam ...
  phone TEXT,
  telegram TEXT,                       -- @username (ixtiyoriy)
  hours TEXT,                          -- Ish vaqti: 09:00–21:00
  note TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at TIMESTAMPTZ
);

-- Botga qo'shilgan foydalanuvchi ma'lumotlari
ALTER TABLE customers ADD COLUMN IF NOT EXISTS tg_username TEXT;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS last_seen_at TIMESTAMPTZ;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS joined_via TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS phone TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS tg_username TEXT;

DO $$
DECLARE t TEXT;
BEGIN
  FOR t IN SELECT table_name FROM information_schema.columns
           WHERE table_schema='public' AND column_name='updated_at' LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS trg_updated_at ON %I', t);
    EXECUTE format('CREATE TRIGGER trg_updated_at BEFORE UPDATE ON %I FOR EACH ROW EXECUTE FUNCTION set_updated_at()', t);
  END LOOP;
END $$;
