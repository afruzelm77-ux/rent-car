// Test uchun soxta Telegram Bot API serveri: server yuborgan xabarlarni yozib oladi (haqiqiy Telegramga hech narsa ketmaydi)
const http = require('http');
const log = [];
http.createServer((req, res) => {
  const chunks = []; req.on('data', c => chunks.push(c));
  req.on('end', () => {
    const raw = Buffer.concat(chunks); const url = req.url;
    const send = o => { res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify(o)); };
    if (url === '/__log') return send(log);
    if (url === '/__reset') { log.length = 0; return send({ ok: true }); }
    let m = /^\/file\/bot[^/]+\/(.+)$/.exec(url);
    if (m) { res.setHeader('Content-Type', 'image/png'); return res.end(Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64')); }
    m = /^\/bot[^/]+\/(\w+)$/.exec(url);
    if (!m) return send({ ok: false, description: 'not found' });
    const method = m[1];
    if (method === 'getUpdates') return setTimeout(() => send({ ok: true, result: [] }), 1500);
    if (method === 'getMe') return send({ ok: true, result: { username: 'testbot' } });
    if (method === 'getFile') return send({ ok: true, result: { file_path: 'photos/f.jpg' } });
    if (['setWebhook', 'setChatMenuButton'].includes(method)) { let b = {}; try { b = JSON.parse(raw.toString() || '{}'); } catch {} log.push({ method, body: b }); return send({ ok: true, result: true }); }
    if (['deleteWebhook', 'answerCallbackQuery'].includes(method)) return send({ ok: true, result: true });
    let body = {};
    if ((req.headers['content-type'] || '').includes('multipart')) {
      const t = raw.toString('latin1'); const g = n => { const x = new RegExp(`name="${n}"\\r\\n\\r\\n([^\\r]*)`).exec(t); return x && x[1]; };
      body = { chat_id: g('chat_id'), caption: g('caption'), reply_markup: g('reply_markup'), has_file: t.includes('%PDF'), multipart: true };
    } else { try { body = JSON.parse(raw.toString() || '{}'); } catch {} }
    log.push({ method, body });
    send({ ok: true, result: { message_id: log.length } });
  });
}).listen(+process.env.FAKE_TG_PORT || 4010, () => console.log('Soxta Telegram :' + (process.env.FAKE_TG_PORT || 4010)));
