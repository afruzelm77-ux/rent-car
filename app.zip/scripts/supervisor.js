// Supervisor: server jarayoni biror sabab bilan to'xtab qolsa, avtomatik qayta ishga tushiradi (kutish vaqti oshib boradi).
const { spawn } = require('child_process');
const path = require('path');
let child = null, stopping = false, delay = 1000;
function run() {
  const started = Date.now();
  child = spawn(process.execPath, [path.join(__dirname, '..', 'src', 'server.js')], { stdio: 'inherit', env: process.env });
  child.on('exit', (code, sig) => {
    if (stopping) return process.exit(0);
    const alive = Date.now() - started;
    delay = alive > 60000 ? 1000 : Math.min(delay * 2, 30000);   // barqaror ishlagan bo'lsa kutishni nollaydi
    console.error(`[supervisor] server to'xtadi (kod=${code}, signal=${sig}, ${Math.round(alive / 1000)}s ishladi). ${delay / 1000}s dan keyin qayta ishga tushadi…`);
    setTimeout(run, delay);
  });
}
['SIGTERM', 'SIGINT'].forEach(s => process.on(s, () => { stopping = true; if (child) child.kill(s); else process.exit(0); }));
run();
