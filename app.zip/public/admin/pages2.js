'use strict';
/* ================= FINANCE ================= */
async function openExpenseForm(done) {
  const [cats, cars] = await Promise.all([getCategories(), api('GET', '/cars')]);
  const spec = [{ n: 'category_id', label: 'Kategoriya', t: 'select', o: cats.map(c => [c.id, c.name]), num: 1 }, { n: 'car_id', label: 'Mashina', t: 'select', o: [['', 'Umumiy (mashinaga bog\'lanmagan)'], ...cars.map(c => [c.id, `${c.brand} ${c.model} (${c.plate})`])], num: 1 },
    { n: 'amount', label: "Summa (so'm)", t: 'number', req: 1 }, { n: 'spent_on', label: 'Sana', t: 'date', v: isoDate() }, { n: 'note', label: 'Izoh', t: 'textarea', w: 2 }];
  const m = modal('Xarajat kiritish', `<div class="grid g2">${fields(spec)}</div>`, { footer: '<button class="btn" data-close>Bekor qilish</button><button class="btn primary" data-go>Saqlash</button>' });
  $('[data-go]', m.el).addEventListener('click', ev => guard(async () => { const b = collect(m.el, spec);
    if (!(await confirmBox('Moliyaviy amal', `${money(b.amount)} xarajat qayd etiladi.`))) return;
    await api('POST', '/expenses', b); toast('Xarajat saqlandi'); m.close(); bust(); done && done(); App.refresh && App.refresh(); }, ev.target));
}
async function openPaymentPicker() {   // tezkor tugma: buyurtma tanlab to'lov qabul qilish
  const rows = (await api('GET', '/bookings?limit=200')).filter(b => ['PENDING', 'CONFIRMED', 'ACTIVE', 'OVERDUE', 'COMPLETED'].includes(b.status) && Number(b.remaining) > 0);
  if (!rows.length) return toast("To'lov kutayotgan buyurtma yo'q");
  const m = modal("To'lov — buyurtmani tanlang", rows.map(b => `<div class="sched" data-pick="${b.id}" style="cursor:pointer"><b style="width:90px">${esc(b.code)}</b><span class="sp">${esc(b.customer)} · ${esc(b.car)}</span><b class="num">${money(b.remaining)}</b></div>`).join(''), { size: 'sm' });
  m.el.addEventListener('click', e => { const p = e.target.closest('[data-pick]'); if (p) { m.close(); openBooking(+p.dataset.pick); } });
}
async function openBookingPicker(statuses, title, empty) {
  const rows = (await api('GET', '/bookings?limit=200')).filter(b => statuses.includes(b.status));
  if (!rows.length) return toast(empty);
  const m = modal(title, rows.map(b => `<div class="sched" data-pick="${b.id}" style="cursor:pointer"><b style="width:90px">${esc(b.code)}</b><span class="sp">${esc(b.car)} · ${esc(b.customer)}</span><span class="small muted">${fDT(statuses.includes('CONFIRMED') ? b.pickup_at : b.return_at)}</span></div>`).join(''), { size: 'sm' });
  m.el.addEventListener('click', e => { const p = e.target.closest('[data-pick]'); if (!p) return; m.close(); openBooking(+p.dataset.pick); });
}

PAGES.finance = {
  title: 'Moliya', icon: '💰', perm: 'payments.write',
  async render(el) {
    let tab = can('finance.read') ? 'payments' : 'payments';
    el.innerHTML = `<div class="row" style="margin-bottom:14px"><div class="tabs" id="ft" style="margin:0"><button class="tab on" data-t="payments">To'lovlar</button><button class="tab" data-t="deposits">Depozitlar</button><button class="tab" data-t="claims">To'lov so'rovlari</button><button class="tab" data-t="accounts">To'lov joylari (karta)</button>${can('finance.read') || can('expenses.write') ? '<button class="tab" data-t="expenses">Xarajatlar</button>' : ''}</div><span class="sp"></span><a class="btn" href="/api/export/payments.csv">⬇ CSV</a>${can('payments.write') ? '<button class="btn" data-act="payment">+ To\'lov</button>' : ''}${can('expenses.write') ? '<button class="btn primary" data-act="expense">+ Xarajat</button>' : ''}</div><div class="card" id="fb">${loading}</div>`;
    const load = async () => {
      const box = $('#fb', el); box.innerHTML = loading;
      if (tab === 'claims') return renderClaims(box);
      if (tab === 'accounts') return renderAccounts(box);
      if (tab === 'payments') { const rows = await api('GET', '/payments?limit=200'); box.innerHTML = rows.length ? `<div class="tablewrap"><table><tr><th>Vaqt</th><th>Buyurtma</th><th>Mijoz</th><th>Tur</th><th>Usul</th><th>Holat</th><th class="right">Summa</th></tr>${rows.map(p => `<tr class="click" data-act="booking" data-id="${p.booking_id}"><td class="nowrap">${fDT(p.paid_at)}</td><td>${esc(p.code)}</td><td>${esc(p.customer)}</td><td>${esc(KIND[p.kind] || p.kind)}</td><td>${esc(METHOD[p.method] || p.method)}</td><td>${pill(p.status, PAYST[p.status])}</td><td class="right num" style="color:${['REFUND', 'RENTAL_REFUND'].includes(p.kind) ? 'var(--red)' : 'inherit'}">${['REFUND', 'RENTAL_REFUND'].includes(p.kind) ? '− ' : ''}${moneyS(p.amount)}</td></tr>`).join('')}</table></div>` : emptyState("To'lovlar yo'q", "Birinchi to'lov qabul qilinganda shu yerda ko'rinadi."); }
      if (tab === 'deposits') { const rows = await api('GET', '/deposits'); box.innerHTML = rows.length ? `<div class="tablewrap"><table><tr><th>Buyurtma</th><th>Mijoz</th><th>Mashina</th><th>Holat</th><th class="right">Depozit</th><th class="right">Ushlangan</th><th class="right">Ushlab turilgan</th><th class="right">Qaytarilgan</th></tr>${rows.map(d => `<tr class="click" data-act="booking" data-id="${d.booking_id}"><td>${esc(d.code)}</td><td>${esc(d.customer)}</td><td>${esc(d.car)}</td><td>${pill(d.status, DEPST[d.status])}</td><td class="right num">${moneyS(d.amount)}</td><td class="right num">${moneyS(d.deducted_amount)}</td><td class="right num">${moneyS(Number(d.held_amount) - Number(d.deducted_amount) - Number(d.returned_amount))}</td><td class="right num">${moneyS(d.returned_amount)}</td></tr>`).join('')}</table></div>` : emptyState("Depozitlar yo'q"); }
      if (tab === 'expenses') { const rows = await api('GET', '/expenses?limit=200'); const tot = rows.reduce((s, e) => s + Number(e.amount), 0);
        box.innerHTML = rows.length ? `<div class="row small" style="margin-bottom:8px"><b>Jami: ${money(tot)}</b><span class="muted">(oxirgi ${rows.length} ta)</span></div><div class="tablewrap"><table><tr><th>Sana</th><th>Kategoriya</th><th>Mashina</th><th>Izoh</th><th>Kim kiritgan</th><th class="right">Summa</th><th></th></tr>${rows.map(x => `<tr><td class="nowrap">${fDate(x.spent_on)}</td><td>${esc(x.category)}</td><td>${esc(x.car || '—')}</td><td>${esc(x.note || '')}</td><td>${esc(x.created_by_name || '—')}</td><td class="right num">${moneyS(x.amount)}</td><td>${can('expenses.write') ? `<button class="btn sm danger" data-delx="${x.id}">×</button>` : ''}</td></tr>`).join('')}</table></div>` : emptyState("Xarajatlar yo'q", "Xarajat qo'shish uchun yuqoridagi tugmani bosing."); }
    };
    App.refresh = load; load();
    el.addEventListener('click', async e => {
      const t = e.target.closest('[data-t]'); if (t) { tab = t.dataset.t; $$('.tab', el).forEach(b => b.classList.toggle('on', b === t)); load(); }
      const dx = e.target.closest('[data-delx]'); if (dx && await confirmBox("Xarajatni o'chirish", "Bu xarajat hisobotlardan olib tashlanadi.", "O'chirish", true)) guard(async () => { await api('DELETE', '/expenses/' + dx.dataset.delx); toast("Xarajat o'chirildi"); load(); });
    });
  },
};

/* ================= MAINTENANCE ================= */
PAGES.maintenance = {
  title: 'Texnik xizmat', icon: '🔧', perm: 'maintenance.read',
  async render(el) {
    el.innerHTML = loading; const d = await api('GET', '/maintenance'); const cars = await api('GET', '/cars');
    el.innerHTML = `<div class="row" style="margin-bottom:14px"><h3 style="margin:0">Ogohlantirishlar</h3><span class="sp"></span>${can('maintenance.write') ? '<button class="btn primary" data-act="newmaint">+ Xizmat qo\'shish</button>' : ''}</div>
      <div class="grid g2" style="margin-bottom:14px">${d.alerts.length ? d.alerts.map(a => `<div class="alert ${a.level === 'danger' ? 'danger' : ''}"><span>${a.type === 'MAINTENANCE' ? '🔧' : '📄'}</span><span><b>${esc(a.title)}</b><br>${esc(a.text)}</span></div>`).join('') : '<div class="card" style="grid-column:1/-1">' + emptyState("Ogohlantirish yo'q", "Barcha mashinalarning texnik xizmati muddatida.") + '</div>'}</div>
      <div class="card"><h3>Tarix</h3>${d.items.length ? `<div class="tablewrap"><table><tr><th>Sana</th><th>Mashina</th><th>Tur</th><th class="right">Bajarilgan km</th><th class="right">Keyingi</th><th class="right">Narx</th><th>Izoh</th></tr>${d.items.map(x => { const left = x.next_due_km != null ? x.next_due_km - x.current_km : null;
        return `<tr><td>${fDate(x.done_at)}</td><td>${esc(x.car)}<div class="muted small">${esc(x.plate)}</div></td><td>${MKIND[x.kind]}</td><td class="right num">${x.mileage_at ?? '—'}</td><td class="right num">${x.next_due_km != null ? `${x.next_due_km} km${left != null ? `<div class="small" style="color:${left <= 500 ? 'var(--red)' : 'var(--muted)'}">qolgan: ${left} km</div>` : ''}` : x.next_due_date ? fDate(x.next_due_date) : '—'}</td><td class="right num">${moneyS(x.cost)}</td><td>${esc(x.note || '')}</td></tr>`; }).join('')}</table></div>` : emptyState("Tarix yo'q")}</div>`;
    el.querySelector('[data-act=newmaint]')?.addEventListener('click', () => {
      const spec = [{ n: 'car_id', label: 'Mashina', t: 'select', o: cars.map(c => [c.id, `${c.brand} ${c.model} — ${moneyS(c.mileage)} km`]), num: 1 }, { n: 'kind', label: 'Tur', t: 'select', o: Object.entries(MKIND) },
        { n: 'done_at', label: 'Sana', t: 'date', v: isoDate() }, { n: 'mileage_at', label: 'Kilometr (bo\'sh = joriy)', t: 'number' }, { n: 'next_due_km', label: 'Keyingi xizmat (km)', t: 'number', hint: 'Masalan: moy uchun hozirgi km + 5000' }, { n: 'next_due_date', label: 'Keyingi xizmat sanasi', t: 'date' },
        { n: 'cost', label: "Narx (so'm)", t: 'number', v: 0, hint: "Narx kiritilsa avtomatik xarajatga yoziladi" }, { n: 'note', label: 'Izoh' }];
      const m = modal("Texnik xizmat qo'shish", `<div class="grid g2">${fields(spec)}</div>`, { footer: '<button class="btn" data-close>Bekor qilish</button><button class="btn primary" data-go>Saqlash</button>' });
      $('[data-go]', m.el).addEventListener('click', ev => guard(async () => { const b = collect(m.el, spec); await api('POST', '/maintenance', b); toast('Texnik xizmat saqlandi'); m.close(); bust(); PAGES.maintenance.render(el); }, ev.target));
    });
  },
};

/* ================= SHARTNOMALAR (elektron) ================= */
const ECST = { PENDING: ['🟡', 'Kutilmoqda'], REVIEW: ['🔵', "Ko'rib chiqilmoqda"], APPROVED: ['🟢', 'Tasdiqlangan'], CANCELLED: ['🔴', 'Bekor qilingan'], EXPIRED: ['⚫', 'Muddati tugagan'] };
const ecPill = s => `<span class="pill ${s === 'APPROVED' ? 'AVAILABLE' : s === 'CANCELLED' ? 'CANCELLED' : s === 'EXPIRED' ? 'INACTIVE' : s === 'REVIEW' ? 'RESERVED' : 'PENDING'}">${(ECST[s] || ['', s])[0]} ${(ECST[s] || ['', s])[1]}</span>`;
const EVN = { CREATED: 'Yaratildi', VIEWED: 'Mijoz ochdi', OTP_SENT: 'OTP yuborildi', OTP_FAILED: "OTP noto'g'ri", APPROVED: 'Tasdiqlandi', CANCELLED: 'Bekor qilindi', EXPIRED: 'Muddati tugadi', RENEWED: 'Yangilandi', PDF_VIEW: "PDF ko'rildi", PDF_DOWNLOAD: 'PDF yuklab olindi', HANDOVER_ACT: 'Topshirish dalolatnomasi', RETURN_ACT: 'Qaytarish dalolatnomasi', ACT_VIEW: "Dalolatnoma ko'rildi", INTEGRITY_FAIL: '⚠ Fayl yaxlitligi buzilgan' };

async function openEContract(id) {
  const c = await api('GET', '/econtracts/' + id), a = c.audit, can_cancel = can('contract.manage') && c.status !== 'CANCELLED';
  const m = modal(`Shartnoma ${c.number}`, `<div class="grid g2"><div class="card"><h3>Shartnoma</h3><dl class="dl"><dt>Holat</dt><dd>${ecPill(c.status)}</dd><dt>Versiya</dt><dd>v${esc(c.version_label)}</dd><dt>Buyurtma</dt><dd><a href="#" data-act="booking" data-id="${c.booking_id}">${esc(c.code)}</a></dd>
      <dt>Mijoz</dt><dd>${esc(c.customer)} · ${esc(c.phone)}</dd><dt>Pasport</dt><dd>${esc(c.passport_masked || '—')}</dd><dt>Manzil</dt><dd>${esc(c.address || '—')}</dd><dt>Avtomobil</dt><dd>${esc(c.car)} · ${esc(c.plate)}</dd>
      <dt>Ijara muddati</dt><dd>${fDT(c.pickup_at)} — ${fDT(c.return_at)} (${c.days} kun)</dd><dt>Jami summa</dt><dd>${money(c.total_amount)}</dd><dt>Garov</dt><dd>${money(c.deposit_amount)}</dd>
      <dt>Tasdiqlangan</dt><dd>${c.approved_at ? fDT(c.approved_at) : '—'}</dd>${c.status === 'CANCELLED' && c.cancelled_reason ? `<dt>Sabab</dt><dd>${esc(c.cancelled_reason)}</dd>` : ''}${c.frozen ? '<dt>Muzlatilgan</dt><dd>🔒 Ha — mazmun o\'zgartirib bo\'lmaydi</dd>' : ''}</dl></div>
    <div class="card"><h3>Audit ma'lumotlari</h3>${a ? `<dl class="dl"><dt>contract_id</dt><dd>${a.contract_id}</dd><dt>order_id</dt><dd>${a.order_id}</dd><dt>customer_id</dt><dd>${a.customer_id}</dd><dt>Telegram ID</dt><dd>${esc(a.telegram_id || '—')}</dd><dt>F.I.Sh.</dt><dd>${esc(a.customer_name)}</dd><dt>Telefon</dt><dd>${esc(a.phone)}</dd>
      <dt>Versiya</dt><dd>${esc(a.contract_version)}</dd><dt>Sana / vaqt</dt><dd>${esc(a.approved_date)} ${esc(a.approved_time)}</dd><dt>OTP</dt><dd>${a.otp_status === 'VERIFIED' ? '✅ tasdiqlangan' : esc(a.otp_status)}</dd><dt>PDF ID</dt><dd class="small" style="word-break:break-all">${esc(a.pdf_id)}</dd>
      <dt>PDF SHA-256</dt><dd class="small" style="word-break:break-all">${esc(a.pdf_sha256)}</dd><dt>Hujjat xeshi</dt><dd class="small" style="word-break:break-all">${esc(a.doc_hash)}</dd><dt>IP</dt><dd>${esc(a.ip || '—')}</dd><dt>Qurilma</dt><dd class="small">${esc(a.user_agent || '—')}</dd></dl>` : '<div class="small muted">Shartnoma hali tasdiqlanmagan — audit yozuvi tasdiqlangandan keyin paydo bo\'ladi.</div>'}</div></div>
    ${c.settlement ? `<div class="card" style="margin-top:14px"><h3>Yakuniy hisob-kitob</h3><div class="kv"><span>Jami hisob-kitob</span><b>${money(c.settlement.charges_total)}</b></div><div class="kv"><span>Garovdan ushlandi</span><b>${money(c.settlement.deposit_deducted)}</b></div><div class="kv"><span>Qaytarilgan garov</span><b>${money(c.settlement.deposit_refund)}</b></div><div class="kv"><span>Qo'shimcha to'lov</span><b>${money(c.settlement.balance_due)}</b></div></div>` : ''}
    <div class="card" style="margin-top:14px"><h3>Hodisalar</h3>${c.events.length ? `<div class="tablewrap"><table><tr><th>Vaqt</th><th>Hodisa</th><th>Kim</th><th>IP</th></tr>${c.events.map(e => `<tr><td>${fDT(e.created_at)}</td><td>${esc(EVN[e.event] || e.event)}</td><td>${esc(e.actor || '—')}</td><td class="small">${esc(e.ip || '')}</td></tr>`).join('')}</table></div>` : '<div class="small muted">—</div>'}</div>`,
  { size: 'lg', footer: `<a class="btn" href="/api/econtracts/${id}/pdf" target="_blank" rel="noopener">👁 PDF ko'rish</a><a class="btn" href="/api/econtracts/${id}/pdf?download=1">⬇ PDF yuklab olish</a>
    ${c.acts.map(x => `<a class="btn" href="/api/bookings/${c.booking_id}/acts/${x.kind.toLowerCase()}/pdf" target="_blank" rel="noopener">📄 ${x.kind === 'HANDOVER' ? 'Topshirish' : 'Qaytarish'} dalolatnomasi</a>`).join('')}<span class="sp"></span>${can_cancel ? '<button class="btn danger" data-do="cancel">Bekor qilish</button>' : ''}` });
  m.el.addEventListener('click', e => { const t = e.target.closest('[data-do="cancel"]'); if (!t) return;
    const mm = modal('Shartnomani bekor qilish', '<div class="field"><label class="f">Sabab</label><input id="ecr"></div>', { size: 'sm', footer: '<button class="btn" data-close>Yopish</button><button class="btn danger" data-go>Bekor qilish</button>' });
    $('[data-go]', mm.el).addEventListener('click', ev => guard(async () => { await api('POST', `/econtracts/${id}/cancel`, { reason: $('#ecr', mm.el).value }); toast('Shartnoma bekor qilindi'); mm.close(); m.close(); App.refresh && App.refresh(); }, ev.target)); });
}
PAGES.contracts = {
  title: 'Shartnomalar', icon: '📄', perm: 'contracts.read',
  async render(el) {
    const st = { status: '', q: '' };
    el.innerHTML = `<div class="row" style="margin-bottom:14px;gap:10px"><div class="tabs" id="ecs" style="margin:0"></div><span class="sp"></span><input id="ecq" placeholder="Shartnoma №, buyurtma, mijoz, telefon, raqam" style="max-width:320px"></div><div class="card" id="ecl">${loading}</div>`;
    const load = async () => {
      const d = await api('GET', '/econtracts' + qs({ status: st.status, q: st.q })), total = Object.values(d.counts).reduce((x, y) => x + y, 0);
      $('#ecs', el).innerHTML = [['', 'Barchasi', total], ...Object.entries(ECST).map(([k, v]) => [k, v[0] + ' ' + v[1], d.counts[k] || 0])].map(([k, l, n]) => `<button class="tab ${st.status === k ? 'on' : ''}" data-s="${k}">${l} ${n}</button>`).join('');
      $('#ecl', el).innerHTML = d.items.length ? `<div class="tablewrap"><table><tr><th>Shartnoma №</th><th>Mijoz</th><th>Avtomobil</th><th>Buyurtma</th><th class="right">Summa</th><th class="right">Garov</th><th>Ijara muddati</th><th>Holat</th><th>Tasdiqlangan</th><th></th></tr>
        ${d.items.map(r => `<tr class="click" data-id="${r.id}"><td><b>${esc(r.number)}</b><div class="small muted">v${esc(r.version_label)}</div></td><td>${esc(r.customer)}<div class="small muted">${esc(r.phone || '')}</div></td><td>${esc(r.car)} <span class="muted small">${esc(r.plate)}</span></td>
          <td><a href="#" data-act="booking" data-id="${r.booking_id}">${esc(r.code)}</a></td><td class="right num">${moneyS(r.total_amount)}</td><td class="right num">${moneyS(r.deposit_amount)}</td><td class="small">${fDT(r.pickup_at)}<br>${fDT(r.return_at)}</td><td>${ecPill(r.status)}${r.has_handover ? '<div class="small muted">🚗 topshirilgan</div>' : ''}${r.has_return ? '<div class="small muted">↩ qaytarilgan</div>' : ''}</td><td class="small">${r.approved_at ? fDT(r.approved_at) : '—'}</td>
          <td class="nowrap"><a class="btn sm" href="/api/econtracts/${r.id}/pdf" target="_blank" rel="noopener" data-stop>👁</a> <a class="btn sm" href="/api/econtracts/${r.id}/pdf?download=1" data-stop>⬇</a></td></tr>`).join('')}</table></div>`
        : emptyState('Shartnoma topilmadi', 'Buyurtma yaratilganda shartnoma avtomatik hosil bo\'ladi.');
    };
    App.refresh = load; load();
    el.addEventListener('click', e => { if (e.target.closest('[data-stop]') || e.target.closest('[data-act="booking"]')) return; const b = e.target.closest('[data-s]'); if (b) { st.status = b.dataset.s; return load(); }
      const r = e.target.closest('tr[data-id]'); if (r) openEContract(+r.dataset.id); });
    let tm; $('#ecq', el).addEventListener('input', e => { clearTimeout(tm); tm = setTimeout(() => { st.q = e.target.value; load(); }, 250); });
  },
};

/* ================= REPORTS ================= */
PAGES.reports = {
  title: 'Hisobotlar', icon: '📊', perm: 'reports.read',
  async render(el) {
    const st = { period: 'month', from: addD(isoDate(), -30), to: isoDate() };
    el.innerHTML = `<div class="card" style="margin-bottom:14px"><div class="row"><div class="tabs" id="pt" style="margin:0">${[['today', 'Bugun'], ['yesterday', 'Kecha'], ['week', 'Hafta'], ['month', 'Oy'], ['custom', 'Boshqa davr']].map(([k, v]) => `<button class="tab ${k === 'month' ? 'on' : ''}" data-p="${k}">${v}</button>`).join('')}</div>
      <span id="cr" class="row hidden"><input type="date" id="rf" value="${st.from}" style="width:auto"><input type="date" id="rt" value="${st.to}" style="width:auto"><button class="btn sm" id="rgo">Ko'rsatish</button></span><span class="sp"></span><a class="btn" id="xcsv">⬇ Excel/CSV</a><a class="btn" id="xpdf">⬇ PDF</a></div></div><div id="rb">${loading}</div>`;
    const url = (ext) => `/api/reports/export.${ext}` + qs(st);
    const load = async () => {
      $('#xcsv', el).href = url('csv'); $('#xpdf', el).href = url('pdf');
      const r = await api('GET', '/reports/summary' + qs(st));
      $('#rb', el).innerHTML = `<div class="grid g4" style="margin-bottom:14px">
        <div class="card kpi s-av"><span>Daromad</span><b class="num">${money(r.revenue)}</b></div><div class="card kpi s-rent"><span>Xarajat</span><b class="num">${money(r.expenses)}</b></div><div class="card kpi amber"><span>Sof foyda</span><b class="num">${money(r.profit)}</b></div><div class="card kpi"><span>Ijaralar · bandlik</span><b>${r.rentals} · ${r.utilization}%</b></div></div>
        <div class="card chart" style="margin-bottom:14px"><h3>${fDate(r.from + 'T00:00:00+05:00')} — ${fDate(r.to + 'T00:00:00+05:00')}</h3>${r.daily.length > 1 ? lineChart(r.daily.map(d => d.day.slice(5)), [{ data: r.daily.map(d => d.revenue), color: '#A855F7' }, { data: r.daily.map(d => d.expenses), color: '#6D35D9' }, { data: r.daily.map(d => d.profit), color: '#20C77A' }]) + '<div class="legend"><span><i style="background:#A855F7"></i>Daromad</span><span><i style="background:#6D35D9"></i>Xarajat</span><span><i style="background:#20C77A"></i>Foyda</span></div>' : emptyState('Grafik uchun kamida 2 kun tanlang')}</div>
        <div class="grid g2"><div class="card"><h3>Eng ko'p daromad qilgan mashinalar</h3>${hbars(r.top_cars.filter(c => c.revenue > 0).map(c => ({ name: c.name, value: c.revenue })))}</div><div class="card"><h3>Xarajatlar kategoriyasi</h3>${donut(r.expense_categories.map(c => ({ name: c.name, value: c.amount })))}</div></div>
        <div class="card" style="margin-top:14px"><h3>Har bir mashina bo'yicha</h3><div class="tablewrap"><table><tr><th>Mashina</th><th class="right">Daromad</th><th class="right">Xarajat</th><th class="right">Sof foyda</th><th style="width:160px">Bandlik</th></tr>${r.cars.map(c => `<tr class="click" data-act="car" data-id="${c.id}"><td><b>${esc(c.name)}</b><div class="muted small">${esc(c.plate)}</div></td><td class="right num">${moneyS(c.revenue)}</td><td class="right num">${moneyS(c.expenses)}</td><td class="right num" style="color:${c.profit >= 0 ? 'var(--green)' : 'var(--red)'}"><b>${moneyS(c.profit)}</b></td><td><div class="row" style="flex-wrap:nowrap"><div class="bar sp"><i style="width:${c.utilization}%"></i></div><span class="small num">${c.utilization}%</span></div></td></tr>`).join('')}</table></div></div>
        <div class="small muted" style="margin-top:10px">Formula: jami daromad − jami xarajat = sof foyda. Depozit daromadga kirmaydi; faqat zarar/kechikish uchun ushlangan qismi hisoblanadi.</div>`;
    };
    App.refresh = load; load();
    $('#pt', el).addEventListener('click', e => { const b = e.target.closest('[data-p]'); if (!b) return; st.period = b.dataset.p; $$('.tab', el).forEach(t => t.classList.toggle('on', t === b)); $('#cr', el).classList.toggle('hidden', st.period !== 'custom'); if (st.period !== 'custom') load(); });
    $('#rgo', el).addEventListener('click', () => { st.from = $('#rf', el).value; st.to = $('#rt', el).value; guard(load); });
  },
};

/* ================= NOTIFICATIONS ================= */
PAGES.notifications = {
  title: 'Bildirishnomalar', icon: '🔔', perm: 'notifications.read',
  async render(el) {
    el.innerHTML = loading; const d = await api('GET', '/notifications');
    const ic = { PAY_CLAIM: '💳', CONSENT: '✅', BROADCAST: '📣', NEW_BOOKING: '🆕', PAYMENT: '💰', CAR_RETURNED: '↩️', OVERDUE: '⏰', MAINTENANCE: '🔧', EXPIRY: '📄', DOC: '📎', RETURN_SOON: '🕒' };
    el.innerHTML = `<div class="row" style="margin-bottom:14px"><b>${d.unread} ta o'qilmagan</b><span class="sp"></span><button class="btn" id="mr">Hammasini o'qilgan qilish</button></div><div class="card">${d.items.length ? d.items.map(n => `<div class="sched" style="${n.is_read ? 'opacity:.6' : ''}"><span style="font-size:22px;width:34px">${ic[n.type] || '🔔'}</span><span class="sp"><b>${esc(n.title)}</b><div class="small muted" style="white-space:pre-line">${esc(n.body || '')}</div></span><span class="small muted nowrap">${fDT(n.created_at)}</span></div>`).join('') : emptyState("Bildirishnoma yo'q", "Yangi bron, to'lov, kechikish va ogohlantirishlar shu yerda ko'rinadi.")}</div>`;
    $('#mr', el).addEventListener('click', () => guard(async () => { await api('POST', '/notifications/read'); App.badge(); PAGES.notifications.render(el); }));
  },
};

/* ================= STAFF ================= */
const ROLE_NAME = { OWNER: 'Egasi', ADMIN: 'Administrator', MANAGER: 'Menejer', ACCOUNTANT: 'Buxgalter' };
PAGES.staff = {
  title: 'Xodimlar', icon: '👨‍💼', perm: 'users.manage',
  async render(el) {
    el.innerHTML = loading; const rows = await api('GET', '/users');
    el.innerHTML = `<div class="row" style="margin-bottom:14px"><span class="sp"></span><button class="btn primary" data-act="newuser">+ Xodim qo'shish</button></div>
      <div class="grid g4" style="margin-bottom:14px">${Object.entries(ROLE_NAME).map(([k, v]) => `<div class="card"><b>${v}</b><div class="small muted">${{ OWNER: "Barcha ma'lumotlar va sozlamalar", ADMIN: "Hamma narsa, xodimlar va sozlamalardan tashqari", MANAGER: "Bron, mashina berish/qabul qilish, mijozlar", ACCOUNTANT: "Moliya, to'lov, xarajat, hisobotlar" }[k]}</div></div>`).join('')}</div>
      <div class="card" style="margin-bottom:14px"><div class="tablewrap"><table><tr><th>Xodim</th><th>Login</th><th>Telefon</th><th>Telegram</th><th>Rol</th><th>Oxirgi kirish</th><th>Holat</th><th></th></tr>${rows.map(u => `<tr><td><b>${esc(u.full_name)}</b></td><td>${esc(u.username)}</td><td>${u.phone ? `<a href="tel:${esc(u.phone)}">${esc(u.phone)}</a>` : '—'}</td><td>${u.tg_username ? '@' + esc(u.tg_username) : '—'}${u.telegram_id ? `<div class="small muted">ID ${esc(u.telegram_id)}</div>` : ''}</td><td>${esc(ROLE_NAME[u.role])}</td><td>${u.last_login_at ? fDT(u.last_login_at) : '—'}</td><td>${u.is_active ? pill('AVAILABLE', 'Faol') : pill('INACTIVE', 'Bloklangan')}</td><td><button class="btn sm" data-edit="${u.id}">Tahrirlash</button></td></tr>`).join('')}</table></div></div><div class="card" id="rl">${loading}</div>`;
    renderRoles($('#rl', el)).catch(() => { $('#rl', el).innerHTML = ''; });
    const form = u => { const spec = [{ n: 'full_name', label: 'F.I.O.', req: 1, v: u?.full_name }, ...(u ? [] : [{ n: 'username', label: 'Login', req: 1 }]), { n: 'password', label: u ? 'Yangi parol (ixtiyoriy)' : 'Parol (kamida 8 belgi)', t: 'password', req: !u },
        { n: 'role', label: 'Rol', t: 'select', o: Object.entries(ROLE_NAME), v: u?.role || 'MANAGER' }, { n: 'phone', label: 'Telefon raqami', v: u?.phone, ph: '+998 90 123 45 67' }, { n: 'tg_username', label: 'Telegram @username', v: u?.tg_username }, { n: 'telegram_id', label: 'Telegram ID (bot buyruqlari uchun)', t: 'number', v: u?.telegram_id }, ...(u ? [{ n: 'is_active', label: 'Faol', t: 'checkbox', v: u.is_active }] : [])];
      const m = modal(u ? 'Xodimni tahrirlash' : "Yangi xodim", `<div class="grid g2">${fields(spec)}</div>`, { footer: '<button class="btn" data-close>Bekor qilish</button><button class="btn primary" data-go>Saqlash</button>' });
      $('[data-go]', m.el).addEventListener('click', ev => guard(async () => { const b = collect(m.el, spec); Object.keys(b).forEach(k => (b[k] === null || b[k] === '') && delete b[k]); if (u) await api('PATCH', '/users/' + u.id, b); else await api('POST', '/users', b); toast('Xodim saqlandi'); m.close(); PAGES.staff.render(el); }, ev.target)); };
    el.addEventListener('click', e => { if (e.target.closest('[data-act=newuser]')) form(); const ed = e.target.closest('[data-edit]'); if (ed) form(rows.find(u => u.id == ed.dataset.edit)); });
  },
};

/* ================= SETTINGS ================= */
PAGES.settings = {
  title: 'Sozlamalar', icon: '⚙️',
  async render(el) {
    const tabs = [['general', 'Umumiy', 'settings.manage'], ['contract', 'Shartnoma', 'contract.manage'], ['promo', 'Promo kodlar', 'promo.write'], ['backup', 'Zaxira nusxa', 'backup.manage'], ['audit', 'Audit log', 'audit.read']].filter(t => can(t[2]) || (t[0] === 'promo' && can('bookings.read') && false));
    let tab = tabs[0]?.[0];
    if (!tab) { el.innerHTML = emptyState('Ruxsat yo\'q', "Sozlamalar bo'limi sizning rolingiz uchun mavjud emas."); return; }
    el.innerHTML = `<div class="tabs" id="st">${tabs.map(([k, v]) => `<button class="tab ${k === tab ? 'on' : ''}" data-t="${k}">${v}</button>`).join('')}</div><div id="sb">${loading}</div>`;
    const load = async () => {
      const box = $('#sb', el); box.innerHTML = loading;
      if (tab === 'contract') return renderContract(box);
      if (tab === 'general') { const S = await api('GET', '/settings'); bust();
        const spec = [{ n: 'company_name', label: 'Kompaniya nomi', v: S.company_name }, { n: 'company_phone', label: 'Telefon', v: S.company_phone }, { n: 'company_address', label: 'Manzil', v: S.company_address, w: 2 },
          { n: 'late_fee_per_hour', label: "Kechikish tarifi (so'm / soat)", t: 'number', v: S.late_fee_per_hour }, { n: 'late_grace_minutes', label: 'Imtiyoz muddati (daqiqa)', t: 'number', v: S.late_grace_minutes },
          { n: 'maintenance_warn_km', label: 'Texnik xizmat ogohlantirishi (km qolganda)', t: 'number', v: S.maintenance_warn_km }, { n: 'alert_days', label: "Muddat ogohlantirishi (necha kun oldin)", t: 'number', v: S.alert_days },
          { n: 'referral_bonus', label: "Referral bonusi (so'm)", t: 'number', v: S.referral_bonus }, { n: 'backup_every_hours', label: 'Zaxira nusxa (har necha soatda)', t: 'number', v: S.backup_every_hours }, { n: 'backup_keep', label: 'Nechta nusxa saqlansin', t: 'number', v: S.backup_keep },
          { n: 'office_lat', label: 'Ofis kengligi (lat)', v: S.office_lat }, { n: 'office_lng', label: 'Ofis uzunligi (lng)', v: S.office_lng },
          { n: 'bot_intro', label: "Botdagi tanishtiruv matni (bo'sh = standart, HTML: <b>qalin</b>)", t: 'textarea', v: S.bot_intro, w: 2 },
          { n: 'delivery_fee', label: "Yetkazib berish narxi (so'm)", t: 'number', v: S.delivery_fee, hint: "Bo'sh = xizmat o'chiq, 0 = bepul" }, { n: 'gps_speed_limit', label: 'GPS: tezlik limiti (km/soat)', t: 'number', v: S.gps_speed_limit, hint: '0 = o\'chiq' }, { n: 'gps_zone_km', label: 'GPS: ofisdan maksimal masofa (km)', t: 'number', v: S.gps_zone_km, hint: '0 = o\'chiq (ofis koordinatasi kerak)' }
          ];
        box.innerHTML = `<div class="card"><div class="grid g2">${fields(spec)}</div><div class="row" style="margin-top:8px"><button class="btn primary" id="sv">Saqlash</button></div></div>`;
        $('#sv', box).addEventListener('click', ev => guard(async () => { const b = collect(box, spec.map(s => ({ ...s, t: 'text', num: false }))); Object.keys(b).forEach(k => b[k] === null && (b[k] = '')); await api('PUT', '/settings', b); bust(); toast('Sozlamalar saqlandi'); }, ev.target)); }
      if (tab === 'promo') { const rows = await api('GET', '/promos');
        box.innerHTML = `<div class="row" style="margin-bottom:12px"><span class="sp"></span><button class="btn primary" id="np">+ Promo kod</button></div><div class="card">${rows.length ? `<div class="tablewrap"><table><tr><th>Kod</th><th>Chegirma</th><th>Min. kun</th><th>Amal qilish</th><th>Ishlatilgan</th><th>Holat</th></tr>${rows.map(p => `<tr><td><b>${esc(p.code)}</b></td><td>${p.percent ? p.percent + '%' : money(p.fixed_amount)}</td><td>${p.min_days}</td><td>${p.valid_from ? fDate(p.valid_from) : '…'} — ${p.valid_until ? fDate(p.valid_until) : '…'}</td><td>${p.used_count}${p.usage_limit ? ' / ' + p.usage_limit : ''}</td><td><button class="btn sm" data-tg="${p.id}" data-on="${p.is_active}">${p.is_active ? 'Faol' : 'O\'chiq'}</button></td></tr>`).join('')}</table></div>` : emptyState("Promo kod yo'q", "RENT10 kabi chegirma kodi yarating.")}</div>`;
        $('#np', box).addEventListener('click', () => { const spec = [{ n: 'code', label: 'Kod', req: 1, ph: 'RENT10' }, { n: 'percent', label: 'Foiz (%)', t: 'number', min: 1, max: 100 }, { n: 'fixed_amount', label: "Aniq summa (so'm)", t: 'number', hint: 'Foiz yoki aniq summadan bittasi' }, { n: 'min_days', label: 'Minimal ijara kuni', t: 'number', v: 1 }, { n: 'valid_from', label: 'Boshlanish sanasi', t: 'date' }, { n: 'valid_until', label: 'Tugash sanasi', t: 'date' }, { n: 'usage_limit', label: 'Foydalanish limiti', t: 'number' }];
          const m = modal('Yangi promo kod', `<div class="grid g2">${fields(spec)}</div>`, { footer: '<button class="btn" data-close>Bekor qilish</button><button class="btn primary" data-go>Yaratish</button>' });
          $('[data-go]', m.el).addEventListener('click', ev => guard(async () => { await api('POST', '/promos', collect(m.el, spec)); toast('Promo kod yaratildi'); m.close(); load(); }, ev.target)); });
        box.addEventListener('click', e => { const t = e.target.closest('[data-tg]'); if (t) guard(async () => { await api('PATCH', '/promos/' + t.dataset.tg, { is_active: t.dataset.on !== 'true' }); load(); }); }); }
      if (tab === 'backup') { const rows = await api('GET', '/backups');
        box.innerHTML = `<div class="row" style="margin-bottom:12px"><span class="muted">Zaxira nusxa jadvali Umumiy sozlamalarda o'rnatiladi.</span><span class="sp"></span><button class="btn primary" id="nbk">Hozir zaxira nusxa olish</button></div><div class="card">${rows.length ? `<div class="tablewrap"><table><tr><th>Fayl</th><th>Hajmi</th><th>Vaqt</th><th></th></tr>${rows.map(b => `<tr><td>${esc(b.name)}</td><td>${Math.round(b.size / 1024)} KB</td><td>${fDT(b.at)}</td><td><a class="btn sm" href="/api/backups/${encodeURIComponent(b.name)}">Yuklab olish</a></td></tr>`).join('')}</table></div>` : emptyState("Zaxira nusxa yo'q")}</div>`;
        $('#nbk', box).addEventListener('click', ev => guard(async () => { await api('POST', '/backups'); toast('Zaxira nusxa yaratildi'); load(); }, ev.target)); }
      if (tab === 'audit') { const rows = await api('GET', '/audit');
        const short = v => v == null ? '' : esc(typeof v === 'object' ? JSON.stringify(v) : v).slice(0, 90);
        box.innerHTML = `<div class="card">${rows.length ? `<div class="tablewrap"><table><tr><th>Qachon</th><th>Kim</th><th>Nima qildi</th><th>Oldingi qiymat</th><th>Yangi qiymat</th></tr>${rows.map(a => `<tr><td class="nowrap">${fDT(a.created_at)}</td><td>${esc(a.user_name || '—')}</td><td><b>${esc(a.action)}</b> · ${esc(a.entity)} #${esc(a.entity_id ?? '')}</td><td class="small muted">${short(a.old_value)}</td><td class="small">${short(a.new_value)}</td></tr>`).join('')}</table></div>` : emptyState("Yozuv yo'q")}</div>`; }
    };
    $('#st', el).addEventListener('click', e => { const b = e.target.closest('[data-t]'); if (!b) return; tab = b.dataset.t; $$('.tab', el).forEach(t => t.classList.toggle('on', t === b)); load(); });
    App.refresh = load; load();
  },
};
