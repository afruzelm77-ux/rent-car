'use strict';
/* ====== Yordamchi funksiyalar ====== */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = n => (n == null ? '—' : String(Math.round(Number(n))).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + " so'm");
const moneyS = n => (n == null ? '—' : String(Math.round(Number(n))).replace(/\B(?=(\d{3})+(?!\d))/g, ' '));
const p2 = n => String(n).padStart(2, '0');
const tk = d => new Date(new Date(d).getTime() + 5 * 3600e3);           // Asia/Tashkent (UTC+5)
const fDate = d => { if (!d) return '—'; const t = tk(d); return `${p2(t.getUTCDate())}.${p2(t.getUTCMonth() + 1)}.${t.getUTCFullYear()}`; };
const fTime = d => { if (!d) return '—'; const t = tk(d); return `${p2(t.getUTCHours())}:${p2(t.getUTCMinutes())}`; };
const fDT = d => (d ? `${fDate(d)} ${fTime(d)}` : '—');
const isoDate = d => { const t = tk(d || new Date()); return `${t.getUTCFullYear()}-${p2(t.getUTCMonth() + 1)}-${p2(t.getUTCDate())}`; };
const addD = (s, n) => { const d = new Date(s + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };

const ST = { AVAILABLE: "🟢 Bo'sh", RESERVED: '🟡 Bron qilingan', RENTED: '🔴 Ijarada', MAINTENANCE: "🔧 Ta'mirda", INACTIVE: '⚫ Faol emas' };
const BST = { PENDING: 'Kutilmoqda', CONFIRMED: 'Tasdiqlangan', ACTIVE: 'Ijarada', COMPLETED: 'Yakunlangan', CANCELLED: 'Bekor qilingan', OVERDUE: 'Kechikkan' };
const PAYST = { PAID: "To'langan", PENDING: 'Kutilmoqda', FAILED: 'Xato', REFUNDED: 'Qaytarilgan' };
const METHOD = { CASH: 'Naqd', CARD: 'Karta', ONLINE: 'Online', BANK_TRANSFER: 'Bank o\'tkazma' };
const KIND = { RENTAL: 'Ijara', DEPOSIT: 'Depozit', EXTRA: "Qo'shimcha", DEPOSIT_DEDUCTION: 'Depozitdan ushlangan', REFUND: 'Depozit qaytarildi', RENTAL_REFUND: 'Ijara qaytarildi' };
const DEPST = { PENDING: 'Kutilmoqda', HELD: 'Ushlab turilgan', RETURNED: 'DEPOSIT RETURNED', PARTIALLY_RETURNED: 'Qisman qaytarilgan', FORFEITED: 'Zarar uchun ushlangan' };
const MKIND = { OIL: 'Moy', FILTER: 'Filtr', BRAKE_PADS: 'Kolodka', TIRES: 'Shina', BATTERY: 'Akkumulyator', REPAIR: 'Remont', INSPECTION: "Texnik ko'rik", INSURANCE: "Sug'urta" };
const TRANS = { AUTOMATIC: 'Avtomat', MANUAL: 'Mexanika' };
const FUELT = { PETROL: 'Benzin', GAS: 'Gaz', DIESEL: 'Dizel', HYBRID: 'Gibrid', ELECTRIC: 'Elektr' };
const pill = (k, label) => `<span class="pill ${esc(k)}">${esc(label ?? BST[k] ?? ST[k] ?? k)}</span>`;
const carPill = s => `<span class="pill ${esc(s)}">${esc(ST[s] || s)}</span>`;

/* ====== API ====== */
const api = async (method, path, body, opts = {}) => {
  let r;
  try {
    r = await fetch('/api' + path, { method, credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'rac' }, body: body == null ? undefined : JSON.stringify(body) });
  } catch { throw new Error("Server bilan aloqa yo'q. Internetni tekshiring."); }
  const ct = r.headers.get('content-type') || '';
  const data = ct.includes('json') ? await r.json() : null;
  if (!r.ok) {
    if (r.status === 401 && !opts.noRedirect && path !== '/auth/login') { App.user = null; App.showLogin(); }
    const e = new Error(data?.error || `Xatolik (${r.status})`); e.status = r.status; e.code = data?.code; throw e;
  }
  return data;
};
const upload = async (file, path = '/upload') => {
  const fd = new FormData(); fd.append('file', file);
  const r = await fetch('/api' + path, { method: 'POST', body: fd, headers: { 'X-Requested-With': 'rac' } });
  const d = await r.json(); if (!r.ok) throw new Error(d.error || 'Yuklab bo\'lmadi'); return d;
};
const qs = o => { const p = new URLSearchParams(); Object.entries(o).forEach(([k, v]) => v !== '' && v != null && p.set(k, v)); const s = p.toString(); return s ? '?' + s : ''; };

/* ====== UI primitive'lar ====== */
const toast = (msg, err) => {
  const t = document.createElement('div'); t.className = 'toast' + (err ? ' err' : ''); t.textContent = msg; $('#toasts').append(t);
  setTimeout(() => t.remove(), err ? 6000 : 3500);
};
const guard = async (fn, btn) => {   // xatoni toastda ko'rsatadi, tugmani bloklaydi
  if (btn) btn.disabled = true;
  try { return await fn(); } catch (e) { toast(e.message, true); return undefined; } finally { if (btn) btn.disabled = false; }
};
let modalStack = [];
function modal(title, body, { footer = '', size = '', onMount, onClose } = {}) {
  const ov = document.createElement('div'); ov.className = 'ov';
  ov.innerHTML = `<div class="modal ${size}" role="dialog" aria-modal="true" aria-label="${esc(title)}"><header><h3>${esc(title)}</h3><button class="x" data-close aria-label="Yopish">×</button></header><div class="bd">${body}</div>${footer ? `<footer>${footer}</footer>` : ''}</div>`;
  const close = () => { ov.remove(); modalStack = modalStack.filter(m => m !== api2); onClose && onClose(); };
  const api2 = { el: ov, close, $: s => $(s, ov), $$: s => $$(s, ov) };
  ov.addEventListener('click', e => { if (e.target === ov || e.target.closest('[data-close]')) close(); });
  document.body.append(ov); modalStack.push(api2);
  const first = $('input:not([type=hidden]),select,textarea', ov); first && first.focus();
  onMount && onMount(api2);
  return api2;
}
document.addEventListener('keydown', e => { if (e.key === 'Escape' && modalStack.length) modalStack[modalStack.length - 1].close(); });
const confirmBox = (title, text, okLabel = 'Tasdiqlash', danger = false) => new Promise(res => {
  const m = modal(title, `<p style="margin:0">${text}</p>`, { size: 'sm', footer: `<button class="btn" data-close>Bekor qilish</button><button class="btn ${danger ? 'danger' : 'primary'}" data-ok>${esc(okLabel)}</button>`, onClose: () => res(false) });
  $('[data-ok]', m.el).addEventListener('click', () => { res(true); m.el.remove(); modalStack = modalStack.filter(x => x !== m); });
});

/* Forma yasash: maydonlar spetsifikatsiyasi → HTML, va qiymatlarni yig'ish */
function fields(spec) {
  return spec.map(f => {
    const id = 'f_' + f.n, v = f.v ?? '';
    let input;
    if (f.t === 'select') input = `<select id="${id}" name="${f.n}">${f.o.map(o => { const [val, lab] = Array.isArray(o) ? o : [o, o]; return `<option value="${esc(val)}" ${String(val) === String(v) ? 'selected' : ''}>${esc(lab)}</option>`; }).join('')}</select>`;
    else if (f.t === 'textarea') input = `<textarea id="${id}" name="${f.n}" ${f.ph ? `placeholder="${esc(f.ph)}"` : ''}>${esc(v)}</textarea>`;
    else if (f.t === 'checkbox') input = `<label style="display:flex;gap:8px;align-items:center;min-height:40px"><input type="checkbox" id="${id}" name="${f.n}" style="width:auto;min-height:0" ${v ? 'checked' : ''}> ${esc(f.label)}</label>`;
    else input = `<input id="${id}" name="${f.n}" type="${f.t || 'text'}" value="${esc(v)}" ${f.ph ? `placeholder="${esc(f.ph)}"` : ''} ${f.req ? 'required' : ''} ${f.min != null ? `min="${f.min}"` : ''} ${f.max != null ? `max="${f.max}"` : ''} ${f.t === 'number' ? 'inputmode="numeric"' : ''} autocomplete="off">`;
    return `<div class="field" style="${f.w ? `grid-column:span ${f.w}` : ''}">${f.t === 'checkbox' ? '' : `<label class="f" for="${id}">${esc(f.label)}${f.req ? ' *' : ''}</label>`}${input}${f.hint ? `<div class="small muted">${esc(f.hint)}</div>` : ''}</div>`;
  }).join('');
}
function collect(root, spec) {
  const o = {};
  for (const f of spec) {
    const el = $(`[name="${f.n}"]`, root); if (!el) continue;
    if (f.t === 'checkbox') o[f.n] = el.checked;
    else if (el.value === '') o[f.n] = f.nullable === false ? '' : null;
    else o[f.n] = f.t === 'number' || f.num ? Number(el.value) : el.value;
  }
  return o;
}
const emptyState = (title, text = '', action = '') => `<div class="empty"><b>${esc(title)}</b>${esc(text)}${action ? `<div style="margin-top:12px">${action}</div>` : ''}</div>`;
const loading = '<div class="loading"><span class="spin"></span></div>';

/* ====== SVG grafiklar (tashqi kutubxonasiz) ====== */
const nf = n => (Math.abs(n) >= 1e6 ? (n / 1e6).toFixed(1).replace('.0', '') + ' mln' : Math.abs(n) >= 1e3 ? Math.round(n / 1e3) + ' ming' : String(n));
const COLORS = ['#e8a800', '#2b6cb0', '#1f9d63', '#d64545', '#7c5cbf', '#0f8b8d', '#c26a1b', '#6b7280'];
function lineChart(labels, series, { h = 220, fmt = nf } = {}) {
  const W = 640, pl = 46, pr = 10, pt = 14, pb = 26;
  const all = series.flatMap(s => s.data); const max = Math.max(1, ...all), min = Math.min(0, ...all);
  const x = i => pl + (labels.length < 2 ? 0 : i * (W - pl - pr) / (labels.length - 1));
  const y = v => pt + (h - pt - pb) * (1 - (v - min) / (max - min || 1));
  let g = '';
  for (let i = 0; i <= 4; i++) { const v = min + (max - min) * i / 4, yy = y(v); g += `<line x1="${pl}" x2="${W - pr}" y1="${yy}" y2="${yy}" stroke="var(--line)"/><text x="${pl - 6}" y="${yy + 4}" text-anchor="end">${fmt(Math.round(v))}</text>`; }
  const step = Math.ceil(labels.length / 8);
  labels.forEach((l, i) => { if (i % step === 0) g += `<text x="${x(i)}" y="${h - 8}" text-anchor="middle">${esc(l)}</text>`; });
  const lines = series.map((s, k) => `<polyline fill="none" stroke="${s.color || COLORS[k]}" stroke-width="2.4" stroke-linejoin="round" points="${s.data.map((v, i) => `${x(i)},${y(v)}`).join(' ')}"/>`).join('');
  return `<svg viewBox="0 0 ${W} ${h}" role="img">${g}${lines}</svg>`;
}
function barChart(labels, series, { h = 220, fmt = nf } = {}) {
  const W = 640, pl = 46, pr = 10, pt = 14, pb = 26;
  const all = series.flatMap(s => s.data); const max = Math.max(1, ...all), min = Math.min(0, ...all);
  const y = v => pt + (h - pt - pb) * (1 - (v - min) / (max - min || 1));
  const gw = (W - pl - pr) / labels.length, bw = Math.min(34, gw / (series.length + 0.6));
  let g = '';
  for (let i = 0; i <= 4; i++) { const v = min + (max - min) * i / 4, yy = y(v); g += `<line x1="${pl}" x2="${W - pr}" y1="${yy}" y2="${yy}" stroke="var(--line)"/><text x="${pl - 6}" y="${yy + 4}" text-anchor="end">${fmt(Math.round(v))}</text>`; }
  labels.forEach((l, i) => {
    g += `<text x="${pl + gw * i + gw / 2}" y="${h - 8}" text-anchor="middle">${esc(l)}</text>`;
    series.forEach((s, k) => { const v = s.data[i]; const bx = pl + gw * i + gw / 2 - (series.length * bw) / 2 + k * bw; g += `<rect x="${bx}" y="${Math.min(y(v), y(0))}" width="${bw - 2}" height="${Math.abs(y(v) - y(0))}" rx="3" fill="${s.color || COLORS[k]}"><title>${esc(s.name || '')}: ${money(v)}</title></rect>`; });
  });
  return `<svg viewBox="0 0 ${W} ${h}" role="img">${g}</svg>`;
}
function hbars(items, { fmt = money, max } = {}) {
  if (!items.length) return emptyState("Ma'lumot yo'q");
  const m = max || Math.max(1, ...items.map(i => i.value));
  return items.map((i, k) => `<div style="margin:9px 0"><div class="row small" style="margin-bottom:3px"><span>${esc(i.name)}</span><span class="sp"></span><b class="num">${esc(fmt(i.value))}</b></div><div class="bar"><i style="width:${Math.max(2, Math.round(i.value / m * 100))}%;background:${COLORS[k % COLORS.length]}"></i></div></div>`).join('');
}
function donut(items, { size = 150 } = {}) {
  const tot = items.reduce((s, i) => s + i.value, 0); if (!tot) return emptyState("Ma'lumot yo'q");
  let a = -Math.PI / 2; const R = 60, r = 38; let paths = '';
  items.forEach((i, k) => {
    const da = i.value / tot * Math.PI * 2 - 0.0001, b = a + da, big = da > Math.PI ? 1 : 0;
    const p = (ang, rad) => [80 + rad * Math.cos(ang), 80 + rad * Math.sin(ang)].map(n => n.toFixed(2)).join(' ');
    paths += `<path d="M${p(a, R)} A${R} ${R} 0 ${big} 1 ${p(b, R)} L${p(b, r)} A${r} ${r} 0 ${big} 0 ${p(a, r)} Z" fill="${COLORS[k % COLORS.length]}"><title>${esc(i.name)}: ${money(i.value)}</title></path>`; a += da + 0.0001;
  });
  const legend = items.map((i, k) => `<div class="small" style="margin:4px 0"><i style="display:inline-block;width:10px;height:10px;border-radius:3px;background:${COLORS[k % COLORS.length]};margin-right:6px"></i>${esc(i.name)} — <b>${Math.round(i.value / tot * 100)}%</b></div>`).join('');
  return `<div class="row" style="gap:18px"><svg viewBox="0 0 160 160" width="${size}" height="${size}" role="img">${paths}</svg><div>${legend}</div></div>`;
}
function gauge(pct) { const c = 2 * Math.PI * 52; return `<svg viewBox="0 0 130 130" width="130" height="130"><circle cx="65" cy="65" r="52" fill="none" stroke="var(--line)" stroke-width="13"/><circle cx="65" cy="65" r="52" fill="none" stroke="var(--amber)" stroke-width="13" stroke-linecap="round" stroke-dasharray="${c * pct / 100} ${c}" transform="rotate(-90 65 65)"/><text x="65" y="72" text-anchor="middle" style="font-size:26px;font-weight:800;fill:var(--text)">${pct}%</text></svg>`; }

const can = p => !!(App.user && App.user.permissions.includes(p));
const App = { user: null, perms: [], showLogin: () => {} };
