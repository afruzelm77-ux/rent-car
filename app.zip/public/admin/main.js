'use strict';
const root = $('#root');
const NAV = [['dashboard', 'Dashboard', '▦'], ['cars', 'Avtomobillar', '🚗'], ['bookings', 'Buyurtmalar', '📅'], ['customers', 'Mijozlar', '👥'], ['botusers', 'Foydalanuvchilar', '👤'], ['finance', 'Moliya', '💰'], ['maintenance', 'Texnik xizmat', '🔧'],
  ['contracts', 'Shartnomalar', '📄'], ['reports', 'Hisobotlar', '📊'], ['chat', 'Suhbatlar', '💬'], ['messages', 'Xabarlar', '✉️'], ['fines', 'Jarimalar', '🚨'], ['gps', 'GPS kuzatuv', '📍'], ['notifications', 'Bildirishnomalar', '🔔'], ['features', 'Funksiyalar', '🧩'], ['staff', 'Xodimlar', '👨‍💼'], ['settings', 'Sozlamalar', '⚙️']];
const NAV_PERM = { dashboard: null, cars: 'cars.read', bookings: 'bookings.read', customers: 'customers.read', botusers: 'customers.read', finance: 'payments.write', maintenance: 'maintenance.read', contracts: 'contracts.read', reports: 'reports.read', notifications: 'notifications.read', messages: 'messages.send', chat: 'messages.send', fines: 'bookings.read', gps: 'cars.read', features: 'settings.manage', staff: 'users.manage',
  settings: ['settings.manage', 'contract.manage', 'promo.write', 'backup.manage', 'audit.read'] };
const NAV_GROUPS = [['Asosiy', ['dashboard', 'cars', 'bookings', 'customers', 'botusers']], ['Operatsiya', ['chat', 'messages', 'fines', 'gps', 'maintenance', 'notifications']], ['Moliya va hisobot', ['finance', 'reports']], ['Tizim', ['contracts', 'features', 'staff', 'settings']]];
const navLink = ([k, v, i]) => `<a href="#/${k}" data-k="${k}"><span>${i}</span>${v}${k === 'notifications' ? '<span class="badge hidden" id="nbadge">0</span>' : ''}</a>`;
function navHtml(items) {
  const by = Object.fromEntries(items.map(x => [x[0], x])); const used = new Set(); let h = '';
  for (const [g, keys] of NAV_GROUPS) { const list = keys.filter(k => by[k]); if (!list.length) continue; list.forEach(k => used.add(k)); h += `<div class="ngrp">${g}</div>` + list.map(k => navLink(by[k])).join(''); }
  const rest = items.filter(x => !used.has(x[0])); if (rest.length) h += '<div class="ngrp">Boshqa</div>' + rest.map(navLink).join('');
  return h;
}
const PAGE_SUB = { bookings: "Barcha buyurtmalar, to'lov va ijara holati", customers: 'Mijozlar bazasi va ijara tarixi', botusers: 'Telegram bot foydalanuvchilari', finance: "To'lovlar, depozitlar va xarajatlar", maintenance: 'Ta\'mirlash va texnik xizmat yozuvlari', contracts: 'Ijara shartnomalari', reports: 'Hisobotlar va tahlil', notifications: 'Tizim bildirishnomalari', messages: 'Mijozlarga yuborilgan xabarlar', features: 'Funksiyalarni yoqish va o\'chirish', staff: 'Xodimlar va ruxsatlar', settings: 'Tizim sozlamalari' };
const allowed = k => { const p = NAV_PERM[k]; return p == null || [].concat(p).some(x => can(x)); };

/* ---- Tema ---- */
const theme = { get: () => localStorage.getItem('rac_theme'), set(v) { localStorage.setItem('rac_theme', v); document.documentElement.dataset.theme = v; } };
if (theme.get()) document.documentElement.dataset.theme = theme.get();

/* ---- Login ---- */
App.showLogin = () => {
  root.innerHTML = `<div class="login"><form class="login-card" id="lf" autocomplete="on"><div class="brand"><i>🚗</i><span>LIDER<small>RENT A CAR</small></span><span class="tag">ADMIN PANEL</span></div><h1>Boshqaruv paneliga kirish</h1>
    <div class="field"><label class="f" for="u">Login</label><input id="u" name="username" autocomplete="username" required autofocus></div>
    <div class="field"><label class="f" for="p">Parol</label><input id="p" name="password" type="password" autocomplete="current-password" required></div>
    <div id="le" style="color:var(--red);min-height:22px;font-size:14px"></div><button class="btn primary" style="width:100%;margin-top:6px" id="lb">Kirish</button></form></div>`;
  $('#lf').addEventListener('submit', async e => { e.preventDefault(); const b = $('#lb'); b.disabled = true; $('#le').textContent = '';
    try { const r = await api('POST', '/auth/login', { username: $('#u').value, password: $('#p').value }); App.user = r.user; App.start(); } catch (err) { $('#le').textContent = err.message; } finally { b.disabled = false; } });
};

/* ---- Qobiq ---- */
App.badge = async () => { try { const n = await api('GET', '/notifications', null, { noRedirect: true }); const b = $('#nbadge'); if (b) { b.textContent = n.unread; b.classList.toggle('hidden', !n.unread); } } catch {} };
App.start = () => {
  const items = NAV.filter(([k]) => allowed(k));
  root.innerHTML = `<div class="shell"><aside class="side" id="side"><div class="brand"><i>🚗</i><span>LIDER<small>RENT A CAR</small></span></div><div style="padding:0 10px 14px"><span class="brand"><span class="tag">ADMIN PANEL</span></span></div><nav class="nav">${navHtml(items)}</nav>
    <div class="foot"><div><b>${esc(App.user.full_name)}</b></div><div class="muted">${esc(ROLE_NAME[App.user.role] || App.user.role)}</div><div class="row" style="margin-top:10px"><button class="btn sm" id="lo">Chiqish</button></div></div></aside>
    <div class="main"><div class="top"><button class="btn menu-btn" id="mb" aria-label="Menyu">☰</button><h2 id="pt"></h2><div class="search"><input id="gs" type="search" placeholder="Qidirish: mashina, raqam, mijoz, telefon, ID" autocomplete="off"><div class="results hidden" id="gr"></div></div></div>
      <main class="content" id="page"></main></div></div>
    <div class="quick" id="quick"><button data-q="newcar"><b>🚗</b>Mashina</button><button data-q="newbooking"><b>＋</b>Yangi bron</button><button data-q="handover"><b>🔑</b>Berish</button><button data-q="return"><b>↩</b>Qaytarish</button><button data-q="expense"><b>🧾</b>Xarajat</button></div>
    ${can('ai.use') ? '<button class="btn dark ai" id="aib" aria-label="AI yordamchi">✨ AI yordamchi</button>' : ''}`;
  const side = $('#side');
  $('#mb').addEventListener('click', () => { side.classList.toggle('open'); if (side.classList.contains('open')) { const s = document.createElement('div'); s.className = 'scrim'; s.addEventListener('click', () => { side.classList.remove('open'); s.remove(); }); document.body.append(s); } });

  $('#lo').addEventListener('click', async () => { await api('POST', '/auth/logout').catch(() => {}); App.user = null; location.hash = ''; App.showLogin(); });
  setupSearch(); if (can('ai.use')) setupAI();
  window.addEventListener('hashchange', route); route(); App.badge(); setInterval(App.badge, 60000);
};
function quickAction(q) {
  const need = { newcar: 'cars.write', newbooking: 'bookings.write', handover: 'handover', return: 'handover', payment: 'payments.write', expense: 'expenses.write' }[q];
  if (!can(need)) return toast("Bu amal uchun sizda ruxsat yo'q", true);
  guard(async () => {
    if (q === 'newcar') return openCarForm();
    if (q === 'newbooking') await openNewBooking();
    if (q === 'handover') await openBookingPicker(['CONFIRMED'], 'Mashina berish — buyurtmani tanlang', "Topshirishga tayyor (tasdiqlangan) buyurtma yo'q");
    if (q === 'return') await openBookingPicker(['ACTIVE', 'OVERDUE'], 'Mashina qaytarish — buyurtmani tanlang', "Hozir ijarada mashina yo'q");
    if (q === 'payment') await openPaymentPicker();
    if (q === 'expense') await openExpenseForm();
  });
}
async function route() {
  if (!App.user) return;
  $('#side')?.classList.remove('open'); $$('.scrim').forEach(s => s.remove());
  let k = (location.hash.replace('#/', '') || 'dashboard').split('?')[0];
  if (!PAGES[k] || !allowed(k)) k = 'dashboard';
  $$('.nav a').forEach(a => a.classList.toggle('on', a.dataset.k === k));
  $('#pt').textContent = PAGES[k].title; document.title = `${PAGES[k].title} — LIDER RENT A CAR`;
  const el = $('#page'); App.refresh = null; el.replaceWith(el.cloneNode(false)); const page = $('.content');   // eski event listenerlarni tozalash
  page.id = 'page'; page.innerHTML = loading;
  try { await PAGES[k].render(page); if (!page.querySelector('.hello')) page.insertAdjacentHTML('afterbegin', `<div class="hello"><div><h1>${esc(PAGES[k].title)}</h1>${PAGE_SUB[k] ? `<p>${PAGE_SUB[k]}</p>` : ''}</div></div>`); } catch (e) { page.innerHTML = emptyState("Sahifani yuklab bo'lmadi", e.message, '<button class="btn" onclick="location.reload()">Qayta urinish</button>'); }
}
document.addEventListener('click', e => { const q = e.target.closest('[data-q]')?.dataset.q; if (q) quickAction(q); });
document.addEventListener('click', e => {   // barcha data-act elementlar (sahifa va modal ichida)
  {
    const a = e.target.closest('[data-act]'); if (!a) return; const act = a.dataset.act, id = +a.dataset.id;
    if (e.target.closest('a[href^="/api"]')) return;
    if (act === 'booking') { e.preventDefault(); guard(() => openBooking(id)); } else if (act === 'car') { e.preventDefault(); guard(() => openCar(id)); } else if (act === 'customer') { e.preventDefault(); guard(() => openCustomer(id)); }
    else if (act === 'newbooking') guard(() => openNewBooking()); else if (act === 'newcar') openCarForm(); else if (act === 'editcar') guard(async () => openCarForm(await api('GET', '/cars/' + id))); else if (act === 'newcust') openCustomerForm();
    else if (act === 'payment') guard(openPaymentPicker); else if (act === 'expense') guard(() => openExpenseForm());
  }
});
App.refresh = null;

/* ---- Global qidiruv ---- */
function setupSearch() {
  const inp = $('#gs'), box = $('#gr'); let tm;
  inp.addEventListener('input', () => { clearTimeout(tm); const q = inp.value.trim(); if (q.length < 2) return box.classList.add('hidden');
    tm = setTimeout(async () => { try { const r = await api('GET', '/search?q=' + encodeURIComponent(q));
      const sec = (t, arr, f) => arr.length ? `<h5>${t}</h5>${arr.map(f).join('')}` : '';
      const html = sec('MASHINALAR', r.cars, c => `<a data-s="car" data-id="${c.id}">${esc(c.brand)} ${esc(c.model)} · ${esc(c.plate)} ${carPill(c.status)}</a>`) + sec('MIJOZLAR', r.customers, c => `<a data-s="customer" data-id="${c.id}">${esc(c.first_name)} ${esc(c.last_name)} · ${esc(c.phone)}</a>`) + sec('BUYURTMALAR', r.bookings, b => `<a data-s="booking" data-id="${b.id}">${esc(b.code)} · ${esc(b.car)} · ${esc(b.customer)} ${pill(b.status)}</a>`);
      box.innerHTML = html || '<a class="muted">Hech narsa topilmadi</a>'; box.classList.remove('hidden'); } catch {} }, 250); });
  box.addEventListener('click', e => { const a = e.target.closest('[data-s]'); if (!a) return; box.classList.add('hidden'); inp.value = ''; const id = +a.dataset.id; ({ car: openCar, customer: openCustomer, booking: openBooking })[a.dataset.s](id); });
  document.addEventListener('click', e => { if (!e.target.closest('.search')) box.classList.add('hidden'); });
}

/* ---- AI yordamchi ---- */
function setupAI() {
  let box = null;
  $('#aib').addEventListener('click', () => {
    if (box) { box.remove(); box = null; return; }
    box = document.createElement('div'); box.className = 'aibox';
    const ex = ['Bugun qancha foyda qildik?', "Qaysi mashinalar bo'sh?", 'Ertaga nechta mashina qaytadi?', "Bu oy eng ko'p daromad qilgan mashina qaysi?", 'Malibu oxirgi oy qancha foyda qildi?'];
    box.innerHTML = `<div class="row" style="padding:12px 14px;border-bottom:1px solid var(--line)"><b>✨ AI yordamchi</b><span class="sp"></span><button class="x" id="aix">×</button></div><div class="msgs" id="am"><div class="msg a">Savol bering — faqat bazadagi haqiqiy ma'lumotdan javob beraman. Ma'lumot bo'lmasa, taxmin qilmayman.</div></div>
      <div class="chips">${ex.map(x => `<span class="chip">${esc(x)}</span>`).join('')}</div><form class="row" style="padding:10px;border-top:1px solid var(--line);flex-wrap:nowrap" id="af"><input id="aq" placeholder="Savolingizni yozing…" maxlength="300" style="flex:1"><button class="btn primary">Yuborish</button></form>`;
    document.body.append(box);
    const msgs = $('#am', box); const add = (t, c) => { const d = document.createElement('div'); d.className = 'msg ' + c; d.textContent = t; msgs.append(d); msgs.scrollTop = 1e9; return d; };
    const ask = async q => { if (!q.trim()) return; add(q, 'u'); const w = add('…', 'a'); try { const r = await api('POST', '/assistant', { question: q }); w.textContent = r.answer + (r.examples ? '\n\n' + r.examples.map(x => '• ' + x).join('\n') : ''); } catch (e) { w.textContent = e.message; } };
    $('#af', box).addEventListener('submit', e => { e.preventDefault(); const i = $('#aq', box); const q = i.value; i.value = ''; ask(q); });
    box.addEventListener('click', e => { if (e.target.closest('#aix')) { box.remove(); box = null; } const c = e.target.closest('.chip'); if (c) ask(c.textContent); });
    $('#aq', box).focus();
  });
}

/* ---- Boshlash ---- */
(async () => {
  try { const r = await api('GET', '/auth/me', null, { noRedirect: true }); App.user = r.user; App.start(); } catch { App.showLogin(); }
})();
