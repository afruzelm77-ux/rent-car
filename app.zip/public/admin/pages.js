'use strict';
const PAGES = {};
let CACHE = {};
const getSettings = async () => (CACHE.settings ||= await api('GET', '/settings').catch(() => ({})));
const getCategories = async () => (CACHE.cats ||= await api('GET', '/expense-categories'));
const bust = () => { CACHE = {}; };
const afterChange = () => { bust(); App.refresh && App.refresh(); };

/* ================= DASHBOARD ================= */
PAGES.dashboard = {
  title: 'Dashboard', icon: '▦',
  async render(el) {
    el.innerHTML = loading;
    const d = await api('GET', '/dashboard');
    const fin = can('finance.read');
    const kpi = (cls, label, val) => `<div class="card kpi ${cls}"><span>${label}</span><b class="num">${val}</b></div>`;
    const pct = d.cars.total ? Math.round(d.cars.rented / d.cars.total * 100) : 0;
    el.innerHTML = `
      ${d.setup && d.setup.length ? `<div class="card" style="margin-bottom:14px;border-left:4px solid var(--amber)"><h3>Boshlash uchun sozlang</h3>${d.setup.map(x => `<div class="alert ${x.key === 'contract' ? 'danger' : ''}"><span>${x.key === 'contract' ? '⚠️' : '•'}</span><span>${esc(x.text)}${x.link ? ` — <a href="${x.link}"><b>sozlash</b></a>` : ''}</span></div>`).join('')}</div>` : ''}
      <div class="grid g6" style="margin-bottom:14px">
        ${kpi('amber', 'Jami mashinalar', d.cars.total)}${kpi('s-av', "🟢 Bo'sh", d.cars.available)}${kpi('s-res', '🟡 Bron qilingan', d.cars.reserved)}
        ${kpi('s-rent', '🔴 Ijarada', d.cars.rented)}${kpi('s-mnt', "🔧 Ta'mirda", d.cars.maintenance)}${kpi('', 'Kutilayotgan buyurtma', d.pending_bookings)}
      </div>
      ${fin ? `<div class="grid g3" style="margin-bottom:14px">
        ${kpi('s-av', 'Bugungi daromad', money(d.today.revenue))}${kpi('s-rent', 'Bugungi xarajat', money(d.today.expenses))}${kpi('amber', 'Bugungi sof foyda', money(d.today.profit))}</div>` : ''}
      <div class="grid g2" style="margin-bottom:14px;grid-template-columns:1.2fr 1fr">
        <div class="card"><h3>BUGUNGI ISHLAR <span class="muted small">— beriladi: ${d.today.pickups}, qaytadi: ${d.today.returns}</span></h3>
          ${d.schedule.length ? d.schedule.map(s => `<div class="sched click" data-act="booking" data-id="${s.id}" style="cursor:pointer"><time>${esc(s.time)}</time><span class="k">${pill(s.kind === 'PICKUP' ? 'CONFIRMED' : 'ACTIVE', s.kind === 'PICKUP' ? 'Berish' : 'Qaytishi')}</span><span class="sp"><b>${esc(s.car)}</b><br><span class="muted small">${esc(s.customer)} · ${esc(s.code)}</span></span>${fin && s.remaining > 0 ? `<span class="small">Qoldiq: <b>${money(s.remaining)}</b></span>` : ''}</div>`).join('') : emptyState("Bugun reja yo'q", 'Bugun mashina berish yoki qaytarish rejalashtirilmagan.')}
          ${fin ? `<div class="row small" style="margin-top:12px"><span>Kutilayotgan daromad: <b>${money(d.today.expected_income)}</b></span><span class="sp"></span><span>Qaytariladigan depozit: <b>${money(d.today.deposits_to_return)}</b></span></div>` : ''}
        </div>
        <div class="card"><h3>Diqqat talab qiladi</h3>
          ${d.overdue.map(o => `<div class="alert danger" data-act="booking" data-id="${o.id}" style="cursor:pointer"><span>⏰</span><span><b>Kechikmoqda: ${esc(o.car)}</b> (${esc(o.plate)})<br>${esc(o.customer)} · ${esc(o.phone)} · ${esc(o.return_label)}</span></div>`).join('')}
          ${d.alerts.slice(0, 8).map(a => `<div class="alert ${a.level === 'danger' ? 'danger' : ''}"><span>${a.type === 'MAINTENANCE' ? '🔧' : a.type === 'EXPIRY' ? '📄' : '📎'}</span><span><b>${esc(a.title)}</b><br>${esc(a.text)}</span></div>`).join('')}
          ${!d.overdue.length && !d.alerts.length ? emptyState("Hammasi joyida", "Kechikish yoki muddat ogohlantirishlari yo'q.") : ''}
        </div>
      </div>
      ${fin ? `<div class="grid g2" style="margin-bottom:14px">
        <div class="card chart"><h3>Kunlik daromad, xarajat va foyda <span class="muted small">(30 kun)</span></h3>
          ${lineChart(d.charts.daily.map(x => x.day.slice(8)), [{ name: 'Daromad', data: d.charts.daily.map(x => x.revenue), color: '#1f9d63' }, { name: 'Xarajat', data: d.charts.daily.map(x => x.expenses), color: '#d64545' }, { name: 'Foyda', data: d.charts.daily.map(x => x.profit), color: '#e8a800' }])}
          <div class="legend"><span><i style="background:#1f9d63"></i>Daromad</span><span><i style="background:#d64545"></i>Xarajat</span><span><i style="background:#e8a800"></i>Foyda</span></div></div>
        <div class="card chart"><h3>Oylik daromad <span class="muted small">(6 oy)</span></h3>
          ${barChart(d.charts.monthly.map(x => x.month.slice(2)), [{ name: 'Daromad', data: d.charts.monthly.map(x => x.revenue), color: '#1f9d63' }, { name: 'Xarajat', data: d.charts.monthly.map(x => x.expenses), color: '#d64545' }, { name: 'Foyda', data: d.charts.monthly.map(x => x.profit), color: '#e8a800' }])}</div>
      </div>` : ''}
      <div class="grid g3">
        <div class="card"><h3>Mashinalar bandligi <span class="muted small">(30 kun)</span></h3><div class="row" style="align-items:flex-start">${gauge(d.charts.utilization_avg)}<div class="sp" style="min-width:150px">${hbars(d.charts.utilization.slice(0, 5).map(u => ({ name: u.name, value: u.value })), { fmt: v => v + '%', max: 100 })}</div></div></div>
        ${fin ? `<div class="card"><h3>Mashina bo'yicha daromad</h3>${hbars(d.charts.revenue_per_car)}</div>
        <div class="card"><h3>Xarajat kategoriyalari</h3>${donut(d.charts.expense_categories.map(c => ({ name: c.name, value: c.amount })))}</div>` : ''}
      </div>`;
  },
};

/* ================= CARS ================= */
const carFormSpec = c => [
  { n: 'brand', label: 'Marka', req: 1, v: c?.brand }, { n: 'model', label: 'Model', req: 1, v: c?.model },
  { n: 'plate', label: 'Davlat raqami', req: 1, v: c?.plate, ph: '01 A 123 AA' }, { n: 'vin', label: 'VIN', v: c?.vin },
  { n: 'year', label: 'Ishlab chiqarilgan yil', t: 'number', v: c?.year }, { n: 'color', label: 'Rang', v: c?.color },
  { n: 'transmission', label: 'Transmissiya', t: 'select', o: [['AUTOMATIC', 'Avtomat'], ['MANUAL', 'Mexanika']], v: c?.transmission },
  { n: 'fuel_type', label: "Yoqilg'i turi", t: 'select', o: Object.entries(FUELT), v: c?.fuel_type },
  { n: 'seats', label: "O'rindiqlar soni", t: 'number', v: c?.seats ?? 5 },
  { n: 'price_day', label: 'Kunlik narx (so\'m)', t: 'number', req: 1, v: c?.price_day }, { n: 'price_3d', label: '3+ kunlik narx', t: 'number', req: 1, v: c?.price_3d },
  { n: 'price_7d', label: '7+ kunlik narx', t: 'number', req: 1, v: c?.price_7d }, { n: 'deposit', label: 'Depozit', t: 'number', v: c?.deposit ?? 0 },
  { n: 'mileage', label: 'Kilometr', t: 'number', v: c?.mileage ?? 0 }, { n: 'fuel_level', label: "Yoqilg'i darajasi (%)", t: 'number', min: 0, max: 100, v: c?.fuel_level ?? 100 },
  { n: 'insurance_until', label: "Sug'urta muddati", t: 'date', v: c?.insurance_until?.slice(0, 10) }, { n: 'inspection_until', label: "Texnik ko'rik muddati", t: 'date', v: c?.inspection_until?.slice(0, 10) },
];
async function openCarForm(car) {
  const spec = carFormSpec(car); const cspec = await customSpec('car', car?.custom || {});
  const m = modal(car ? `${car.brand} ${car.model} — tahrirlash` : "Yangi mashina", `<div class="grid g2">${fields([...spec, ...cspec])}</div><div class="field"><label class="f">Asosiy rasm</label><input type="file" accept="image/jpeg,image/png,image/webp" id="carphoto"><input type="hidden" id="carphotourl" value="${esc(car?.image_url || '')}"><div class="small muted" id="phinfo">${car?.image_url ? 'Rasm yuklangan' : 'JPG, PNG yoki WEBP, 6 MB gacha'}</div></div>`,
    { size: 'lg', footer: `<button class="btn" data-close>Bekor qilish</button><button class="btn primary" data-save>Saqlash</button>` });
  $('#carphoto', m.el).addEventListener('change', async e => { if (!e.target.files[0]) return; await guard(async () => { const r = await upload(e.target.files[0]); $('#carphotourl', m.el).value = r.url; $('#phinfo', m.el).textContent = 'Rasm yuklandi ✓'; }); });
  $('[data-save]', m.el).addEventListener('click', e => guard(async () => {
    const body = collect(m.el, spec); body.image_url = $('#carphotourl', m.el).value || null; if (cspec.length) body.custom = collectCustom(m.el, cspec);
    if (car) await api('PATCH', '/cars/' + car.id, body); else await api('POST', '/cars', body);
    toast('Mashina saqlandi'); m.close(); afterChange();
  }, e.target));
}
PAGES.cars = {
  title: 'Mashinalar', icon: '🚗', perm: 'cars.read',
  async render(el) {
    const st = { status: '', q: '' };
    el.innerHTML = `<div class="row" style="margin-bottom:14px"><div class="tabs" id="ctabs" style="margin:0">${[['', 'Hammasi'], ...Object.entries(ST)].map(([k, v]) => `<button class="tab ${k === '' ? 'on' : ''}" data-s="${k}">${esc(v)}</button>`).join('')}</div><span class="sp"></span><input id="cq" placeholder="Qidirish: marka, raqam..." style="max-width:240px">${can('cars.write') ? '<button class="btn primary" data-act="newcar">+ Mashina qo\'shish</button>' : ''}</div><div id="cl">${loading}</div>`;
    const load = async () => {
      const rows = await api('GET', '/cars' + qs(st));
      $('#cl', el).innerHTML = rows.length ? `<div class="grid g4">${rows.map(c => `<div class="card carcard" data-act="car" data-id="${c.id}"><div class="ph" style="${c.image_url ? `background-image:url('${esc(c.image_url)}')` : ''}">${c.image_url ? '' : '🚗'}${carPill(c.status)}</div>
        <div class="bd"><b>${esc(c.brand)} ${esc(c.model)}</b><div class="muted small">${esc(c.plate)} · ${c.year || ''} · ${TRANS[c.transmission]} · ${FUELT[c.fuel_type]}</div>
        <div class="row" style="margin-top:8px"><b class="num">${moneyS(c.price_day)}</b><span class="muted small">so'm/kun</span><span class="sp"></span><span class="muted small">${moneyS(c.mileage)} km</span></div>
        ${c.holder ? `<div class="small" style="margin-top:6px;color:var(--red)">👤 ${esc(c.holder.customer)} · ${fDT(c.holder.return_at)} gacha</div>` : ''}</div></div>`).join('')}</div>`
        : emptyState('Mashina topilmadi', "Filtrni o'zgartiring yoki yangi mashina qo'shing.", can('cars.write') ? '<button class="btn primary" data-act="newcar">+ Mashina qo\'shish</button>' : '');
    };
    App.refresh = load; await load();
    $('#ctabs', el).addEventListener('click', e => { const b = e.target.closest('[data-s]'); if (!b) return; st.status = b.dataset.s; $$('.tab', el).forEach(t => t.classList.toggle('on', t === b)); load(); });
    let tm; $('#cq', el).addEventListener('input', e => { clearTimeout(tm); tm = setTimeout(() => { st.q = e.target.value; load(); }, 250); });
  },
};

async function openCar(id, month) {
  const c = await api('GET', '/cars/' + id);
  const cdefs = (await customSpec('car', c.custom || {})).filter(x => x.v !== '');
  const s = c.stats, fin = can('finance.read');
  const cal = await api('GET', `/cars/${id}/calendar${month ? '?month=' + month : ''}`);
  const first = new Date(cal.month + '-01T00:00:00Z'); const off = (first.getUTCDay() + 6) % 7;
  const calHtml = ['Du', 'Se', 'Ch', 'Pa', 'Ju', 'Sh', 'Ya'].map(d => `<div class="h">${d}</div>`).join('') + '<div></div>'.repeat(off) + cal.days.map(d => `<div class="d ${d.status}" title="${esc(d.booking ? d.booking.code + ' · ' + d.booking.customer : '')}">${+d.date.slice(8)}</div>`).join('');
  const prev = (() => { const d = new Date(cal.month + '-01T00:00:00Z'); d.setUTCMonth(d.getUTCMonth() - 1); return d.toISOString().slice(0, 7); })();
  const next = (() => { const d = new Date(cal.month + '-01T00:00:00Z'); d.setUTCMonth(d.getUTCMonth() + 1); return d.toISOString().slice(0, 7); })();
  const w = can('cars.write');
  const m = modal(`${c.brand} ${c.model}`, `
    <div class="row" style="margin-bottom:14px">${carPill(c.status)}<span class="muted">${esc(c.plate)} · VIN ${esc(c.vin || '—')} · ${c.year || ''} · ${esc(c.color || '')}</span></div>
    <div class="grid g2">
      <div class="card"><h3>Hozirgi holat</h3><dl class="dl">
        <dt>Kimda?</dt><dd>${s.current ? `<a href="#" data-act="customer" data-id="${s.current.customer_id}">${esc(s.current.customer)}</a> · ${esc(s.current.phone)}` : 'Hech kimda'}</dd>
        <dt>Qachon berilgan?</dt><dd>${s.current ? fDT(s.current.actual_pickup_at || s.current.pickup_at) : '—'}</dd>
        <dt>Qachon qaytadi?</dt><dd>${s.current ? fDT(s.current.return_at) : s.next ? `Keyingi bron: ${fDT(s.next.pickup_at)}` : '—'}</dd>
        <dt>Necha kun ijarada?</dt><dd>${s.current ? s.current.days_out + ' kun (hozirgi)' : '—'} · jami ${s.days_rented} kun, ${s.rentals} ta ijara</dd>
        <dt>Qancha daromad qilgan?</dt><dd>${fin ? money(s.revenue) : '—'}</dd><dt>Qancha xarajat bo'lgan?</dt><dd>${fin ? money(s.expenses) : '—'}</dd>
        <dt>Sof foyda qancha?</dt><dd>${fin ? `<span style="color:${s.profit >= 0 ? 'var(--green)' : 'var(--red)'}">${money(s.profit)}</span>` : '—'}</dd><dt>Bandlik (30 kun)</dt><dd>${s.utilization}%</dd></dl></div>
      <div class="card"><h3>Ma'lumotlar</h3><dl class="dl"><dt>Narx</dt><dd>${money(c.price_day)} / 3+: ${money(c.price_3d)} / 7+: ${money(c.price_7d)}</dd><dt>Depozit</dt><dd>${money(c.deposit)}</dd>
        <dt>Kilometr</dt><dd>${moneyS(c.mileage)} km</dd><dt>Yoqilg'i</dt><dd>${FUELT[c.fuel_type]}, ${c.fuel_level}%</dd><dt>Transmissiya / o'rin</dt><dd>${TRANS[c.transmission]}, ${c.seats} o'rin</dd>
        <dt>Sug'urta</dt><dd>${c.insurance_until ? fDate(c.insurance_until) : '—'}</dd><dt>Texnik ko'rik</dt><dd>${c.inspection_until ? fDate(c.inspection_until) : '—'}</dd>${cdefs.map(x => `<dt>${esc(x.label)}</dt><dd>${esc(x.v)}</dd>`).join('')}</dl></div>
    </div>
    <div class="card" style="margin-top:14px"><div class="row"><h3 style="margin:0">Kalendar — ${esc(cal.month)}</h3><span class="sp"></span><button class="btn sm" data-month="${prev}">←</button><button class="btn sm" data-month="${next}">→</button></div>
      <div class="legend" style="margin:8px 0"><span><i style="background:#9fe0c0"></i>Bo'sh</span><span><i style="background:#f6d56b"></i>Bron</span><span><i style="background:#f2a0a0"></i>Ijarada</span><span><i style="background:#a8c4ea"></i>Ta'mir</span></div><div class="cal">${calHtml}</div></div>
    <div class="grid g2" style="margin-top:14px">
      <div class="card"><h3>Texnik xizmat tarixi</h3>${s.maintenance.length ? `<div class="tablewrap"><table><tr><th>Sana</th><th>Tur</th><th>km</th><th>Keyingi</th></tr>${s.maintenance.slice(0, 8).map(x => `<tr><td>${fDate(x.done_at)}</td><td>${MKIND[x.kind]}</td><td class="num">${x.mileage_at ?? '—'}</td><td class="num">${x.next_due_km ? x.next_due_km + ' km' : x.next_due_date ? fDate(x.next_due_date) : '—'}</td></tr>`).join('')}</table></div>` : emptyState("Tarix yo'q")}</div>
      <div class="card"><h3>Holat tarixi</h3>${c.status_history.length ? c.status_history.map(h => `<div class="kv small"><span>${esc(h.old_status || '—')} → <b>${esc(h.new_status)}</b></span><span class="muted">${fDT(h.created_at)}${h.full_name ? ' · ' + esc(h.full_name) : ''}</span></div>`).join('') : emptyState("Tarix yo'q")}
        <h3 style="margin-top:14px">Qo'shimcha rasmlar</h3><div class="row">${c.images.map(i => `<span style="position:relative"><img src="${esc(i.url)}" alt="" style="width:74px;height:56px;object-fit:cover;border-radius:6px">${w ? `<button class="x" data-delimg="${i.id}" style="position:absolute;top:-8px;right:-4px;background:var(--card);border-radius:50%;width:20px;height:20px;font-size:14px">×</button>` : ''}</span>`).join('') || '<span class="muted small">Yo\'q</span>'}${w ? '<label class="btn sm">+ Rasm<input type="file" id="addimg" accept="image/jpeg,image/png,image/webp" hidden></label>' : ''}</div></div>
    </div>`, { size: 'lg', footer: w ? `<button class="btn danger" data-del>O'chirish</button><span class="sp"></span>
      ${['AVAILABLE', 'MAINTENANCE', 'INACTIVE'].filter(x => x !== c.status && !['RENTED', 'RESERVED'].includes(c.status)).map(x => `<button class="btn" data-st="${x}">${esc(ST[x])}</button>`).join('')}${c.status === 'RESERVED' ? `<button class="btn" data-st="AVAILABLE">${esc(ST.AVAILABLE)}</button>` : ''}
      <button class="btn dark" data-edit>Tahrirlash</button>` : '' });
  m.el.addEventListener('click', async e => {
    const t = e.target;
    if (t.closest('[data-month]')) { m.close(); openCar(id, t.closest('[data-month]').dataset.month); }
    else if (t.closest('[data-edit]')) { m.close(); openCarForm(c); }
    else if (t.closest('[data-st]')) { const to = t.closest('[data-st]').dataset.st; if (await confirmBox('Holatni o\'zgartirish', `Mashina holati «${esc(ST[to])}» ga o'zgartiriladi.`)) guard(async () => { await api('POST', `/cars/${id}/status`, { status: to }); toast('Holat yangilandi'); m.close(); afterChange(); }); }
    else if (t.closest('[data-del]')) { if (await confirmBox("Mashinani o'chirish", `<b>${esc(c.brand)} ${esc(c.model)}</b> o'chiriladi. Buyurtmalar tarixi saqlanib qoladi. Davom etasizmi?`, "O'chirish", true)) guard(async () => { await api('DELETE', '/cars/' + id); toast("Mashina o'chirildi"); m.close(); afterChange(); }); }
    else if (t.closest('[data-delimg]')) guard(async () => { await api('DELETE', `/cars/${id}/images/${t.closest('[data-delimg]').dataset.delimg}`); m.close(); openCar(id); });
  });
  const ai = $('#addimg', m.el); ai && ai.addEventListener('change', e => guard(async () => { const r = await upload(e.target.files[0]); await api('POST', `/cars/${id}/images`, { url: r.url }); m.close(); openCar(id); }));
}

/* ================= BOOKINGS ================= */
async function pickCustomer(sel) {
  const list = await api('GET', '/customers?limit=200'); sel.innerHTML = list.map(c => `<option value="${c.id}">${esc(c.first_name)} ${esc(c.last_name)} — ${esc(c.phone)}</option>`).join('');
}
async function openNewBooking(pre = {}) {
  const [cars, S, promos] = await Promise.all([api('GET', '/cars'), getSettings(), api('GET', '/promos').catch(() => [])]);
  const locs = JSON.parse(S.locations || '[]'), extras = JSON.parse(S.extras_catalog || '[]');
  const tomorrow = addD(isoDate(), 1);
  const m = modal('Yangi bron', `<div class="grid g2">
    <div class="field"><label class="f">Mijoz *</label><div class="row" style="flex-wrap:nowrap"><select id="nb_c" style="flex:1"></select><button class="btn" data-newcust type="button">+ Yangi</button></div></div>
    <div class="field"><label class="f">Mashina *</label><select id="nb_car">${cars.filter(c => c.status !== 'INACTIVE').map(c => `<option value="${c.id}" ${pre.car_id == c.id ? 'selected' : ''}>${esc(c.brand)} ${esc(c.model)} (${esc(c.plate)}) — ${moneyS(c.price_day)}${c.status !== 'AVAILABLE' ? ' · ' + (ST[c.status] || '') : ''}</option>`).join('')}</select></div>
    <div class="field"><label class="f">Olish sanasi *</label><input type="date" id="nb_pd" value="${tomorrow}"></div><div class="field"><label class="f">Olish vaqti *</label><input type="time" id="nb_pt" value="10:00"></div>
    <div class="field"><label class="f">Qaytarish sanasi *</label><input type="date" id="nb_rd" value="${addD(tomorrow, 3)}"></div><div class="field"><label class="f">Qaytarish vaqti *</label><input type="time" id="nb_rt" value="10:00"></div>
    <div class="field"><label class="f">Olib ketish joyi</label>${locs.length ? `<select id="nb_loc">${locs.map(l => `<option>${esc(l)}</option>`).join('')}</select>` : '<input id="nb_loc" placeholder="Ixtiyoriy">'}</div>
    <div class="field"><label class="f">Promo kod</label><input id="nb_promo" placeholder="RENT10" style="text-transform:uppercase"></div>
  </div>
  ${extras.length ? `<div class="field"><label class="f">Qo'shimcha xizmatlar</label>${extras.map((x, i) => `<label style="display:flex;gap:8px;align-items:center;min-height:34px"><input type="checkbox" class="nb_x" value="${esc(x.name)}" style="width:auto;min-height:0"> ${esc(x.name)} — ${money(x.price)}${x.per === 'day' ? ' / kun' : ''}</label>`).join('')}</div>` : ''}
  <div class="field"><label class="f">Izoh</label><textarea id="nb_notes"></textarea></div>
  <div class="card" id="nb_q" style="background:var(--bg)"><span class="muted">Narx hisoblanmoqda…</span></div>`,
    { size: 'lg', footer: '<button class="btn" data-close>Bekor qilish</button><button class="btn primary" data-save>Bron yaratish</button>' });
  await pickCustomer($('#nb_c', m.el)); if (pre.customer_id) $('#nb_c', m.el).value = pre.customer_id;
  const body = () => ({ customer_id: +$('#nb_c', m.el).value, car_id: +$('#nb_car', m.el).value, pickup_date: $('#nb_pd', m.el).value, pickup_time: $('#nb_pt', m.el).value, return_date: $('#nb_rd', m.el).value, return_time: $('#nb_rt', m.el).value,
    location: $('#nb_loc', m.el).value || null, promo_code: $('#nb_promo', m.el).value.trim() || null, notes: $('#nb_notes', m.el).value || null, extras: $$('.nb_x:checked', m.el).map(x => ({ name: x.value, qty: 1 })) });
  let tm; const quote = () => { clearTimeout(tm); tm = setTimeout(async () => {
    const b = body(); const box = $('#nb_q', m.el);
    try { const q = await api('POST', '/bookings/quote', b);
      box.innerHTML = `<div class="kv"><span>${q.days} kun × ${money(q.rate)}</span><b class="num">${money(q.rental)}</b></div>${q.discount ? `<div class="kv"><span>Chegirma</span><b class="num">− ${money(q.discount)}</b></div>` : ''}${q.items.map(i => `<div class="kv"><span>${esc(i.name)}</span><b class="num">${money(i.total)}</b></div>`).join('')}<div class="kv"><span>Ijara jami</span><b class="num">${money(q.total)}</b></div><div class="kv"><span>Depozit (alohida)</span><b class="num">${money(q.deposit)}</b></div><div class="kv total"><span>To'lanadigan jami</span><span class="num">${money(q.grand_total)}</span></div>`;
    } catch (e) { box.innerHTML = `<span style="color:var(--red)">${esc(e.message)}</span>`; } }, 250); };
  m.el.addEventListener('input', quote); m.el.addEventListener('change', quote); quote();
  m.el.addEventListener('click', e => { if (e.target.closest('[data-newcust]')) openCustomerForm(async nc => { await pickCustomer($('#nb_c', m.el)); $('#nb_c', m.el).value = nc.id; quote(); }); });
  $('[data-save]', m.el).addEventListener('click', ev => guard(async () => { const b = await api('POST', '/bookings', body()); toast(`Bron yaratildi: ${b.code}`); m.close(); afterChange(); openBooking(b.id); }, ev.target));
}

PAGES.bookings = {
  title: 'Buyurtmalar', icon: '📅', perm: 'bookings.read',
  async render(el) {
    const st = { status: '', q: '', pay: '', from: '', to: '', car_id: '' };
    const cars = await api('GET', '/cars');
    el.innerHTML = `<div class="row" style="margin-bottom:12px">${can('bookings.write') ? '<button class="btn primary" data-act="newbooking">+ Yangi bron</button>' : ''}<span class="sp"></span><a class="btn" href="/api/export/bookings.csv">⬇ CSV</a></div>
      <div class="card" style="margin-bottom:14px"><div class="grid g6" style="align-items:end">
        <div><label class="f">Qidirish</label><input id="f_q" placeholder="ID, mijoz, telefon, raqam"></div>
        <div><label class="f">Ijara statusi</label><select id="f_status"><option value="">Hammasi</option>${Object.entries(BST).map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}</select></div>
        <div><label class="f">To'lov statusi</label><select id="f_pay"><option value="">Hammasi</option><option value="paid">To'langan</option><option value="partial">Qisman</option><option value="unpaid">To'lanmagan</option></select></div>
        <div><label class="f">Mashina</label><select id="f_car"><option value="">Hammasi</option>${cars.map(c => `<option value="${c.id}">${esc(c.brand)} ${esc(c.model)}</option>`).join('')}</select></div>
        <div><label class="f">Sanadan</label><input type="date" id="f_from"></div><div><label class="f">Sanagacha</label><input type="date" id="f_to"></div></div></div>
      <div class="card" id="bl">${loading}</div>`;
    const load = async () => {
      const rows = await api('GET', '/bookings' + qs({ status: st.status, q: st.q, pay: st.pay, from: st.from, to: st.to, car_id: st.car_id, limit: 200 }));
      $('#bl', el).innerHTML = rows.length ? `<div class="tablewrap"><table><tr><th>ID</th><th>Mijoz</th><th>Mashina</th><th>Olish</th><th>Qaytarish</th><th>Holat</th><th class="right">Jami</th><th class="right">Qoldiq</th></tr>
        ${rows.map(b => `<tr class="click" data-act="booking" data-id="${b.id}"><td class="nowrap"><b>${esc(b.code)}</b></td><td>${esc(b.customer)}<div class="muted small">${esc(b.phone)}</div></td><td>${esc(b.car)}<div class="muted small">${esc(b.plate)}</div></td><td class="nowrap">${fDT(b.pickup_at)}</td><td class="nowrap">${fDT(b.return_at)}</td><td>${pill(b.status)}</td><td class="right num">${moneyS(b.total_amount)}</td><td class="right num" style="color:${Number(b.remaining) > 0 && !['CANCELLED'].includes(b.status) ? 'var(--red)' : 'inherit'}">${b.status === 'CANCELLED' ? '—' : moneyS(b.remaining)}</td></tr>`).join('')}</table></div>`
        : emptyState('Buyurtma topilmadi', "Filtrlarni o'zgartiring yoki yangi bron yarating.");
    };
    App.refresh = load; load();
    const map = { f_q: 'q', f_status: 'status', f_pay: 'pay', f_from: 'from', f_to: 'to', f_car: 'car_id' };
    let tm; el.addEventListener('input', e => { const k = map[e.target.id]; if (!k) return; st[k] = e.target.value; clearTimeout(tm); tm = setTimeout(load, 250); });
  },
};

const depLine = b => b.dep_status ? `<div class="kv"><span>Depozit</span><span>${money(b.deposit_amount)} · ${esc(DEPST[b.dep_status] || b.dep_status)}${Number(b.dep_deducted) ? ` · ushlangan ${money(b.dep_deducted)}` : ''}${Number(b.dep_returned) ? ` · qaytarilgan ${money(b.dep_returned)}` : ''}</span></div>` : '';
async function openBooking(id) {
  const b = await api('GET', '/bookings/' + id);
  const w = can('bookings.write'), pay = can('payments.write'), ho = can('handover');
  const st = b.status, rem = Number(b.total_amount) - Number(b.paid_amount), depLeft = Number(b.deposit_amount) - Number(b.dep_held || 0);
  let cmp = ''; if (b.inspections.length) { try { const c = await api('GET', `/bookings/${id}/compare`);
    const row = (k, a, r, d) => `<tr><td>${k}</td><td>${esc(a ?? '—')}</td><td>${esc(r ?? '—')}</td><td>${d ?? ''}</td></tr>`;
    cmp = `<div class="card" style="margin-top:14px"><h3>Berish va qaytarish holati</h3><div class="tablewrap"><table><tr><th></th><th>Berilganda</th><th>Qaytarilganda</th><th>Farq</th></tr>
      ${row('Vaqt', fDT(c.handover.inspected_at), c.return && fDT(c.return.inspected_at))}${row('Kilometr', c.handover.mileage + ' km', c.return && c.return.mileage + ' km', c.diff && `<b>${c.diff.driven_km} km yurilgan</b>`)}
      ${row("Yoqilg'i", c.handover.fuel_level + '%', c.return && c.return.fuel_level + '%', c.diff && (c.diff.fuel_change < 0 ? `<span style="color:var(--red)">${c.diff.fuel_change}%</span>` : `${c.diff.fuel_change}%`))}
      ${row('Kuzov', c.handover.body_condition, c.return?.body_condition, c.diff?.body_changed ? '<span style="color:var(--red)">o\'zgargan</span>' : '')}${row('Salon', c.handover.interior_condition, c.return?.interior_condition, c.diff?.interior_changed ? '<span style="color:var(--red)">o\'zgargan</span>' : '')}
      ${row('Shikastlar', c.handover.damages || 'yo\'q', c.return ? c.return.damages || "yo'q" : null, c.diff?.new_damages ? `<span style="color:var(--red)">yangi: ${esc(c.diff.new_damages)}</span>` : '')}${row('Xodim', c.handover.staff, c.return?.staff)}</table></div>
      ${[...(c.handover.photos || []), ...((c.return && c.return.photos) || [])].map(u => `<img src="${esc(u)}" alt="" style="width:80px;height:60px;object-fit:cover;border-radius:6px;margin:6px 6px 0 0">`).join('')}</div>`; } catch {} }
  const m = modal(`${b.code} · ${BST[st]}`, `
    <div class="grid g2"><div class="card"><h3>Mijoz va mashina</h3><dl class="dl"><dt>Mijoz</dt><dd><a href="#" data-act="customer" data-id="${b.customer_id}">${esc(b.first_name)} ${esc(b.last_name)}</a></dd><dt>Telefon</dt><dd><a href="tel:${esc(b.phone)}">${esc(b.phone)}</a></dd>
      <dt>Mashina</dt><dd><a href="#" data-act="car" data-id="${b.car_id}">${esc(b.brand)} ${esc(b.model)}</a> · ${esc(b.plate)}</dd><dt>Olish</dt><dd>${fDT(b.pickup_at)}</dd><dt>Qaytarish</dt><dd>${fDT(b.return_at)}${b.late_info?.late_minutes ? ` <span style="color:var(--red)">· ${Math.floor(b.late_info.late_minutes / 60)} soat ${b.late_info.late_minutes % 60} daqiqa kechikkan</span>` : ''}</dd>
      <dt>Joy</dt><dd>${esc(b.pickup_location || '—')}</dd><dt>Manba</dt><dd>${esc(b.source)}</dd>
      <dt>Shartnoma roziligi</dt><dd>${b.consent ? `<span style="color:var(--green)">✅ Rozilik berilgan</span><div class="small muted">${fDT(b.consent.accepted_at)} · ${({ MINIAPP: 'Telegram Mini App', BOT: 'Telegram bot', PAPER: "Qog'ozda imzolangan" })[b.consent.channel]} · v${b.consent.version}${b.consent.recorded_by_name ? ' · qayd etgan: ' + esc(b.consent.recorded_by_name) : ''}</div>` : (st === 'CANCELLED' ? '—' : '<span style="color:var(--red)">❌ Rozilik olinmagan</span>')}</dd>${b.notes ? `<dt>Izoh</dt><dd>${esc(b.notes)}</dd>` : ''}</dl></div>
    <div class="card"><h3>Hisob-kitob</h3><div class="kv"><span>${b.days} kun × ${money(b.daily_rate)}</span><span class="num">${money(b.rental_amount)}</span></div>
      ${Number(b.discount) ? `<div class="kv"><span>Chegirma</span><span class="num">− ${money(b.discount)}</span></div>` : ''}${b.items.map(i => `<div class="kv"><span>${esc(i.name)} × ${i.qty}</span><span class="num">${money(i.total)}</span></div>`).join('')}
      ${Number(b.late_fee) ? `<div class="kv"><span>Kechikish haqi</span><span class="num">${money(b.late_fee)}</span></div>` : ''}${Number(b.damage_fee) ? `<div class="kv"><span>Zarar</span><span class="num">${money(b.damage_fee)}</span></div>` : ''}
      <div class="kv"><span>Jami ijara</span><b class="num">${money(b.total_amount)}</b></div><div class="kv"><span>To'langan</span><span class="num">${money(b.paid_amount)}</span></div><div class="kv total"><span>Qolgan summa</span><span class="num" style="color:${rem > 0 && st !== 'CANCELLED' ? 'var(--red)' : 'var(--green)'}">${st === 'CANCELLED' ? '—' : money(rem)}</span></div>${depLine(b)}</div></div>
    ${b.payments.length ? `<div class="card" style="margin-top:14px"><h3>To'lovlar</h3><div class="tablewrap"><table><tr><th>Vaqt</th><th>Tur</th><th>Usul</th><th class="right">Summa</th></tr>${b.payments.map(p => `<tr><td>${fDT(p.paid_at)}</td><td>${esc(KIND[p.kind] || p.kind)}</td><td>${esc(METHOD[p.method] || p.method)}</td><td class="right num">${money(p.amount)}</td></tr>`).join('')}</table></div></div>` : ''}${cmp}`,
    { size: 'lg', footer: `
      ${b.contract || st === 'CONFIRMED' || st === 'ACTIVE' || st === 'COMPLETED' ? `<a class="btn" href="/api/bookings/${id}/contract" download>📄 Shartnoma (PDF)</a>` : ''}<span class="sp"></span>
      ${w && st === 'PENDING' ? '<button class="btn ok" data-do="confirm">✅ Tasdiqlash</button><button class="btn danger" data-do="cancel">❌ Rad etish</button>' : ''}
      ${w && st === 'CONFIRMED' ? '<button class="btn danger" data-do="cancel">Bekor qilish</button>' : ''}
      ${pay && ['PENDING', 'CONFIRMED'].includes(st) && depLeft > 0 ? '<button class="btn" data-do="deposit">Depozit qabul qilish</button>' : ''}
      ${pay && ['PENDING', 'CONFIRMED', 'ACTIVE', 'OVERDUE', 'COMPLETED'].includes(st) && rem > 0 ? `<button class="btn" data-do="pay">💰 To'lov</button>` : ''}
      ${!b.consent && ['PENDING', 'CONFIRMED'].includes(st) && (ho || w) ? `${b.customer_tg ? '<button class="btn" data-do="reqconsent">📨 Rozilik so\'rovi</button>' : ''}<button class="btn" data-do="paper">✍️ Qog'ozda imzolandi</button>` : ''}
      ${ho && st === 'CONFIRMED' ? '<button class="btn primary" data-do="handover">🚗 Mashina berish</button>' : ''}${ho && ['ACTIVE', 'OVERDUE'].includes(st) ? '<button class="btn primary" data-do="return">↩ Mashina qaytarish</button>' : ''}` });
  m.el.addEventListener('click', async e => {
    const t = e.target, act = t.closest('[data-do]')?.dataset.do;
    if (!act) return;
    if (act === 'confirm') { if (await confirmBox('Buyurtmani tasdiqlash', `<b>${esc(b.code)}</b> tasdiqlanadi, shartnoma yaratiladi va mijozga xabar yuboriladi.`)) guard(async () => { await api('POST', `/bookings/${id}/confirm`); toast('Buyurtma tasdiqlandi'); m.close(); afterChange(); openBooking(id); }); }
    if (act === 'cancel') { const mm = modal('Buyurtmani bekor qilish', `<div class="field"><label class="f">Sabab</label><input id="cr"></div>${Number(b.paid_amount) > 0 ? `<label style="display:flex;gap:8px;align-items:center"><input type="checkbox" id="cr_refund" style="width:auto;min-height:0">To'langan ijara summasini (${money(b.paid_amount)}) qaytarish</label>` : ''}`, { size: 'sm', footer: '<button class="btn" data-close>Yopish</button><button class="btn danger" data-go>Bekor qilish</button>' });
      $('[data-go]', mm.el).addEventListener('click', ev => guard(async () => { await api('POST', `/bookings/${id}/cancel`, { reason: $('#cr', mm.el).value, refund_paid: !!$('#cr_refund', mm.el)?.checked }); toast('Buyurtma bekor qilindi'); mm.close(); m.close(); afterChange(); }, ev.target)); }
    if (act === 'pay' || act === 'deposit') openPayment(b, act === 'deposit', () => { m.close(); afterChange(); openBooking(id); });
    if (act === 'reqconsent') guard(async () => { await api('POST', `/bookings/${id}/request-consent`); toast('Rozilik so\'rovi mijozga Telegramda yuborildi'); }, t.closest('[data-do]'));
    if (act === 'paper' && await confirmBox("Qog'ozdagi rozilik", "Mijoz shartnomani o'qib, qog'ozga imzo qo'ydi — buni tasdiqlaysizmi? Amal audit logga yoziladi.")) guard(async () => { await api('POST', `/bookings/${id}/consent-paper`); toast('Rozilik qayd etildi'); m.close(); afterChange(); openBooking(id); });
    if (act === 'handover') openHandover(b, () => { m.close(); afterChange(); openBooking(id); });
    if (act === 'return') openReturn(b, () => { m.close(); afterChange(); openBooking(id); });
  });
}
function openPayment(b, isDeposit, done) {
  const rem = Number(b.total_amount) - Number(b.paid_amount), depLeft = Number(b.deposit_amount) - Number(b.dep_held || 0);
  const spec = [{ n: 'amount', label: "Summa (so'm)", t: 'number', req: 1, v: isDeposit ? depLeft : rem, hint: isDeposit ? `Depozit qolgan: ${money(depLeft)}` : `Qolgan summa: ${money(rem)}` },
    { n: 'method', label: "To'lov usuli", t: 'select', o: Object.entries(METHOD) }];
  const m = modal(isDeposit ? 'Depozit qabul qilish' : "To'lov qabul qilish", fields(spec), { size: 'sm', footer: '<button class="btn" data-close>Bekor qilish</button><button class="btn primary" data-go>Qabul qilish</button>' });
  $('[data-go]', m.el).addEventListener('click', async ev => { const body = collect(m.el, spec); if (!(await confirmBox('Moliyaviy amal', `${money(body.amount)} — ${esc(METHOD[body.method])} orqali ${isDeposit ? 'depozit' : "to'lov"} qabul qilinadi.`))) return;
    guard(async () => { await api('POST', `/bookings/${b.id}/payments`, { ...body, kind: isDeposit ? 'DEPOSIT' : 'RENTAL' }); toast("To'lov qabul qilindi"); m.close(); done(); }, ev.target); });
}
async function openHandover(b, done) {
  const car = await api('GET', '/cars/' + b.car_id);
  const spec = [{ n: 'mileage', label: "Boshlang'ich kilometr", t: 'number', req: 1, v: car.mileage }, { n: 'fuel_level', label: "Yoqilg'i (%)", t: 'number', min: 0, max: 100, v: car.fuel_level },
    { n: 'body_condition', label: 'Kuzov holati', v: 'Yaxshi, shikastsiz', w: 2 }, { n: 'interior_condition', label: 'Salon holati', v: 'Toza', w: 2 }, { n: 'damages', label: 'Mavjud shikastlar', t: 'textarea', w: 2, ph: "Masalan: old bamperda kichik chizilish" }, { n: 'video_url', label: 'Video havola (ixtiyoriy)', w: 2 }];
  const photos = [];
  const depWarn = Number(b.dep_held) < Number(b.deposit_amount);
  const m = modal(`Mashina berish — ${b.brand} ${b.model}`, `${depWarn ? `<div class="alert danger">Depozit to'liq qabul qilinmagan: ${money(b.dep_held)} / ${money(b.deposit_amount)}</div>` : ''}<div class="grid g2">${fields(spec)}</div>
    <div class="field"><label class="f">Rasmlar (kuzov, salon, shikastlar)</label><input type="file" id="hp" accept="image/jpeg,image/png,image/webp" multiple><div id="hpl" class="row" style="margin-top:6px"></div></div>`, { size: 'lg', footer: '<button class="btn" data-close>Bekor qilish</button><button class="btn primary" data-go>Mashinani topshirish</button>' });
  $('#hp', m.el).addEventListener('change', e => guard(async () => { for (const f of e.target.files) { const r = await upload(f); photos.push(r.url); $('#hpl', m.el).insertAdjacentHTML('beforeend', `<img src="${esc(r.url)}" alt="" style="width:64px;height:48px;object-fit:cover;border-radius:6px">`); } }));
  $('[data-go]', m.el).addEventListener('click', ev => guard(async () => {
    const body = collect(m.el, spec); body.photos = photos; if (body.video_url === null) delete body.video_url;
    if (depWarn && await confirmBox('Depozit qabul qilinmagan', "Depozitsiz topshirilsinmi?", 'Baribir topshirish', true)) body.force = true; else if (depWarn) return;
    await api('POST', `/bookings/${b.id}/handover`, body); toast('Mashina topshirildi'); m.close(); done(); }, ev.target));
}
async function openReturn(b, done) {
  const car = await api('GET', '/cars/' + b.car_id); const late = b.late_info || {};
  const spec = [{ n: 'mileage', label: 'Yakuniy kilometr', t: 'number', req: 1, v: car.mileage, hint: `Hozirgi: ${car.mileage} km` }, { n: 'fuel_level', label: "Yoqilg'i (%)", t: 'number', min: 0, max: 100, req: 1, v: 50 },
    { n: 'body_condition', label: 'Kuzov holati', v: 'Yaxshi', w: 2 }, { n: 'interior_condition', label: 'Salon holati', v: 'Toza', w: 2 }, { n: 'damages', label: 'Yangi shikastlar', t: 'textarea', w: 2 },
    { n: 'damage_fee', label: "Zarar summasi (so'm)", t: 'number', v: 0 }, { n: 'refund_method', label: "Depozit qaytarish usuli", t: 'select', o: Object.entries(METHOD).filter(([k]) => k !== 'ONLINE') },
    { n: 'use_deposit', label: "Kechikish/zarar depozitdan ushlansin", t: 'checkbox', v: true, w: 2 }, { n: 'send_to_maintenance', label: "Mashinani ta'mirga yuborish", t: 'checkbox', w: 2 }];
  const photos = [];
  const m = modal(`Mashina qaytarish — ${b.brand} ${b.model}`, `${late.late_minutes > 0 ? `<div class="alert ${late.late_fee ? 'danger' : ''}"><span>⏰</span><span>Kechikish: <b>${Math.floor(late.late_minutes / 60)} soat ${late.late_minutes % 60} daqiqa</b>${late.late_fee ? ` — kechikish haqi <b>${money(late.late_fee)}</b>` : ' (imtiyoz muddati ichida)'}</span></div>` : ''}
    <div class="grid g2">${fields(spec)}</div><div class="field"><label class="f">Rasmlar</label><input type="file" id="rp" accept="image/jpeg,image/png,image/webp" multiple><div id="rpl" class="row" style="margin-top:6px"></div></div>`,
    { size: 'lg', footer: '<button class="btn" data-close>Bekor qilish</button><button class="btn primary" data-go>Qaytarishni yakunlash</button>' });
  $('#rp', m.el).addEventListener('change', e => guard(async () => { for (const f of e.target.files) { const r = await upload(f); photos.push(r.url); $('#rpl', m.el).insertAdjacentHTML('beforeend', `<img src="${esc(r.url)}" alt="" style="width:64px;height:48px;object-fit:cover;border-radius:6px">`); } }));
  $('[data-go]', m.el).addEventListener('click', async ev => {
    const body = collect(m.el, spec); body.photos = photos; body.damage_fee ||= 0;
    if (!(await confirmBox('Qaytarishni yakunlash', "Ijara yakunlanadi, kilometr yangilanadi va depozit hisob-kitob qilinadi. Davom etasizmi?"))) return;
    guard(async () => { const r = await api('POST', `/bookings/${b.id}/return`, body), s = r.summary; m.close();
      modal('Ijara yakunlandi', `<div class="kv"><span>Yurilgan masofa</span><b>${s.driven_km} km</b></div><div class="kv"><span>Kechikish</span><b>${Math.floor(s.late_minutes / 60)} soat ${s.late_minutes % 60} daqiqa (${money(s.late_fee)})</b></div><div class="kv"><span>Zarar</span><b>${money(s.damage_fee)}</b></div>
        <div class="kv"><span>Depozitdan ushlandi</span><b>${money(s.deposit_deducted)}</b></div><div class="kv"><span>DEPOSIT RETURNED</span><b style="color:var(--green)">${money(s.deposit_returned)}</b></div><div class="kv total"><span>Qoldiq to'lov</span><span style="color:${s.remaining > 0 ? 'var(--red)' : 'var(--green)'}">${money(s.remaining)}</span></div>`, { size: 'sm', footer: '<button class="btn primary" data-close>Yopish</button>', onClose: done }); }, ev.target); });
}

/* ================= CUSTOMERS ================= */
async function openCustomerForm(done, c) {
  const cspec = await customSpec('customer', c?.custom || {});
  const spec = [{ n: 'first_name', label: 'Ism', req: 1, v: c?.first_name }, { n: 'last_name', label: 'Familiya', req: 1, v: c?.last_name }, { n: 'phone', label: 'Telefon', req: 1, v: c?.phone, ph: '+998 90 123 45 67' },
    { n: 'telegram_id', label: 'Telegram ID', t: 'number', v: c?.telegram_id }, { n: 'passport', label: 'Passport / ID raqami', ph: c ? 'O\'zgartirish uchun yangisini kiriting' : 'AA1234567' }, { n: 'license', label: 'Haydovchilik guvohnomasi', ph: c ? 'O\'zgartirish uchun yangisini kiriting' : '' }];
  const m = modal(c ? 'Mijozni tahrirlash' : 'Yangi mijoz', `<div class="grid g2">${fields([...spec, ...cspec])}</div>`, { footer: '<button class="btn" data-close>Bekor qilish</button><button class="btn primary" data-go>Saqlash</button>' });
  $('[data-go]', m.el).addEventListener('click', ev => guard(async () => { const body = collect(m.el, spec); Object.keys(body).forEach(k => body[k] === null && delete body[k]); if (cspec.length) body.custom = collectCustom(m.el, cspec);
    const r = c ? await api('PATCH', '/customers/' + c.id, body) : await api('POST', '/customers', body); toast('Mijoz saqlandi'); m.close(); bust(); done && done(r); App.refresh && App.refresh(); }, ev.target));
}
PAGES.customers = {
  title: 'Mijozlar', icon: '👥', perm: 'customers.read',
  async render(el) {
    let q = '';
    el.innerHTML = `<div class="row" style="margin-bottom:14px"><input id="cq" placeholder="Ism yoki telefon bo'yicha qidirish" style="max-width:320px"><span class="sp"></span><a class="btn" href="/api/export/customers.csv">⬇ CSV</a>${can('customers.write') ? '<button class="btn primary" data-act="newcust">+ Mijoz qo\'shish</button>' : ''}</div><div class="card" id="cl">${loading}</div>`;
    const load = async () => { const rows = await api('GET', '/customers' + qs({ q, limit: 200 }));
      $('#cl', el).innerHTML = rows.length ? `<div class="tablewrap"><table><tr><th>Mijoz</th><th>Telefon</th><th>Telegram</th><th class="right">Ijaralar</th><th class="right">Jami to'lov</th><th class="right">Kechikish</th><th class="right">Zarar</th><th></th></tr>
        ${rows.map(c => `<tr class="click" data-act="customer" data-id="${c.id}"><td><b>${esc(c.first_name)} ${esc(c.last_name)}</b></td><td>${esc(c.phone || '—')}</td><td>${c.tg_username ? '@' + esc(c.tg_username) : c.has_telegram ? '<span class="muted small">ID ' + esc(c.telegram_id) + '</span>' : '—'}</td><td class="right num">${c.rentals}</td><td class="right num">${moneyS(c.total_paid)}</td><td class="right num">${c.late_count}</td><td class="right num">${moneyS(c.damage_total)}</td><td>${c.is_blocked ? pill('CANCELLED', 'Bloklangan') : ''}</td></tr>`).join('')}</table></div>` : emptyState('Mijoz topilmadi', "Qidiruvni o'zgartiring yoki yangi mijoz qo'shing."); };
    App.refresh = load; load(); let tm; $('#cq', el).addEventListener('input', e => { clearTimeout(tm); tm = setTimeout(() => { q = e.target.value; load(); }, 250); });
  },
};
async function openCustomer(id) {
  const c = await api('GET', '/customers/' + id); const w = can('customers.write'), pii = can('customers.pii');
  const cdefs = (await customSpec('customer', c.custom || {})).filter(x => x.v !== '');
  const m = modal(`${c.first_name} ${c.last_name}`, `
    <div class="grid g2"><div class="card"><h3>Profil</h3><dl class="dl"><dt>Telefon</dt><dd><a href="tel:${esc(c.phone)}">${esc(c.phone || '—')}</a></dd><dt>Telegram</dt><dd>${c.tg_username ? `<a href="https://t.me/${esc(c.tg_username)}" target="_blank" rel="noopener">@${esc(c.tg_username)}</a> · ` : ''}ID ${esc(c.telegram_id || '—')}</dd>
      <dt>Passport / ID</dt><dd><span id="pp">${esc(c.passport_masked || '—')}</span> ${pii && c.passport_masked ? '<button class="btn sm" data-pii>Ko\'rsatish</button>' : ''}</dd><dt>Haydovchilik guvohnomasi</dt><dd><span id="ll">${esc(c.license_masked || '—')}</span></dd>
      <dt>Referral kod</dt><dd>${esc(c.referral_code || '—')} · ${c.referrals} ta taklif · bonus ${money(c.bonus_balance)}</dd>${cdefs.map(x => `<dt>${esc(x.label)}</dt><dd>${esc(x.v)}</dd>`).join('')}</dl></div>
    <div class="card"><h3>Statistika</h3><dl class="dl"><dt>Ijaralar soni</dt><dd>${c.rentals}</dd><dt>Jami to'lov</dt><dd>${money(c.total_paid)}</dd><dt>Depozit (ushlab turilgan)</dt><dd>${money(c.deposit_held)}</dd><dt>Kechikishlar</dt><dd>${c.late_count}</dd><dt>Zararlar</dt><dd>${money(c.damage_total)}</dd></dl></div></div>
    <div class="card" style="margin-top:14px"><h3>Hujjat rasmlari</h3><div class="row">${c.documents.map(d => `<span class="pill">${esc(d.doc_type)}${pii ? ` <a href="/api/customers/documents/${d.id}/file" target="_blank" rel="noopener">ochish</a>` : ''}</span>`).join('') || '<span class="muted small">Yuklanmagan</span>'}${w ? `<select id="dtype" style="width:auto"><option value="PASSPORT">Passport</option><option value="LICENSE">Guvohnoma</option><option value="OTHER">Boshqa</option></select><label class="btn sm">+ Yuklash<input type="file" id="dupl" accept="image/jpeg,image/png,image/webp" hidden></label>` : ''}</div></div>
    <div class="card" style="margin-top:14px"><h3>Ijara tarixi</h3>${c.history.length ? `<div class="tablewrap"><table><tr><th>ID</th><th>Mashina</th><th>Muddat</th><th>Holat</th><th class="right">Jami</th></tr>${c.history.map(h => `<tr class="click" data-act="booking" data-id="${h.id}"><td>${esc(h.code)}</td><td>${esc(h.car)}</td><td class="nowrap">${fDate(h.pickup_at)} — ${fDate(h.return_at)}</td><td>${pill(h.status)}</td><td class="right num">${moneyS(h.total_amount)}</td></tr>`).join('')}</table></div>` : emptyState("Hali ijara yo'q")}</div>`,
    { size: 'lg', footer: `${w ? `<button class="btn ${c.is_blocked ? 'ok' : 'danger'}" data-block>${c.is_blocked ? 'Blokdan chiqarish' : 'Bloklash'}</button><button class="btn" data-edit>Tahrirlash</button>` : ''}${can('messages.send') && c.telegram_id ? '<button class="btn" data-msg>✉️ Xabar yozish</button>' : ''}${can('bookings.write') ? '<button class="btn primary" data-book>+ Yangi bron</button>' : ''}` });
  m.el.addEventListener('click', async e => {
    const t = e.target;
    if (t.closest('[data-pii]')) guard(async () => { const p = await api('GET', `/customers/${id}/pii`); $('#pp', m.el).textContent = p.passport || '—'; $('#ll', m.el).textContent = p.license || '—'; t.remove(); });
    else if (t.closest('[data-edit]')) { m.close(); openCustomerForm(() => openCustomer(id), c); }
    else if (t.closest('[data-block]')) { if (await confirmBox(c.is_blocked ? 'Blokdan chiqarish' : 'Mijozni bloklash', c.is_blocked ? 'Mijoz yana bron qila oladi.' : 'Bloklangan mijoz bron qila olmaydi.', 'Tasdiqlash', !c.is_blocked)) guard(async () => { await api('PATCH', '/customers/' + id, { is_blocked: !c.is_blocked }); m.close(); openCustomer(id); }); }
    else if (t.closest('[data-book]')) { m.close(); openNewBooking({ customer_id: id }); }
    else if (t.closest('[data-msg]')) openMessageModal(id, `${c.first_name} ${c.last_name}`);
  });
  const up = $('#dupl', m.el); up && up.addEventListener('change', e => guard(async () => { const fd = new FormData(); fd.append('file', e.target.files[0]); fd.append('doc_type', $('#dtype', m.el).value);
    const r = await fetch(`/api/customers/${id}/documents`, { method: 'POST', body: fd, headers: { 'X-Requested-With': 'rac' } }); const d = await r.json(); if (!r.ok) throw new Error(d.error); toast('Hujjat yuklandi'); m.close(); openCustomer(id); }));
}
