'use strict';
/* ================= XABARLAR (bot orqali) ================= */
async function openMessageModal(customerId, name) {
  const m = modal(`Xabar — ${name}`, `<div class="field"><label class="f">Xabar matni</label><textarea id="mt" maxlength="3500" placeholder="Mijozga Telegram bot orqali yuboriladi" style="min-height:130px"></textarea></div><div class="small muted">Mijoz xabarni botda ko'radi va shu yerga yozib javob qaytara oladi.</div>`,
    { size: 'sm', footer: '<button class="btn" data-close>Bekor qilish</button><button class="btn primary" data-go>Yuborish</button>' });
  $('[data-go]', m.el).addEventListener('click', ev => guard(async () => { await api('POST', '/messages/send', { customer_id: customerId, text: $('#mt', m.el).value }); toast('Xabar yuborildi ✓'); m.close(); App.refresh && App.refresh(); }, ev.target));
}
PAGES.messages = {
  title: 'Xabarlar', icon: '✉️', perm: 'messages.send',
  async render(el) {
    el.innerHTML = loading;
    const [data, custs] = await Promise.all([api('GET', '/messages'), api('GET', '/customers?limit=200')]);
    const linked = custs.filter(c => c.has_telegram);
    const kindL = { DIRECT: 'Alohida', BROADCAST: 'Ommaviy', REPLY: 'Javob', INBOUND: 'Mijozdan' };
    el.innerHTML = `<div class="grid g2" style="margin-bottom:14px">
      <div class="card"><h3>✉️ Bitta mijozga yozish</h3>
        ${linked.length ? `<div class="field"><label class="f">Mijoz (botga ulanganlar: ${linked.length})</label><select id="mc">${linked.map(c => `<option value="${c.id}">${esc(c.first_name)} ${esc(c.last_name)} — ${esc(c.phone || '')}</option>`).join('')}</select></div>
        <div class="field"><label class="f">Xabar</label><textarea id="mx" maxlength="3500" style="min-height:110px"></textarea></div><button class="btn primary" id="ms">Yuborish</button>`
          : emptyState("Botga ulangan mijoz yo'q", "Mijoz botni ishga tushirgandan so'ng shu yerda ko'rinadi.")}</div>
      <div class="card"><h3>📣 Hammaga xabar</h3><p class="muted small" style="margin-top:0">Botga ulangan <b>${data.recipients}</b> ta mijozga yuboriladi. Bloklangan mijozlar kirmaydi.</p>
        <div class="field"><textarea id="bx" maxlength="3500" placeholder="Aksiya, yangilik yoki muhim e'lon matni" style="min-height:110px"></textarea></div><button class="btn dark" id="bs" ${data.recipients ? '' : 'disabled'}>Hammaga yuborish</button></div></div>
      <div class="card"><h3>Xabarlar tarixi</h3>${data.items.length ? `<div class="tablewrap"><table><tr><th>Vaqt</th><th>Mijoz</th><th></th><th>Matn</th><th>Kim</th><th>Holat</th></tr>${data.items.map(x => `<tr><td class="nowrap">${fDT(x.created_at)}</td><td>${esc(x.customer)}</td><td>${x.direction === 'IN' ? '⬅️' : '➡️'} <span class="small muted">${kindL[x.kind]}</span></td><td style="max-width:380px;white-space:pre-wrap">${esc(x.body)}</td><td>${esc(x.sent_by_name || '')}</td><td>${x.status === 'FAILED' ? `<span class="pill CANCELLED" title="${esc(x.error || '')}">Yetmadi</span>` : x.direction === 'IN' ? '' : pill('COMPLETED', 'Yuborildi')}</td></tr>`).join('')}</table></div>` : emptyState("Xabarlar yo'q", "Yuborilgan va kelgan xabarlar shu yerda saqlanadi.")}</div>`;
    App.refresh = () => PAGES.messages.render(el);
    $('#ms', el)?.addEventListener('click', ev => guard(async () => { const r = await api('POST', '/messages/send', { customer_id: +$('#mc', el).value, text: $('#mx', el).value }); toast(`${r.customer} ga yuborildi ✓`); PAGES.messages.render(el); }, ev.target));
    $('#bs', el)?.addEventListener('click', async ev => { const t = $('#bx', el).value.trim(); if (!t) return toast('Xabar matnini kiriting', true);
      if (!(await confirmBox('Hammaga xabar yuborish', `<b>${data.recipients}</b> ta mijozga quyidagi xabar yuboriladi:<br><br><i>${esc(t).slice(0, 300)}</i><br><br>Bu amalni qaytarib bo'lmaydi.`, 'Yuborish'))) return;
      guard(async () => { const r = await api('POST', '/messages/broadcast', { text: t }); toast(r.done ? `Yuborildi: ${r.sent}, xato: ${r.failed}` : `${r.total} ta mijozga yuborish boshlandi`); PAGES.messages.render(el); }, ev.target); });
  },
};

/* ================= FUNKSIYALAR MARKAZI ================= */
PAGES.features = {
  title: 'Funksiyalar', icon: '🧩', perm: 'settings.manage',
  async render(el) {
    el.innerHTML = loading; const f = await api('GET', '/features');
    const locs = JSON.parse((await api('GET', '/settings')).locations || '[]'); const extras = JSON.parse((await api('GET', '/settings')).extras_catalog || '[]');
    const ENT = { customer: 'Mijoz', car: 'Mashina' }, TY = { text: 'Matn', number: 'Son', date: 'Sana', select: 'Tanlov' };
    el.innerHTML = `<div class="card" style="margin-bottom:14px"><h3>Modullar</h3><p class="muted small" style="margin-top:0">Kerakli funksiyalarni yoqing yoki o'chiring — o'zgarish admin panelga, botga va Mini App ga darrov ta'sir qiladi.</p>
      ${Object.entries(f.catalog).map(([k, v]) => `<label class="kv" style="cursor:pointer;align-items:center"><span><b>${esc(v.name)}</b><div class="small muted">${esc(v.desc)}</div></span><input type="checkbox" data-flag="${k}" ${f.flags[k] ? 'checked' : ''} style="width:22px;min-height:0;height:22px"></label>`).join('')}</div>
    <div class="card" id="cc" style="margin-bottom:14px"></div>
    <div class="grid g2" style="margin-bottom:14px">
      <div class="card"><h3>Olib ketish joylari</h3><div id="ll">${locs.map((l, i) => `<div class="row" style="margin-bottom:6px"><span class="sp">${esc(l)}</span><button class="btn sm danger" data-dl="${i}">×</button></div>`).join('') || '<span class="muted small">Kiritilmagan — bron paytida joy so\'ralmaydi</span>'}</div>
        <div class="row" style="margin-top:10px"><input id="nl" placeholder="Masalan: Toshkent aeroporti"><button class="btn" id="al">Qo'shish</button></div></div>
      <div class="card"><h3>Qo'shimcha xizmatlar</h3><div id="el">${extras.map((x, i) => `<div class="row" style="margin-bottom:6px"><span class="sp">${esc(x.name)} — ${money(x.price)}${x.per === 'day' ? ' / kun' : ''}</span><button class="btn sm danger" data-de="${i}">×</button></div>`).join('') || '<span class="muted small">Kiritilmagan</span>'}</div>
        <div class="row" style="margin-top:10px;flex-wrap:nowrap"><input id="en" placeholder="Nomi (GPS)"><input id="ep" type="number" placeholder="Narx" style="max-width:110px"><select id="eper" style="max-width:110px"><option value="booking">buyurtmaga</option><option value="day">kuniga</option></select><button class="btn" id="ae">+</button></div></div></div>
    <div class="card"><h3>Maxsus maydonlar</h3><p class="muted small" style="margin-top:0">Mijoz yoki mashina kartasiga o'zingizga kerakli maydon qo'shing (masalan: «Yashash manzili», «Sug'urta polisi raqami»). Maydon formalarda va profilda avtomatik paydo bo'ladi.</p>
      ${f.fields.length ? `<div class="tablewrap"><table><tr><th>Maydon</th><th>Qayerda</th><th>Tur</th><th>Majburiy</th><th></th></tr>${f.fields.map(x => `<tr><td><b>${esc(x.label)}</b>${x.type === 'select' ? `<div class="small muted">${esc(x.options.join(', '))}</div>` : ''}</td><td>${ENT[x.entity]}</td><td>${TY[x.type]}</td><td>${x.required ? 'Ha' : "Yo'q"}</td><td><button class="btn sm danger" data-df="${x.id}">O'chirish</button></td></tr>`).join('')}</table></div>` : '<div class="muted small" style="margin-bottom:8px">Hali maydon qo\'shilmagan.</div>'}
      <div class="grid g4" style="margin-top:12px;align-items:end"><div><label class="f">Nomi</label><input id="fl"></div><div><label class="f">Qayerda</label><select id="fe"><option value="customer">Mijoz</option><option value="car">Mashina</option></select></div><div><label class="f">Tur</label><select id="ft"><option value="text">Matn</option><option value="number">Son</option><option value="date">Sana</option><option value="select">Tanlov</option></select></div><div id="fo-w" class="hidden"><label class="f">Variantlar (vergul bilan)</label><input id="fo"></div></div>
      <div class="row" style="margin-top:10px"><label class="row" style="gap:6px"><input type="checkbox" id="fr" style="width:auto;min-height:0">Majburiy</label><span class="sp"></span><button class="btn primary" id="af">+ Maydon qo'shish</button></div></div>`;
    renderContacts($('#cc', el));
    const saveSet = async (k, v) => { await api('PUT', '/settings', { [k]: JSON.stringify(v) }); bust(); PAGES.features.render(el); };
    el.addEventListener('change', e => { const c = e.target.closest('[data-flag]'); if (c) guard(async () => { await api('PUT', '/features', { [c.dataset.flag]: c.checked }); toast(c.checked ? 'Yoqildi' : "O'chirildi"); }).catch(() => {}); if (e.target.id === 'ft') $('#fo-w', el).classList.toggle('hidden', e.target.value !== 'select'); });
    el.addEventListener('click', async e => {
      const t = e.target;
      if (t.id === 'al') { const v = $('#nl', el).value.trim(); if (v) guard(() => saveSet('locations', [...locs, v])); }
      if (t.dataset.dl) guard(() => saveSet('locations', locs.filter((_, i) => i != t.dataset.dl)));
      if (t.id === 'ae') { const n = $('#en', el).value.trim(), p = +$('#ep', el).value; if (!n || !(p >= 0)) return toast('Nom va narxni kiriting', true); guard(() => saveSet('extras_catalog', [...extras, { name: n, price: p, per: $('#eper', el).value }])); }
      if (t.dataset.de) guard(() => saveSet('extras_catalog', extras.filter((_, i) => i != t.dataset.de)));
      if (t.id === 'af') guard(async () => { await api('POST', '/custom-fields', { label: $('#fl', el).value, entity: $('#fe', el).value, type: $('#ft', el).value, options: $('#fo', el).value, required: $('#fr', el).checked }); toast("Maydon qo'shildi"); bust(); PAGES.features.render(el); }, t);
      if (t.dataset.df && await confirmBox("Maydonni o'chirish", "Maydon formalardan olib tashlanadi (kiritilgan qiymatlar bazada qoladi).", "O'chirish", true)) guard(async () => { await api('DELETE', '/custom-fields/' + t.dataset.df); bust(); PAGES.features.render(el); });
    });
  },
};

/* Maxsus maydonlarni formaga qo'shish / qiymatlarini yig'ish (mijoz va mashina formalari uchun) */
async function customSpec(entity, values = {}) {
  const f = (CACHE.cf ||= await api('GET', '/features').then(x => x.fields));
  return f.filter(x => x.entity === entity).map(x => ({ n: 'cf_' + x.key, label: x.label, t: x.type === 'select' ? 'select' : x.type, o: x.type === 'select' ? [['', '—'], ...x.options] : undefined, req: x.required, v: values[x.key] ?? '', _key: x.key }));
}
const collectCustom = (root, spec) => { const o = {}; for (const f of spec) { const el = $(`[name="${f.n}"]`, root); if (el) o[f._key] = el.value === '' ? null : el.value; } return o; };

/* ================= TO'LOV JOYLARI (karta/bank) ================= */
async function openAccountForm(acc, done) {
  const spec = [{ n: 'kind', label: 'Turi', t: 'select', o: [['CARD', 'Bank kartasi'], ['BANK', 'Bank hisob raqami']], v: acc?.kind || 'CARD' }, { n: 'title', label: 'Nomi', req: 1, v: acc?.title, ph: 'Humo / Uzcard / Visa' },
    { n: 'card_number', label: 'Karta raqami', v: acc?.card_number, ph: '8600 1234 5678 9012', hint: 'Karta turi uchun' }, { n: 'holder_name', label: 'Karta egasi (F.I.O.)', v: acc?.holder_name },
    { n: 'bank_name', label: 'Bank nomi', v: acc?.bank_name }, { n: 'account_number', label: 'Hisob raqami', v: acc?.account_number, hint: 'Bank hisob raqami turi uchun' },
    { n: 'note', label: "Mijozga izoh", t: 'textarea', v: acc?.note, w: 2, ph: "Masalan: To'lov izohiga buyurtma ID sini yozing" }, { n: 'is_active', label: "Faol (mijozlarga ko'rsatiladi)", t: 'checkbox', v: acc ? acc.is_active : true, w: 2 }];
  const m = modal(acc ? "To'lov joyini tahrirlash" : "To'lov joyi qo'shish", `<div class="grid g2">${fields(spec)}</div>`, { footer: '<button class="btn" data-close>Bekor qilish</button><button class="btn primary" data-go>Saqlash</button>' });
  $('[data-go]', m.el).addEventListener('click', ev => guard(async () => { const b = collect(m.el, spec); Object.keys(b).forEach(k => b[k] === null && (b[k] = ''));
    if (acc) await api('PUT', '/payment-accounts/' + acc.id, b); else await api('POST', '/payment-accounts', b); toast("To'lov joyi saqlandi"); m.close(); done && done(); }, ev.target));
}
const fmtCard = n => String(n || '').replace(/\D/g, '').replace(/(\d{4})(?=\d)/g, '$1 ');
async function renderAccounts(box) {
  const rows = await api('GET', '/payment-accounts');
  box.innerHTML = `<div class="row" style="margin-bottom:12px"><span class="muted small">Mijozlar shu rekvizitga to'laydi va chekni botdan yuboradi — siz tasdiqlaysiz.</span><span class="sp"></span>${can('contract.manage') ? '<button class="btn primary" id="na">+ Karta / hisob qo\'shish</button>' : ''}</div>
    ${rows.length ? `<div class="grid g3">${rows.map(a => `<div class="card" style="${a.is_active ? '' : 'opacity:.55'}"><div class="row"><b>${esc(a.title)}</b><span class="sp"></span>${a.is_active ? pill('AVAILABLE', 'Faol') : pill('INACTIVE', "O'chiq")}</div>
      ${a.kind === 'CARD' ? `<div class="num" style="font-size:20px;letter-spacing:1px;margin:10px 0 4px">${esc(fmtCard(a.card_number))}</div><div class="muted small">${esc(a.holder_name || '')}${a.bank_name ? ' · ' + esc(a.bank_name) : ''}</div>` : `<div class="num" style="font-size:16px;margin:10px 0 4px">${esc(a.account_number)}</div><div class="muted small">${esc(a.bank_name || '')} ${esc(a.holder_name || '')}</div>`}
      ${can('contract.manage') ? `<div class="row" style="margin-top:12px"><button class="btn sm" data-ea="${a.id}">Tahrirlash</button><button class="btn sm danger" data-xa="${a.id}">O'chirish</button></div>` : ''}</div>`).join('')}</div>` : emptyState("To'lov joyi qo'shilmagan", "Karta qo'shilmaguncha mijozlar botdan to'lov qila olmaydi.")}`;
  $('#na', box)?.addEventListener('click', () => openAccountForm(null, () => renderAccounts(box)));
  box.onclick = async e => { const ea = e.target.closest('[data-ea]'), xa = e.target.closest('[data-xa]');
    if (ea) openAccountForm(rows.find(a => a.id == ea.dataset.ea), () => renderAccounts(box));
    if (xa && await confirmBox("To'lov joyini o'chirish", "Mijozlarga ko'rsatilmay qoladi.", "O'chirish", true)) guard(async () => { await api('DELETE', '/payment-accounts/' + xa.dataset.xa); renderAccounts(box); }); };
}

/* ================= TO'LOV SO'ROVLARI ================= */
async function renderClaims(box) {
  const rows = await api('GET', '/payment-claims'); const pend = rows.filter(r => r.status === 'PENDING').length;
  const stL = { PENDING: ['PENDING', 'Kutilmoqda'], CONFIRMED: ['COMPLETED', 'Tasdiqlangan'], REJECTED: ['CANCELLED', 'Rad etilgan'] };
  box.innerHTML = rows.length ? `<div class="row small" style="margin-bottom:8px"><b>${pend} ta kutilmoqda</b></div><div class="tablewrap"><table><tr><th>Vaqt</th><th>Buyurtma</th><th>Mijoz</th><th>Tur</th><th>Qayerga</th><th class="right">Summa</th><th>Holat</th><th></th></tr>${rows.map(c => `<tr><td class="nowrap">${fDT(c.created_at)}</td><td>${esc(c.code)}</td><td>${esc(c.customer)}<div class="muted small">${esc(c.phone || '')}</div></td><td>${c.kind === 'DEPOSIT' ? 'Depozit' : 'Ijara'}</td><td>${esc(c.account || '—')}</td><td class="right num"><b>${moneyS(c.amount)}</b></td><td>${pill(stL[c.status][0], stL[c.status][1])}${c.reject_reason ? `<div class="small muted">${esc(c.reject_reason)}</div>` : ''}</td>
      <td class="nowrap">${c.has_receipt ? `<button class="btn sm" data-rc="${c.id}">🧾 Chek</button> ` : ''}${c.status === 'PENDING' ? `<button class="btn sm ok" data-ok="${c.id}">✅</button> <button class="btn sm danger" data-no="${c.id}">❌</button>` : ''}</td></tr>`).join('')}</table></div>`
    : emptyState("To'lov so'rovlari yo'q", "Mijoz botdan chek yuborganda shu yerda ko'rinadi va sizga Telegramda xabar keladi.");
  box.onclick = async e => { const t = e.target.closest('button'); if (!t) return;
    if (t.dataset.rc) modal('To\'lov cheki', `<img src="/api/payment-claims/${t.dataset.rc}/receipt" alt="chek" style="width:100%;border-radius:8px" onerror="this.outerHTML='<p>Chekni yuklab bo\\'lmadi</p>'">`, { size: 'sm' });
    if (t.dataset.ok && await confirmBox("To'lovni tasdiqlash", "Chekni tekshirdingizmi? Tasdiqlansa to'lov buyurtmaga yoziladi va mijozga xabar ketadi.")) guard(async () => { await api('POST', `/payment-claims/${t.dataset.ok}/confirm`); toast("To'lov tasdiqlandi"); bust(); renderClaims(box); }, t);
    if (t.dataset.no) { const m = modal("To'lovni rad etish", '<div class="field"><label class="f">Sabab (mijozga ko\'rsatiladi)</label><input id="rr"></div>', { size: 'sm', footer: '<button class="btn" data-close>Yopish</button><button class="btn danger" data-go>Rad etish</button>' });
      $('[data-go]', m.el).addEventListener('click', ev => guard(async () => { await api('POST', `/payment-claims/${t.dataset.no}/reject`, { reason: $('#rr', m.el).value }); m.close(); renderClaims(box); }, ev.target)); } };
}

/* ================= SHARTNOMA (PDF yuklash) ================= */
async function renderContract(box) {
  const d = await api('GET', '/contract-template'); const a = d.active;
  box.innerHTML = `<div class="grid g2"><div class="card"><h3>Faol shartnoma</h3>${a ? `<dl class="dl"><dt>Nomi</dt><dd>${esc(a.title)}</dd><dt>Versiya</dt><dd>v${a.version}</dd><dt>Turi</dt><dd>${a.kind === 'PDF' ? 'PDF fayl · ' + esc(a.file_name || '') : 'Matn'}</dd><dt>Yuklangan</dt><dd>${fDT(a.created_at)}</dd></dl>
      ${a.kind === 'PDF' ? '<a class="btn" style="margin-top:12px" href="/contract.pdf" target="_blank" rel="noopener">📄 Ko\'rish (PDF)</a>' : ''}` : '<div class="alert danger"><span>⚠️</span><span><b>Shartnoma yuklanmagan.</b><br>Yuklanmaguncha mijozlar bron qila olmaydi.</span></div>'}
      <div class="small muted" style="margin-top:12px">Mijoz bron berishdan oldin shartnomani o'qib, «O'qidim, roziman» tugmasini bosadi. Rozilik vaqti, kanali va shartnoma versiyasi saqlanadi — siz buyurtmada ko'rasiz. Tasdiqlangan buyurtmada mijozga shartnoma + buyurtma varag'i (birlashtirilgan PDF) yuboriladi.</div></div>
    <div class="card"><h3>Yangi shartnoma yuklash</h3><div class="field"><label class="f">Sarlavha</label><input id="ct" value="${esc(a?.title || 'Avtomobil ijara shartnomasi')}"></div>
      <div class="field"><label class="f">PDF fayl (15 MB gacha)</label><input type="file" id="cf" accept="application/pdf"></div><button class="btn primary" id="cu">PDF ni yuklash</button>
      <details style="margin-top:14px"><summary class="small muted" style="cursor:pointer">PDF o'rniga matn kiritish</summary><div class="field" style="margin-top:8px"><textarea id="cb" style="min-height:160px" placeholder="Shartnoma matni"></textarea></div><button class="btn" id="cs">Matnni saqlash</button></details>
      <div class="small muted" style="margin-top:10px">Har yangi yuklash — yangi versiya. Avval rozi bo'lgan mijozlarning roziligi o'sha versiyaga bog'liq holda saqlanib qoladi.</div></div></div>
    <div class="card" style="margin-top:14px"><h3>Versiyalar</h3>${d.versions.length ? `<div class="tablewrap"><table><tr><th>Versiya</th><th>Nomi</th><th>Turi</th><th>Yuklagan</th><th>Sana</th><th class="right">Rozilik soni</th><th></th></tr>${d.versions.map(v => `<tr><td>v${v.version}</td><td>${esc(v.title)}</td><td>${v.kind === 'PDF' ? 'PDF' : 'Matn'}</td><td>${esc(v.created_by_name || '—')}</td><td>${fDT(v.created_at)}</td><td class="right">${v.consents}</td><td>${v.is_active ? pill('AVAILABLE', 'Faol') : ''}</td></tr>`).join('')}</table></div>` : emptyState("Versiya yo'q")}</div>`;
  $('#cu', box).addEventListener('click', ev => guard(async () => { const f = $('#cf', box).files[0]; if (!f) return toast('PDF faylni tanlang', true);
    const fd = new FormData(); fd.append('file', f); fd.append('title', $('#ct', box).value);
    const r = await fetch('/api/contract-template/pdf', { method: 'POST', body: fd, headers: { 'X-Requested-With': 'rac' } }); const j = await r.json(); if (!r.ok) throw new Error(j.error);
    toast(`Shartnoma yuklandi (v${j.version}, ${j.pages} bet)`); bust(); renderContract(box); }, ev.target));
  $('#cs', box).addEventListener('click', ev => guard(async () => { await api('POST', '/contract-template', { title: $('#ct', box).value, body: $('#cb', box).value }); toast('Shartnoma saqlandi'); renderContract(box); }, ev.target));
}


/* ================= BOT FOYDALANUVCHILARI ================= */
PAGES.botusers = {
  title: 'Foydalanuvchilar', icon: '👤', perm: 'customers.read',
  async render(el) {
    let q = '';
    el.innerHTML = `<div class="row" style="margin-bottom:14px"><input id="bq" placeholder="Ism, @username, telefon yoki Telegram ID" style="max-width:340px"><span class="sp"></span><span id="bs" class="muted small"></span></div><div class="card" id="bl">${loading}</div>`;
    const load = async () => {
      const d = await api('GET', '/bot-users' + qs({ q }));
      $('#bs', el).innerHTML = `Jami: <b>${d.total}</b> · telefon yuborgan: <b>${d.with_phone}</b>`;
      $('#bl', el).innerHTML = d.items.length ? `<div class="tablewrap"><table><tr><th>Foydalanuvchi</th><th>Telegram</th><th>Telefon</th><th>Telegram ID</th><th>Qo'shilgan</th><th>Oxirgi faollik</th><th class="right">Buyurtma</th></tr>
        ${d.items.map(u => `<tr class="click" data-act="customer" data-id="${u.id}"><td><b>${esc(u.first_name)} ${esc(u.last_name || '')}</b>${u.is_blocked ? ' ' + pill('CANCELLED', 'Bloklangan') : ''}</td>
          <td>${u.tg_username ? `<a href="https://t.me/${esc(u.tg_username)}" target="_blank" rel="noopener" onclick="event.stopPropagation()">@${esc(u.tg_username)}</a>` : '<span class="muted">username yo\'q</span>'}</td>
          <td>${u.phone ? `<a href="tel:${esc(u.phone)}" onclick="event.stopPropagation()"><b>${esc(u.phone)}</b></a>` : '<span class="muted">raqam yubormagan</span>'}</td>
          <td class="num">${esc(u.telegram_id)}</td><td class="nowrap">${fDT(u.created_at)}<div class="small muted">${u.joined_via === 'MINIAPP' ? 'Mini App' : 'Bot'}</div></td><td class="nowrap">${u.last_seen_at ? fDT(u.last_seen_at) : '—'}</td><td class="right num">${u.bookings}</td></tr>`).join('')}</table></div>`
        : emptyState("Foydalanuvchi topilmadi", "Botni birinchi marta ishga tushirgan odam shu yerda ko'rinadi (ism, @username, telefon).");
    };
    App.refresh = load; load(); let tm; $('#bq', el).addEventListener('input', e => { clearTimeout(tm); tm = setTimeout(() => { q = e.target.value; load(); }, 250); });
  },
};

/* ================= ALOQA RAQAMLARI (Funksiyalar sahifasida) ================= */
async function renderContacts(box) {
  const rows = await api('GET', '/contacts'); const w = can('contract.manage') || can('settings.manage');
  box.innerHTML = `<h3>Aloqa raqamlari</h3><p class="muted small" style="margin-top:0">Mijozlar botdagi «☎️ Operator» tugmasida va Mini App profilida shu raqamlarni ko'radi.</p>
    ${rows.length ? rows.map(c => `<div class="row" style="padding:8px 0;border-bottom:1px solid var(--line);${c.is_active ? '' : 'opacity:.5'}"><span class="sp"><b>${esc(c.label)}</b><div class="small muted">${[c.phone, c.telegram, c.hours].filter(Boolean).map(esc).join(' · ')}</div></span>${w ? `<button class="btn sm" data-ec="${c.id}">✎</button><button class="btn sm danger" data-xc="${c.id}">×</button>` : ''}</div>`).join('') : '<div class="muted small">Hali raqam kiritilmagan — mijozlarga faqat «savolingizni yozing» deb ko\'rsatiladi.</div>'}
    ${w ? '<div style="margin-top:12px"><button class="btn primary" id="nc">+ Raqam qo\'shish</button></div>' : ''}`;
  const form = c => { const spec = [{ n: 'label', label: 'Nomi', req: 1, v: c?.label, ph: 'Operator / Menejer / Texnik yordam' }, { n: 'phone', label: 'Telefon', v: c?.phone, ph: '+998 90 123 45 67' }, { n: 'telegram', label: 'Telegram (@username)', v: c?.telegram },
      { n: 'hours', label: 'Ish vaqti', v: c?.hours, ph: '09:00–21:00' }, { n: 'note', label: 'Izoh', v: c?.note, w: 2 }, { n: 'is_active', label: "Faol (mijozlarga ko'rsatiladi)", t: 'checkbox', v: c ? c.is_active : true, w: 2 }];
    const m = modal(c ? 'Aloqa raqamini tahrirlash' : "Aloqa raqami qo'shish", `<div class="grid g2">${fields(spec)}</div>`, { footer: '<button class="btn" data-close>Bekor qilish</button><button class="btn primary" data-go>Saqlash</button>' });
    $('[data-go]', m.el).addEventListener('click', ev => guard(async () => { const b = collect(m.el, spec); Object.keys(b).forEach(k => b[k] === null && (b[k] = '')); if (c) await api('PUT', '/contacts/' + c.id, b); else await api('POST', '/contacts', b); toast('Saqlandi'); m.close(); renderContacts(box); }, ev.target)); };
  $('#nc', box)?.addEventListener('click', () => form());
  box.onclick = async e => { const ec = e.target.closest('[data-ec]'), xc = e.target.closest('[data-xc]'); if (ec) form(rows.find(r => r.id == ec.dataset.ec));
    if (xc && await confirmBox("Raqamni o'chirish", "Mijozlarga ko'rsatilmay qoladi.", "O'chirish", true)) guard(async () => { await api('DELETE', '/contacts/' + xc.dataset.xc); renderContacts(box); }); };
}

/* ================= ROL HUQUQLARI (faqat Egasi) ================= */
async function renderRoles(box) {
  const d = await api('GET', '/roles/permissions'); const owner = App.user.role === 'OWNER';
  const NAMES = { OWNER: 'Egasi', ADMIN: 'Administrator', MANAGER: 'Menejer', ACCOUNTANT: 'Buxgalter' };
  const roles = d.roles.filter(r => r.code !== 'OWNER');
  box.innerHTML = `<h3>Rollar va huquqlar</h3><p class="muted small" style="margin-top:0">${owner ? "Har bir rol nimalarni qila olishini belgilang. O'zgarish darrov kuchga kiradi. Egasi doim hamma narsaga ega." : "Huquqlarni faqat Egasi o'zgartira oladi."}</p>
    <div class="tablewrap"><table><tr><th>Huquq</th>${roles.map(r => `<th style="text-align:center">${NAMES[r.code] || r.code}</th>`).join('')}</tr>
    ${Object.entries(d.labels).map(([k, l]) => `<tr><td>${esc(l)}</td>${roles.map(r => `<td style="text-align:center"><input type="checkbox" data-role="${r.code}" data-perm="${k}" ${r.permissions.includes(k) ? 'checked' : ''} ${owner ? '' : 'disabled'} style="width:20px;min-height:0;height:20px"></td>`).join('')}</tr>`).join('')}</table></div>
    ${owner ? '<div class="row" style="margin-top:12px"><span class="sp"></span><button class="btn primary" id="sr">Huquqlarni saqlash</button></div>' : ''}`;
  $('#sr', box)?.addEventListener('click', ev => guard(async () => { for (const r of roles) await api('PUT', '/roles/' + r.code, { permissions: $$(`[data-role="${r.code}"]:checked`, box).map(x => x.dataset.perm) }); toast('Huquqlar saqlandi'); }, ev.target));
}
