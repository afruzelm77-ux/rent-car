'use strict';
const tg = window.Telegram && Telegram.WebApp;
const $ = (s, r = document) => r.querySelector(s);
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = n => String(Math.round(Number(n) || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + " so'm";
const p2 = n => String(n).padStart(2, '0');
const tk = d => new Date(new Date(d).getTime() + 5 * 3600e3);
const MON = ['Yan', 'Fev', 'Mar', 'Apr', 'May', 'Iyn', 'Iyl', 'Avg', 'Sen', 'Okt', 'Noy', 'Dek'];
const fD = d => { const t = tk(d); return `${t.getUTCDate()} ${MON[t.getUTCMonth()]}`; };
const fDT = d => { const t = tk(d); return `${p2(t.getUTCDate())}.${p2(t.getUTCMonth() + 1)}.${t.getUTCFullYear()} ${p2(t.getUTCHours())}:${p2(t.getUTCMinutes())}`; };
const today = () => { const t = tk(new Date()); return `${t.getUTCFullYear()}-${p2(t.getUTCMonth() + 1)}-${p2(t.getUTCDate())}`; };
const addD = (s, n) => { const d = new Date(s + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const ST = { AVAILABLE: "Bo'sh", RESERVED: 'Bron qilingan', RENTED: 'Ijarada', MAINTENANCE: "Ta'mirda", INACTIVE: 'Faol emas' };
const BST = { PENDING: 'Kutilmoqda', CONFIRMED: 'Tasdiqlangan', ACTIVE: 'Faol', COMPLETED: 'Tugagan', CANCELLED: 'Bekor qilingan', OVERDUE: 'Kechikkan' };
const TR = { AUTOMATIC: 'Avtomat', MANUAL: 'Mexanika' }, FU = { PETROL: 'Benzin', GAS: 'Gaz', DIESEL: 'Dizel', HYBRID: 'Gibrid', ELECTRIC: 'Elektr' };
const FRIENDLY = 'Bu xizmat hozircha mavjud emas.';

/* ---- Lucide ikonlari (bitta tizim, inline SVG) ---- */
const IC = {
  home: '<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
  car: '<path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2"/><path d="M9 17h6"/><circle cx="17" cy="17" r="2"/>',
  cal: '<path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/>',
  list: '<rect width="8" height="4" x="8" y="2" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M12 11h4"/><path d="M12 16h4"/><path d="M8 11h.01"/><path d="M8 16h.01"/>',
  heart: '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>',
  user: '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
  right: '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
  left: '<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
  fuel: '<line x1="3" x2="15" y1="22" y2="22"/><line x1="4" x2="14" y1="9" y2="9"/><path d="M14 22V4a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v18"/><path d="M14 13h2a2 2 0 0 1 2 2v2a2 2 0 0 0 2 2a2 2 0 0 0 2-2V9.83a2 2 0 0 0-.59-1.42L18 5"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M4.93 4.93l2.12 2.12M16.95 16.95l2.12 2.12M2 12h3M19 12h3M4.93 19.07l2.12-2.12M16.95 7.05l2.12-2.12"/>',
  phone: '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>',
  menu: '<line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  pin: '<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/>',
  card: '<rect width="20" height="14" x="2" y="5" rx="2"/><line x1="2" x2="22" y1="10" y2="10"/>',
  copy: '<rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
  refresh: '<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/>',
  palette: '<circle cx="13.5" cy="6.5" r=".5"/><circle cx="17.5" cy="10.5" r=".5"/><circle cx="8.5" cy="7.5" r=".5"/><circle cx="6.5" cy="12.5" r=".5"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"/>',
  doc: '<path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/>',
  gift: '<rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13"/><path d="M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7"/><path d="M7.5 8a2.5 2.5 0 0 1 0-5A4.8 8 0 0 1 12 8a4.8 8 0 0 1 4.5-5 2.5 2.5 0 0 1 0 5"/>',
};
const I = (n, c = '') => `<svg class="i ${c}" viewBox="0 0 24 24" aria-hidden="true">${IC[n] || ''}</svg>`;

const S = { token: null, cfg: null, me: null, cars: [], tab: 'home', q: '', brand: '', ord: 'active', onlyFree: false, fav: new Set() };
try { S.fav = new Set(JSON.parse(localStorage.getItem('lrc_fav') || '[]')); } catch { /* localStorage mavjud emas */ }
const saveFav = () => { try { localStorage.setItem('lrc_fav', JSON.stringify([...S.fav])); } catch { /* e'tiborsiz */ } };
const app = $('#app');
let tt; const toast = (m, err) => { const t = $('#toast'); t.textContent = m; t.className = 'show' + (err ? ' err' : ''); clearTimeout(tt); tt = setTimeout(() => (t.className = ''), 3200); };

async function api(method, path, body) {
  let r; try { r = await fetch('/api/mini' + path, { method, headers: { 'Content-Type': 'application/json', ...(S.token ? { Authorization: 'Bearer ' + S.token } : {}) }, body: body ? JSON.stringify(body) : undefined }); } catch { throw new Error("Internet aloqasi yo'q. Qayta urinib ko'ring."); }
  const d = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(r.status >= 500 || ['NO_BOT', 'NO_CONTRACT'].includes(d.code) ? FRIENDLY : (d.error || FRIENDLY)); e.status = r.status; e.code = d.code; throw e; }
  return d;
}
const haptic = t => { try { tg && tg.HapticFeedback.notificationOccurred(t); } catch { /* ixtiyoriy */ } };

/* ---- Rasm: bitta manba (mashina yozuvi). Buzilgan/yo'q rasm — chiroyli placeholder ---- */
const NOIMG = '<div class="noimg">' + I('car') + '<span>Rasm hozircha mavjud emas</span></div>';
const photo = (url, alt = '', eager = false) => (url ? `<img src="${esc(url)}" alt="${esc(alt)}" ${eager ? '' : 'loading="lazy"'} decoding="async" data-img>` : NOIMG);
document.addEventListener('error', e => { const t = e.target; if (t && t.tagName === 'IMG' && t.hasAttribute('data-img')) { const w = document.createElement('div'); w.innerHTML = NOIMG; t.replaceWith(w.firstChild); } }, true);
const carImgs = c => [...new Set([c.image_url, ...(c.images || [])].filter(Boolean))];

/* ---- Navigatsiya ---- */
const stack = [];
const H = {};   // joriy ekran amallari
function go(fn) { stack.push(fn); fn(); window.scrollTo(0, 0); syncBack(); }
function back() { stack.pop(); const f = stack[stack.length - 1]; f ? f() : showTab(S.tab); syncBack(); }
function syncBack() { if (!tg) return; stack.length ? tg.BackButton.show() : tg.BackButton.hide(); }
const TABS = [['home', 'home', 'Asosiy'], ['cars', 'car', 'Mashinalar'], ['orders', 'list', 'Buyurtmalar'], ['fav', 'heart', 'Sevimli'], ['me', 'user', 'Profil']];
const nav = () => `<nav class="nav">${TABS.map(([k, i, l]) => `<button data-act="tab" data-v="${k}" class="${S.tab === k ? 'on' : ''}">${I(i, 'lg')}${l}</button>`).join('')}</nav>`;
function showTab(t) { S.tab = t; stack.length = 0; syncBack(); ({ home: viewHome, cars: viewCars, orders: viewOrders, fav: viewFav, me: viewMe })[t](); window.scrollTo(0, 0); }
const screen = (html, tabs = true) => { app.innerHTML = `<div class="screen ${tabs ? '' : 'nonav'}">${html}</div>${tabs ? nav() : ''}`; };
const loader = () => { app.innerHTML = '<div class="boot"><span class="spin"></span></div>'; };
const guard = async fn => { try { return await fn(); } catch (e) { toast(e.message, true); haptic('error'); } };
const empty = (ic, title, text, btn) => `<div class="empty"><div class="ic">${ic}</div><b>${title}</b>${text}${btn || ''}</div>`;
const operatorBtn = '<button class="btn alt" data-act="operator">' + '☎️ Operator</button>';
const unavailable = () => empty('🛠', FRIENDLY, '', operatorBtn);

document.addEventListener('click', e => {
  const a = e.target.closest('[data-act]'); if (!a) return;
  const act = a.dataset.act;
  if (act === 'stop') return;
  if (a.dataset.stop !== undefined) e.stopPropagation();
  const fn = G[act] || H[act]; if (fn) fn(a, e);
});
const G = {
  tab: a => showTab(a.dataset.v),
  back: () => back(),
  car: a => go(() => viewCar(+a.dataset.id)),
  book: (a, e) => { e.stopPropagation(); go(() => viewBook(+a.dataset.id)); },
  fav: (a, e) => { e.stopPropagation(); const id = +a.dataset.id; S.fav.has(id) ? S.fav.delete(id) : S.fav.add(id); saveFav(); haptic('success'); a.classList.toggle('on', S.fav.has(id)); if (S.tab === 'fav' && !stack.length) viewFav(); },
  reload: () => location.reload(),
  recheck: () => { S.cars = []; showTab(S.tab); },
  operator: () => callOperator(),
  home: () => showTab('home'),
  cars: () => showTab('cars'),
  orders: () => showTab('orders'),
};
function callOperator() {
  const c = (S.cfg.contacts || [])[0]; const ph = (c && c.phone) || S.cfg.company.phone;
  try {
    if (c && c.telegram && tg) return tg.openTelegramLink(`https://t.me/${c.telegram.replace('@', '')}`);
    if (ph) return (location.href = 'tel:' + ph.replace(/[^\d+]/g, ''));
  } catch { /* pastga */ }
  showTab('me');
}

/* ---- Mashina kartasi ---- */
const specs = c => `<span class="spec">${I('gear')}${TR[c.transmission] || ''}</span><span class="spec">${I('users')}${c.seats} o'rin</span><span class="spec">${I('fuel')}${FU[c.fuel_type] || ''}</span>`;
const subline = c => [c.body_type, c.year].filter(Boolean).join(' · ');
const carCard = (c, i = 0) => `<div class="car" data-act="car" data-id="${c.id}" style="animation-delay:${Math.min(i, 6) * 40}ms"><div class="media">${photo(c.image_url, c.brand + ' ' + c.model, i < 2)}
  <button class="ibtn fav ${S.fav.has(c.id) ? 'on' : ''}" data-act="fav" data-id="${c.id}" aria-label="Sevimli">${I('heart')}</button>
  <button class="go" data-act="car" data-id="${c.id}" aria-label="Ochish">${I('right')}</button></div>
  <div class="bd"><h3>${esc(c.brand)} ${esc(c.model)}</h3>${subline(c) ? `<div class="sub">${esc(subline(c))}</div>` : ''}
  <div class="st">${specs(c)}</div>
  <div class="ft"><div class="price"><b>${money(c.price_day).replace(" so'm", '')}</b><span>so'm / kun</span></div><span class="dot ${c.status}">${esc(ST[c.status] || '')}</span></div></div></div>`;
const filtered = () => S.cars.filter(c => (!S.brand || c.brand === S.brand) && (!S.onlyFree || c.status === 'AVAILABLE') && (!S.q || (c.brand + ' ' + c.model).toLowerCase().includes(S.q.toLowerCase())));
const carList = (list, limit) => (list.length ? list.slice(0, limit || 99).map(carCard).join('') : S.cars.length ? empty('🔎', 'Hech narsa topilmadi', "Qidiruv yoki filtrni o'zgartirib ko'ring.") : empty('🚗', "Hozircha mavjud avtomobillar yo'q.", 'Tez orada yangi avtomobillar qo\'shiladi.', '<button class="btn" data-act="recheck">' + I('refresh') + ' Qayta tekshirish</button>'));
const brandChips = () => { const bs = [...new Set(S.cars.map(c => c.brand))]; return bs.length ? `<div class="brands">${bs.map(b => `<button class="brand-chip ${S.brand === b ? 'on' : ''}" data-act="brand" data-v="${esc(b)}"><i>${esc(b.slice(0, 1).toUpperCase())}</i><span>${esc(b)}</span></button>`).join('')}</div>` : ''; };
async function loadCars() { if (!S.cars.length) S.cars = await api('GET', '/cars'); }
const initials = () => esc(((S.me.first_name || 'M')[0] + ((S.me.last_name || '')[0] || '')).toUpperCase());
const searchBox = ph => `<label class="search">${I('search')}<input id="q" type="search" placeholder="${ph}" value="${esc(S.q)}" autocomplete="off"></label>`;
function bindSearch(render) {
  H.brand = a => { S.brand = S.brand === a.dataset.v ? '' : a.dataset.v; render(); };
  const q = $('#q'); if (!q) return;
  q.addEventListener('input', () => { S.q = q.value; const l = $('#list'); if (l) l.innerHTML = listHtml(); });
}
let listHtml = () => '';

/* ---- Asosiy ---- */
async function viewHome() {
  loader(); try { await loadCars(); } catch (e) { return fail(e); }
  const render = () => {
    listHtml = () => carList(filtered(), 6);
    screen(`<div class="top"><div class="brand"><b>LIDER</b><span>RENT A CAR</span></div><button class="avatar" data-act="tab" data-v="me" aria-label="Profil">${initials()}</button><button class="ibtn" data-act="tab" data-v="me" aria-label="Menyu">${I('menu')}</button></div>
      ${searchBox('Orzuingizdagi avtomobilni qidiring')}
      <div class="sec">Mashhur brendlar</div>${brandChips() || '<div class="note">Brendlar tez orada.</div>'}
      <div class="sec">Mashhur avtomobillar<button data-act="cars">Hammasi</button></div><div id="list">${listHtml()}</div>`);
    bindSearch(render);
  }; render();
}
function fail(e) { screen(empty('🛠', FRIENDLY, '', '<button class="btn" data-act="recheck">' + I('refresh') + ' Qayta urinish</button>' + '<div style="height:10px"></div>' + operatorBtn)); }

/* ---- Mashinalar ---- */
async function viewCars() {
  loader(); try { await loadCars(); } catch (e) { return fail(e); }
  const render = () => {
    listHtml = () => carList(filtered());
    screen(`<div class="top"><div class="brand"><h1 class="h1">Mashinalar</h1><div class="sub">${S.cars.length} ta avtomobil</div></div></div>${searchBox('Marka yoki model')}
      <div class="sec">Brend</div>${brandChips()}
      <div class="seg" style="margin-top:14px"><button class="${!S.onlyFree ? 'on' : ''}" data-act="free" data-v="0">Hammasi</button><button class="${S.onlyFree ? 'on' : ''}" data-act="free" data-v="1">Bo'sh</button></div>
      <div id="list">${listHtml()}</div>`);
    bindSearch(render); H.free = a => { S.onlyFree = a.dataset.v === '1'; render(); };
  }; render();
}
async function viewFav() {
  loader(); try { await loadCars(); } catch (e) { return fail(e); }
  const list = S.cars.filter(c => S.fav.has(c.id));
  screen(`<div class="top"><div class="brand"><h1 class="h1">Sevimlilar</h1></div></div>${list.length ? list.map(carCard).join('') : empty('♡', "Sevimli avtomobillar yo'q", 'Mashina kartasidagi yurak belgisini bosing.', '<button class="btn" data-act="cars">' + I('car') + ' Mashinalarni ko\'rish</button>')}`);
}

/* ---- Mashina tafsiloti ---- */
async function viewCar(id) {
  loader(); let c; try { c = await api('GET', '/cars/' + id); } catch (e) { return screen(unavailable(), false); }
  const imgs = carImgs(c); const dis = c.status === 'MAINTENANCE';
  const first = new Date(c.calendar[0].date + 'T00:00:00Z'); const off = (first.getUTCDay() + 6) % 7;
  const tile = (ic, v, l) => `<div class="tile">${I(ic, 'lg')}<b>${esc(v)}</b><span>${l}</span></div>`;
  const panes = {
    about: `<div class="specgrid">${tile('gear', TR[c.transmission], 'Karobka')}${tile('users', c.seats, "O'rindiq")}${tile('fuel', FU[c.fuel_type], "Yoqilg'i")}${c.year ? tile('cal', c.year, 'Yil') : ''}${c.color ? tile('palette', c.color, 'Rang') : ''}${c.body_type ? tile('car', c.body_type, 'Kuzov') : ''}</div>
      ${c.description ? `<div class="sec">Izoh</div><div class="card" style="white-space:pre-wrap;color:var(--muted)">${esc(c.description)}</div>` : ''}
      <div class="sec">Tariflar</div><div class="card"><div class="kv"><span>1+ kun</span><b>${money(c.price_day)}</b></div><div class="kv"><span>3+ kun</span><b>${money(c.price_3d)}</b></div><div class="kv"><span>7+ kun</span><b>${money(c.price_7d)}</b></div><div class="kv"><span>Depozit (qaytariladi)</span><b>${money(c.deposit)}</b></div></div>
      <div class="sec">Band kunlar — keyingi 60 kun</div><div class="card"><div class="cal">${['Du', 'Se', 'Ch', 'Pa', 'Ju', 'Sh', 'Ya'].map(d => `<i class="h">${d}</i>`).join('')}${'<i class="h"></i>'.repeat(off)}${c.calendar.map(d => `<i class="${d.busy ? 'b' : ''}">${+d.date.slice(8)}</i>`).join('')}</div></div>`,
    gallery: imgs.length ? `<div class="gal">${imgs.map(u => `<div class="g">${photo(u, c.brand)}</div>`).join('')}</div>` : `<div class="card" style="position:relative;height:200px">${NOIMG}</div>`,
    reviews: empty('⭐', "Hozircha sharhlar yo'q", 'Birinchi ijaradan keyin sharhlar shu yerda ko\'rinadi.'),
  };
  screen(`<div class="hero"><div class="snap" id="snap">${(imgs.length ? imgs : [null]).map(u => `<div class="slide">${photo(u, c.brand + ' ' + c.model, true)}</div>`).join('')}</div>
      <div class="bar"><button class="ibtn" data-act="back" aria-label="Orqaga">${I('left')}</button><b>Avtomobil</b><button class="ibtn fav ${S.fav.has(c.id) ? 'on' : ''}" data-act="fav" data-id="${c.id}" aria-label="Sevimli">${I('heart')}</button></div>
      ${imgs.length > 1 ? `<div class="dots" id="dots">${imgs.map((_, i) => `<i class="${i ? '' : 'on'}"></i>`).join('')}</div>` : ''}</div>
    <div class="sheet"><div class="titlerow"><div style="flex:1;min-width:0"><h2>${esc(c.brand)} ${esc(c.model)}</h2>${subline(c) ? `<div class="sub">${esc(subline(c))}</div>` : ''}</div><span class="dot ${c.status}" style="margin-top:8px">${esc(ST[c.status] || '')}</span></div>
    <div class="tabs"><button class="on" data-act="pane" data-v="about">Haqida</button><button data-act="pane" data-v="gallery">Galereya</button><button data-act="pane" data-v="reviews">Sharhlar</button></div><div id="pane">${panes.about}</div></div>
    <div class="cta"><div class="in"><div class="price"><b>${money(c.price_day).replace(" so'm", '')}</b><span>so'm / kun</span></div><button class="btn" data-act="gobook" ${dis ? 'disabled' : ''}><span class="ci">${I('right')}</span>BRON QILISH</button></div></div>`, false);
  H.pane = a => { document.querySelectorAll('.tabs button').forEach(b => b.classList.toggle('on', b === a)); $('#pane').innerHTML = panes[a.dataset.v]; };
  H.gobook = () => go(() => viewBook(id));
  const sn = $('#snap'), dots = $('#dots');
  if (sn && dots) sn.addEventListener('scroll', () => { const i = Math.round(sn.scrollLeft / sn.clientWidth); [...dots.children].forEach((d, k) => d.classList.toggle('on', k === i)); }, { passive: true });
}

/* ---- Bron qilish ---- */
async function viewBook(carId) {
  loader();
  let car; try { car = S.cars.find(c => c.id === carId) || (await api('GET', '/cars')).find(c => c.id === carId); } catch (e) { return screen(unavailable(), false); }
  if (!car) return screen(unavailable(), false);
  let terms; try { terms = await api('GET', '/contract'); } catch (e) { screen(`<div class="top"><button class="ibtn" data-act="back">${I('left')}</button><div class="brand"><h1 class="h1">Bron qilish</h1></div></div>${unavailable()}`, false); return; }
  const cfg = S.cfg, t0 = addD(today(), 1);
  const st = { quoteOk: false, opened: terms.kind !== 'PDF' };
  const termsHtml = terms.kind === 'PDF'
    ? `<button class="btn alt" data-act="openpdf">${I('doc')} Shartnomani ochish (PDF)</button><div class="note" id="tn">Shartnomani ochib o'qigandan so'ng rozilik berish mumkin.</div>`
    : `<div id="tb" style="max-height:240px;overflow:auto;white-space:pre-wrap;font-size:13.5px;color:var(--muted);border:1px solid var(--line);border-radius:16px;padding:14px">${esc(terms.body)}</div><div class="note" id="tn">Oxirigacha o'qing.</div>`;
  const sh = (n, t) => `<div class="stephd"><span class="stepno">${n}</span>${t}</div>`;
  screen(`<div class="top"><button class="ibtn" data-act="back" aria-label="Orqaga">${I('left')}</button><div class="brand"><h1 class="h1" style="font-size:20px">${esc(car.brand)} ${esc(car.model)}</h1><div class="sub">${money(car.price_day)} / kun</div></div></div>
    <div class="car" style="cursor:default"><div class="media" style="aspect-ratio:21/9">${photo(car.image_url, car.brand, true)}</div></div>
    <div class="card">${sh(1, 'Sana va vaqt')}<div class="two"><div><label class="f">Olish sanasi</label><input type="date" id="pd" min="${today()}" value="${t0}"></div><div><label class="f">Olish vaqti</label><input type="time" id="pt" value="10:00"></div></div>
      <div class="two"><div><label class="f">Qaytarish sanasi</label><input type="date" id="rd" min="${today()}" value="${addD(t0, 3)}"></div><div><label class="f">Qaytarish vaqti</label><input type="time" id="rt" value="10:00"></div></div>
      ${cfg.delivery && cfg.delivery.enabled ? `<label class="chk"><input type="checkbox" id="dlv"><span>🚚 Mashinani manzilimga yetkazib bering <b>${cfg.delivery.fee ? '(+' + money(cfg.delivery.fee) + ')' : '(bepul)'}</b></span></label><div id="dla" style="display:none"><input id="dladdr" placeholder="Ko'cha, uy raqami, mo'ljal" maxlength="250"></div>` : ''}
      <div id="locw">${cfg.locations.length ? `<label class="f">Olib ketish joyi</label><select id="loc">${cfg.locations.map(l => `<option>${esc(l)}</option>`).join('')}</select>` : ''}</div></div>
    <div class="card">${sh(2, "Mijoz ma'lumotlari")}<label class="f">Telefon raqamingiz</label><input id="ph" type="tel" inputmode="tel" placeholder="+998 90 123 45 67" value="${esc(S.me.phone || '')}">
      ${S.me.has_documents ? '' : `<label class="f">Passport / ID raqami (ixtiyoriy)</label><input id="pp" autocomplete="off"><label class="f">Haydovchilik guvohnomasi (ixtiyoriy)</label><input id="ll" autocomplete="off"><div class="note">Hujjat ma'lumotlari shifrlangan holda saqlanadi.</div>`}
      ${cfg.extras.length ? `<label class="f">Qo'shimcha xizmatlar</label>${cfg.extras.map(x => `<label class="chk"><input type="checkbox" class="ex" value="${esc(x.name)}"><span>${esc(x.name)} — ${money(x.price)}${x.per === 'day' ? ' / kun' : ''}</span></label>`).join('')}` : ''}
      ${cfg.features?.promo === false ? '' : `<label class="f">Promo kod</label><input id="promo" placeholder="Masalan: RENT10" autocapitalize="characters">`}</div>
    <div class="card glow" id="q">${sh(3, 'Narx va depozit')}<div class="note">Narx hisoblanmoqda…</div></div>
    <div class="card">${sh(4, 'Ijara shartnomasi')}<b style="display:block;margin:6px 0 10px">${esc(terms.title)}</b>${termsHtml}
      <label class="chk"><input type="checkbox" id="agree" disabled><span>Shartnoma shartlarini to'liq o'qib chiqdim va <b>roziman</b></span></label></div>
    <div id="er" class="err"></div><div style="height:6px"></div><button class="btn" id="go" data-act="submit" disabled><span class="ci">${I('right')}</span>BUYURTMA BERISH</button>`, false);
  const gate = () => { $('#agree').disabled = !st.opened; $('#go').disabled = !(st.quoteOk && $('#agree').checked); };
  H.openpdf = () => { const u = location.origin + terms.pdf_url; try { tg ? tg.openLink(u) : window.open(u, '_blank'); } catch { window.open(u, '_blank'); } st.opened = true; $('#tn').textContent = "Shartnoma ochildi. O'qib bo'lgach, rozilik belgisini qo'ying."; gate(); };
  if (terms.kind !== 'PDF') { const tb = $('#tb'); const chk = () => { if (tb.scrollTop + tb.clientHeight >= tb.scrollHeight - 6) { st.opened = true; $('#tn').textContent = "O'qib bo'ldingiz. Rozilik belgisini qo'ying."; gate(); } }; tb.addEventListener('scroll', chk); setTimeout(chk, 200); }
  const dAddr = () => ($('#dlv') && $('#dlv').checked ? ($('#dladdr').value.trim() || null) : null);
  const read = () => ({ delivery_address: dAddr(), car_id: carId, pickup_date: $('#pd').value, pickup_time: $('#pt').value, return_date: $('#rd').value, return_time: $('#rt').value, promo_code: $('#promo')?.value.trim() || null, extras: [...document.querySelectorAll('.ex:checked')].map(x => ({ name: x.value, qty: 1 })) });
  let tm; const quote = () => { clearTimeout(tm); tm = setTimeout(async () => { st.quoteOk = false; gate(); $('#er').textContent = '';
    try { const q = await api('POST', '/quote', read());
      $('#q').innerHTML = `${sh(3, 'Narx va depozit')}<div class="kv"><span>${q.days} kun × ${money(q.rate)}</span><b>${money(q.rental)}</b></div>${q.discount ? `<div class="kv"><span>Chegirma</span><b>− ${money(q.discount)}</b></div>` : ''}${q.items.map(i => `<div class="kv"><span>${esc(i.name)}</span><b>${money(i.total)}</b></div>`).join('')}<div class="kv"><span>Ijara jami</span><b>${money(q.total)}</b></div><div class="kv"><span>Depozit (qaytariladi)</span><b>${money(q.deposit)}</b></div><div class="kv t"><span>Jami</span><b>${money(q.grand_total)}</b></div>`;
      st.quoteOk = true; gate(); } catch (e) { $('#q').innerHTML = sh(3, 'Narx va depozit') + '<div class="note">—</div>'; $('#er').textContent = e.message; } }, 300); };
  app.oninput = quote; app.onchange = e => { if (e.target.id === 'dlv') { $('#dla').style.display = e.target.checked ? 'block' : 'none'; $('#locw').style.display = e.target.checked ? 'none' : 'block'; } if (e.target.id === 'agree') gate(); else quote(); }; quote();
  H.submit = () => guard(async () => {
    if ($('#dlv') && $('#dlv').checked && !dAddr()) throw new Error('Yetkazib berish manzilini kiriting');
    const b = { ...read(), location: dAddr() ? undefined : ($('#loc')?.value || undefined), phone: $('#ph').value.trim() || undefined, passport: $('#pp')?.value.trim() || undefined, license: $('#ll')?.value.trim() || undefined, accept_terms: $('#agree').checked, template_id: terms.id };
    $('#go').disabled = true; const r = await api('POST', '/bookings', b); S.me.phone = b.phone || S.me.phone; haptic('success');
    app.oninput = app.onchange = null; stack.length = 0; syncBack(); S.tab = 'orders';
    screen(`<div class="ticket"><div class="ok">${I('check')}</div><h2>BUYURTMA QABUL QILINDI</h2><div class="sub">Operator tez orada tasdiqlaydi</div><span class="code">#${esc(r.code)}</span></div>
      <div class="card"><div class="kv"><span>Avtomobil</span><b>${esc(r.car)}</b></div><div class="kv"><span>Sana</span><b>${fD(r.pickup_at)} — ${fD(r.return_at)}</b></div><div class="kv t"><span>Jami</span><b>${money(r.total + r.deposit)}</b></div></div>
      <button class="btn" data-act="orders">${I('list')} Buyurtmani ko'rish</button><div style="height:10px"></div><button class="btn alt" data-act="home">${I('home')} Bosh sahifa</button>`, false);
  }).finally(() => { const g = $('#go'); if (g) gate(); });
}

/* ---- To'lov ---- */
async function viewPay(b, kind) {
  loader(); let d; try { d = await api('GET', '/payment-accounts'); } catch { return screen(unavailable(), false); }
  const amount = kind === 'DEPOSIT' ? b.dep_left : b.remaining;
  const top = `<div class="top"><button class="ibtn" data-act="back" aria-label="Orqaga">${I('left')}</button><div class="brand"><h1 class="h1">To'lov</h1></div></div>`;
  if (!d.enabled || !d.accounts.length) { screen(top + unavailable(), false); return; }
  const fc = n => String(n || '').replace(/\D/g, '').replace(/(\d{4})(?=\d)/g, '$1 ');
  screen(`${top}<div class="card glow"><div class="kv"><span>Buyurtma</span><b>#${esc(b.code)}</b></div><div class="kv t"><span>${kind === 'DEPOSIT' ? 'Depozit' : "To'lanadigan summa"}</span><b>${money(amount)}</b></div></div>
    <div class="sec">Qayerga to'lash</div>${d.accounts.map(a => `<div class="card"><b>${esc(a.title)}</b>
      ${a.kind === 'CARD' ? `<div style="font-size:22px;font-weight:800;letter-spacing:1.5px;margin:10px 0">${esc(fc(a.card_number))}</div><div class="note">${esc(a.holder_name || '')}${a.bank_name ? ' · ' + esc(a.bank_name) : ''}</div>` : `<div style="font-size:18px;font-weight:800;margin:10px 0;word-break:break-all">${esc(a.account_number)}</div><div class="note">${esc(a.bank_name || '')} ${esc(a.holder_name || '')}</div>`}
      ${a.note ? `<div class="note">${esc(a.note)}</div>` : ''}<div style="height:12px"></div><button class="btn alt" data-act="copy" data-v="${esc(a.kind === 'CARD' ? a.card_number : a.account_number)}">${I('copy')} Raqamni nusxalash</button></div>`).join('')}
    <div class="sec">To'lov cheki</div><div class="card"><div class="note" style="margin:0 0 10px">To'lov qilgach, chekning rasmini (screenshot) yuklang. Admin tekshirib tasdiqlaydi.</div><input type="file" id="rc" accept="image/jpeg,image/png,image/webp">
      ${d.accounts.length > 1 ? `<label class="f">Qaysi kartaga to'ladingiz?</label><select id="acc">${d.accounts.map(a => `<option value="${a.id}">${esc(a.title)}</option>`).join('')}</select>` : ''}</div>
    <div id="er" class="err"></div><button class="btn" data-act="send">${I('check')} TO'LADIM — CHEKNI YUBORISH</button>`, false);
  H.copy = a => { navigator.clipboard?.writeText(a.dataset.v).then(() => toast('Nusxalandi ✓')).catch(() => toast(a.dataset.v)); };
  H.send = () => guard(async () => { const f = $('#rc').files[0]; if (!f) throw new Error('Chek rasmini tanlang');
    const fd = new FormData(); fd.append('file', f); const r = await fetch('/api/mini/receipt', { method: 'POST', headers: { Authorization: 'Bearer ' + S.token }, body: fd }); const j = await r.json().catch(() => ({})); if (!r.ok) throw new Error(r.status === 413 ? 'Rasm hajmi juda katta. Iltimos, kichikroq rasm tanlang.' : (j.error || FRIENDLY));
    await api('POST', '/payment-claims', { booking_id: b.id, amount, kind, receipt_file: j.file, account_id: $('#acc') ? +$('#acc').value : (d.accounts[0]?.id) });
    haptic('success'); stack.length = 0; syncBack(); S.tab = 'orders';
    screen(`<div class="ticket"><div class="ok">${I('check')}</div><h2>SO'ROV YUBORILDI</h2><div class="sub">Admin chekni tekshirib tasdiqlaydi. Natijani Telegramda olasiz.</div></div><button class="btn" data-act="orders">${I('list')} Buyurtmalarim</button>`, false); });
}

/* ---- Buyurtmalar ---- */
const CL = { PENDING: 'Tekshirilmoqda', CONFIRMED: 'Tasdiqlandi', REJECTED: 'Rad etildi' };
const OT = [['active', 'Faol', ['CONFIRMED', 'ACTIVE', 'OVERDUE']], ['pending', 'Kutilmoqda', ['PENDING']], ['done', 'Tugagan', ['COMPLETED']], ['cancel', 'Bekor qilingan', ['CANCELLED']]];
async function viewOrders() {
  loader(); let list, claims; try { [list, claims] = await Promise.all([api('GET', '/bookings'), api('GET', '/payment-claims').catch(() => [])]); } catch (e) { return fail(e); }
  S.orders = list;
  const render = () => {
    const sel = OT.find(t => t[0] === S.ord) || OT[0]; const rows = list.filter(b => sel[2].includes(b.status));
    screen(`<div class="top"><div class="brand"><h1 class="h1">Mening buyurtmalarim</h1></div></div>
      <div class="seg">${OT.map(([k, l, ss]) => `<button class="${S.ord === k ? 'on' : ''}" data-act="ot" data-v="${k}">${l} ${list.filter(b => ss.includes(b.status)).length || ''}</button>`).join('')}</div>
      ${rows.length ? rows.map(b => `<div class="ord"><div class="th">${photo(b.image, b.car)}</div><div class="in"><b class="n">${esc(b.car)}</b><div class="dt">${fD(b.pickup_at)} — ${fD(b.return_at)} · ${b.days} kun · #${esc(b.code)}</div>
        <div class="rw"><span class="pill ${b.status}">${esc(BST[b.status])}</span><span class="sp"></span><b>${money(b.total)}</b></div></div></div>
        <div class="ordx">${b.status !== 'CANCELLED' && b.remaining > 0 ? `<button class="btn alt sm" style="width:100%" data-act="pay" data-id="${b.id}" data-k="R">${I('card')} Ijara to'lovini to'lash · ${money(b.remaining)}</button>` : ''}${['PENDING', 'CONFIRMED'].includes(b.status) && b.dep_left > 0 ? `<button class="btn alt sm" style="width:100%" data-act="pay" data-id="${b.id}" data-k="D">${I('card')} Depozitni to'lash · ${money(b.dep_left)}</button>` : ''}${b.status === 'PENDING' ? `<button class="btn red sm" style="width:100%" data-act="cancel" data-id="${b.id}">Buyurtmani bekor qilish</button>` : ''}</div>`).join('')
      : empty('📋', 'Sizda hozircha buyurtmalar yo\'q.', '', '<button class="btn" data-act="cars">' + I('car') + ' Mashinalarni ko\'rish</button>')}
      ${claims.length && S.ord === 'active' ? `<div class="sec">To'lov so'rovlarim</div>${claims.map(c => `<div class="card"><div class="row"><b>#${esc(c.code)} · ${money(c.amount)}</b><span class="sp"></span><span class="pill ${c.status === 'CONFIRMED' ? 'CONFIRMED' : c.status === 'REJECTED' ? 'CANCELLED' : 'PENDING'}">${CL[c.status]}</span></div>${c.reject_reason ? `<div class="note">${esc(c.reject_reason)}</div>` : ''}</div>`).join('')}` : ''}`);
  }; render();
  H.ot = a => { S.ord = a.dataset.v; render(); };
  H.pay = a => { const b = S.orders.find(x => x.id == a.dataset.id); go(() => viewPay(b, a.dataset.k === 'D' ? 'DEPOSIT' : 'RENTAL')); };
  H.cancel = a => { if (confirm('Buyurtma bekor qilinsinmi?')) guard(async () => { await api('POST', `/bookings/${a.dataset.id}/cancel`); toast('Buyurtma bekor qilindi'); viewOrders(); }); };
}

/* ---- Profil ---- */
async function viewMe() {
  loader(); try { S.me = await api('GET', '/me'); } catch (e) { return fail(e); } const m = S.me;
  const link = S.cfg.bot_username ? `https://t.me/${S.cfg.bot_username}?start=ref_${m.referral_code}` : '';
  screen(`<div class="top"><div class="avatar" style="cursor:default">${initials()}</div><div class="brand"><h1 class="h1" style="font-size:20px">${esc(m.first_name)} ${esc(m.last_name)}</h1><div class="sub">${esc(m.phone || 'Telefon kiritilmagan')}</div></div></div>
    <div class="card"><label class="f" style="margin-top:0">Ism</label><input id="fn" value="${esc(m.first_name)}"><label class="f">Familiya</label><input id="ln" value="${esc(m.last_name)}"><label class="f">Telefon</label><input id="ph" type="tel" value="${esc(m.phone)}" placeholder="+998 90 123 45 67">
      <label class="f">Passport / ID ${m.has_documents ? '(saqlangan)' : ''}</label><input id="pp" placeholder="${m.has_documents ? 'O\'zgartirish uchun yangisini kiriting' : 'AA1234567'}" autocomplete="off"><label class="f">Haydovchilik guvohnomasi</label><input id="ll" autocomplete="off"><div style="height:16px"></div><button class="btn" data-act="save">${I('check')} SAQLASH</button></div>
    <div class="sec">Do'stlarni taklif qiling</div><div class="card"><div class="kv"><span>Bonus balansi</span><b>${money(m.bonus_balance)}</b></div><div class="kv"><span>Taklif qilinganlar</span><b>${m.referrals}</b></div>
      ${link ? `<div class="note" style="word-break:break-all">${esc(link)}</div><div style="height:12px"></div><button class="btn alt" data-act="share">${I('gift')} Havolani ulashish</button>` : `<div class="note">Referral kodingiz: <b>${esc(m.referral_code)}</b></div>`}</div>
    <div class="sec">Aloqa</div><div class="card">${(S.cfg.contacts || []).map(c => `<div class="kv" style="align-items:flex-start"><span><b style="color:#fff">${esc(c.label)}</b>${c.hours ? `<div class="note" style="margin:0">${esc(c.hours)}</div>` : ''}</span><b>${c.phone ? `<a href="tel:${esc(c.phone)}" style="text-decoration:none">${esc(c.phone)}</a>` : ''}${c.telegram ? `<div><a href="https://t.me/${esc(c.telegram.slice(1))}" style="text-decoration:none">${esc(c.telegram)}</a></div>` : ''}</b></div>`).join('') || (S.cfg.company.phone ? `<div class="kv"><span>Operator</span><b><a href="tel:${esc(S.cfg.company.phone)}" style="text-decoration:none">${esc(S.cfg.company.phone)}</a></b></div>` : '<div class="note">Savolingiz bo\'lsa, botga yozing — operator javob beradi.</div>')}${S.cfg.company.address ? `<div class="kv"><span>${I('pin', 'sm')} Manzil</span><b>${esc(S.cfg.company.address)}</b></div>` : ''}</div>`);
  H.save = () => guard(async () => { S.me = await api('PATCH', '/me', { first_name: $('#fn').value, last_name: $('#ln').value, phone: $('#ph').value || undefined, passport: $('#pp').value || undefined, license: $('#ll').value || undefined }); toast('Saqlandi ✓'); haptic('success'); });
  H.share = () => { const u = `https://t.me/share/url?url=${encodeURIComponent(link)}&text=${encodeURIComponent('LIDER RENT A CAR — premium avtomobil ijarasi')}`; tg ? tg.openTelegramLink(u) : window.open(u, '_blank'); };
}

/* ---- Boshlash ---- */
(async function init() {
  if (tg) { tg.ready(); tg.expand(); try { tg.setHeaderColor('#07050D'); tg.setBackgroundColor('#07050D'); } catch { /* eski versiya */ } tg.BackButton.onClick(back); }
  try {
    S.cfg = await fetch('/api/mini/config').then(r => r.json());
    const sp = new URLSearchParams(location.search); const initData = tg && tg.initData;
    const body = initData ? { initData } : sp.get('dev') ? { dev_user: { id: sp.get('dev'), first_name: 'Demo' }, start_param: sp.get('ref') ? 'ref_' + sp.get('ref') : undefined } : null;
    if (!body) { app.innerHTML = empty('✈️', 'Telegram orqali oching', 'Bu ilova Telegram Mini App sifatida ishlaydi. Botni oching va «Ochish» tugmasini bosing.'); return; }
    const a = await api('POST', '/auth', body); S.token = a.token; S.me = a.customer;
    const deep = sp.get('car'); showTab('home'); if (deep) setTimeout(() => go(() => viewCar(+deep)), 300);
  } catch (e) { app.innerHTML = empty('🛠', FRIENDLY, '', '<button class="btn" data-act="reload">Qayta urinish</button>'); }
})();
