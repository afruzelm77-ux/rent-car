'use strict';
const tg = window.Telegram && Telegram.WebApp;
const $ = (s, r = document) => r.querySelector(s);
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = n => String(Math.round(Number(n) || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + " so'm";
const p2 = n => String(n).padStart(2, '0');
const tk = d => new Date(new Date(d).getTime() + 5 * 3600e3);
const fDT = d => { const t = tk(d); return `${p2(t.getUTCDate())}.${p2(t.getUTCMonth() + 1)}.${t.getUTCFullYear()} ${p2(t.getUTCHours())}:${p2(t.getUTCMinutes())}`; };
const today = () => { const t = tk(new Date()); return `${t.getUTCFullYear()}-${p2(t.getUTCMonth() + 1)}-${p2(t.getUTCDate())}`; };
const addD = (s, n) => { const d = new Date(s + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const ST = { AVAILABLE: "🟢 Bo'sh", RESERVED: '🟡 Bron qilingan', RENTED: '🔴 Ijarada', MAINTENANCE: "🔧 Ta'mirda", INACTIVE: '⚫ Faol emas' };
const BST = { PENDING: 'Kutilmoqda', CONFIRMED: 'Tasdiqlangan', ACTIVE: 'Ijarada', COMPLETED: 'Yakunlangan', CANCELLED: 'Bekor qilingan', OVERDUE: 'Kechikkan' };
const TR = { AUTOMATIC: 'Avtomat', MANUAL: 'Mexanika' }, FU = { PETROL: 'Benzin', GAS: 'Gaz', DIESEL: 'Dizel', HYBRID: 'Gibrid', ELECTRIC: 'Elektr' };

const S = { token: null, cfg: null, me: null, cars: [], tab: 'cars' };
const app = $('#app');
let tt; const toast = (m, err) => { const t = $('#toast'); t.textContent = m; t.className = 'show' + (err ? ' err' : ''); clearTimeout(tt); tt = setTimeout(() => (t.className = ''), 3500); };

async function api(method, path, body) {
  let r; try { r = await fetch('/api/mini' + path, { method, headers: { 'Content-Type': 'application/json', ...(S.token ? { Authorization: 'Bearer ' + S.token } : {}) }, body: body ? JSON.stringify(body) : undefined }); } catch { throw new Error("Internet aloqasi yo'q"); }
  const d = await r.json().catch(() => ({})); if (!r.ok) { const e = new Error(d.error || 'Xatolik'); e.status = r.status; throw e; } return d;
}
const haptic = t => { try { tg && tg.HapticFeedback.notificationOccurred(t); } catch {} };

/* ---- Navigatsiya ---- */
const stack = [];
function go(fn) { stack.push(fn); fn(); window.scrollTo(0, 0); syncBack(); }
function back() { stack.pop(); const f = stack[stack.length - 1]; f ? f() : showTab(S.tab); syncBack(); }
function syncBack() { if (!tg) return; stack.length ? tg.BackButton.show() : tg.BackButton.hide(); }
const tabbar = () => `<nav class="tabbar">${[['cars', '🚗', 'Mashinalar'], ['book', '📅', 'Bron'], ['orders', '📋', 'Buyurtmalar'], ['me', '👤', 'Profil']].map(([k, i, l]) => `<button data-tab="${k}" class="${S.tab === k ? 'on' : ''}"><b>${i}</b>${l}</button>`).join('')}</nav>`;
function showTab(t) { S.tab = t; stack.length = 0; syncBack(); ({ cars: viewCars, book: viewBookPick, orders: viewOrders, me: viewMe })[t](); }
document.addEventListener('click', e => { const b = e.target.closest('[data-tab]'); if (b) showTab(b.dataset.tab); const bk = e.target.closest('[data-back]'); if (bk) back(); });
const screen = (html, tabs = true) => { app.innerHTML = `<div class="screen">${html}</div>${tabs ? tabbar() : ''}`; };
const loader = () => screen('<div class="boot"><span class="spin"></span></div>');
const guard = async fn => { try { return await fn(); } catch (e) { toast(e.message, true); haptic('error'); } };

/* ---- Mashinalar ---- */
const carCard = (c, action = true) => `<div class="card car" data-car="${c.id}"><div class="ph" style="${c.image_url ? `background-image:url('${esc(c.image_url)}')` : ''}">${c.image_url ? '' : '🚗'}<span class="tag">${esc(ST[c.status])}</span></div>
  <div class="bd"><h3>${esc(c.brand)} ${esc(c.model)}</h3><div class="specs"><span>${TR[c.transmission]}</span><span>${c.seats} o'rin</span><span>${FU[c.fuel_type]}</span>${c.year ? `<span>${c.year}</span>` : ''}</div>
  <div class="row"><div class="price"><b>${money(c.price_day).replace(" so'm", '')}</b><span>so'm / kun</span></div><span class="sp"></span>${action && c.status !== 'MAINTENANCE' ? '<button class="btn" style="width:auto;padding:11px 20px;min-height:44px" data-book="' + c.id + '">Bron qilish</button>' : ''}</div></div></div>`;
async function viewCars() {
  loader(); S.cars = await api('GET', '/cars');
  screen(`<div class="hd"><h1>${esc(S.cfg.company.name)}</h1></div>${S.cars.length ? S.cars.map(c => carCard(c)).join('') : '<div class="empty"><b>Hozircha mashinalar yo\'q</b>Keyinroq qaytib ko\'ring.</div>'}`);
  app.onclick = e => { const b = e.target.closest('[data-book]'); if (b) { e.stopPropagation(); return go(() => viewBook(+b.dataset.book)); } const c = e.target.closest('[data-car]'); if (c) go(() => viewCar(+c.dataset.car)); tabClick(e); };
}
const tabClick = e => { const b = e.target.closest('[data-tab]'); if (b) showTab(b.dataset.tab); };
async function viewCar(id) {
  loader(); const c = await api('GET', '/cars/' + id);
  const imgs = [c.image_url, ...c.images].filter(Boolean);
  const first = new Date(c.calendar[0].date + 'T00:00:00Z'); const off = (first.getUTCDay() + 6) % 7;
  screen(`<div class="hd"><button class="back" data-back>←</button><h1>${esc(c.brand)} ${esc(c.model)}</h1></div>
    <div class="card"><div class="gal">${imgs.length ? imgs.map(u => `<img src="${esc(u)}" alt="">`).join('') : '<div class="ph" style="background:linear-gradient(135deg,#1b2a41,#0f1a2b);display:grid;place-items:center;font-size:60px">🚗</div>'}</div>
      <div class="pad"><span class="pill ${c.status === 'AVAILABLE' ? 'COMPLETED' : 'PENDING'}">${esc(ST[c.status])}</span>
      <div class="specs" style="margin-top:10px"><span>${TR[c.transmission]}</span><span>${c.seats} o'rin</span><span>${FU[c.fuel_type]}</span>${c.year ? `<span>${c.year}</span>` : ''}${c.color ? `<span>${esc(c.color)}</span>` : ''}</div>
      <div class="kv"><span>1+ kun</span><b>${money(c.price_day)}</b></div><div class="kv"><span>3+ kun</span><b>${money(c.price_3d)}</b></div><div class="kv"><span>7+ kun</span><b>${money(c.price_7d)}</b></div><div class="kv"><span>Depozit</span><b>${money(c.deposit)}</b></div></div></div>
    <div class="sec">KALENDAR — KEYINGI 60 KUN</div><div class="card pad"><div class="cal">${['Du', 'Se', 'Ch', 'Pa', 'Ju', 'Sh', 'Ya'].map(d => `<i class="h">${d}</i>`).join('')}${'<i class="h"></i>'.repeat(off)}${c.calendar.map(d => `<i class="${d.busy ? 'b' : ''}">${+d.date.slice(8)}</i>`).join('')}</div>
      <div class="note">🟩 bo'sh · 🟥 band</div></div>
    <button class="btn" data-go="${c.id}" ${c.status === 'MAINTENANCE' ? 'disabled' : ''}>Bron qilish</button>`);
  app.onclick = e => { if (e.target.closest('[data-go]')) go(() => viewBook(id)); tabClick(e); if (e.target.closest('[data-back]')) back(); };
}
function viewBookPick() {
  screen(`<div class="hd"><h1>Bron qilish</h1></div><div class="sec">MASHINANI TANLANG</div>${S.cars.length ? S.cars.filter(c => c.status !== 'MAINTENANCE').map(c => carCard(c, true)).join('') : '<div class="empty"><b>Mashinalar yo\'q</b></div>'}`);
  if (!S.cars.length) api('GET', '/cars').then(c => { S.cars = c; if (S.tab === 'book') viewBookPick(); });
  app.onclick = e => { const b = e.target.closest('[data-book],[data-car]'); if (b) go(() => viewBook(+(b.dataset.book || b.dataset.car))); tabClick(e); };
}

/* ---- Bron qilish ---- */
async function viewBook(carId) {
  const car = S.cars.find(c => c.id === carId) || (await api('GET', '/cars')).find(c => c.id === carId); if (!car) return toast('Mashina topilmadi', true);
  let terms; try { terms = await api('GET', '/contract'); } catch (e) { screen(`<div class="hd"><button class="back" data-back>←</button><h1>Bron qilish</h1></div><div class="empty"><b>Hozircha bron qilib bo'lmaydi</b>${esc(e.message)}</div>`, false); app.onclick = ev => { if (ev.target.closest('[data-back]')) back(); }; return; }
  const cfg = S.cfg, t0 = addD(today(), 1);
  const st = { agree: false, quoteOk: false, opened: terms.kind !== 'PDF' };
  const termsHtml = terms.kind === 'PDF'
    ? `<button class="btn alt" id="openpdf">📄 Shartnomani ochish va o'qish (PDF)</button><div class="note" id="tn">Shartnomani ochib o'qigandan so'ng rozilik berish mumkin.</div>`
    : `<div id="tb" style="max-height:240px;overflow:auto;white-space:pre-wrap;font-size:14px;border:1px solid var(--line);border-radius:12px;padding:12px">${esc(terms.body)}</div><div class="note" id="tn">Oxirigacha o'qing.</div>`;
  screen(`<div class="hd"><button class="back" data-back>←</button><h1>${esc(car.brand)} ${esc(car.model)}</h1></div>
    <div class="card pad"><div class="two"><div><label class="f" style="margin-top:0">Olish sanasi</label><input type="date" id="pd" min="${today()}" value="${t0}"></div><div><label class="f" style="margin-top:0">Olish vaqti</label><input type="time" id="pt" value="10:00"></div></div>
      <div class="two"><div><label class="f">Qaytarish sanasi</label><input type="date" id="rd" min="${today()}" value="${addD(t0, 3)}"></div><div><label class="f">Qaytarish vaqti</label><input type="time" id="rt" value="10:00"></div></div>
      ${cfg.locations.length ? `<label class="f">Olib ketish joyi</label><select id="loc">${cfg.locations.map(l => `<option>${esc(l)}</option>`).join('')}</select>` : ''}
      ${cfg.extras.length ? `<label class="f">Qo'shimcha xizmatlar</label>${cfg.extras.map(x => `<label class="chk"><input type="checkbox" class="ex" value="${esc(x.name)}"><span>${esc(x.name)} — ${money(x.price)}${x.per === 'day' ? ' / kun' : ''}</span></label>`).join('')}` : ''}
      ${cfg.features?.promo === false ? '' : `<label class="f">Promo kod</label><input id="promo" placeholder="Masalan: RENT10" autocapitalize="characters">`}
      <label class="f">Telefon raqamingiz</label><input id="ph" type="tel" inputmode="tel" placeholder="+998 90 123 45 67" value="${esc(S.me.phone || '')}">
      ${S.me.has_documents ? '' : `<label class="f">Passport / ID raqami (ixtiyoriy)</label><input id="pp" autocomplete="off"><label class="f">Haydovchilik guvohnomasi (ixtiyoriy)</label><input id="ll" autocomplete="off"><div class="note">Hujjat ma'lumotlari shifrlangan holda saqlanadi.</div>`}</div>
    <div class="card pad" id="q"><div class="note">Narx hisoblanmoqda…</div></div>
    <div class="sec">IJARA SHARTNOMASI</div><div class="card pad"><b>${esc(terms.title)}</b><div style="margin:10px 0">${termsHtml}</div>
      <label class="chk"><input type="checkbox" id="agree" disabled><span>Shartnoma shartlarini to'liq o'qib chiqdim va <b>roziman</b></span></label></div>
    <div id="er" class="err"></div><button class="btn" id="go" disabled>Buyurtma berish</button>`, false);
  const gate = () => { $('#agree').disabled = !st.opened; $('#go').disabled = !(st.quoteOk && $('#agree').checked); };
  if (terms.kind === 'PDF') $('#openpdf').onclick = () => { const u = location.origin + terms.pdf_url; try { tg ? tg.openLink(u) : window.open(u, '_blank'); } catch { window.open(u, '_blank'); } st.opened = true; $('#tn').textContent = "Shartnoma ochildi. O'qib bo'lgach, rozilik belgisini qo'ying."; gate(); };
  else { const tb = $('#tb'); const chk = () => { if (tb.scrollTop + tb.clientHeight >= tb.scrollHeight - 6) { st.opened = true; $('#tn').textContent = "O'qib bo'ldingiz. Rozilik belgisini qo'ying."; gate(); } }; tb.addEventListener('scroll', chk); setTimeout(chk, 200); }
  const read = () => ({ car_id: carId, pickup_date: $('#pd').value, pickup_time: $('#pt').value, return_date: $('#rd').value, return_time: $('#rt').value, promo_code: $('#promo')?.value.trim() || null,
    extras: [...document.querySelectorAll('.ex:checked')].map(x => ({ name: x.value, qty: 1 })) });
  let tm; const quote = () => { clearTimeout(tm); tm = setTimeout(async () => { st.quoteOk = false; gate(); $('#er').textContent = '';
    try { const q = await api('POST', '/quote', read());
      $('#q').innerHTML = `<div class="kv"><span>${q.days} kun × ${money(q.rate)}</span><b>${money(q.rental)}</b></div>${q.discount ? `<div class="kv"><span>Chegirma</span><b>− ${money(q.discount)}</b></div>` : ''}${q.items.map(i => `<div class="kv"><span>${esc(i.name)}</span><b>${money(i.total)}</b></div>`).join('')}<div class="kv"><span>Ijara jami</span><b>${money(q.total)}</b></div><div class="kv"><span>Depozit (qaytariladi)</span><b>${money(q.deposit)}</b></div><div class="kv t"><span>Jami</span><span>${money(q.grand_total)}</span></div>`;
      st.quoteOk = true; gate(); } catch (e) { $('#q').innerHTML = ''; $('#er').textContent = e.message; } }, 300); };
  app.oninput = quote; app.onchange = e => { if (e.target.id === 'agree') gate(); else quote(); }; quote();
  app.onclick = e => { if (e.target.closest('[data-back]')) return back(); if (e.target.closest('#go')) guard(async () => {
    const b = { ...read(), location: $('#loc')?.value || undefined, phone: $('#ph').value.trim() || undefined, passport: $('#pp')?.value.trim() || undefined, license: $('#ll')?.value.trim() || undefined, accept_terms: $('#agree').checked, template_id: terms.id };
    $('#go').disabled = true; const r = await api('POST', '/bookings', b); S.me.phone = b.phone || S.me.phone; haptic('success');
    stack.length = 0; syncBack(); S.tab = 'orders';
    screen(`<div class="empty" style="padding-top:60px"><div style="font-size:56px">✅</div><b>Buyurtma qabul qilindi</b>${esc(r.code)} — shartnoma shartlariga rozilik berdingiz.<br>Operator tez orada tasdiqlaydi; tasdiqlanganda Telegramda shartnoma bilan birga xabar olasiz.<div style="margin-top:22px"><button class="btn" data-tab="orders">Buyurtmalarimni ko'rish</button></div></div>`);
    app.onclick = tabClick; }).finally(() => { const g = $('#go'); if (g) gate(); }); };
}

/* ---- To'lov (karta orqali) ---- */
async function viewPay(b, kind) {
  loader(); const d = await api('GET', '/payment-accounts');
  const amount = kind === 'DEPOSIT' ? b.dep_left : b.remaining;
  if (!d.enabled || !d.accounts.length) { screen(`<div class="hd"><button class="back" data-back>←</button><h1>To'lov</h1></div><div class="empty"><b>Onlayn to'lov hozircha yoqilmagan</b>Operator bilan bog'lanib, kassada to'lashingiz mumkin.<br>${esc((S.cfg.contacts && S.cfg.contacts[0] && S.cfg.contacts[0].phone) || S.cfg.company.phone || '')}</div>`, false); app.onclick = e => { if (e.target.closest('[data-back]')) back(); }; return; }
  const fc = n => String(n || '').replace(/\D/g, '').replace(/(\d{4})(?=\d)/g, '$1 ');
  screen(`<div class="hd"><button class="back" data-back>←</button><h1>To'lov</h1></div>
    <div class="card pad"><div class="kv"><span>Buyurtma</span><b>${esc(b.code)}</b></div><div class="kv t"><span>${kind === 'DEPOSIT' ? 'Depozit' : "To'lanadigan summa"}</span><span>${money(amount)}</span></div></div>
    <div class="sec">QAYERGA TO'LASH</div>${d.accounts.map(a => `<div class="card pad"><b>${esc(a.title)}</b>
      ${a.kind === 'CARD' ? `<div style="font-size:22px;font-weight:800;letter-spacing:1px;margin:8px 0">${esc(fc(a.card_number))}</div><div class="note">${esc(a.holder_name || '')}${a.bank_name ? ' · ' + esc(a.bank_name) : ''}</div>` : `<div style="font-size:18px;font-weight:800;margin:8px 0;word-break:break-all">${esc(a.account_number)}</div><div class="note">${esc(a.bank_name || '')} ${esc(a.holder_name || '')}</div>`}
      ${a.note ? `<div class="note">${esc(a.note)}</div>` : ''}<button class="btn alt" style="margin-top:10px" data-copy="${esc(a.kind === 'CARD' ? a.card_number : a.account_number)}">📋 Raqamni nusxalash</button></div>`).join('')}
    <div class="sec">TO'LOV CHEKI</div><div class="card pad"><div class="note" style="margin:0 0 8px">To'lov qilgach, chekning rasmini (screenshot) yuklang. Admin tekshirib tasdiqlaydi.</div><input type="file" id="rc" accept="image/jpeg,image/png,image/webp">
      ${d.accounts.length > 1 ? `<label class="f">Qaysi kartaga to'ladingiz?</label><select id="acc">${d.accounts.map(a => `<option value="${a.id}">${esc(a.title)}</option>`).join('')}</select>` : ''}</div>
    <div id="er" class="err"></div><button class="btn" id="send">To'ladim — chekni yuborish</button>`, false);
  app.onclick = e => { if (e.target.closest('[data-back]')) return back();
    const c = e.target.closest('[data-copy]'); if (c) { navigator.clipboard?.writeText(c.dataset.copy).then(() => toast('Nusxalandi ✓')).catch(() => toast(c.dataset.copy)); }
    if (e.target.closest('#send')) guard(async () => { const f = $('#rc').files[0]; if (!f) throw new Error("Chek rasmini tanlang");
      const fd = new FormData(); fd.append('file', f); const r = await fetch('/api/mini/receipt', { method: 'POST', headers: { Authorization: 'Bearer ' + S.token }, body: fd }); const j = await r.json(); if (!r.ok) throw new Error(j.error || 'Yuklab bo\'lmadi');
      await api('POST', '/payment-claims', { booking_id: b.id, amount, kind, receipt_file: j.file, account_id: $('#acc') ? +$('#acc').value : (d.accounts[0]?.id) });
      haptic('success'); stack.length = 0; syncBack(); S.tab = 'orders'; screen(`<div class="empty" style="padding-top:60px"><div style="font-size:56px">🧾</div><b>So'rov yuborildi</b>Admin chekni tekshirib tasdiqlaydi. Natija haqida Telegramda xabar olasiz.<div style="margin-top:22px"><button class="btn" data-tab="orders">Buyurtmalarim</button></div></div>`); app.onclick = tabClick; }); };
}

/* ---- Buyurtmalar ---- */
const CL = { PENDING: 'Tekshirilmoqda', CONFIRMED: 'Tasdiqlandi', REJECTED: 'Rad etildi' };
async function viewOrders() {
  loader(); const [list, claims] = await Promise.all([api('GET', '/bookings'), api('GET', '/payment-claims').catch(() => [])]);
  S.orders = list;
  screen(`<div class="hd"><h1>Buyurtmalarim</h1></div>${list.length ? list.map(b => `<div class="card pad"><div class="row"><b>${esc(b.car)}</b><span class="sp"></span><span class="pill ${b.status}">${esc(BST[b.status])}</span></div>
    <div class="note">${esc(b.code)} · ${b.days} kun</div><div class="kv" style="margin-top:8px"><span>Olish</span><b>${fDT(b.pickup_at)}</b></div><div class="kv"><span>Qaytarish</span><b>${fDT(b.return_at)}</b></div>${b.pickup_location ? `<div class="kv"><span>Joy</span><b>${esc(b.pickup_location)}</b></div>` : ''}
    <div class="kv"><span>Ijara</span><b>${money(b.total)}</b></div><div class="kv"><span>Depozit</span><b>${money(b.deposit)}</b></div>${b.status !== 'CANCELLED' && b.remaining > 0 ? `<div class="kv"><span>To'lanishi kerak</span><b style="color:var(--red)">${money(b.remaining)}</b></div>` : ''}
    ${b.status !== 'CANCELLED' && b.remaining > 0 ? `<button class="btn" style="margin-top:10px" data-pay="${b.id}:R">💳 Ijara to'lovini to'lash</button>` : ''}${['PENDING', 'CONFIRMED'].includes(b.status) && b.dep_left > 0 ? `<button class="btn alt" style="margin-top:8px" data-pay="${b.id}:D">💳 Depozitni to'lash</button>` : ''}
    ${b.status === 'PENDING' ? `<button class="btn red" style="margin-top:10px" data-cancel="${b.id}">Buyurtmani bekor qilish</button>` : ''}</div>`).join('') : '<div class="empty"><b>Hali buyurtma yo\'q</b>«Bron qilish» bo\'limidan birinchi buyurtmangizni bering.</div>'}${claims.length ? `<div class="sec">TO'LOV SO'ROVLARIM</div>${claims.map(c => `<div class="card pad"><div class="row"><b>${esc(c.code)} · ${money(c.amount)}</b><span class="sp"></span><span class="pill ${c.status === 'CONFIRMED' ? 'COMPLETED' : c.status === 'REJECTED' ? 'CANCELLED' : 'PENDING'}">${CL[c.status]}</span></div>${c.reject_reason ? `<div class="note">${esc(c.reject_reason)}</div>` : ''}</div>`).join('')}` : ''}`);
  app.onclick = e => { tabClick(e); const pp = e.target.closest('[data-pay]'); if (pp) { const [id, k] = pp.dataset.pay.split(':'); const b = S.orders.find(x => x.id == id); go(() => viewPay(b, k === 'D' ? 'DEPOSIT' : 'RENTAL')); return; } const c = e.target.closest('[data-cancel]'); if (c && confirm('Buyurtma bekor qilinsinmi?')) guard(async () => { await api('POST', `/bookings/${c.dataset.cancel}/cancel`); toast('Buyurtma bekor qilindi'); viewOrders(); }); };
}

/* ---- Profil ---- */
async function viewMe() {
  loader(); S.me = await api('GET', '/me'); const m = S.me;
  const link = S.cfg.bot_username ? `https://t.me/${S.cfg.bot_username}?start=ref_${m.referral_code}` : '';
  screen(`<div class="hd"><h1>Profil</h1></div>
    <div class="card pad"><label class="f" style="margin-top:0">Ism</label><input id="fn" value="${esc(m.first_name)}"><label class="f">Familiya</label><input id="ln" value="${esc(m.last_name)}"><label class="f">Telefon</label><input id="ph" type="tel" value="${esc(m.phone)}" placeholder="+998 90 123 45 67">
      <label class="f">Passport / ID ${m.has_documents ? '(saqlangan)' : ''}</label><input id="pp" placeholder="${m.has_documents ? 'O\'zgartirish uchun yangisini kiriting' : 'AA1234567'}" autocomplete="off"><label class="f">Haydovchilik guvohnomasi</label><input id="ll" autocomplete="off"><div id="er" class="err"></div><button class="btn" style="margin-top:14px" id="sv">Saqlash</button></div>
    <div class="sec">DO'STLARNI TAKLIF QILING</div><div class="card pad"><div class="kv"><span>Bonus balansi</span><b>${money(m.bonus_balance)}</b></div><div class="kv"><span>Taklif qilinganlar</span><b>${m.referrals}</b></div>
      ${link ? `<div class="note" style="word-break:break-all">${esc(link)}</div><button class="btn alt" style="margin-top:10px" id="sh">Havolani ulashish</button>` : `<div class="note">Referral kodingiz: <b>${esc(m.referral_code)}</b></div>`}</div>
    <div class="sec">ALOQA</div><div class="card pad">${(S.cfg.contacts || []).map(c => `<div class="kv" style="align-items:flex-start"><span><b>${esc(c.label)}</b>${c.hours ? `<div class="note" style="margin:0">🕘 ${esc(c.hours)}</div>` : ''}</span><span style="text-align:right">${c.phone ? `<a href="tel:${esc(c.phone)}" style="color:inherit;font-weight:700">${esc(c.phone)}</a>` : ''}${c.telegram ? `<div><a href="https://t.me/${esc(c.telegram.slice(1))}" style="color:inherit">${esc(c.telegram)}</a></div>` : ''}</span></div>`).join('') || (S.cfg.company.phone ? `<div class="kv"><span>Operator</span><b><a href="tel:${esc(S.cfg.company.phone)}" style="color:inherit">${esc(S.cfg.company.phone)}</a></b></div>` : '<div class="note">Aloqa raqamlari hali kiritilmagan. Botga yozing — operator javob beradi.</div>')}${S.cfg.company.address ? `<div class="kv"><span>Manzil</span><b>${esc(S.cfg.company.address)}</b></div>` : ''}</div>`);
  app.onclick = e => { tabClick(e);
    if (e.target.closest('#sv')) guard(async () => { S.me = await api('PATCH', '/me', { first_name: $('#fn').value, last_name: $('#ln').value, phone: $('#ph').value || undefined, passport: $('#pp').value || undefined, license: $('#ll').value || undefined }); toast('Saqlandi ✓'); haptic('success'); });
    if (e.target.closest('#sh')) { const u = `https://t.me/share/url?url=${encodeURIComponent(link)}&text=${encodeURIComponent('Rent A Car — qulay avtomobil ijarasi')}`; tg ? tg.openTelegramLink(u) : window.open(u, '_blank'); } };
}

/* ---- Boshlash ---- */
(async function init() {
  if (tg) { tg.ready(); tg.expand(); tg.BackButton.onClick(back); if (tg.colorScheme) document.documentElement.dataset.l = tg.colorScheme; }
  try {
    S.cfg = await fetch('/api/mini/config').then(r => r.json());
    const sp = new URLSearchParams(location.search); const initData = tg && tg.initData;
    const body = initData ? { initData } : sp.get('dev') ? { dev_user: { id: sp.get('dev'), first_name: 'Demo' }, start_param: sp.get('ref') ? 'ref_' + sp.get('ref') : undefined } : null;
    if (!body) { app.innerHTML = '<div class="empty" style="padding-top:80px"><b>Telegram orqali oching</b>Bu ilova Telegram Mini App sifatida ishlaydi. Botimizni oching va «Ochish» tugmasini bosing.</div>'; return; }
    const a = await api('POST', '/auth', body); S.token = a.token; S.me = a.customer;
    const deep = sp.get('car'); showTab('cars'); if (deep) setTimeout(() => go(() => viewBook(+deep)), 300);
  } catch (e) { app.innerHTML = `<div class="empty" style="padding-top:80px"><b>Kirib bo'lmadi</b>${esc(e.message)}<div style="margin-top:18px"><button class="btn" onclick="location.reload()">Qayta urinish</button></div></div>`; }
})();
