# Elektron shartnoma moduli

**Jarayon:** BUYURTMA → SHARTNOMA → ELEKTRON ROZILIK → OTP → TASDIQLASH → AVTOMOBILNI TOPSHIRISH → IJARA → AVTOMOBILNI QAYTARISH → YAKUNIY HISOB-KITOB.
Hammasi bitta PostgreSQL bazasida, bitta buyurtmaga (`bookings.id`) bog'langan.

## Ishga tushirish
1. `npm install` (yangi paketlar: `@pdf-lib/fontkit`, `pdfjs-dist`; Node ≥ 20.19).
2. Server ishga tushganda `db/schema.sql` yangi jadvallarni qo'shadi va **RENT_A_CAR_ELEKTRON_SHARTNOMA.pdf** rasmiy shablon sifatida **VERSION 1.0** bo'lib o'rnatiladi
   (`src/contract/templates/`). Faol shablon elektron bo'lgach, yangi buyurtmalar avtomatik shu oqimdan o'tadi. Eski (matn/PDF) shartnomali buyurtmalar o'zgarmaydi.
3. OTP: kod mijozning Telegram botiga yuboriladi. SMS uchun `.env` da `ESKIZ_*` kiriting. Lokal sinov: `OTP_DEV_ECHO=true`.
4. Tekshiruv: `npm run test:contract` (bazasiz; shablon aniqlash, PDF to'ldirish, hisob-kitob).

## PDF shablon qanday ishlaydi
PDF matni, bandlari, jarimalari **o'zgartirilmaydi**. `[F.I.Sh.]`, `[avtomatik]`, `[avtomobildan]`, `[tarifdan]`… kabi joylar PDF ichidan koordinatalari bilan aniqlanadi
(`src/contract/detect.js`, qoidalar: `rules.js`), eski yozuv yopilib, ustidan tizim ma'lumoti yoziladi (`fill.js`). Kilometr limiti (300 km), ortiqcha km narxi (1 000 so'm/km)
va 13 qatorli jarimalar jadvali ham shablondan o'qiladi va hisob-kitobda ishlatiladi — shablon versiyasiga bog'langan.

## Versiyalar
Admin → Sozlamalar → Shartnoma: yangi PDF yuklash, «Kichik» (1.0 → 1.1) yoki «Katta» (→ 2.0) o'zgarish. Majburiy maydonlar va 5 ta ☐ topilmasa yuklanmaydi.
Tasdiqlangan shartnoma o'z versiyasida va o'z PDF faylida qoladi (`econtracts.template_id`, `version_label`).

## Xavfsizlik
- Mijoz faqat o'z shartnomasini ko'radi (`WHERE customer_id = <token>`); boshqasi — 404.
- PDF fayllar `uploads/econtracts/` da (statik berilmaydi). Mini App faylni `Authorization` bilan oladi; yuklab olish uchun 2 daqiqalik bir martalik havola.
- Tasdiqlangan PDF har ochilganda SHA-256 tekshiriladi; mos kelmasa berilmaydi va `INTEGRITY_FAIL` yoziladi.
- Muzlatish bazada trigger bilan: tasdiqlangandan keyin mazmun/PDF/xesh o'zgarmaydi (faqat `APPROVED → CANCELLED`); audit, hodisalar va dalolatnomalar jadvallarida UPDATE/DELETE taqiqlangan.
- OTP: 6 xonali, HMAC bilan saqlanadi, 5 daqiqa, 5 urinish, 60 s oraliq, soatiga 5 ta.
- Pasport shartnoma nusxasida (`econtracts.data`) shifrlangan holda saqlanadi.

## Mavjud avtomatik testlar (`npm test`)
`scripts/e2e.js` eski shartnoma oqimini tekshiradi va "shartnoma yuklanmagan" holatini kutadi — uni `ECONTRACT_AUTOSEED=false` bilan ishga tushirilgan serverda yuriting.
