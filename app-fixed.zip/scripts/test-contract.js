/* Elektron shartnoma moduli: bazasiz tekshiruv (PDF shablon, avtomatik maydonlar, hisob-kitob).
 * Ishga tushirish: node scripts/test-contract.js */
'use strict';
const fs = require('fs'), path = require('path'), assert = require('assert');
const { PDFDocument, StandardFonts } = require('pdf-lib');
const { detect } = require('../src/contract/detect');
const { renderTemplate } = require('../src/contract/fill');
const { computeSettlement, resolveFines } = require('../src/contract/settlement');
const { REQUIRED, CHECK_KEYS } = require('../src/contract/rules');

let ok = 0; const t = (name, fn) => Promise.resolve().then(fn).then(() => { ok++; console.log('  ✓', name); }).catch(e => { console.error('  ✗', name, '\n   ', e.message); process.exitCode = 1; });
const san = s => String(s).replace(/☑/g, 'X').replace(/[^\x20-\x7e\u2018\u2019\u2014\u2013\u2026]/g, '?');

(async () => {
  const buf = fs.readFileSync(path.join(__dirname, '..', 'src', 'contract', 'templates', 'RENT_A_CAR_ELEKTRON_SHARTNOMA.pdf'));
  let fontkit = true; try { require('@pdf-lib/fontkit'); } catch { fontkit = false; }
  const hd = await PDFDocument.create(), hf = await hd.embedFont(StandardFonts.Helvetica);
  const fontsFn = fontkit ? require('../src/contract/fonts').embed : async d => ({ reg: await d.embedFont(StandardFonts.Helvetica), bold: await d.embedFont(StandardFonts.HelveticaBold) });
  const measure = fontkit ? (require('../src/contract/fonts').measurer() || undefined) : (s, z) => hf.widthOfTextAtSize(san(s), z);
  console.log(fontkit ? 'Shrift: DejaVu (fontkit)' : 'Shrift: Helvetica (fontkit o‘rnatilmagan — faqat mantiq tekshiriladi)');
  let map;

  console.log('Shablon:');
  await t('PDF 6 bet, barcha [..] joylar tanildi, tanilmagani yo‘q', async () => { map = await detect(buf, { measure }); assert.strictEqual(map.pages, 6); assert.strictEqual(map.unmapped.length, 0, JSON.stringify(map.unmapped)); assert.ok(map.fields.length >= 50); });
  await t('majburiy maydonlar topildi', () => assert.deepStrictEqual(map.missing, []));
  await t('5 ta rozilik belgisi (☐) topildi', () => assert.deepStrictEqual(map.checks.map(c => c.key).sort(), [...CHECK_KEYS].sort()));
  await t('shartlar shablondan o‘qildi: 300 km, 1000 so‘m/km, 13 jarima', () => { assert.strictEqual(map.terms.km_limit_day, 300); assert.strictEqual(map.terms.extra_km_price, 1000); assert.strictEqual(map.terms.fines.length, 13); assert.strictEqual(map.terms.fines[0].amount, 200000); assert.strictEqual(map.terms.fines[11].kind, 'per_hour'); assert.strictEqual(map.terms.fines[10].kind, 'plus_costs'); });
  await t('noto‘g‘ri PDF (maydonsiz) rad etiladi', async () => { const d = await PDFDocument.create(); d.addPage().drawText('Salom', { x: 50, y: 700 }); const r = await detect(Buffer.from(await d.save())); assert.ok(r.missing.length > 5); });

  console.log('PDF to‘ldirish:');
  const values = { contract_number: 'SH-2026-000123', contract_date: '08.10.2026', e_note: 'avtomatik', customer_name: 'Azizbek Karimov', customer_phone: '+998901234567', customer_passport: 'AB1234567', customer_address: 'Buxoro sh., Mustaqillik 12',
    car_model: 'Chevrolet Malibu', car_plate: '80 A 123 AA', car_vin: 'XW8ZZZ61ZEG123456', rental_period: '09.10.2026 — 12.10.2026 (3 kun)', pickup_info: '09.10.2026 10:00 · ofis', return_info: '12.10.2026 10:00 · ofis', daily_price: '550 000', total_price: '1 650 000', deposit: '2 000 000' };
  let bytes;
  await t('qoralama PDF yaratildi, 6 bet, shablon matni saqlandi', async () => {
    const { doc } = await renderTemplate({ templateBuf: buf, map, values, footer: 'x', watermark: 'TASDIQLANMAGAN', fonts: fontsFn, sanitize: fontkit ? undefined : san });
    bytes = await doc.save(); const out = await PDFDocument.load(bytes); assert.strictEqual(out.getPageCount(), 6); assert.ok(bytes.length > 20000);
  });
  await t('tasdiqlangan PDF (rozilik belgilari bilan) yaratildi', async () => {
    const { doc } = await renderTemplate({ templateBuf: buf, map, values, checks: Object.fromEntries(CHECK_KEYS.map(k => [k, true])), fonts: fontsFn, sanitize: fontkit ? undefined : san });
    assert.ok((await doc.save()).length > 20000);
  });
  await t('dalolatnoma uchun bitta sahifa ajratiladi', async () => {
    const pg = map.fields.find(f => f.key === 'ho_car').page;
    const { doc } = await renderTemplate({ templateBuf: buf, map, values: { ho_car: 'Chevrolet / 80 A', ho_equipment: 'Zapas balon, Kalpak, Aptechka' }, keep: [pg], fonts: fontsFn, sanitize: fontkit ? undefined : san });
    assert.strictEqual((await PDFDocument.load(await doc.save())).getPageCount(), 1);
  });
  fs.writeFileSync('/tmp/test-contract.pdf', bytes);

  console.log('Hisob-kitob:');
  const terms = map.terms, base = { start_km: 1000, end_km: 2000, days: 3, km_limit_day: 300, extra_km_price: 1000, terms, deposit_held: 2000000 };
  await t('limit ichida: ortiqcha km yo‘q, garov to‘liq qaytadi', () => { const s = computeSettlement({ ...base, end_km: 1800 }); assert.strictEqual(s.extra_km, 0); assert.strictEqual(s.charges_total, 0); assert.strictEqual(s.deposit_refund, 2000000); });
  await t('limitdan oshdi: 1000 km − 900 = 100 km × 1000 = 100 000', () => { const s = computeSettlement(base); assert.strictEqual(s.extra_km, 100); assert.strictEqual(s.extra_km_fee, 100000); assert.strictEqual(s.deposit_refund, 1900000); });
  await t('ortiqcha km + jarima + zarar + boshqa = yakuniy; garov − ushlab qolish', () => {
    const s = computeSettlement({ ...base, fines: [{ n: 1 }, { n: 12, qty: 3 }], damage_fee: 500000, other_fee: 50000, late_fee: 20000 });
    assert.strictEqual(s.fines_total, 200000 + 300000); assert.strictEqual(s.charges_total, 100000 + 500000 + 500000 + 50000 + 20000);
    assert.strictEqual(s.deposit_deducted, 1170000); assert.strictEqual(s.deposit_refund, 2000000 - 1170000); assert.strictEqual(s.balance_due, 0);
  });
  await t('hisob-kitob garovdan oshsa — qo‘shimcha to‘lov', () => { const s = computeSettlement({ ...base, deposit_held: 500000, damage_fee: 3000000 }); assert.strictEqual(s.deposit_deducted, 500000); assert.strictEqual(s.deposit_refund, 0); assert.strictEqual(s.balance_due, 100000 + 3000000 - 500000); });
  await t('qo‘lda ushlab qolish summasi chegaralanadi', () => { assert.throws(() => computeSettlement({ ...base, damage_fee: 100000, deduct: 999999999 })); const s = computeSettlement({ ...base, damage_fee: 100000, deduct: 50000 }); assert.strictEqual(s.deposit_deducted, 50000); assert.strictEqual(s.balance_due, 150000); });
  await t('yakuniy km boshlang‘ichdan kam bo‘lsa — xato', () => assert.throws(() => computeSettlement({ ...base, end_km: 900 })));
  await t('"xarajatlar + summa" jarimasi', () => { const r = resolveFines([{ n: 11, extra: 250000 }], terms); assert.strictEqual(r.total, 750000); });
  await t('noma’lum jarima raqami rad etiladi', () => assert.throws(() => resolveFines([{ n: 99 }], terms)));
  await t('REQUIRED ro‘yxati bo‘sh emas', () => assert.ok(REQUIRED.length >= 15));
  console.log(`\n${ok} ta tekshiruv o‘tdi${process.exitCode ? ', XATOLAR BOR' : ''}`);
})();
