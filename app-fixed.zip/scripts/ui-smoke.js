// UI smoke test: jsdom da admin panel va Mini App ni haqiqiy server ustida ishga tushiradi
const { JSDOM, VirtualConsole } = require('jsdom');
const BASE = process.env.BASE || 'http://localhost:3000';
const PASS = process.env.ADMIN_PASSWORD;
const sleep = ms => new Promise(r => setTimeout(r, ms));
const errors = [];
let ok = 0, bad = 0; const t = (n, c, x = '') => { c ? ok++ : bad++; console.log(c ? '  ✓' : '  ✗', n, c ? '' : x); };

function make(url, { cookie = '', pre } = {}) {
  const vc = new VirtualConsole(); vc.on('jsdomError', e => errors.push(url + ' :: ' + (e.detail?.message || e.message))); vc.on('error', e => errors.push('console.error: ' + e));
  return JSDOM.fromURL(BASE + url, { runScripts: 'dangerously', resources: 'usable', pretendToBeVisual: true, virtualConsole: vc, beforeParse(w) {
    w.jar = { c: cookie };
    w.fetch = async (u, o = {}) => { const full = new URL(u, BASE); const h = { ...(o.headers || {}) }; if (w.jar.c) h.cookie = w.jar.c;
      const r = await fetch(full, { ...o, headers: h }); const sc = r.headers.get('set-cookie'); if (sc) w.jar.c = sc.split(';')[0]; return r; };
    w.FormData = FormData; w.confirm = () => true; w.matchMedia = () => ({ matches: false, addEventListener() {} });
    w.addEventListener('unhandledrejection', e => errors.push('unhandled: ' + (e.reason?.message || e.reason)));
    w.Telegram = undefined; pre && pre(w);
  } });
}
const until = async (fn, ms = 6000) => { const s = Date.now(); while (Date.now() - s < ms) { try { if (fn()) return true; } catch {} await sleep(80); } return false; };

async function setup() {
  const r = await fetch(BASE + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'rac' }, body: JSON.stringify({ username: 'owner', password: PASS }) });
  const cookie = r.headers.get('set-cookie').split(';')[0];
  const post = (p, b) => fetch(BASE + '/api' + p, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'rac', cookie }, body: JSON.stringify(b) });
  await post('/contract-template', { title: 'Avtomobil ijara shartnomasi', body: 'Ijara shartlari.\n1. Ijarachi avtomobilni ehtiyotkorlik bilan ishlatadi.\n2. Zarar depozit hisobidan qoplanadi.\n3. Kechikish uchun alohida tarif qo\'llanadi.' });
  await post('/payment-accounts', { kind: 'CARD', title: 'Humo', card_number: '4111111111111111', holder_name: 'TEST EGASI' });
}
(async () => {
  await setup();
  console.log('\n[Admin panel UI]');
  const dom = await make('/admin/'); const w = dom.window, d = w.document;
  t('login forma chiqdi', await until(() => d.querySelector('#lf')));
  d.querySelector('#u').value = 'owner'; d.querySelector('#p').value = 'wrong'; d.querySelector('#lf').dispatchEvent(new w.Event('submit', { cancelable: true }));
  t("noto'g'ri parol xabari ko'rinadi", await until(() => /noto'g'ri/.test(d.querySelector('#le')?.textContent || '')));
  d.querySelector('#p').value = PASS; d.querySelector('#lf').dispatchEvent(new w.Event('submit', { cancelable: true }));
  t('login → dashboard', await until(() => d.querySelector('#page .kpi')), d.body.textContent.slice(0, 200));
  t("dashboard: grafiklar (SVG) chiqdi", d.querySelectorAll('#page svg').length >= 4, d.querySelectorAll('#page svg').length);
  t('dashboard: BUGUNGI ISHLAR bloki', /BUGUNGI ISHLAR/.test(d.querySelector('#page').textContent));
  t("sidebar: 14 ta bo'lim (OWNER)", d.querySelectorAll('.nav a').length === 14, d.querySelectorAll('.nav a').length);
  t('mobil tezkor tugmalar (5 ta)', d.querySelectorAll('#quick button').length === 5);
  for (const [k, title] of [['cars', 'Mashinalar'], ['bookings', 'Buyurtmalar'], ['customers', 'Mijozlar'], ['botusers', 'Foydalanuvchilar'], ['finance', 'Moliya'], ['maintenance', 'Texnik xizmat'], ['contracts', 'Shartnomalar'], ['reports', 'Hisobotlar'], ['messages', 'Xabarlar'], ['notifications', 'Bildirishnomalar'], ['features', 'Funksiyalar'], ['staff', 'Xodimlar'], ['settings', 'Sozlamalar']]) {
    w.location.hash = '#/' + k;
    const loaded = await until(() => d.querySelector('#pt').textContent === title && !d.querySelector('#page .loading') && d.querySelector('#page').children.length > 0, 8000);
    const txt = d.querySelector('#page').textContent;
    t(`sahifa: ${title}`, loaded && !/yuklab bo'lmadi/.test(txt), txt.slice(0, 160));
  }
  w.location.hash = '#/cars'; await until(() => d.querySelectorAll('.carcard').length >= 10);
  t('mashinalar: 10 ta karta', d.querySelectorAll('.carcard').length >= 10, d.querySelectorAll('.carcard').length);
  d.querySelector('.carcard').click(); await until(() => d.querySelector('.modal .cal'));
  t('mashina modali: «Kimda?», kalendar, texnik tarix', /Kimda\?/.test(d.querySelector('.modal').textContent) && d.querySelector('.modal .cal') && /Texnik xizmat tarixi/.test(d.querySelector('.modal').textContent));
  d.querySelector('.modal [data-close]').click();
  w.location.hash = '#/bookings'; await until(() => d.querySelector('#bl tr.click'));
  d.querySelector('#bl tr.click').click(); await until(() => d.querySelector('.modal .kv.total'));
  t('buyurtma modali: hisob-kitob, qolgan summa', /Qolgan summa/.test(d.querySelector('.modal').textContent));
  d.querySelector('.modal [data-close]').click();
  w.location.hash = '#/customers'; await until(() => d.querySelector('#cl tr.click'));
  d.querySelector('#cl tr.click').click(); await until(() => /Ijara tarixi/.test(d.querySelector('.modal')?.textContent || ''));
  t('mijoz modali: profil + ijara tarixi', /Ijara tarixi/.test(d.querySelector('.modal')?.textContent || ''));
  d.querySelector('.modal [data-close]').click();
  w.eval("openNewBooking()"); await until(() => d.querySelector('#nb_q .kv.total'), 8000);
  t('yangi bron formasi: narx avtomatik hisoblanadi', !!d.querySelector('#nb_q .kv.total'), d.querySelector('#nb_q')?.textContent);
  d.querySelector('.modal [data-close]').click();
  // XSS: <script> ismli mijoz escape qilinadimi
  w.location.hash = '#/customers'; await sleep(600); w.eval("PAGES.customers.render(document.querySelector('#page'))"); await until(() => d.querySelector('#cl tr.click'));
  t("XSS: mijoz ismi escape qilinadi (DOM da <script> yo'q)", !d.querySelector('#page script'));
  // AI
  d.querySelector('#aib').click(); const inp = d.querySelector('#aq'); inp.value = 'Bugun qancha foyda qildik?'; d.querySelector('#af').dispatchEvent(new w.Event('submit', { cancelable: true }));
  t('AI yordamchi: javob keldi', await until(() => /Sof foyda/.test(d.querySelector('#am')?.textContent || '')));
  w.eval("toast('test')"); t('toast ishlaydi', d.querySelector('.toast'));
  w.location.hash = '#/finance'; await until(() => d.querySelector('#ft'));
  d.querySelector('[data-t=accounts]').click(); t("Moliya → To'lov joylari: karta ko'rinadi", await until(() => /4111 1111 1111 1111/.test(d.querySelector('#fb')?.textContent || '')));
  d.querySelector('[data-t=claims]').click(); t("Moliya → To'lov so'rovlari bo'limi ochiladi", await until(() => /so'rovlari yo'q|kutilmoqda/i.test(d.querySelector('#fb')?.textContent || '')));
  w.location.hash = '#/settings'; await until(() => d.querySelector('#st'));
  d.querySelector('#st [data-t=contract]').click(); t('Sozlamalar → Shartnoma: PDF yuklash va faol versiya', await until(() => d.querySelector('#cf') && /Faol shartnoma/.test(d.querySelector('#sb')?.textContent || '')));
  w.location.hash = '#/features'; t('Funksiyalar markazi: modullar, maxsus maydonlar, aloqa raqamlari', await until(() => d.querySelectorAll('[data-flag]').length === 6 && d.querySelector('#af') && d.querySelector('#nc')));
  w.location.hash = '#/staff'; t('Xodimlar: telefon/Telegram ustunlari va rol huquqlari jadvali', await until(() => /Telefon/.test(d.querySelector('#page')?.textContent || '') && d.querySelectorAll('[data-perm]').length > 40, 8000));
  w.location.hash = '#/botusers'; t("Foydalanuvchilar: ro'yxat sarlavhasi (Telegram, Telefon, ID)", await until(() => /Foydalanuvchi/.test(d.querySelector('#page')?.textContent || '') && !d.querySelector('#page .loading')));
  w.location.hash = '#/messages'; t('Xabarlar sahifasi: alohida va ommaviy xabar', await until(() => /Hammaga xabar/.test(d.querySelector('#page')?.textContent || '') && /Bitta mijozga yozish/.test(d.querySelector('#page').textContent)));
  w.location.hash = '#/bookings'; await until(() => d.querySelector('#bl tr.click')); d.querySelector('#bl tr.click').click();
  t('buyurtma modalida shartnoma roziligi holati ko\'rinadi', await until(() => /Shartnoma roziligi/.test(d.querySelector('.modal')?.textContent || '')));
  d.querySelector('.modal [data-close]').click();

  console.log('\n[Mini App UI]');
  const mini = await make('/app/?dev=880011'); const mw = mini.window, md = mw.document;
  t("Mini App: birinchi kirishda ro'yxatdan o'tish ekrani", await until(() => md.querySelector('#rgo'), 8000), md.body.textContent.slice(0, 150));
  t("Mini App: ma'lumot va rozilik bo'lmaguncha tugma bloklangan", md.querySelector('#rgo').disabled);
  for (const [id, v] of [['#rfn', 'Test'], ['#rln', 'Mijoz'], ['#rph', '+998901110000']]) { md.querySelector(id).value = v; md.querySelector(id).dispatchEvent(new mw.Event('input', { bubbles: true })); }
  const ra = md.querySelector('#ragree'); await until(() => !ra.disabled, 4000); ra.checked = true; ra.dispatchEvent(new mw.Event('change', { bubbles: true }));
  t("Mini App: ism, telefon va rozilik berilgach tugma yoqiladi", await until(() => !md.querySelector('#rgo').disabled, 4000));
  md.querySelector('#rgo').click();
  t('Mini App: mashinalar ro\'yxati', await until(() => md.querySelectorAll('.card.car').length >= 9, 8000), md.body.textContent.slice(0, 150));
  t('Mini App: karta (narx, avtomat, holat)', /Avtomat/.test(md.body.textContent) && /Bo'sh/.test(md.body.textContent));
  t('Mini App: pastki tab bar (4 ta)', md.querySelectorAll('.tabbar button').length === 4);
  md.querySelector('.card.car').click(); t('Mini App: mashina sahifasi + 60 kunlik kalendar', await until(() => md.querySelectorAll('.cal i:not(.h)').length === 60));
  md.querySelector('[data-go]').click(); t('Mini App: bron formasi, narx hisoblandi', await until(() => md.querySelector('#q .kv.t'), 8000), md.querySelector('#q')?.textContent);
  const fd = n => { const d = new Date(Date.now() + n * 864e5 + 5 * 3600e3).toISOString().slice(0, 10); return d; };
  md.querySelector('#pd').value = fd(40); md.querySelector('#rd').value = fd(43); md.querySelector('#pd').dispatchEvent(new mw.Event('change', { bubbles: true }));
  await until(() => md.querySelector('#q .kv.t') && !md.querySelector('#go').disabled, 8000); await sleep(400);
  t('Mini App: shartnoma shartlari ko\'rsatiladi, rozilik belgisisiz tugma bloklangan', /IJARA SHARTNOMASI/.test(md.body.textContent) && md.querySelector('#go').disabled);
  const ag = md.querySelector('#agree'); await until(() => !ag.disabled, 4000); ag.checked = true; ag.dispatchEvent(new mw.Event('change', { bubbles: true }));
  t('Mini App: rozilik berilgach «Buyurtma berish» yoqiladi', await until(() => !md.querySelector('#go').disabled, 4000));
  md.querySelector('#ph').value = '+998901112299'; md.querySelector('#go').click();
  t('Mini App: buyurtma yuborildi', await until(() => /Buyurtma qabul qilindi/.test(md.body.textContent), 8000), md.body.textContent.slice(0, 200));
  md.querySelector('[data-tab=orders]').click(); t('Mini App: «Buyurtmalarim»', await until(() => md.querySelectorAll('.card.pad .pill.PENDING').length >= 1));
  t("Mini App: buyurtmada «To'lash» tugmasi bor", !!md.querySelector('[data-pay]'));
  md.querySelector('[data-pay]').click(); t("Mini App: to'lov sahifasi — karta raqami va chek yuklash", await until(() => /4111 1111 1111 1111/.test(md.body.textContent) && md.querySelector('#rc') && md.querySelector('#send')), md.body.textContent.slice(0, 160));
  md.querySelector('[data-back]').click(); await sleep(300);
  md.querySelector('[data-tab=orders]').click(); await until(() => md.querySelector('.card.pad'));
  md.querySelector('[data-tab=me]').click(); t('Mini App: profil + referral', await until(() => /DO'STLARNI TAKLIF/.test(md.body.textContent)));
  const noTg = await make('/app/'); t('Telegramsiz ochilsa tushuntirish chiqadi', await until(() => /Telegram orqali oching/.test(noTg.window.document.body.textContent)));

  const real = errors.filter(e => !/Could not load|Not implemented|navigation|getComputedStyle|scrollTo/i.test(e));
  t("JavaScript xatolari yo'q", real.length === 0, '\n   ' + real.slice(0, 8).join('\n   '));
  console.log(`\nUI NATIJA: ${ok} o'tdi, ${bad} xato`); process.exit(bad ? 1 : 0);
})().catch(e => { console.error('UI TEST YIQILDI', e); process.exit(2); });
