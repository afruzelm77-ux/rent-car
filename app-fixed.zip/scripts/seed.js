const crypto = require('crypto');
const db = require('../src/db');
const { hash } = require('../src/auth');
const { ROLES } = require('../src/permissions');
const { encrypt, parseTkt, todayStr, addDays } = require('../src/util');
const bookingsSvc = require('../src/services/bookings');

const CATS = [['FUEL', 'Benzin'], ['OIL', 'Moy'], ['REPAIR', 'Remont'], ['WASH', 'Yuvish'], ['TIRES', 'Shina'], ['INSURANCE', "Sug'urta"], ['TAX', 'Soliq'], ['ADS', 'Reklama'], ['OTHER', 'Boshqa']];

async function base() {
  for (const [code, r] of Object.entries(ROLES)) {
    // OWNER har doim to'liq huquqda. Boshqa rollar faqat BIRINCHI marta yaratiladi — Egasi keyin o'zgartirgan huquqlar qayta ishga tushganda tiklanib ketmaydi
    if (code === 'OWNER') await db.query(`INSERT INTO roles(code,name,permissions) VALUES($1,$2,$3) ON CONFLICT (code) DO UPDATE SET name=EXCLUDED.name, permissions=EXCLUDED.permissions`, [code, r.name, JSON.stringify(r.permissions)]);
    else await db.query(`INSERT INTO roles(code,name,permissions) VALUES($1,$2,$3) ON CONFLICT (code) DO NOTHING`, [code, r.name, JSON.stringify(r.permissions)]);
  }
  for (const [code, name] of CATS) await db.query(`INSERT INTO expense_categories(code,name) VALUES($1,$2) ON CONFLICT (code) DO NOTHING`, [code, name]);
  const n = (await db.query('SELECT COUNT(*)::int n FROM users')).rows[0].n;
  if (n === 0) {
    const pw = process.env.ADMIN_PASSWORD || crypto.randomBytes(9).toString('base64url');
    await db.query(`INSERT INTO users(role_id,full_name,username,password_hash) VALUES((SELECT id FROM roles WHERE code='OWNER'),'Kompaniya egasi','owner',$1)`, [await hash(pw)]);
    console.log(`\n=== BIRINCHI KIRISH ===\nLogin: owner\nParol: ${pw}\n(Parolni Sozlamalar → Xodimlar bo'limida almashtiring)\n=======================\n`);
    return { pw };
  }
  return null;
}

const CARS = [
  ['Chevrolet', 'Cobalt', '01 A 123 AA', 2022, 'Oq', 'AUTOMATIC', 'GAS', 5, 300000, 280000, 260000, 1000000, 4850],
  ['Chevrolet', 'Malibu', '01 B 456 BA', 2023, 'Qora', 'AUTOMATIC', 'PETROL', 5, 550000, 520000, 480000, 2000000, 32400],
  ['Chevrolet', 'Onix', '01 C 789 CA', 2023, 'Kumush', 'AUTOMATIC', 'PETROL', 5, 350000, 330000, 300000, 1200000, 21800],
  ['Chevrolet', 'Tracker', '01 D 321 DA', 2024, 'Qizil', 'AUTOMATIC', 'PETROL', 5, 480000, 450000, 420000, 1800000, 12600],
  ['Kia', 'K5', '01 E 654 EA', 2022, 'Oq', 'AUTOMATIC', 'PETROL', 5, 600000, 570000, 520000, 2500000, 41200],
  ['BYD', 'Song Plus', '01 F 987 FA', 2024, 'Ko\'k', 'AUTOMATIC', 'HYBRID', 5, 750000, 700000, 650000, 3000000, 9800],
  ['Toyota', 'Camry', '01 G 147 GA', 2021, 'Qora', 'AUTOMATIC', 'PETROL', 5, 700000, 660000, 600000, 3000000, 58700],
  ['Hyundai', 'Elantra', '01 H 258 HA', 2023, 'Kulrang', 'AUTOMATIC', 'PETROL', 5, 420000, 390000, 360000, 1500000, 27300],
  ['Kia', 'Sportage', '01 J 369 JA', 2023, 'Oq', 'AUTOMATIC', 'PETROL', 5, 650000, 610000, 560000, 2500000, 35100],
  ['Chevrolet', 'Equinox', '01 K 741 KA', 2022, 'Qora', 'AUTOMATIC', 'PETROL', 5, 520000, 490000, 450000, 2000000, 44900],
];
const CUSTOMERS = [['Azizbek', 'Karimov', '+998901234567'], ['Dilshod', 'Rahimov', '+998909876543'], ['Malika', 'Yusupova', '+998935551122'], ['Sardor', 'Tursunov', '+998977003344'],
  ['Nodira', 'Aliyeva', '+998946667788'], ['Jasur', 'Ismoilov', '+998911112233'], ['Bekzod', 'Normatov', '+998998889900'], ['Madina', 'Saidova', '+998901445566'],
  ['Otabek', 'Qodirov', '+998936778899'], ['Zilola', 'Abdullayeva', '+998971230045']];

async function demo(adminId) {
  if ((await db.query('SELECT COUNT(*)::int n FROM cars')).rows[0].n > 0) return;
  console.log('Demo ma\'lumotlar yaratilmoqda...');
  const cat = Object.fromEntries((await db.query('SELECT code,id FROM expense_categories')).rows.map(r => [r.code, r.id]));
  const T = todayStr();
  const at = (dayOff, time) => parseTkt(addDays(T, dayOff), time);
  const carIds = [], custIds = [], km = {};

  await db.tx(async c => {
    for (const x of CARS) {
      const r = await c.query(`INSERT INTO cars(brand,model,plate,vin,year,color,transmission,fuel_type,seats,price_day,price_3d,price_7d,deposit,mileage,fuel_level,status,insurance_until,inspection_until)
        VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,80,'AVAILABLE',$15,$16) RETURNING id`,
      [x[0], x[1], x[2], 'XW' + crypto.randomBytes(7).toString('hex').toUpperCase().slice(0, 15), x[3], x[4], x[5], x[6], x[7], x[8], x[9], x[10], x[11], x[12], addDays(T, 120), addDays(T, 200)]);
      carIds.push(r.rows[0].id); km[r.rows[0].id] = x[12];
    }
    await c.query('UPDATE cars SET insurance_until=$2 WHERE id=$1', [carIds[6], addDays(T, 9)]);   // sug'urta tugashi ogohlantirishi uchun
    for (const x of CUSTOMERS) {
      const r = await c.query(`INSERT INTO customers(first_name,last_name,phone,passport_enc,license_enc,passport_last4,referral_code) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
        [x[0], x[1], x[2], encrypt('AB' + (1000000 + custIds.length * 137911)), encrypt('LIC' + (500000 + custIds.length * 71)), String(137911 * custIds.length).slice(-3), 'C' + crypto.randomBytes(3).toString('hex').toUpperCase()]);
      custIds.push(r.rows[0].id);
    }
    await c.query(`INSERT INTO promo_codes(code,percent,min_days,usage_limit) VALUES('RENT10',10,1,100),('MIN7',7,7,NULL)`);
    await c.query(`INSERT INTO promo_codes(code,fixed_amount,valid_until) VALUES('FIX50',50000,$1)`, [addDays(T, 60)]);

    // booking helper
    let seq = 0;
    const mk = async ({ car, cust, start, startT = '10:00', days, status, paid = 'full', loc = 'Ofis (Toshkent)', late = 0, damage = 0, promo = null }) => {
      const carRow = (await c.query('SELECT * FROM cars WHERE id=$1', [carIds[car]])).rows[0];
      const pickup = at(start, startT), ret = new Date(pickup.getTime() + days * 864e5);
      const rate = days >= 7 ? carRow.price_7d : days >= 3 ? carRow.price_3d : carRow.price_day;
      const rental = Number(rate) * days;
      const discount = promo ? Math.floor(rental * promo / 100) : 0;
      const dep = Number(carRow.deposit);
      const id = (await c.query(`SELECT nextval(pg_get_serial_sequence('bookings','id')) id`)).rows[0].id;
      const total0 = rental - discount;
      const total = total0 + late + damage;
      const done = status === 'COMPLETED';
      const paidNow = done ? total : paid === 'full' ? total0 : paid === 'half' ? Math.floor(total0 / 2) : 0;
      const real = status === 'OVERDUE' || status === 'ACTIVE' || done;
      await c.query(`INSERT INTO bookings(id,code,customer_id,car_id,pickup_at,return_at,pickup_location,days,daily_rate,rental_amount,discount,deposit_amount,late_fee,damage_fee,total_amount,paid_amount,status,source,
        actual_pickup_at,actual_return_at,created_by,created_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22)`,
      [id, 'BK-' + String(id).padStart(6, '0'), custIds[cust], carIds[car], pickup, ret, loc, days, rate, rental, discount, dep, late, damage, total, paidNow, status, seq++ % 3 === 0 ? 'BOT' : seq % 3 === 1 ? 'MINIAPP' : 'ADMIN',
        real ? pickup : null, done ? new Date(ret.getTime() + (late ? 3.5 * 3600e3 : -1800e3)) : null, adminId, new Date(pickup.getTime() - 2 * 864e5)]);
      const depHeld = ['COMPLETED', 'ACTIVE', 'OVERDUE'].includes(status) || (status === 'CONFIRMED' && paid !== 'none') ? dep : 0;
      const deduct = done ? Math.min(depHeld, late + damage) : 0;
      await c.query(`INSERT INTO deposits(booking_id,amount,held_amount,deducted_amount,returned_amount,status,deduction_reason,returned_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8)`,
        [id, dep, depHeld, deduct, done ? depHeld - deduct : 0, done ? (deduct === 0 ? 'RETURNED' : depHeld - deduct > 0 ? 'PARTIALLY_RETURNED' : 'FORFEITED') : depHeld ? 'HELD' : 'PENDING', deduct ? 'kechikish + zarar' : null, done ? ret : null]);
      const pay = async (kind, amount, when, method) => amount > 0 && c.query(`INSERT INTO payments(booking_id,customer_id,amount,kind,method,status,paid_at,created_by,provider) VALUES($1,$2,$3,$4,$5,'PAID',$6,$7,$8)`,
        [id, custIds[cust], amount, kind, method, when, adminId, kind === 'DEPOSIT_DEDUCTION' ? 'deposit' : null]);
      const m = id % 2 ? 'CASH' : 'CARD';
      if (done) await pay('RENTAL', total0, pickup, m); else await pay('RENTAL', paidNow, pickup, m);
      if (done && deduct) await pay('DEPOSIT_DEDUCTION', deduct, new Date(ret.getTime() + 3.5 * 3600e3), 'CASH');
      if (done && late + damage > deduct) await pay('EXTRA', late + damage - deduct, new Date(ret.getTime() + 3.5 * 3600e3), 'CASH');
      if (depHeld) await pay('DEPOSIT', depHeld, pickup, m);
      if (done && depHeld - deduct > 0) await pay('REFUND', depHeld - deduct, ret, 'CASH');
      if (real) {
        const start0 = km[carIds[car]]; const driven = days * (110 + (id * 13) % 90);
        await c.query(`INSERT INTO car_inspections(booking_id,car_id,stage,mileage,fuel_level,body_condition,interior_condition,damages,staff_id,inspected_at) VALUES($1,$2,'HANDOVER',$3,90,'Yaxshi, chizilishlarsiz','Toza',NULL,$4,$5)`, [id, carIds[car], start0, adminId, pickup]);
        if (done) {
          km[carIds[car]] = start0 + driven;
          await c.query(`INSERT INTO car_inspections(booking_id,car_id,stage,mileage,fuel_level,body_condition,interior_condition,damages,staff_id,inspected_at) VALUES($1,$2,'RETURN',$3,70,$4,'Toza',$5,$6,$7)`,
            [id, carIds[car], start0 + driven, damage ? "Old bamperda chizilish" : 'Yaxshi', damage ? "Old bamperda chizilish" : null, adminId, ret]);
        }
      }
      if (['CONFIRMED', 'ACTIVE', 'OVERDUE', 'COMPLETED'].includes(status)) await c.query(`INSERT INTO rental_contracts(booking_id,number) VALUES($1,$2)`, [id, `SH-${new Date().getFullYear()}-${String(id).padStart(5, '0')}`]);
      return id;
    };

    // 12 ta yakunlangan ijara (oxirgi 4 hafta)
    const done = [[0, -27, 3], [1, -26, 2], [2, -24, 4], [4, -22, 3], [5, -21, 5], [6, -19, 2], [7, -18, 3], [8, -15, 4], [9, -14, 7], [3, -12, 3], [0, -10, 2], [1, -8, 5]];
    const customersOrder = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 2];
    for (let i = 0; i < done.length; i++) {
      const [car, st, d] = done[i];
      await mk({ car, cust: customersOrder[i], start: st, days: d, status: 'COMPLETED', promo: i === 4 ? 10 : null, late: i === 3 ? 90000 : 0, damage: i === 7 ? 250000 : 0, loc: i % 2 ? 'Toshkent aeroporti' : 'Ofis (Toshkent)' });
    }
    await mk({ car: 2, cust: 3, start: -6, days: 3, status: 'COMPLETED' });
    await mk({ car: 4, cust: 7, start: -9, days: 2, status: 'COMPLETED' });
    // Faol ijaralar
    await mk({ car: 1, cust: 5, start: -2, days: 4, status: 'ACTIVE', paid: 'full' });
    const overdueNow = at(0, '18:00') < new Date();
    await mk({ car: 3, cust: 8, start: -1, startT: '09:00', days: 1, status: 'ACTIVE', paid: 'half' });   // bugun qaytadi
    await c.query(`UPDATE bookings SET return_at=$2,days=1 WHERE car_id=$1 AND status='ACTIVE' AND days=1`, [carIds[3], at(0, '18:00')]);
    if (overdueNow) await c.query(`UPDATE bookings SET status='OVERDUE' WHERE car_id=$1 AND status='ACTIVE' AND return_at<now()`, [carIds[3]]);
    await mk({ car: 6, cust: 1, start: -3, days: 5, status: 'ACTIVE', paid: 'full' });
    // Tasdiqlangan va kutilayotgan
    await mk({ car: 0, cust: 4, start: 0, startT: '15:00', days: 3, status: 'CONFIRMED', paid: 'half' });
    await mk({ car: 7, cust: 9, start: 1, startT: '10:00', days: 3, status: 'CONFIRMED', paid: 'full' });
    await mk({ car: 5, cust: 6, start: 3, days: 3, status: 'PENDING', paid: 'none' });
    await mk({ car: 8, cust: 2, start: 5, days: 7, status: 'PENDING', paid: 'none', promo: 7 });
    await mk({ car: 9, cust: 0, start: 2, days: 2, status: 'CANCELLED', paid: 'none' });
    for (const [i, id] of carIds.entries()) await c.query('UPDATE cars SET mileage=$2 WHERE id=$1', [id, km[id]]);
    await c.query(`UPDATE cars SET status='RENTED' WHERE id=ANY($1)`, [[carIds[1], carIds[3], carIds[6]]]);
    await c.query(`UPDATE cars SET status='MAINTENANCE' WHERE id=$1`, [carIds[9]]);
    await c.query(`INSERT INTO car_status_history(car_id,old_status,new_status,changed_by,note) VALUES($1,'AVAILABLE','MAINTENANCE',$2,'Demo: dvigatel tekshiruvi')`, [carIds[9], adminId]);

    // Xarajatlar
    const ex = [['FUEL', 0, -20, 120000], ['FUEL', 1, -17, 180000], ['WASH', 2, -16, 50000], ['WASH', 4, -13, 60000], ['TIRES', 5, -12, 1800000], ['REPAIR', 7, -11, 650000], ['FUEL', 6, -10, 200000],
      ['INSURANCE', 3, -9, 900000], ['ADS', null, -8, 500000], ['WASH', 8, -7, 50000], ['OIL', 0, -6, 350000], ['FUEL', 9, -5, 160000], ['REPAIR', 9, -4, 1200000], ['TAX', null, -3, 400000],
      ['WASH', 1, -2, 50000], ['FUEL', 3, -1, 130000], ['WASH', 5, 0, 50000], ['OTHER', null, 0, 100000], ['FUEL', 2, -23, 140000], ['WASH', 6, -22, 50000], ['OIL', 4, -25, 380000], ['ADS', null, -26, 450000]];
    for (const [k, car, d, amt] of ex) await c.query(`INSERT INTO expenses(car_id,category_id,amount,spent_on,note,created_by) VALUES($1,$2,$3,$4,$5,$6)`, [car == null ? null : carIds[car], cat[k], amt, addDays(T, d), 'Demo xarajat', adminId]);

    // Texnik xizmat
    for (const [i, id] of carIds.entries()) {
      const k = km[id];
      await c.query(`INSERT INTO maintenance(car_id,kind,done_at,mileage_at,next_due_km,cost,note,created_by) VALUES($1,'OIL',$2,$3,$4,$5,'Moy almashtirildi',$6)`,
        [id, addDays(T, -40 - i), Math.max(0, k - 4500 - i * 40), i === 0 ? k + 150 : k + 4800 - i * 60, 350000, adminId]);
    }
    await c.query(`INSERT INTO maintenance(car_id,kind,done_at,mileage_at,next_due_km,cost,note,created_by) VALUES($1,'REPAIR',$2,$3,NULL,1200000,'Dvigatel tekshiruvi va ta''mir',$4)`, [carIds[9], addDays(T, -4), km[carIds[9]], adminId]);
    await c.query(`INSERT INTO maintenance(car_id,kind,done_at,mileage_at,next_due_km,cost,note,created_by) VALUES($1,'TIRES',$2,$3,$4,1800000,'Yozgi shinalar',$5)`, [carIds[5], addDays(T, -12), km[carIds[5]], km[carIds[5]] + 40000, adminId]);
    await c.query(`INSERT INTO notifications(audience,type,title,body) VALUES('ADMIN','NEW_BOOKING','YANGI BUYURTMA','Mijoz: Jasur Ismoilov — Chevrolet Tracker (demo)')`);
  });
  await bookingsSvc.syncCarStatuses();
  console.log('Demo ma\'lumotlar tayyor: 10 mashina, 10 mijoz, 20 buyurtma.');
}

async function run() {
  const fs = require('fs'), path = require('path');
  await db.query(fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8'));
  await require('../src/services/econtract').ensureTemplate().catch(e => console.error("Elektron shartnoma shabloni o'rnatilmadi:", e.message));
  const first = await base();
  if (require('../src/config').seedDemo) {
    const adm = (await db.query(`SELECT id FROM users WHERE username='owner'`)).rows[0];
    await demo(adm?.id || null);
  }
  return first;
}
module.exports = { run };
if (require.main === module) run().then(() => process.exit(0)).catch(e => { console.error(e); process.exit(1); });
