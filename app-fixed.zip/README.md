# RENT A CAR — Cloud AI Mini App

Avtomobil ijarasi uchun to'liq tizim: **Admin panel (login/parol) + Telegram bot + Telegram Mini App + REST API + PostgreSQL**.
UI o'zbek tilida · so'm (butun son) · `DD.MM.YYYY` · 24 soatlik vaqt · `Asia/Tashkent`.

**Real mahsulotda hech narsa oldindan to'ldirilmagan**: mashinalar, tariflar, joylar, shartnoma, to'lov kartasi — hammasini admin o'zi kiritadi.

## Ishga tushirish

```bash
npm install
cp .env.example .env     # DATABASE_URL va maxfiy kalitlarni to'ldiring
npm start                # supervisor orqali: to'xtab qolsa o'zi qayta ko'tariladi
```
Birinchi ishga tushishda konsolda `owner` login va parol chiqadi → `http://localhost:3000/admin/`

Dashboardning yuqorisida **«Boshlash uchun sozlang»** ro'yxati chiqadi (shartnoma, birinchi mashina, bot, HTTPS, admin Telegram ID, kechikish tarifi).

## Admin panelda birinchi qadamlar

1. **Sozlamalar → Shartnoma** — tayyor shartnoma **PDF** faylini yuklang (yoki matn kiriting). Yuklanmaguncha mijozlar bron qila olmaydi.
2. **Moliya → To'lov joylari** — karta (yoki bank hisobi) qo'shing. Karta raqami Luhn bilan tekshiriladi.
3. **Mashinalar** — mashinalarni qo'shing. **Funksiyalar** — joylar, qo'shimcha xizmatlar, modullarni yoqish/o'chirish.
4. **Xodimlar** — xodim qo'shing va Telegram ID sini kiriting (yangi buyurtma xabarlari shunga keladi).

## Asosiy jarayon

1. Mijoz botdan yoki Mini App dan bron beradi → **shartnomani o'qib «roziman» deydi** (PDF ochilmaguncha rozilik belgisi yoqilmaydi). Rozilik vaqti, kanali, shartnoma versiyasi va xeshi saqlanadi.
2. Adminga Telegramda **YANGI BUYURTMA** keladi (✅ Tasdiqlash / ❌ Rad etish tugmalari). Admin panelda ham ko'rinadi.
3. Admin tasdiqlasa — **mijozga o'sha zahoti Telegramda xabar + shartnoma PDF** (kompaniya shartnomasi + buyurtma varag'i + rozilik tamg'asi, bitta hujjat) yuboriladi.
4. Mijoz karta rekvizitiga to'laydi → Mini App/botdan **chek rasmini** yuboradi → adminga xabar keladi → admin chekni ko'rib **tasdiqlaydi** → to'lov buyurtmaga yoziladi, mijozga xabar ketadi.
5. Mashina berishdan oldin **mijoz roziligi shart** (admin yaratgan buyurtmada mijozga Telegramda rozilik so'rovi ketadi yoki «qog'ozda imzolandi» deb xodim qayd etadi — audit logga yoziladi).

## Mijozlarga xabar (admin → bot orqali)

- **Admin panel → Xabarlar**: bitta mijozga alohida yozish yoki hammaga yuborish; hammasi tarixda saqlanadi.
- **Telegram botda (admin)**: `/xabar` — mijozni topib alohida yozish; `/hammaga` — ko'rib chiqib tasdiqlab, barcha mijozlarga yuborish.
- Mijoz botga yozsa, xabar adminlarga **«Javob berish»** tugmasi bilan yetadi.
- Faqat botni ishga tushirgan (Telegramga ulangan) mijozlarga yuborish mumkin — Telegram qoidasi.

## Doimiy ishlash

- `scripts/supervisor.js` serverni kuzatadi: jarayon o'lsa 1–30 soniyada qayta ko'taradi (sinalgan: `kill -9` dan 2 s da tiklandi).
- Baza hali ishga tushmagan bo'lsa server yiqilmaydi, 2 daqiqagacha kutadi. Bot suhbat holati bazada — qayta ishga tushsa yo'qolmaydi.
- `/healthz` baza va fon ishlarini tekshiradi; muammo bo'lsa 503 qaytaradi → Railway (`restartPolicyType: ALWAYS`) o'zi qayta ishga tushiradi.
- Fon ishlari (har daqiqa): kechikish, eslatmalar, mashina holati, ogohlantirishlar, zaxira nusxa.
- **Halol eslatma:** hech bir dastur 100% to'xtamaslikka kafolat bera olmaydi (hosting/internet uzilishi bo'lishi mumkin). Shuning uchun `/healthz` ga **UptimeRobot** (bepul) kabi monitoring qo'ying — uzilsa Telegramga xabar keladi. Railway'da **Volume** ni `/app/uploads` va `/app/backups` ga ulang.

## Railway'ga deploy

1. Loyiha → **PostgreSQL** qo'shing. 2. Kodni GitHub orqali servis sifatida ulang (Dockerfile avtomatik). 3. Variables: `DATABASE_URL`, `JWT_SECRET`, `DATA_ENC_KEY`, `ADMIN_PASSWORD`, `BOT_TOKEN`, `PUBLIC_URL`, `NODE_ENV=production`. 4. Volume: `/app/uploads`, `/app/backups`. 5. Domen (HTTPS) → `PUBLIC_URL`. Webhook va Mini App tugmasi avtomatik o'rnatiladi.

## Funksiyalar markazi

Admin panel → **Funksiyalar**: modullarni yoqish/o'chirish (promo, referral, qo'shimcha xizmatlar, xabarlar, AI, to'lov so'rovlari), olib ketish joylari va xizmatlarni boshqarish, hamda **maxsus maydonlar** — mijoz yoki mashina kartasiga o'zingiz kerakli maydon qo'shasiz (matn/son/sana/tanlov, majburiy yoki yo'q).

## Eksport
Mijozlar, buyurtmalar, to'lovlar — CSV (Excel'da ochiladi); hisobotlar — CSV va PDF.

## Tekshiruv
```bash
# alohida terminalda: node scripts/fake-telegram.js   (haqiqiy Telegramga hech narsa ketmaydi)
SEED_DEMO=true BOT_TOKEN=1:T TELEGRAM_API=http://localhost:4010 ADMIN_CHAT_IDS=555 ALLOW_DEV_AUTH=true ADMIN_PASSWORD=... npm run start:direct
ADMIN_PASSWORD=... npm test        # end-to-end: 202 tekshiruv
ADMIN_PASSWORD=... npm run test:ui # interfeys: 47 tekshiruv
```

## Xavfsizlik
bcrypt + blok (5 xato → 15 daqiqa) · rollar (OWNER/ADMIN/MANAGER/ACCOUNTANT) · zod validatsiya · parametrli SQL · CSP/XSS escape · CSRF (SameSite + header) · rate limit · passport AES-256-GCM bilan shifrlangan · rasm/PDF "magic bytes" tekshiruvi · webhook secret-token · Mini App initData HMAC · audit log (shu jumladan shartnoma, karta, rozilik, xabar amallari).

## Hali ulanmagan (halol)
- **Payme/Click avtomatik to'lov**: karta-karta o'tkazma bank tomonidan avtomatik tasdiqlanmaydi — shu sababli chek + admin tasdig'i ishlatiladi. Avtomatik tasdiq uchun Payme/Click merchant kaliti kerak (`services/paymentProviders.js` tayyor).
- AI yordamchi LLM emas: savol turini taniydi va faqat bazadan javob beradi.

## Tezkor shartnoma va oddiy mashina qo'shish
- **Admin panel → «Shartnoma»** tugmasi: faqat **pasport** va **necha soat**ga ekanini yozasiz, mashinani tanlaysiz → buyurtma yaratiladi, tasdiqlanadi, rozilik qayd etiladi va mashina topshiriladi. Mijoz pasport bo'yicha topiladi yoki yangi yaratiladi (ism/telefon ixtiyoriy).
- **Mashina qo'shish**: faqat **nomi** majburiy («Chevrolet Malibu»). Soatlik/kunlik narx, raqam va boshqalar ixtiyoriy («Qo'shimcha»).
- Soatlik narx kiritilmasa, kunlik narx / 24 olinadi (kunlik narxdan oshmaydi).

## Elektron shartnoma (OTP, PDF shablon, dalolatnomalar)
Batafsil: [docs/ELEKTRON_SHARTNOMA.md](docs/ELEKTRON_SHARTNOMA.md)

## Ro'yxatdan o'tish va shartnomaga rozilik (Mini App)

Mijoz botdan Mini App'ni birinchi marta ochganda **majburiy ro'yxatdan o'tish** ekrani chiqadi:
ism, familiya, telefon raqam va **shartnoma shartlariga rozilik** (faol shartnoma matni ko'rsatiladi).
Rozilik berilmaguncha Mini App API (`403 REGISTER_REQUIRED`) va botdagi bron/to'lov tugmalari yopiq.

- Rozilik `registration_consents` jadvaliga yoziladi: sana-vaqt, ism, telefon, shartnoma versiyasi, kanal, IP.
- Admin panel → **Mijozlar**: «Shartnoma roziligi» ustuni (✅ sana / ❌ yo'q); mijoz kartasida rozilik tarixi.
- Adminga Telegram/panel bildirishnomasi: «Yangi mijoz ro'yxatdan o'tdi va shartnomaga rozilik berdi».
- Eski mijozlar ham bir marta ro'yxatdan o'tadi (ma'lumotlari oldindan to'ldirilgan holda).
