const express = require('express');
const fs = require('fs');
const path = require('path');
const { z } = require('zod');
const db = require('../db');
const { requirePerm, hash } = require('../auth');
const { audit } = require('../audit');
const { AppError, wrap, encrypt, decrypt, parseTkt, todayStr, addDays, fmtDate, fmtDT, money } = require('../util');
const bookings = require('../services/bookings');
const reports = require('../services/reports');
const contract = require('../services/contract');
const settings = require('../services/settings');
const backup = require('../services/backup');
const assistant = require('../services/assistant');
const messages = require('../services/messages');
const features = require('../services/features');
const contacts = require('../services/contacts');
const payacc = require('../services/payacc');
const tgSvc = require('../services/notify');
const cfg = require('../config');
const { adminChatIds } = require('../services/notify');
const providers = require('../services/paymentProviders');
const { ROLES, can } = require('../permissions');
const up = require('../upload');
const gpsSvc = require('../services/gps');
const finesSvc = require('../services/fines');
const econtract = require('../services/econtract');

const r = express.Router();
const P = requirePerm;
const parse = (schema, data) => {
  const x = schema.safeParse(data);
  if (!x.success) {
    const i = x.error.issues[0];
    throw new AppError(400, `Noto'g'ri maydon: ${i.path.join('.') || 'so\'rov'} — ${i.message}`, 'VALIDATION');
  }
  return x.data;
};
const num = z.coerce.number().int().min(0);
const idp = z.coerce.number().int().positive();
const str = (max = 200) => z.string().trim().max(max);
const opt = s => s.optional().nullable().transform(v => (v === '' ? null : v));
const page = req => ({ limit: Math.min(200, parseInt(req.query.limit) || 100), offset: Math.max(0, parseInt(req.query.offset) || 0) });
const maskId = v => { const s = decrypt(v); return s ? (s.length > 4 ? s.slice(0, 2) + ' ••••' + s.slice(-3) : '••••') : null; };

// ---------- DASHBOARD ----------
r.get('/dashboard', wrap(async (req, res) => {
  const d = await reports.dashboard();
  const S = await settings.all();
  d.setup = [
    { key: 'contract', ok: !!(await contract.getActive()), text: "Ijara shartnomasi matnini kiriting — usiz mijozlar bron qila olmaydi", link: '#/settings' },
    { key: 'cars', ok: d.cars.total > 0, text: "Birinchi mashinani qo'shing", link: '#/cars' },
    { key: 'bot', ok: !!cfg.botToken, text: 'Telegram bot ulanmagan (BOT_TOKEN kiritilmagan)' },
    { key: 'https', ok: cfg.publicUrl.startsWith('https://'), text: 'Mini App uchun HTTPS manzil (PUBLIC_URL) kiritilmagan' },
    { key: 'admin_tg', ok: (await adminChatIds()).length > 0, text: "Hech bir adminning Telegram ID si kiritilmagan — yangi buyurtma xabarlari kelmaydi", link: '#/staff' },
    { key: 'late', ok: Number(S.late_fee_per_hour) > 0, text: "Kechikish tarifi belgilanmagan (hozir kechikish haqi olinmaydi)", link: '#/settings' },
  ].filter(x => !x.ok);
  if (!can(req.user, 'finance.read')) {
    d.today = { ...d.today, revenue: null, expenses: null, profit: null, expected_income: null, deposits_to_return: null };
    d.month = { revenue: null, expenses: null, profit: null };
    d.charts = { utilization: d.charts.utilization, utilization_avg: d.charts.utilization_avg, daily: [], monthly: [], revenue_per_car: [], expense_categories: [] };
    d.schedule = d.schedule.map(s => ({ ...s, remaining: null }));
  }
  res.json(d);
}));

// ---------- SEARCH ----------
r.get('/search', wrap(async (req, res) => {
  const q = String(req.query.q || '').trim();
  if (q.length < 2) return res.json({ cars: [], customers: [], bookings: [] });
  const like = `%${q.replace(/[%_]/g, '')}%`;
  const [cars, customers, bks] = await Promise.all([
    db.query(`SELECT id,brand,model,plate,status FROM cars WHERE deleted_at IS NULL AND (brand||' '||model ILIKE $1 OR plate ILIKE $1 OR vin ILIKE $1) LIMIT 8`, [like]),
    db.query(`SELECT id,first_name,last_name,phone FROM customers WHERE deleted_at IS NULL AND (first_name||' '||last_name ILIKE $1 OR phone ILIKE $1) LIMIT 8`, [like]),
    db.query(`SELECT b.id,b.code,b.status,c.first_name||' '||c.last_name customer,car.brand||' '||car.model car FROM bookings b JOIN customers c ON c.id=b.customer_id JOIN cars car ON car.id=b.car_id
      WHERE b.deleted_at IS NULL AND (b.code ILIKE $1 OR c.phone ILIKE $1 OR car.plate ILIKE $1) ORDER BY b.id DESC LIMIT 8`, [like]),
  ]);
  res.json({ cars: cars.rows, customers: customers.rows, bookings: bks.rows });
}));

// ---------- UPLOAD ----------
r.post('/upload', P('cars.write', 'handover', 'customers.write'), up.mem.single('file'), wrap(async (req, res) => {
  res.json(up.save(req.file, 'public'));
}));

// ---------- CARS ----------
const carSchema = z.object({
  brand: opt(str(60)), model: opt(str(60)), plate: opt(str(20)), vin: opt(str(30)), year: opt(z.coerce.number().int().min(1990).max(2100)),
  color: opt(str(30)), transmission: z.enum(['AUTOMATIC', 'MANUAL']).default('AUTOMATIC'), fuel_type: z.enum(['PETROL', 'GAS', 'DIESEL', 'HYBRID', 'ELECTRIC']).default('PETROL'),
  seats: z.coerce.number().int().min(1).max(20).default(5), price_day: num.default(0), price_3d: num.default(0), price_7d: num.default(0), price_hour: num.default(0), deposit: num.default(0),
  mileage: num.default(0), fuel_level: z.coerce.number().int().min(0).max(100).default(100), image_url: opt(str(300)), body_type: opt(str(40)), description: opt(str(1000)),
  tech_passport: opt(str(30)), car_value: num.default(0), insurance_until: opt(str(10)), inspection_until: opt(str(10)), custom: z.record(z.string(), z.any()).optional(),
});
r.get('/cars', P('cars.read'), wrap(async (req, res) => {
  const w = ['c.deleted_at IS NULL']; const p = [];
  if (req.query.status) { p.push(req.query.status); w.push(`c.status=$${p.length}`); }
  if (req.query.q) { p.push(`%${req.query.q}%`); w.push(`(c.brand||' '||c.model ILIKE $${p.length} OR c.plate ILIKE $${p.length})`); }
  const { rows } = await db.query(`SELECT c.*, (SELECT json_build_object('customer',cu.first_name||' '||cu.last_name,'return_at',b.return_at)
      FROM bookings b JOIN customers cu ON cu.id=b.customer_id WHERE b.car_id=c.id AND b.status IN ('ACTIVE','OVERDUE') AND b.deleted_at IS NULL LIMIT 1) holder
    FROM cars c WHERE ${w.join(' AND ')} ORDER BY c.brand,c.model`, p);
  res.json(rows);
}));
// «Chevrolet Malibu» → brand=Chevrolet, model=Malibu (formada faqat bitta «Nomi» maydoni)
const splitCarName = body => {
  const b = { ...(body || {}) };
  if (typeof b.name === 'string') { const t = b.name.trim().replace(/\s+/g, ' '); const i = t.indexOf(' '); b.brand = i < 0 ? t : t.slice(0, i); b.model = i < 0 ? '' : t.slice(i + 1); }
  delete b.name; return b;
};
r.post('/cars', P('cars.write'), wrap(async (req, res) => {
  const d = parse(carSchema, splitCarName(req.body));
  d.brand = d.brand || ''; d.model = d.model || ''; d.plate = d.plate || '';
  if (!d.brand && !d.model) throw new AppError(400, 'Mashina nomini kiriting');
  const custom = await features.cleanCustom('car', d.custom); delete d.custom;
  try {
    const { rows } = await db.query(`INSERT INTO cars(brand,model,plate,vin,year,color,transmission,fuel_type,seats,price_day,price_3d,price_7d,price_hour,deposit,mileage,fuel_level,image_url,insurance_until,inspection_until,body_type,description,tech_passport,car_value)
      VALUES($1,$2,upper($3),$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23) RETURNING *`,
      [d.brand, d.model, d.plate, d.vin, d.year, d.color, d.transmission, d.fuel_type, d.seats, d.price_day, d.price_3d, d.price_7d, d.price_hour, d.deposit, d.mileage, d.fuel_level, d.image_url, d.insurance_until, d.inspection_until, d.body_type, d.description, d.tech_passport, d.car_value]);
    if (Object.keys(custom).length) await db.query('UPDATE cars SET custom=$2 WHERE id=$1', [rows[0].id, JSON.stringify(custom)]);
    await audit(req.user, 'CREATE', 'car', rows[0].id, null, d, req);
    res.status(201).json(rows[0]);
  } catch (e) { if (e.code === '23505') throw new AppError(409, 'Bu davlat raqami yoki VIN allaqachon mavjud'); throw e; }
}));
r.get('/cars/:id', P('cars.read'), wrap(async (req, res) => {
  const { rows } = await db.query('SELECT * FROM cars WHERE id=$1 AND deleted_at IS NULL', [req.params.id]);
  if (!rows[0]) throw new AppError(404, 'Mashina topilmadi');
  const stats = await reports.carStats(rows[0].id);
  if (!can(req.user, 'finance.read')) { stats.revenue = stats.expenses = stats.profit = null; }
  const images = (await db.query('SELECT id,url FROM car_images WHERE car_id=$1 ORDER BY sort_order,id', [rows[0].id])).rows;
  const history = (await db.query(`SELECT h.*,u.full_name FROM car_status_history h LEFT JOIN users u ON u.id=h.changed_by WHERE car_id=$1 ORDER BY h.id DESC LIMIT 15`, [rows[0].id])).rows;
  res.json({ ...rows[0], stats, images, status_history: history });
}));
r.patch('/cars/:id', P('cars.write'), wrap(async (req, res) => {
  const old = (await db.query('SELECT * FROM cars WHERE id=$1 AND deleted_at IS NULL', [req.params.id])).rows[0];
  if (!old) throw new AppError(404, 'Mashina topilmadi');
  const inb = splitCarName(req.body);
  const d = parse(carSchema.partial(), Object.fromEntries(Object.entries(inb).filter(([k]) => k in carSchema.shape)));
  for (const k of Object.keys(d)) if (!(k in inb)) delete d[k];
  for (const k of ['brand', 'model', 'plate']) if (k in d && d[k] == null) d[k] = '';   // default qiymatlar PATCH da qo'llanmaydi
  delete d.status;
  const customIn = d.custom; delete d.custom;
  const keys = Object.keys(d); if (!keys.length && customIn === undefined) throw new AppError(400, "O'zgartirish uchun maydon yo'q");
  if (customIn !== undefined) { const merged = await features.cleanCustom('car', customIn, old.custom || {}, { partial: true }); await db.query('UPDATE cars SET custom=$2 WHERE id=$1', [req.params.id, JSON.stringify(merged)]); }
  if (!keys.length) return res.json((await db.query('SELECT * FROM cars WHERE id=$1', [req.params.id])).rows[0]);
  const sets = keys.map((k, i) => `${k}=${k === 'plate' ? `upper($${i + 2})` : `$${i + 2}`}`);
  try {
    const { rows } = await db.query(`UPDATE cars SET ${sets.join(',')} WHERE id=$1 RETURNING *`, [req.params.id, ...keys.map(k => d[k])]);
    await audit(req.user, 'UPDATE', 'car', req.params.id, Object.fromEntries(keys.map(k => [k, old[k]])), d, req);
    res.json(rows[0]);
  } catch (e) { if (e.code === '23505') throw new AppError(409, 'Bu davlat raqami yoki VIN allaqachon mavjud'); throw e; }
}));
r.post('/cars/:id/status', P('cars.write'), wrap(async (req, res) => {
  const { status, note } = parse(z.object({ status: z.enum(['AVAILABLE', 'MAINTENANCE', 'INACTIVE']), note: opt(str(200)) }), req.body);
  await db.tx(async c => {
    const car = (await c.query('SELECT status FROM cars WHERE id=$1 AND deleted_at IS NULL FOR UPDATE', [req.params.id])).rows[0];
    if (!car) throw new AppError(404, 'Mashina topilmadi');
    if (['RENTED', 'RESERVED'].includes(car.status) && status !== 'AVAILABLE') throw new AppError(409, "Ijarada/bronda turgan mashina holatini qo'lda o'zgartirib bo'lmaydi");
    if (car.status === 'RENTED') throw new AppError(409, 'Mashina ijarada — avval qaytarib oling');
    await bookings.setCarStatus(c, req.params.id, status, req.user, note);
  });
  res.json({ ok: true });
}));
r.delete('/cars/:id', P('cars.write'), wrap(async (req, res) => {
  const act = await db.query(`SELECT 1 FROM bookings WHERE car_id=$1 AND status IN ('PENDING','CONFIRMED','ACTIVE','OVERDUE') AND deleted_at IS NULL LIMIT 1`, [req.params.id]);
  if (act.rows[0]) throw new AppError(409, "Mashinada faol buyurtmalar bor — o'chirib bo'lmaydi");
  const { rows } = await db.query(`UPDATE cars SET deleted_at=now(), status='INACTIVE', plate=plate||'#del'||id, vin=NULL WHERE id=$1 AND deleted_at IS NULL RETURNING id,brand,model`, [req.params.id]);
  if (!rows[0]) throw new AppError(404, 'Mashina topilmadi');
  await audit(req.user, 'DELETE', 'car', req.params.id, rows[0], null, req);
  res.json({ ok: true });
}));
r.post('/cars/:id/images', P('cars.write'), wrap(async (req, res) => {
  const { url } = parse(z.object({ url: str(300).regex(/^\/uploads\/public\/[a-f0-9]{32}\.(jpg|png|webp)$/, "Rasm manzili noto'g'ri") }), req.body);
  const { rows } = await db.query('INSERT INTO car_images(car_id,url) VALUES($1,$2) RETURNING *', [req.params.id, url]);
  res.status(201).json(rows[0]);
}));
r.delete('/cars/:id/images/:imgId', P('cars.write'), wrap(async (req, res) => {
  await db.query('DELETE FROM car_images WHERE id=$1 AND car_id=$2', [req.params.imgId, req.params.id]); res.json({ ok: true });
}));
// Mashina kalendari: har bir kun uchun holat
r.get('/cars/:id/calendar', P('cars.read'), wrap(async (req, res) => {
  const month = /^\d{4}-\d{2}$/.test(req.query.month || '') ? req.query.month : todayStr().slice(0, 7);
  const first = `${month}-01`;
  const dt = new Date(first + 'T00:00:00Z'); dt.setUTCMonth(dt.getUTCMonth() + 1);
  const next = dt.toISOString().slice(0, 10);
  const days = Math.round((dt - new Date(first + 'T00:00:00Z')) / 864e5);
  const car = (await db.query('SELECT status FROM cars WHERE id=$1', [req.params.id])).rows[0];
  if (!car) throw new AppError(404, 'Mashina topilmadi');
  const bks = (await db.query(`SELECT b.id,b.code,b.status,b.pickup_at,b.return_at,c.first_name||' '||c.last_name customer FROM bookings b JOIN customers c ON c.id=b.customer_id
    WHERE b.car_id=$1 AND b.deleted_at IS NULL AND b.status IN ('PENDING','CONFIRMED','ACTIVE','OVERDUE') AND b.pickup_at<$3 AND b.return_at>$2`,
  [req.params.id, parseTkt(first), parseTkt(next)])).rows;
  const maint = (await db.query(`SELECT done_at FROM maintenance WHERE car_id=$1 AND kind IN ('REPAIR') AND done_at>=$2 AND done_at<$3`, [req.params.id, first, next])).rows.map(m => new Date(m.done_at).toISOString().slice(0, 10));
  const out = [];
  for (let i = 0; i < days; i++) {
    const day = addDays(first, i);
    const s = parseTkt(day).getTime(), e = s + 864e5;
    const hit = bks.find(b => new Date(b.pickup_at).getTime() < e && new Date(b.return_at).getTime() > s);
    let status = 'FREE';
    if (hit) status = ['ACTIVE', 'OVERDUE'].includes(hit.status) ? 'RENTED' : 'RESERVED';
    else if (maint.includes(day)) status = 'MAINTENANCE';
    out.push({ date: day, status, booking: hit ? { id: hit.id, code: hit.code, customer: hit.customer } : null });
  }
  res.json({ month, days: out });
}));

// ---------- CUSTOMERS ----------
const custSchema = z.object({
  first_name: str(60).min(1), last_name: str(60).min(1), phone: str(25).regex(/^\+?[0-9 ()-]{7,20}$/, "Telefon raqami noto'g'ri"),
  telegram_id: opt(z.coerce.number().int().positive()), passport: opt(str(30)), license: opt(str(30)), address: opt(str(250)), custom: z.record(z.string(), z.any()).optional(),
});
const normPhone = p => { const d = String(p).replace(/\D/g, ''); return d.length === 9 ? '+998' + d : '+' + d; };
r.get('/customers', P('customers.read'), wrap(async (req, res) => {
  const p = []; let w = 'c.deleted_at IS NULL';
  if (req.query.q) { p.push(`%${req.query.q}%`); w += ` AND (c.first_name||' '||c.last_name ILIKE $1 OR c.phone ILIKE $1)`; }
  const { rows } = await db.query(`SELECT c.id,c.first_name,c.last_name,c.phone,c.telegram_id,c.tg_username,c.created_at,(c.telegram_id IS NOT NULL) has_telegram,c.late_count,c.damage_total,c.is_blocked,c.bonus_balance,c.registered_at,
      (SELECT rc.accepted_at FROM registration_consents rc WHERE rc.customer_id=c.id ORDER BY rc.id DESC LIMIT 1) terms_accepted_at,
      (SELECT COUNT(*)::int FROM bookings b WHERE b.customer_id=c.id AND b.status IN ('ACTIVE','COMPLETED','OVERDUE') AND b.deleted_at IS NULL) rentals,
      (SELECT COALESCE(SUM(b.paid_amount),0)::bigint FROM bookings b WHERE b.customer_id=c.id AND b.deleted_at IS NULL) total_paid
    FROM customers c WHERE ${w} ORDER BY c.id DESC LIMIT ${page(req).limit} OFFSET ${page(req).offset}`, p);
  res.json(rows);
}));
r.post('/customers', P('customers.write'), wrap(async (req, res) => {
  const d = parse(custSchema, req.body);
  const custom = await features.cleanCustom('customer', d.custom);
  const code = 'C' + Math.random().toString(36).slice(2, 8).toUpperCase();
  const { rows } = await db.query(`INSERT INTO customers(first_name,last_name,phone,telegram_id,passport_enc,license_enc,passport_last4,referral_code,address)
    VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id,first_name,last_name,phone`,
  [d.first_name, d.last_name, normPhone(d.phone), d.telegram_id, encrypt(d.passport), encrypt(d.license), d.passport ? d.passport.slice(-3) : null, code, d.address || null]).catch(e => {
    if (e.code === '23505') throw new AppError(409, 'Bu Telegram ID bilan mijoz allaqachon mavjud'); throw e;
  });
  if (Object.keys(custom).length) await db.query('UPDATE customers SET custom=$2 WHERE id=$1', [rows[0].id, JSON.stringify(custom)]);
  await audit(req.user, 'CREATE', 'customer', rows[0].id, null, { name: d.first_name + ' ' + d.last_name }, req);
  res.status(201).json(rows[0]);
}));
r.get('/customers/:id', P('customers.read'), wrap(async (req, res) => {
  const c = (await db.query('SELECT * FROM customers WHERE id=$1 AND deleted_at IS NULL', [req.params.id])).rows[0];
  if (!c) throw new AppError(404, 'Mijoz topilmadi');
  const hist = (await db.query(`SELECT b.id,b.code,b.status,b.pickup_at,b.return_at,b.total_amount,b.paid_amount,b.deposit_amount,b.late_fee,b.damage_fee,car.brand||' '||car.model car,car.plate
    FROM bookings b JOIN cars car ON car.id=b.car_id WHERE b.customer_id=$1 AND b.deleted_at IS NULL ORDER BY b.pickup_at DESC`, [c.id])).rows;
  const docs = (await db.query('SELECT id,doc_type,expires_at,created_at FROM customer_documents WHERE customer_id=$1 AND deleted_at IS NULL', [c.id])).rows;
  const deps = (await db.query(`SELECT COALESCE(SUM(d.held_amount-d.returned_amount-d.deducted_amount),0)::bigint v FROM deposits d JOIN bookings b ON b.id=d.booking_id WHERE b.customer_id=$1 AND b.status IN ('ACTIVE','OVERDUE','CONFIRMED')`, [c.id])).rows[0];
  const ref = (await db.query('SELECT COUNT(*)::int n FROM referrals WHERE referrer_id=$1', [c.id])).rows[0].n;
  const done = hist.filter(h => ['COMPLETED', 'ACTIVE', 'OVERDUE'].includes(h.status));
  const consents = (await db.query(`SELECT rc.id,rc.full_name,rc.phone,rc.channel,rc.ip,rc.accepted_at,t.version,t.version_label,t.title FROM registration_consents rc LEFT JOIN contract_templates t ON t.id=rc.template_id WHERE rc.customer_id=$1 ORDER BY rc.id DESC LIMIT 20`, [c.id])).rows;
  res.json({ registered_at: c.registered_at, consents, id: c.id, tg_username: c.tg_username, custom: c.custom || {}, first_name: c.first_name, last_name: c.last_name, phone: c.phone, telegram_id: c.telegram_id, is_blocked: c.is_blocked,
    passport_masked: maskId(c.passport_enc), license_masked: maskId(c.license_enc), address: c.address, referral_code: c.referral_code, bonus_balance: c.bonus_balance, referrals: ref,
    late_count: c.late_count, damage_total: c.damage_total, rentals: done.length, total_paid: hist.reduce((s, h) => s + Number(h.paid_amount), 0), deposit_held: Number(deps.v),
    documents: docs, history: hist });
}));
r.get('/customers/:id/pii', P('customers.pii'), wrap(async (req, res) => {
  const c = (await db.query('SELECT passport_enc,license_enc FROM customers WHERE id=$1', [req.params.id])).rows[0];
  if (!c) throw new AppError(404, 'Mijoz topilmadi');
  await audit(req.user, 'VIEW_PII', 'customer', req.params.id, null, null, req);   // shaxsiy ma'lumot ochilishi qayd etiladi
  res.json({ passport: decrypt(c.passport_enc), license: decrypt(c.license_enc) });
}));
r.patch('/customers/:id', P('customers.write'), wrap(async (req, res) => {
  const d = parse(custSchema.partial().extend({ is_blocked: z.boolean().optional() }), req.body);
  const old = (await db.query('SELECT first_name,last_name,phone,is_blocked,custom FROM customers WHERE id=$1 AND deleted_at IS NULL', [req.params.id])).rows[0];
  if (!old) throw new AppError(404, 'Mijoz topilmadi');
  if (d.custom !== undefined) { const merged = await features.cleanCustom('customer', d.custom, old.custom || {}, { partial: true }); await db.query('UPDATE customers SET custom=$2 WHERE id=$1', [req.params.id, JSON.stringify(merged)]); }
  const m = { first_name: d.first_name, last_name: d.last_name, phone: d.phone && normPhone(d.phone), telegram_id: d.telegram_id, is_blocked: d.is_blocked,
    passport_enc: d.passport ? encrypt(d.passport) : undefined, passport_last4: d.passport ? d.passport.slice(-3) : undefined, license_enc: d.license ? encrypt(d.license) : undefined, address: d.address };
  const keys = Object.keys(m).filter(k => m[k] !== undefined);
  if (!keys.length && d.custom === undefined) throw new AppError(400, "O'zgartirish uchun maydon yo'q");
  if (keys.length) await db.query(`UPDATE customers SET ${keys.map((k, i) => `${k}=$${i + 2}`).join(',')} WHERE id=$1`, [req.params.id, ...keys.map(k => m[k])]);
  await audit(req.user, 'UPDATE', 'customer', req.params.id, old, { ...d, passport: d.passport ? '***' : undefined, license: d.license ? '***' : undefined }, req);
  res.json({ ok: true });
}));
r.post('/customers/:id/documents', P('customers.write'), up.mem.single('file'), wrap(async (req, res) => {
  const doc_type = ['PASSPORT', 'LICENSE', 'OTHER'].includes(req.body.doc_type) ? req.body.doc_type : 'OTHER';
  const f = up.save(req.file, 'private');
  const { rows } = await db.query('INSERT INTO customer_documents(customer_id,doc_type,file_path,expires_at) VALUES($1,$2,$3,$4) RETURNING id,doc_type', [req.params.id, doc_type, f.name, req.body.expires_at || null]);
  await audit(req.user, 'UPLOAD_DOC', 'customer', req.params.id, null, { doc_type }, req);
  res.status(201).json(rows[0]);
}));
r.get('/customers/documents/:docId/file', P('customers.pii'), wrap(async (req, res) => {
  const d = (await db.query('SELECT * FROM customer_documents WHERE id=$1 AND deleted_at IS NULL', [req.params.docId])).rows[0];
  if (!d) throw new AppError(404, 'Hujjat topilmadi');
  await audit(req.user, 'VIEW_DOC', 'customer', d.customer_id, null, { doc: d.id }, req);
  res.setHeader('Cache-Control', 'no-store'); res.sendFile(up.privatePath(d.file_path));
}));

// ---------- BOOKINGS ----------
const bookingSchema = z.object({
  customer_id: idp, car_id: idp, pickup_date: str(10), pickup_time: str(5), return_date: str(10), return_time: str(5),
  location: opt(str(120)), promo_code: opt(str(40)), notes: opt(str(500)),
  extras: z.array(z.object({ name: str(80), qty: z.coerce.number().int().min(1).max(20).default(1), unit_price: z.coerce.number().int().min(0).optional() })).max(10).optional(),
});
r.post('/bookings/quote', P('bookings.read'), wrap(async (req, res) => {
  const d = parse(bookingSchema.pick({ car_id: true, pickup_date: true, pickup_time: true, return_date: true, return_time: true, promo_code: true, extras: true }), req.body);
  const car = (await db.query('SELECT * FROM cars WHERE id=$1 AND deleted_at IS NULL', [d.car_id])).rows[0];
  if (!car) throw new AppError(404, 'Mashina topilmadi');
  const q = await db.tx(c => bookings.quote(c, { car, pickup: parseTkt(d.pickup_date, d.pickup_time), ret: parseTkt(d.return_date, d.return_time), promo_code: d.promo_code, extras: d.extras, trusted: true }));
  delete q.promo; res.json(q);
}));
const quickSchema = z.object({ car_id: idp, hours: z.coerce.number().int().min(1, 'Soat kamida 1').max(2160, 'Soat juda katta'), passport: str(30).min(6, 'Pasport raqamini kiriting'),
  name: opt(str(100)), phone: opt(str(25)), amount: opt(num) });
r.post('/quick-contract/quote', P('bookings.read'), wrap(async (req, res) => {
  const d = parse(quickSchema.pick({ car_id: true, hours: true, amount: true }), req.body); res.json(await bookings.quickQuote(d));
}));
r.post('/quick-contract', P('bookings.write'), wrap(async (req, res) => {
  const d = parse(quickSchema, req.body); res.status(201).json(await bookings.quickContract(d, req.user, req, can(req.user, 'handover')));
}));
r.get('/bookings', P('bookings.read'), wrap(async (req, res) => {
  const w = ['b.deleted_at IS NULL']; const p = [];
  const add = (cond, v) => { p.push(v); w.push(cond.replace('?', '$' + p.length)); };
  if (req.query.status) add('b.status=?', req.query.status);
  if (req.query.car_id) add('b.car_id=?', +req.query.car_id);
  if (req.query.customer_id) add('b.customer_id=?', +req.query.customer_id);
  if (req.query.from) add('b.return_at>=?', parseTkt(req.query.from));
  if (req.query.to) add('b.pickup_at<?', parseTkt(addDays(req.query.to, 1)));
  if (req.query.pay === 'paid') w.push('b.paid_amount>=b.total_amount');
  if (req.query.pay === 'unpaid') w.push('b.paid_amount=0');
  if (req.query.pay === 'partial') w.push('b.paid_amount>0 AND b.paid_amount<b.total_amount');
  if (req.query.q) add(`(b.code ILIKE ? OR c.phone ILIKE ? OR c.first_name||' '||c.last_name ILIKE ? OR car.plate ILIKE ? OR car.brand||' '||car.model ILIKE ?)`.replace(/\?/g, () => '$' + (p.length + 1)), `%${req.query.q}%`);
  const { rows } = await db.query(`SELECT b.id,b.code,b.status,b.pickup_at,b.return_at,b.days,b.total_amount,b.paid_amount,b.deposit_amount,b.source,
      c.id customer_id,c.first_name||' '||c.last_name customer,c.phone,car.id car_id,car.brand||' '||car.model car,car.plate,(b.total_amount-b.paid_amount) remaining
    FROM bookings b JOIN customers c ON c.id=b.customer_id JOIN cars car ON car.id=b.car_id WHERE ${w.join(' AND ')} ORDER BY b.id DESC LIMIT ${page(req).limit} OFFSET ${page(req).offset}`, p);
  res.json(rows);
}));
r.post('/bookings', P('bookings.write'), wrap(async (req, res) => {
  const d = parse(bookingSchema, req.body);
  const b = await bookings.createBooking({ customer_id: d.customer_id, car_id: d.car_id, pickup_at: parseTkt(d.pickup_date, d.pickup_time), return_at: parseTkt(d.return_date, d.return_time),
    location: d.location, promo_code: d.promo_code, extras: d.extras, notes: d.notes, source: 'ADMIN' }, req.user, req);
  res.status(201).json(b);
}));
r.get('/bookings/:id', P('bookings.read'), wrap(async (req, res) => {
  const b = await bookings.getBooking(req.params.id);
  if (['ACTIVE', 'OVERDUE'].includes(b.status)) b.late_info = await bookings.lateInfo(b);
  if (!can(req.user, 'payments.write') && !can(req.user, 'finance.read')) b.payments = [];
  res.json(b);
}));
r.post('/bookings/:id/confirm', P('bookings.write'), wrap(async (req, res) => res.json(await bookings.confirmBooking(+req.params.id, req.user, req))));
r.post('/bookings/:id/cancel', P('bookings.write'), wrap(async (req, res) => {
  const d = parse(z.object({ reason: opt(str(200)), refund_method: z.enum(['CASH', 'CARD', 'BANK_TRANSFER', 'ONLINE']).default('CASH'), refund_paid: z.boolean().default(false) }), req.body || {});
  res.json(await bookings.cancelBooking(+req.params.id, req.user, req, { ...d, reason: d.reason || '' }));
}));
const inspSchema = z.object({ mileage: z.coerce.number().int().min(0).optional(), fuel_level: z.coerce.number().int().min(0).max(100).optional(), body_condition: opt(str(300)),
  interior_condition: opt(str(300)), damages: opt(str(1000)), photos: z.array(str(300).regex(/^\/uploads\/public\/[a-f0-9]{32}\.(jpg|png|webp)$/)).max(12).default([]), video_url: opt(str(300).url()),
  equipment: z.record(z.string(), z.boolean()).optional().transform(e => (e ? Object.fromEntries(require('../contract/settlement').EQUIPMENT.map(k => [k, !!e[k]])) : undefined)), cleanliness: z.boolean().optional().nullable(),
  admin_note: opt(str(500)), customer_note: opt(str(500)), video_file: opt(str(60).regex(/^[a-f0-9]{32}\.(mp4|webm)$/)) });
const fineSel = z.object({ n: z.coerce.number().int().positive().optional(), title: opt(str(120)), qty: z.coerce.number().int().min(1).max(1000).optional(), extra: z.coerce.number().int().min(0).optional(), amount: z.coerce.number().int().min(0).optional(), note: opt(str(200)) });
const settleSchema = { fines: z.array(fineSel).max(30).default([]), other_fee: z.coerce.number().int().min(0).default(0), other_note: opt(str(300)), deduct: opt(z.coerce.number().int().min(0)) };
r.post('/bookings/:id/handover', P('handover'), wrap(async (req, res) => {
  const d = parse(inspSchema.extend({ force: z.boolean().optional() }), req.body);
  res.json(await bookings.handover(+req.params.id, d, req.user, req));
}));
r.post('/bookings/:id/return', P('handover'), wrap(async (req, res) => {
  const d = parse(inspSchema.extend({ mileage: z.coerce.number().int().min(0), fuel_level: z.coerce.number().int().min(0).max(100), damage_fee: z.coerce.number().int().min(0).default(0),
    use_deposit: z.boolean().default(true), refund_method: z.enum(['CASH', 'CARD', 'BANK_TRANSFER', 'ONLINE']).default('CASH'), send_to_maintenance: z.boolean().default(false), deduction_reason: opt(str(200)), ...settleSchema }), req.body);
  res.json(await bookings.returnCar(+req.params.id, d, req.user, req));
}));
r.get('/bookings/:id/compare', P('bookings.read'), wrap(async (req, res) => {
  const ins = (await db.query('SELECT i.*,u.full_name staff FROM car_inspections i LEFT JOIN users u ON u.id=i.staff_id WHERE booking_id=$1', [req.params.id])).rows;
  const a = ins.find(i => i.stage === 'HANDOVER'), b = ins.find(i => i.stage === 'RETURN');
  if (!a) throw new AppError(404, 'Topshirish dalolatnomasi yo\'q');
  res.json({ handover: a, return: b || null, diff: b ? { driven_km: b.mileage - a.mileage, fuel_change: b.fuel_level - a.fuel_level, new_damages: b.damages && b.damages !== a.damages ? b.damages : null,
    body_changed: (a.body_condition || '') !== (b.body_condition || ''), interior_changed: (a.interior_condition || '') !== (b.interior_condition || '') } : null });
}));
r.get('/bookings/:id/contract', P('contracts.read'), wrap(async (req, res) => {
  const ecx = (await db.query('SELECT * FROM econtracts WHERE booking_id=$1', [req.params.id])).rows[0];
  if (ecx) { const f = await econtract.pdfFor(ecx); res.setHeader('Content-Type', 'application/pdf'); res.setHeader('Content-Disposition', `attachment; filename="${f.name}"`); res.setHeader('Cache-Control', 'no-store'); return res.send(f.bytes); }
  const c = await contract.getFile(+req.params.id);
  res.setHeader('Content-Type', 'application/pdf'); res.setHeader('Content-Disposition', `attachment; filename="${c.number}.pdf"`);
  fs.createReadStream(c.file_path).pipe(res);
}));
r.post('/bookings/:id/contract', P('bookings.write'), wrap(async (req, res) => res.json(await contract.generate(+req.params.id))));
r.get('/contracts', P('contracts.read'), wrap(async (req, res) => {
  const { rows } = await db.query(`SELECT rc.booking_id,rc.number,rc.generated_at,b.code,b.status,c.first_name||' '||c.last_name customer,car.brand||' '||car.model car,car.plate
    FROM rental_contracts rc JOIN bookings b ON b.id=rc.booking_id JOIN customers c ON c.id=b.customer_id JOIN cars car ON car.id=b.car_id ORDER BY rc.generated_at DESC LIMIT 200`);
  res.json(rows);
}));

// ---------- CONTRACT TEMPLATE / CONSENT ----------
r.get('/contract-template', P('bookings.read', 'contract.manage'), wrap(async (req, res) => res.json({ active: await contract.getActive(), versions: await contract.listTemplates() })));
r.post('/contract-template', P('contract.manage'), wrap(async (req, res) => {
  const d = parse(z.object({ title: str(200), body: z.string().max(60000) }), req.body);
  res.status(201).json(await contract.saveTemplate(d, req.user, req));
}));
r.post('/bookings/:id/consent-paper', P('handover', 'bookings.write'), wrap(async (req, res) => res.json(await bookings.recordPaperConsent(+req.params.id, req.user, req))));
r.post('/bookings/:id/request-consent', P('bookings.write', 'handover'), wrap(async (req, res) => {
  if (await contract.getConsent(+req.params.id)) throw new AppError(409, 'Rozilik allaqachon olingan');
  const r2 = await contract.sendConsentRequest(+req.params.id);
  await audit(req.user, 'CONSENT_REQUEST', 'booking', req.params.id, null, null, req); res.json(r2);
}));

// ---------- MESSAGES (admin -> mijoz, bot orqali) ----------
r.get('/messages', P('messages.send'), wrap(async (req, res) => res.json({ items: await messages.history(req.query.customer_id ? +req.query.customer_id : null), recipients: await messages.countRecipients() })));
r.post('/messages/send', P('messages.send'), wrap(async (req, res) => {
  await features.requireEnabled('messages');
  const d = parse(z.object({ customer_id: idp, text: str(3500) }), req.body);
  res.json(await messages.sendToCustomer(d.customer_id, d.text, req.user, 'DIRECT', req));
}));
r.post('/messages/broadcast', P('messages.send'), wrap(async (req, res) => {
  await features.requireEnabled('messages');
  const d = parse(z.object({ text: str(3500) }), req.body);
  res.json(await messages.broadcast(d.text, req.user, req));
}));

// ---------- CONTRACT PDF UPLOAD ----------
r.post('/contract-template/pdf', P('contract.manage'), up.memPdf.single('file'), wrap(async (req, res) => {
  if (!req.file) throw new AppError(400, 'PDF fayl tanlanmadi');
  const title = String(req.body.title || '').trim() || 'Avtomobil ijara shartnomasi';
  res.status(201).json(await contract.savePdfTemplate({ title, buffer: req.file.buffer, filename: req.file.originalname }, req.user, req));
}));

// ---------- TO'LOV JOYLARI (karta / bank) va to'lov so'rovlari ----------
r.get('/payment-accounts', P('payments.write', 'finance.read', 'settings.manage'), wrap(async (req, res) => res.json(await payacc.listAccounts())));
r.post('/payment-accounts', P('contract.manage', 'settings.manage'), wrap(async (req, res) => res.status(201).json(await payacc.saveAccount(req.body || {}, null, req.user, req))));
r.put('/payment-accounts/:id', P('contract.manage', 'settings.manage'), wrap(async (req, res) => res.json(await payacc.saveAccount(req.body || {}, +req.params.id, req.user, req))));
r.delete('/payment-accounts/:id', P('contract.manage', 'settings.manage'), wrap(async (req, res) => { await payacc.deleteAccount(+req.params.id, req.user, req); res.json({ ok: true }); }));
r.get('/payment-claims', P('payments.write'), wrap(async (req, res) => res.json(await payacc.listClaims(req.query.status || null))));
r.post('/payment-claims/:id/confirm', P('payments.write'), wrap(async (req, res) => res.json(await payacc.confirmClaim(+req.params.id, req.user, req))));
r.post('/payment-claims/:id/reject', P('payments.write'), wrap(async (req, res) => {
  const d = parse(z.object({ reason: opt(str(200)) }), req.body || {}); await payacc.rejectClaim(+req.params.id, d.reason, req.user, req); res.json({ ok: true });
}));
r.get('/payment-claims/:id/receipt', P('payments.write'), wrap(async (req, res) => {
  const c = (await db.query('SELECT receipt_file,receipt_tg_file_id FROM payment_claims WHERE id=$1', [req.params.id])).rows[0];
  if (!c) throw new AppError(404, 'Topilmadi');
  res.setHeader('Cache-Control', 'no-store');
  if (c.receipt_file) return res.sendFile(up.privatePath(c.receipt_file));
  if (c.receipt_tg_file_id) {   // botdan kelgan chek: Telegram serveridan olinadi
    const f = await tgSvc.tg.call('getFile', { file_id: c.receipt_tg_file_id });
    if (!f.ok) throw new AppError(502, "Chekni Telegramdan olib bo'lmadi");
    const resp = await fetch(`${cfg.tgApi}/file/bot${cfg.botToken}/${f.result.file_path}`);
    res.setHeader('Content-Type', resp.headers.get('content-type') || 'image/jpeg'); return res.send(Buffer.from(await resp.arrayBuffer()));
  }
  throw new AppError(404, "Chek yuborilmagan");
}));

// ---------- ALOQA RAQAMLARI ----------
r.get('/contacts', wrap(async (req, res) => res.json(await contacts.list())));
r.post('/contacts', P('contract.manage', 'settings.manage'), wrap(async (req, res) => res.status(201).json(await contacts.save(req.body || {}, null, req.user, req))));
r.put('/contacts/:id', P('contract.manage', 'settings.manage'), wrap(async (req, res) => res.json(await contacts.save(req.body || {}, +req.params.id, req.user, req))));
r.delete('/contacts/:id', P('contract.manage', 'settings.manage'), wrap(async (req, res) => { await contacts.remove(+req.params.id, req.user, req); res.json({ ok: true }); }));

// ---------- BOTGA QO'SHILGAN FOYDALANUVCHILAR ----------
r.get('/bot-users', P('customers.read'), wrap(async (req, res) => {
  const p = []; let w = 'c.telegram_id IS NOT NULL AND c.deleted_at IS NULL';
  if (req.query.q) { p.push(`%${String(req.query.q).replace(/[\\%_]/g, m => '\\' + m)}%`); w += ` AND (c.first_name||' '||c.last_name ILIKE $1 ESCAPE '\\' OR c.phone ILIKE $1 ESCAPE '\\' OR c.tg_username ILIKE $1 ESCAPE '\\' OR c.telegram_id::text ILIKE $1 ESCAPE '\\')`; }
  const { rows } = await db.query(`SELECT c.id,c.first_name,c.last_name,c.phone,c.tg_username,c.telegram_id,c.joined_via,c.created_at,c.last_seen_at,c.is_blocked,
      (SELECT COUNT(*)::int FROM bookings b WHERE b.customer_id=c.id AND b.deleted_at IS NULL) bookings FROM customers c WHERE ${w} ORDER BY c.created_at DESC LIMIT 500`, p);
  const total = (await db.query('SELECT COUNT(*)::int n, COUNT(*) FILTER (WHERE phone IS NOT NULL AND phone<>\'\')::int with_phone FROM customers WHERE telegram_id IS NOT NULL AND deleted_at IS NULL')).rows[0];
  res.json({ items: rows, total: total.n, with_phone: total.with_phone });
}));

// ---------- ROLLAR VA HUQUQLAR (faqat Egasi) ----------
r.get('/roles/permissions', P('users.manage'), wrap(async (req, res) => {
  const roles = (await db.query('SELECT code,name,permissions FROM roles ORDER BY id')).rows;
  res.json({ labels: require('../permissions').LABELS, roles });
}));
r.put('/roles/:code', P('users.manage'), wrap(async (req, res) => {
  if (req.user.role !== 'OWNER') throw new AppError(403, "Rol huquqlarini faqat Egasi o'zgartira oladi");
  if (req.params.code === 'OWNER') throw new AppError(400, "Egasi huquqlari o'zgartirilmaydi");
  const valid = require('../permissions').ALL;
  const perms = (Array.isArray(req.body?.permissions) ? req.body.permissions : []).filter(p => valid.includes(p));
  const old = (await db.query('SELECT permissions FROM roles WHERE code=$1', [req.params.code])).rows[0];
  if (!old) throw new AppError(404, 'Rol topilmadi');
  await db.query('UPDATE roles SET permissions=$2 WHERE code=$1', [req.params.code, JSON.stringify(perms)]);
  await audit(req.user, 'ROLE_PERMISSIONS', 'role', req.params.code, { count: old.permissions.length }, { count: perms.length }, req);
  res.json({ ok: true, count: perms.length });
}));

// ---------- FUNKSIYALAR MARKAZI ----------
r.get('/features', wrap(async (req, res) => res.json({ catalog: features.FEATURES, flags: await features.flags(), fields: await features.listFields() })));
r.put('/features', P('settings.manage'), wrap(async (req, res) => { const f = await features.setFlags(req.body || {}); await audit(req.user, 'UPDATE', 'features', null, null, f, req); res.json(f); }));
r.post('/custom-fields', P('settings.manage'), wrap(async (req, res) => { const f = await features.saveField(req.body || {}); await audit(req.user, 'CREATE', 'custom_field', f.id, null, { label: f.label, entity: f.entity }, req); res.status(201).json(f); }));
r.delete('/custom-fields/:id', P('settings.manage'), wrap(async (req, res) => { await features.deleteField(+req.params.id); await audit(req.user, 'DELETE', 'custom_field', req.params.id, null, null, req); res.json({ ok: true }); }));

// ---------- EKSPORT (CSV) ----------
const csvSend = (res, name, rows, cols) => { res.setHeader('Content-Type', 'text/csv; charset=utf-8'); res.setHeader('Content-Disposition', `attachment; filename="${name}-${todayStr()}.csv"`); res.send(reports.csv(rows, cols)); };
r.get('/export/customers.csv', P('customers.read'), wrap(async (req, res) => {
  const { rows } = await db.query(`SELECT first_name,last_name,phone,late_count,damage_total,bonus_balance,to_char(created_at AT TIME ZONE 'Asia/Tashkent','DD.MM.YYYY') created FROM customers WHERE deleted_at IS NULL ORDER BY id`);
  csvSend(res, 'mijozlar', rows, [{ key: 'first_name', label: 'Ism' }, { key: 'last_name', label: 'Familiya' }, { key: 'phone', label: 'Telefon' }, { key: 'late_count', label: 'Kechikishlar' }, { key: 'damage_total', label: "Zararlar (so'm)" }, { key: 'bonus_balance', label: 'Bonus' }, { key: 'created', label: "Qo'shilgan" }]);
}));
r.get('/export/bookings.csv', P('bookings.read'), wrap(async (req, res) => {
  const { rows } = await db.query(`SELECT b.code,b.status,c.first_name||' '||c.last_name customer,c.phone,car.brand||' '||car.model car,car.plate,to_char(b.pickup_at AT TIME ZONE 'Asia/Tashkent','DD.MM.YYYY HH24:MI') pickup,
      to_char(b.return_at AT TIME ZONE 'Asia/Tashkent','DD.MM.YYYY HH24:MI') ret,b.days,b.total_amount,b.paid_amount,b.deposit_amount,b.source FROM bookings b JOIN customers c ON c.id=b.customer_id JOIN cars car ON car.id=b.car_id WHERE b.deleted_at IS NULL ORDER BY b.id DESC`);
  csvSend(res, 'buyurtmalar', rows, [{ key: 'code', label: 'ID' }, { key: 'status', label: 'Holat' }, { key: 'customer', label: 'Mijoz' }, { key: 'phone', label: 'Telefon' }, { key: 'car', label: 'Mashina' }, { key: 'plate', label: 'Raqam' }, { key: 'pickup', label: 'Olish' }, { key: 'ret', label: 'Qaytarish' }, { key: 'days', label: 'Kun' }, { key: 'total_amount', label: 'Jami' }, { key: 'paid_amount', label: "To'langan" }, { key: 'deposit_amount', label: 'Depozit' }, { key: 'source', label: 'Manba' }]);
}));
r.get('/export/payments.csv', P('finance.read', 'payments.write'), wrap(async (req, res) => {
  const { rows } = await db.query(`SELECT to_char(p.paid_at AT TIME ZONE 'Asia/Tashkent','DD.MM.YYYY HH24:MI') at,b.code,c.first_name||' '||c.last_name customer,p.kind,p.method,p.status,p.amount FROM payments p JOIN bookings b ON b.id=p.booking_id JOIN customers c ON c.id=p.customer_id ORDER BY p.id DESC`);
  csvSend(res, 'tolovlar', rows, [{ key: 'at', label: 'Vaqt' }, { key: 'code', label: 'Buyurtma' }, { key: 'customer', label: 'Mijoz' }, { key: 'kind', label: 'Tur' }, { key: 'method', label: 'Usul' }, { key: 'status', label: 'Holat' }, { key: 'amount', label: "Summa (so'm)" }]);
}));

// ---------- PAYMENTS / DEPOSITS ----------
const paySchema = z.object({ booking_id: idp, amount: z.coerce.number().int().positive(), kind: z.enum(['RENTAL', 'DEPOSIT', 'EXTRA']).default('RENTAL'),
  method: z.enum(['CASH', 'CARD', 'ONLINE', 'BANK_TRANSFER']), provider: opt(str(30)), provider_txn_id: opt(str(80)) });
r.get('/payments', P('payments.write', 'finance.read'), wrap(async (req, res) => {
  const w = ['1=1']; const p = [];
  if (req.query.booking_id) { p.push(+req.query.booking_id); w.push(`p.booking_id=$${p.length}`); }
  if (req.query.from) { p.push(parseTkt(req.query.from)); w.push(`p.paid_at>=$${p.length}`); }
  if (req.query.to) { p.push(parseTkt(addDays(req.query.to, 1))); w.push(`p.paid_at<$${p.length}`); }
  if (req.query.method) { p.push(req.query.method); w.push(`p.method=$${p.length}`); }
  const { rows } = await db.query(`SELECT p.*,b.code,c.first_name||' '||c.last_name customer FROM payments p JOIN bookings b ON b.id=p.booking_id JOIN customers c ON c.id=p.customer_id
    WHERE ${w.join(' AND ')} ORDER BY p.paid_at DESC,p.id DESC LIMIT ${page(req).limit}`, p);
  res.json(rows);
}));
r.post('/payments', P('payments.write'), wrap(async (req, res) => {
  const d = parse(paySchema, req.body);
  if (d.method === 'ONLINE') providers.get(d.provider || 'manual');
  res.status(201).json(await bookings.addPayment(d, req.user, req));
}));
r.post('/bookings/:id/payments', P('payments.write'), wrap(async (req, res) => {
  const d = parse(paySchema.omit({ booking_id: true }), req.body);
  res.status(201).json(await bookings.addPayment({ ...d, booking_id: +req.params.id }, req.user, req));
}));
r.get('/deposits', P('payments.write', 'finance.read'), wrap(async (req, res) => {
  const { rows } = await db.query(`SELECT d.*,b.code,b.status booking_status,c.first_name||' '||c.last_name customer,car.brand||' '||car.model car FROM deposits d JOIN bookings b ON b.id=d.booking_id
    JOIN customers c ON c.id=b.customer_id JOIN cars car ON car.id=b.car_id WHERE d.held_amount>0 OR d.status<>'PENDING' ORDER BY d.id DESC LIMIT 200`);
  res.json(rows);
}));

// ---------- EXPENSES ----------
r.get('/expense-categories', wrap(async (req, res) => res.json((await db.query('SELECT id,code,name FROM expense_categories ORDER BY id')).rows)));
r.get('/expenses', P('finance.read', 'expenses.write'), wrap(async (req, res) => {
  const w = ['e.deleted_at IS NULL']; const p = [];
  if (req.query.car_id) { p.push(+req.query.car_id); w.push(`e.car_id=$${p.length}`); }
  if (req.query.category_id) { p.push(+req.query.category_id); w.push(`e.category_id=$${p.length}`); }
  if (req.query.from) { p.push(req.query.from); w.push(`e.spent_on>=$${p.length}`); }
  if (req.query.to) { p.push(req.query.to); w.push(`e.spent_on<=$${p.length}`); }
  const { rows } = await db.query(`SELECT e.*,ec.name category,car.brand||' '||car.model car,car.plate,u.full_name created_by_name FROM expenses e JOIN expense_categories ec ON ec.id=e.category_id
    LEFT JOIN cars car ON car.id=e.car_id LEFT JOIN users u ON u.id=e.created_by WHERE ${w.join(' AND ')} ORDER BY e.spent_on DESC,e.id DESC LIMIT ${page(req).limit}`, p);
  res.json(rows);
}));
r.post('/expenses', P('expenses.write'), wrap(async (req, res) => {
  const d = parse(z.object({ car_id: opt(idp), category_id: idp, amount: z.coerce.number().int().positive(), spent_on: opt(str(10)), note: opt(str(300)) }), req.body);
  const { rows } = await db.query(`INSERT INTO expenses(car_id,category_id,amount,spent_on,note,created_by) VALUES($1,$2,$3,COALESCE($4::date,$5::date),$6,$7) RETURNING *`,
    [d.car_id, d.category_id, d.amount, d.spent_on, todayStr(), d.note, req.user.id]);
  await audit(req.user, 'CREATE', 'expense', rows[0].id, null, { amount: d.amount, category_id: d.category_id, car_id: d.car_id }, req);
  res.status(201).json(rows[0]);
}));
r.delete('/expenses/:id', P('expenses.write'), wrap(async (req, res) => {
  const { rows } = await db.query('UPDATE expenses SET deleted_at=now() WHERE id=$1 AND deleted_at IS NULL RETURNING id,amount,category_id', [req.params.id]);
  if (!rows[0]) throw new AppError(404, 'Xarajat topilmadi');
  await audit(req.user, 'DELETE', 'expense', req.params.id, rows[0], null, req); res.json({ ok: true });
}));

// ---------- MAINTENANCE ----------
r.get('/maintenance', P('maintenance.read'), wrap(async (req, res) => {
  const p = []; let w = '1=1';
  if (req.query.car_id) { p.push(+req.query.car_id); w = 'm.car_id=$1'; }
  const { rows } = await db.query(`SELECT m.*,car.brand||' '||car.model car,car.plate,car.mileage current_km FROM maintenance m JOIN cars car ON car.id=m.car_id WHERE ${w} ORDER BY m.done_at DESC,m.id DESC LIMIT 200`, p);
  res.json({ items: rows, alerts: (await reports.alerts()).filter(a => a.type !== 'DOC') });
}));
r.post('/maintenance', P('maintenance.write'), wrap(async (req, res) => {
  const d = parse(z.object({ car_id: idp, kind: z.enum(['OIL', 'FILTER', 'BRAKE_PADS', 'TIRES', 'BATTERY', 'REPAIR', 'INSPECTION', 'INSURANCE']), done_at: opt(str(10)), mileage_at: opt(num),
    next_due_km: opt(num), next_due_date: opt(str(10)), cost: num.default(0), note: opt(str(300)) }), req.body);
  const row = await db.tx(async c => {
    const car = (await c.query('SELECT id,mileage FROM cars WHERE id=$1 AND deleted_at IS NULL', [d.car_id])).rows[0];
    if (!car) throw new AppError(404, 'Mashina topilmadi');
    let expId = null;
    if (d.cost > 0) {
      const cat = { OIL: 'OIL', INSURANCE: 'INSURANCE', REPAIR: 'REPAIR', TIRES: 'TIRES' }[d.kind] || 'REPAIR';
      expId = (await c.query(`INSERT INTO expenses(car_id,category_id,amount,spent_on,note,created_by) VALUES($1,(SELECT id FROM expense_categories WHERE code=$2),$3,COALESCE($4::date,$5::date),$6,$7) RETURNING id`,
        [d.car_id, cat, d.cost, d.done_at, todayStr(), 'Texnik xizmat: ' + d.kind, req.user.id])).rows[0].id;
    }
    const m = (await c.query(`INSERT INTO maintenance(car_id,kind,done_at,mileage_at,next_due_km,next_due_date,cost,note,expense_id,created_by) VALUES($1,$2,COALESCE($3::date,$9::date),$4,$5,$6,$7,$8,$10,$11) RETURNING *`,
      [d.car_id, d.kind, d.done_at, d.mileage_at ?? car.mileage, d.next_due_km, d.next_due_date, d.cost, d.note, todayStr(), expId, req.user.id])).rows[0];
    if (d.kind === 'INSURANCE' && d.next_due_date) await c.query('UPDATE cars SET insurance_until=$2 WHERE id=$1', [d.car_id, d.next_due_date]);
    if (d.kind === 'INSPECTION' && d.next_due_date) await c.query('UPDATE cars SET inspection_until=$2 WHERE id=$1', [d.car_id, d.next_due_date]);
    await audit(req.user, 'CREATE', 'maintenance', m.id, null, { car_id: d.car_id, kind: d.kind, cost: d.cost }, req, c);
    return m;
  });
  res.status(201).json(row);
}));

// ---------- REPORTS ----------
const rep = wrap(async (req, res) => {
  const [f, t] = reports.period(req.query.period, req.query.from, req.query.to);
  res.json(await reports.summary(f, addDays(t, -1)));
});
r.get('/reports/summary', P('reports.read'), rep);
r.get('/reports/revenue', P('reports.read'), wrap(async (req, res) => { const [f, t] = reports.period(req.query.period, req.query.from, req.query.to); const s = await reports.summary(f, addDays(t, -1)); res.json({ from: s.from, to: s.to, revenue: s.revenue, daily: s.daily.map(d => ({ day: d.day, revenue: d.revenue })), top_cars: s.top_cars }); }));
r.get('/reports/profit', P('reports.read'), wrap(async (req, res) => { const [f, t] = reports.period(req.query.period, req.query.from, req.query.to); const s = await reports.summary(f, addDays(t, -1)); res.json({ from: s.from, to: s.to, revenue: s.revenue, expenses: s.expenses, profit: s.profit, cars: s.cars, expense_categories: s.expense_categories }); }));
r.get('/reports/utilization', P('reports.read'), wrap(async (req, res) => { const [f, t] = reports.period(req.query.period, req.query.from, req.query.to); const s = await reports.summary(f, addDays(t, -1)); res.json({ from: s.from, to: s.to, utilization: s.utilization, cars: s.cars.map(c => ({ id: c.id, name: c.name, plate: c.plate, utilization: c.utilization })) }); }));
r.get('/reports/export.csv', P('reports.read'), wrap(async (req, res) => {
  const [f, t] = reports.period(req.query.period, req.query.from, req.query.to);
  const s = await reports.summary(f, addDays(t, -1));
  const body = reports.csv(s.cars.map(c => ({ ...c })), [{ key: 'name', label: 'Mashina' }, { key: 'plate', label: 'Davlat raqami' }, { key: 'revenue', label: 'Daromad (so\'m)' },
    { key: 'expenses', label: 'Xarajat (so\'m)' }, { key: 'profit', label: 'Sof foyda (so\'m)' }, { key: 'utilization', label: 'Bandlik %' }]);
  res.setHeader('Content-Type', 'text/csv; charset=utf-8'); res.setHeader('Content-Disposition', `attachment; filename="hisobot-${s.from}_${s.to}.csv"`); res.send(body);
}));
r.get('/reports/export.pdf', P('reports.read'), wrap(async (req, res) => {
  const [f, t] = reports.period(req.query.period, req.query.from, req.query.to);
  const s = await reports.summary(f, addDays(t, -1));
  const PDFDocument = require('pdfkit');
  const dir = path.dirname(require.resolve('dejavu-fonts-ttf/package.json'));
  const doc = new PDFDocument({ size: 'A4', margin: 40 });
  res.setHeader('Content-Type', 'application/pdf'); res.setHeader('Content-Disposition', `attachment; filename="hisobot-${s.from}_${s.to}.pdf"`);
  doc.pipe(res);
  doc.font(path.join(dir, 'ttf/DejaVuSans-Bold.ttf')).fontSize(15).text(`Hisobot: ${fmtDate(parseTkt(s.from))} — ${fmtDate(parseTkt(s.to))}`);
  doc.moveDown().font(path.join(dir, 'ttf/DejaVuSans.ttf')).fontSize(10);
  [['Daromad', money(s.revenue)], ['Xarajat', money(s.expenses)], ['Sof foyda', money(s.profit)], ['Ijaralar soni', s.rentals], ["O'rtacha bandlik", s.utilization + '%']].forEach(([k, v]) => doc.text(`${k}: ${v}`));
  doc.moveDown().font(path.join(dir, 'ttf/DejaVuSans-Bold.ttf')).text('Mashinalar bo\'yicha'); doc.font(path.join(dir, 'ttf/DejaVuSans.ttf')).fontSize(9);
  s.cars.forEach(c => doc.text(`${c.name} (${c.plate})  •  daromad ${money(c.revenue)}  •  xarajat ${money(c.expenses)}  •  foyda ${money(c.profit)}  •  bandlik ${c.utilization}%`));
  doc.moveDown().font(path.join(dir, 'ttf/DejaVuSans-Bold.ttf')).fontSize(10).text('Xarajat kategoriyalari'); doc.font(path.join(dir, 'ttf/DejaVuSans.ttf')).fontSize(9);
  s.expense_categories.forEach(c => doc.text(`${c.name}: ${money(c.amount)}`));
  doc.end();
}));

// ---------- NOTIFICATIONS ----------
r.get('/notifications', P('notifications.read'), wrap(async (req, res) => {
  const { rows } = await db.query(`SELECT id,type,title,body,is_read,created_at FROM notifications WHERE audience='ADMIN' ORDER BY id DESC LIMIT 100`);
  const unread = (await db.query(`SELECT COUNT(*)::int n FROM notifications WHERE audience='ADMIN' AND NOT is_read`)).rows[0].n;
  res.json({ items: rows, unread });
}));
r.post('/notifications/read', P('notifications.read'), wrap(async (req, res) => { await db.query(`UPDATE notifications SET is_read=true WHERE audience='ADMIN' AND NOT is_read`); res.json({ ok: true }); }));

// ---------- PROMO ----------
r.get('/promos', P('promo.write', 'bookings.read'), wrap(async (req, res) => res.json((await db.query('SELECT * FROM promo_codes ORDER BY id DESC')).rows)));
r.post('/promos', P('promo.write'), wrap(async (req, res) => {
  const d = parse(z.object({ code: str(30).min(3).regex(/^[A-Za-z0-9_-]+$/), percent: opt(z.coerce.number().int().min(1).max(100)), fixed_amount: opt(num), min_days: z.coerce.number().int().min(1).default(1),
    valid_from: opt(str(10)), valid_until: opt(str(10)), usage_limit: opt(z.coerce.number().int().min(1)) }), req.body);
  if (!d.percent && !d.fixed_amount) throw new AppError(400, 'Foiz yoki aniq summani kiriting');
  if (d.percent && d.fixed_amount) throw new AppError(400, "Foiz va aniq summadan faqat bittasini tanlang");
  try {
    const { rows } = await db.query(`INSERT INTO promo_codes(code,percent,fixed_amount,min_days,valid_from,valid_until,usage_limit) VALUES(upper($1),$2,$3,$4,$5,$6,$7) RETURNING *`,
      [d.code, d.percent, d.fixed_amount, d.min_days, d.valid_from, d.valid_until, d.usage_limit]);
    await audit(req.user, 'CREATE', 'promo', rows[0].id, null, d, req); res.status(201).json(rows[0]);
  } catch (e) { if (e.code === '23505') throw new AppError(409, 'Bu promo kod mavjud'); throw e; }
}));
r.patch('/promos/:id', P('promo.write'), wrap(async (req, res) => {
  const { is_active } = parse(z.object({ is_active: z.boolean() }), req.body);
  await db.query('UPDATE promo_codes SET is_active=$2 WHERE id=$1', [req.params.id, is_active]); res.json({ ok: true });
}));

// ---------- STAFF / ROLES ----------
r.get('/roles', wrap(async (req, res) => res.json((await db.query('SELECT id,code,name FROM roles ORDER BY id')).rows)));
r.get('/users', P('users.manage'), wrap(async (req, res) => res.json((await db.query(`SELECT u.id,u.full_name,u.username,u.phone,u.tg_username,u.telegram_id,u.is_active,u.last_login_at,u.created_at,r.code role FROM users u JOIN roles r ON r.id=u.role_id WHERE u.deleted_at IS NULL ORDER BY u.id`)).rows)));
r.post('/users', P('users.manage'), wrap(async (req, res) => {
  const d = parse(z.object({ full_name: str(80).min(2), username: str(30).regex(/^[a-zA-Z0-9_.-]{3,30}$/, 'Login 3–30 belgi (lotin harf, raqam)'), password: z.string().min(8, 'Parol kamida 8 belgi').max(100),
    role: z.enum(['OWNER', 'ADMIN', 'MANAGER', 'ACCOUNTANT']), telegram_id: opt(z.coerce.number().int().positive()), phone: opt(str(25)), tg_username: opt(str(40)) }), req.body);
  if (d.role === 'OWNER' && req.user.role !== 'OWNER') throw new AppError(403, "Egasi rolini faqat Egasi bera oladi");
  try {
    const { rows } = await db.query(`INSERT INTO users(role_id,full_name,username,password_hash,telegram_id,phone,tg_username) VALUES((SELECT id FROM roles WHERE code=$1),$2,$3,$4,$5,$6,$7) RETURNING id,full_name,username`,
      [d.role, d.full_name, d.username, await hash(d.password), d.telegram_id, d.phone ? contacts.normPhone(d.phone) : null, d.tg_username ? d.tg_username.replace(/^@/, '') : null]);
    await audit(req.user, 'CREATE', 'user', rows[0].id, null, { username: d.username, role: d.role }, req); res.status(201).json(rows[0]);
  } catch (e) { if (e.code === '23505') throw new AppError(409, 'Bu login yoki Telegram ID band'); throw e; }
}));
r.patch('/users/:id', P('users.manage'), wrap(async (req, res) => {
  const d = parse(z.object({ full_name: str(80).optional(), is_active: z.boolean().optional(), role: z.enum(['OWNER', 'ADMIN', 'MANAGER', 'ACCOUNTANT']).optional(), password: z.string().min(8).max(100).optional(), telegram_id: opt(z.coerce.number().int().positive()), phone: opt(str(25)), tg_username: opt(str(40)) }), req.body);
  const old = (await db.query('SELECT u.id,u.is_active,r.code role FROM users u JOIN roles r ON r.id=u.role_id WHERE u.id=$1', [req.params.id])).rows[0];
  if (!old) throw new AppError(404, 'Xodim topilmadi');
  if (+req.params.id === req.user.id && (d.is_active === false || (d.role && d.role !== old.role))) throw new AppError(400, "O'zingizni bloklay yoki rolingizni o'zgartira olmaysiz");
  if ((d.role === 'OWNER' || old.role === 'OWNER') && req.user.role !== 'OWNER') throw new AppError(403, 'Egasi hisobini faqat Egasi o\'zgartira oladi');
  const sets = [], v = [req.params.id];
  const add = (c, x) => { v.push(x); sets.push(`${c}=$${v.length}`); };
  if (d.full_name) add('full_name', d.full_name); if (d.is_active !== undefined) add('is_active', d.is_active);
  if (d.role) { v.push(d.role); sets.push(`role_id=(SELECT id FROM roles WHERE code=$${v.length})`); }
  if (d.password) add('password_hash', await hash(d.password)); if (d.telegram_id !== undefined) add('telegram_id', d.telegram_id);
  if (d.phone !== undefined) add('phone', d.phone ? contacts.normPhone(d.phone) : null); if (d.tg_username !== undefined) add('tg_username', d.tg_username ? d.tg_username.replace(/^@/, '') : null);
  if (!sets.length) throw new AppError(400, "O'zgartirish uchun maydon yo'q");
  await db.query(`UPDATE users SET ${sets.join(',')},failed_logins=0,locked_until=NULL WHERE id=$1`, v);
  await audit(req.user, 'UPDATE', 'user', req.params.id, old, { ...d, password: d.password ? '***' : undefined }, req); res.json({ ok: true });
}));

// ---------- SETTINGS / BACKUP / AUDIT ----------
r.get('/settings', P('settings.manage', 'bookings.read'), wrap(async (req, res) => res.json(await settings.all())));
r.put('/settings', P('settings.manage'), wrap(async (req, res) => {
  const old = await settings.all();
  for (const [k, v] of Object.entries(req.body || {})) {
    if (['late_fee_per_hour', 'late_grace_minutes', 'backup_every_hours', 'backup_keep', 'maintenance_warn_km', 'alert_days', 'referral_bonus'].includes(k) && !/^\d+$/.test(String(v))) throw new AppError(400, `${k}: butun son kiriting`);
    if (k === 'extras_catalog' || k === 'locations') { try { if (!Array.isArray(JSON.parse(v))) throw 0; } catch { throw new AppError(400, "Qo'shimcha xizmatlar JSON ro'yxat bo'lishi kerak"); } }
    await settings.set(k, v);
  }
  await audit(req.user, 'UPDATE', 'settings', null, old, req.body, req); res.json({ ok: true });
}));
r.get('/backups', P('backup.manage'), wrap(async (req, res) => res.json(backup.list())));
r.post('/backups', P('backup.manage'), wrap(async (req, res) => { const b = await backup.run().catch(e => { throw new AppError(500, 'Zaxira nusxa yaratilmadi: ' + e.message); }); await audit(req.user, 'BACKUP', 'system', null, null, b, req); res.json(b); }));
r.get('/backups/:name', P('backup.manage'), wrap(async (req, res) => {
  if (!/^rentacar-[\w.-]+\.sql$/.test(req.params.name)) throw new AppError(400, "Fayl nomi noto'g'ri");
  res.download(path.join(backup.DIR, req.params.name));
}));
r.get('/audit', P('audit.read'), wrap(async (req, res) => {
  const p = []; let w = '1=1';
  if (req.query.entity) { p.push(req.query.entity); w += ` AND entity=$${p.length}`; }
  const { rows } = await db.query(`SELECT * FROM audit_logs WHERE ${w} ORDER BY id DESC LIMIT 200`, p);
  res.json(rows);
}));

// ---------- AI ----------
r.post('/assistant', P('ai.use'), wrap(async (req, res) => {
  await features.requireEnabled('ai');
  const { question } = parse(z.object({ question: str(300).min(2) }), req.body);
  const a = await assistant.ask(question);
  if (!can(req.user, 'finance.read') && /foyda|daromad|xarajat|tushum/i.test(question)) return res.json({ answer: "Moliyaviy ma'lumotlarni ko'rish uchun sizda ruxsat yo'q." });
  res.json(a);
}));


// ---------- Suhbatlar (operator chat) ----------
r.get('/chat/threads', P('messages.send'), wrap(async (req, res) => { await features.requireEnabled('messages'); res.json({ items: await messages.threads(), unread: await messages.unreadTotal() }); }));
r.get('/chat/unread', P('messages.send'), wrap(async (req, res) => res.json({ unread: await messages.unreadTotal() })));
r.get('/chat/:id', P('messages.send'), wrap(async (req, res) => res.json(await messages.thread(+req.params.id))));
r.post('/chat/:id', P('messages.send'), wrap(async (req, res) => {
  await features.requireEnabled('messages');
  res.json(await messages.sendToCustomer(+req.params.id, (req.body || {}).text, req.user, 'REPLY', req));
}));

// ---------- Jarimalar ----------
r.get('/fines', P('bookings.read'), wrap(async (req, res) => res.json(await finesSvc.list({ status: req.query.status || null, car_id: req.query.car_id ? +req.query.car_id : null, q: req.query.q || null }))));
r.post('/fines', P('payments.write'), wrap(async (req, res) => {
  const d = parse(z.object({ car_id: z.coerce.number().int().positive(), fine_date: z.string().min(8), amount: z.coerce.number().int().positive(), reason: z.string().max(300).optional().nullable(), doc_no: z.string().max(60).optional().nullable(), note: z.string().max(300).optional().nullable() }), req.body);
  res.status(201).json(await finesSvc.create(d, req.user, req));
}));
r.post('/fines/:id/status', P('payments.write'), wrap(async (req, res) => res.json(await finesSvc.setStatus(+req.params.id, (req.body || {}).status, req.user, req))));

// ---------- GPS ----------
r.get('/gps/cars', P('cars.read'), wrap(async (req, res) => res.json(await gpsSvc.overview())));
r.get('/gps/cars/:id/track', P('cars.read'), wrap(async (req, res) => res.json(await gpsSvc.track(+req.params.id, req.query.hours))));
r.post('/gps/cars/:id/token', P('cars.write'), wrap(async (req, res) => {
  const t = (req.body || {}).reset ? await gpsSvc.resetToken(+req.params.id) : await gpsSvc.ensureToken(+req.params.id);
  await audit(req.user, 'GPS_TOKEN', 'car', +req.params.id, null, null, req);
  res.json({ token: t, url: `${cfg.publicUrl || ''}/api/gps/${t}` });
}));

// ---------- ELEKTRON SHARTNOMALAR ----------
r.get('/econtracts', P('contracts.read'), wrap(async (req, res) => res.json(await econtract.listAdmin({ status: req.query.status, q: req.query.q, from: req.query.from, to: req.query.to }))));
r.get('/econtracts/config', P('bookings.read', 'handover'), wrap(async (req, res) => res.json(await econtract.config())));
r.get('/econtracts/:id', P('contracts.read'), wrap(async (req, res) => res.json(await econtract.detailAdmin(+req.params.id))));
r.get('/econtracts/:id/pdf', P('contracts.read'), wrap(async (req, res) => {
  const c = (await db.query('SELECT * FROM econtracts WHERE id=$1', [+req.params.id])).rows[0]; if (!c) throw new AppError(404, 'Shartnoma topilmadi');
  const f = await econtract.pdfFor(c); const dl = req.query.download === '1';
  await econtract.logEvent(db, c.id, dl ? 'PDF_DOWNLOAD' : 'PDF_VIEW', req.user.full_name, null, req.ip);
  res.setHeader('Content-Type', 'application/pdf'); res.setHeader('Content-Disposition', `${dl ? 'attachment' : 'inline'}; filename="${f.name}"`); res.setHeader('Cache-Control', 'no-store'); res.send(f.bytes);
}));
r.get('/bookings/:id/acts/:kind/pdf', P('contracts.read'), wrap(async (req, res) => {
  const kind = String(req.params.kind).toUpperCase(); if (!['HANDOVER', 'RETURN'].includes(kind)) throw new AppError(400, 'Dalolatnoma turi noto‘g‘ri');
  const f = await econtract.actPdf(+req.params.id, kind);
  await econtract.logEvent(db, f.act.contract_id, 'ACT_VIEW', req.user.full_name, { kind }, req.ip);
  res.setHeader('Content-Type', 'application/pdf'); res.setHeader('Content-Disposition', `${req.query.download === '1' ? 'attachment' : 'inline'}; filename="${f.name}"`); res.setHeader('Cache-Control', 'no-store'); res.send(f.bytes);
}));
r.post('/econtracts/:id/cancel', P('contract.manage'), wrap(async (req, res) => {
  const d = parse(z.object({ reason: opt(str(300)) }), req.body || {}); await econtract.cancelByAdmin(+req.params.id, d.reason, req.user, req); res.json({ ok: true });
}));
r.post('/bookings/:id/econtract', P('bookings.write'), wrap(async (req, res) => {
  const id = await db.tx(c => econtract.createDraft(c, +req.params.id));
  if (!id) throw new AppError(409, 'Elektron shartnoma shabloni faol emas (Sozlamalar → Shartnoma)');
  await audit(req.user, 'ECONTRACT_CREATE', 'booking', req.params.id, null, { econtract_id: id }, req); res.status(201).json({ id });
}));
r.post('/bookings/:id/request-sign', P('bookings.write', 'handover'), wrap(async (req, res) => {
  const out = await bookings.requestSign(+req.params.id); await audit(req.user, 'ECONTRACT_SIGN_REQUEST', 'booking', req.params.id, null, null, req); res.json(out);
}));
r.post('/bookings/:id/return/preview', P('handover'), wrap(async (req, res) => {
  const d = parse(z.object({ mileage: z.coerce.number().int().min(0), damage_fee: z.coerce.number().int().min(0).default(0), ...settleSchema }), req.body);
  res.json(await bookings.previewReturn(+req.params.id, d));
}));
r.post('/contract-template/form', P('contract.manage'), up.memPdf.single('file'), wrap(async (req, res) => {
  if (!req.file) throw new AppError(400, 'PDF fayl tanlanmadi');
  const bump = req.body.bump === 'major' ? 'major' : 'minor';
  res.status(201).json(await econtract.saveFormTemplate({ title: req.body.title, buffer: req.file.buffer, filename: req.file.originalname, bump, changelog: req.body.changelog }, req.user, req));
}));
r.get('/contract-template/:id/pdf', P('contract.manage'), wrap(async (req, res) => {
  const t = await econtract.templateById(+req.params.id); res.setHeader('Content-Type', 'application/pdf'); res.setHeader('Content-Disposition', `inline; filename="${t.file_name || 'shablon.pdf'}"`); res.send(require('fs').readFileSync(t.file_path));
}));
r.get('/contract-template/:id/preview', P('contract.manage'), wrap(async (req, res) => {
  const bytes = await econtract.previewTemplate(+req.params.id); res.setHeader('Content-Type', 'application/pdf'); res.setHeader('Content-Disposition', 'inline; filename="namuna.pdf"'); res.send(bytes);
}));
r.post('/upload-video', P('handover'), up.memVideo.single('file'), wrap(async (req, res) => res.json(up.saveVideo(req.file))));
r.get('/media/video/:name', P('bookings.read', 'handover'), wrap(async (req, res) => { res.setHeader('Cache-Control', 'no-store'); res.sendFile(up.videoPath(req.params.name)); }));

module.exports = r;
