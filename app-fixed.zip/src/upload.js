const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const multer = require('multer');
const { AppError } = require('./util');

const ROOT = path.join(__dirname, '..', 'uploads');
const PUBLIC = path.join(ROOT, 'public');
const PRIVATE = path.join(ROOT, 'private');
[PUBLIC, PRIVATE].forEach(d => fs.mkdirSync(d, { recursive: true }));

// Faqat rasm (JPG/PNG/WEBP) — kengaytma emas, fayl "magic bytes" bo'yicha tekshiriladi
function sniff(buf) {
  if (buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'jpg';
  if (buf.length > 8 && buf.slice(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'png';
  if (buf.length > 12 && buf.slice(0, 4).toString() === 'RIFF' && buf.slice(8, 12).toString() === 'WEBP') return 'webp';
  return null;
}
const mem = multer({ storage: multer.memoryStorage(), limits: { fileSize: 6 * 1024 * 1024, files: 1 } });

// scope: 'public' (mashina/dalolatnoma rasmlari) yoki 'private' (hujjatlar — faqat ruxsat bilan beriladi)
function save(file, scope = 'public') {
  if (!file) throw new AppError(400, 'Fayl yuborilmadi');
  const ext = sniff(file.buffer);
  if (!ext) throw new AppError(400, "Faqat JPG, PNG yoki WEBP rasm yuklash mumkin");
  const name = crypto.randomBytes(16).toString('hex') + '.' + ext;
  const dir = scope === 'private' ? PRIVATE : PUBLIC;
  fs.writeFileSync(path.join(dir, name), file.buffer, { mode: 0o640 });
  return { name, url: scope === 'private' ? name : `/uploads/public/${name}` };
}
const privatePath = name => {
  if (!/^[a-f0-9]{32}\.(jpg|png|webp)$/.test(name || '')) throw new AppError(400, 'Fayl nomi noto\'g\'ri');
  return path.join(PRIVATE, name);
};
const memPdf = multer({ storage: multer.memoryStorage(), limits: { fileSize: 15 * 1024 * 1024, files: 1 } });
// Video (topshirish/qaytarish): faqat MP4/MOV/WEBM, "magic bytes" bo'yicha; yopiq papkada saqlanadi
const VIDEOS = path.join(PRIVATE, 'videos'); fs.mkdirSync(VIDEOS, { recursive: true });
const memVideo = multer({ storage: multer.memoryStorage(), limits: { fileSize: 40 * 1024 * 1024, files: 1 } });
function saveVideo(file) {
  if (!file) throw new AppError(400, 'Fayl yuborilmadi');
  const b = file.buffer;
  const ext = b.length > 12 && b.slice(4, 8).toString() === 'ftyp' ? 'mp4' : b.length > 4 && b[0] === 0x1a && b[1] === 0x45 && b[2] === 0xdf && b[3] === 0xa3 ? 'webm' : null;
  if (!ext) throw new AppError(400, 'Faqat MP4, MOV yoki WEBM video yuklash mumkin');
  const name = crypto.randomBytes(16).toString('hex') + '.' + ext;
  fs.writeFileSync(path.join(VIDEOS, name), b, { mode: 0o640 });
  return { name };
}
const videoPath = name => { if (!/^[a-f0-9]{32}\.(mp4|webm)$/.test(name || '')) throw new AppError(400, "Fayl nomi noto'g'ri"); return path.join(VIDEOS, name); };
module.exports = { mem, memPdf, memVideo, save, saveVideo, videoPath, privatePath, PUBLIC, ROOT };
