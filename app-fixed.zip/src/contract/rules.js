'use strict';
/*
 * Rasmiy shablon PDF dagi "[...]" joylarni tizim maydonlariga bog'lash qoidalari.
 * Shablon matni, bandlari va jarimalari O'ZGARTIRILMAYDI — faqat qo'lda yoziladigan joylar to'ldiriladi.
 *   sec   — joy qaysi bo'lim (1., 7., 9. ...) ichida turibdi
 *   label — joydan oldingi yorliq (xuddi shu qatorda)
 *   br    — qavs ichidagi matn
 *   bg    — katak foni (oq bo'lmasa), yopuvchi to'rtburchak rangi
 */
const RULES = [
  // --- Sarlavha jadvali (1-sahifa) ---
  { key: 'contract_number', label: /Shartnoma raqami/i, br: /^avtomatik$/i, bg: '#f5f5f5' },
  { key: 'contract_date', label: /Tuzilgan sana/i, br: /^avtomatik$/i, bg: '#f5f5f5' },
  { key: 'e_note', label: /Elektron shakl/i, br: /^avtomatik$/i },
  { key: 'customer_name', label: /Ijarachi:/i, br: /^F\.?I\.?Sh\.?$/i },
  { key: 'customer_phone', label: /Telefon:/i, br: /foydalanuvchi profili/i },
  { key: 'customer_passport', label: /Pasport\/ID:/i, br: /foydalanuvchi profili/i },
  { key: 'customer_address', label: /Manzil:/i, br: /foydalanuvchi profili/i },
  // --- 7. Avtomobil va ijara ma'lumotlari ---
  { key: 'car_model', sec: 7, br: /^tanlangan avtomobil$/i },
  { key: 'car_year', sec: 7, label: /Ishlab chiqarilgan yil/i },
  { key: 'car_color', sec: 7, label: /^Rangi/i },
  { key: 'car_vin', sec: 7, label: /Kuzov\/VIN/i },
  { key: 'car_plate', sec: 7, label: /Davlat raqami/i },
  { key: 'car_tech_passport', sec: 7, label: /Texnik pasport/i },
  { key: 'car_value', sec: 7, label: /Avtomobil qiymati/i },
  { key: 'rental_period', sec: 7, br: /^boshlanish\s*[—–-]\s*tugash$/i },
  { key: 'pickup_info', sec: 7, label: /Topshirish sanasi/i },
  { key: 'return_info', sec: 7, label: /Qaytarish sanasi/i },
  { key: 'daily_price', sec: 7, label: /Bir kunlik/i },
  { key: 'total_price', sec: 7, label: /Jami ijara/i },
  { key: 'deposit', sec: 7, label: /Garov\/depozit/i },
  { key: 'delivery', sec: 7, br: /^tanlov$/i },
  // --- 9. Qabul qilish-topshirish dalolatnomasi ---
  { key: 'ho_car', sec: 9, label: /^Avtomobil$/i },
  { key: 'ho_datetime', sec: 9, label: /Sana, vaqt, joy/i },
  { key: 'ho_km', sec: 9, label: /Spidometr/i },
  { key: 'ho_fuel', sec: 9, label: /Yoqilg/i },
  { key: 'ho_clean', sec: 9, label: /Tozaligi/i },
  { key: 'ho_damages', sec: 9, label: /Tashqi shikastlar/i },
  { key: 'ho_equipment', sec: 9, label: /Komplektatsiya/i },
  { key: 'ho_note', sec: 9, label: /Mijoz izohi/i },
  // --- 10. Qaytarish dalolatnomasi ---
  { key: 'rt_datetime', sec: 10, label: /Qaytarilgan sana/i },
  { key: 'rt_km', sec: 10, label: /Spidometr/i },
  { key: 'rt_fuel', sec: 10, label: /Yoqilg/i },
  { key: 'rt_extra_km', sec: 10, label: /Ortiqcha masofa/i },
  { key: 'rt_clean', sec: 10, label: /Tozaligi/i },
  { key: 'rt_damages', sec: 10, label: /Yangi shikastlar/i },
  { key: 'rt_equipment', sec: 10, label: /Komplektatsiya/i },
  { key: 'rt_damage_total', sec: 10, label: /Umumiy zarar/i },
  { key: 'rt_deduct', sec: 10, label: /Garovdan ushlab/i },
  { key: 'rt_final', sec: 10, label: /Yakuniy hisob/i },
  // --- 11. Elektron rozilik va tasdiqlash (audit jadvali) ---
  { key: 'contract_number', sec: 11, br: /^unikal ID$/i },
  { key: 'audit_user', sec: 11, br: /^F\.?I\.?Sh\.?,\s*profil ID$/i },
  { key: 'customer_phone', sec: 11, br: /^raqam$/i },
  { key: 'otp_method', sec: 11, br: /^OTP\s*\/\s*boshqa$/i },
  { key: 'approved_at_text', sec: 11, br: /^server vaqti$/i },
  { key: 'version_label', sec: 11, br: /^versiya$/i },
  { key: 'doc_hash', sec: 11, br: /^SHA-256$/i },
  { key: 'tech_log', sec: 11, br: /^tizim siyosatiga muvofiq$/i },
  { key: 'pdf_id', sec: 11, br: /^saqlash identifikatori$/i },
  // --- 12. Rekvizitlar ---
  { key: 'customer_name', sec: 12, br: /^F\.?I\.?Sh\.?$/i },
  { key: 'customer_address', sec: 12, br: /^manzil$/i },
  { key: 'customer_passport', sec: 12, br: /^Pasport\/ID$/i },
  { key: 'customer_phone', sec: 12, br: /^telefon$/i },
  { key: 'approval_stamp', sec: 12, br: /^sana-vaqt\s*\/\s*OTP$/i },
];

// Rozilik belgilari (☐) — shablondagi tartib bo'yicha emas, matn bo'yicha aniqlanadi
const CHECK_RULES = [
  ['read', /o.qidim/i], ['understood', /tushundim/i], ['correct', /to.g.ri ekanligini/i],
  ['personal', /Shaxsiy/i], ['media', /foto\/video/i],
];
const CHECK_KEYS = CHECK_RULES.map(c => c[0]);

// Shablon yuklanganda majburiy topilishi kerak bo'lgan maydonlar
const REQUIRED = ['contract_number', 'contract_date', 'customer_name', 'customer_phone', 'customer_passport', 'customer_address',
  'car_model', 'car_plate', 'car_vin', 'rental_period', 'pickup_info', 'return_info', 'daily_price', 'total_price', 'deposit'];

const KEY_LABELS = {
  contract_number: 'Shartnoma raqami', contract_date: 'Tuzilgan sana', customer_name: 'Ijarachi F.I.Sh.', customer_phone: 'Telefon', customer_passport: 'Pasport/ID',
  customer_address: 'Manzil', car_model: 'Avtomobil modeli', car_plate: 'Davlat raqami', car_vin: 'Kuzov/VIN', rental_period: 'Ijara muddati', pickup_info: 'Topshirish sanasi/vaqti/manzili',
  return_info: 'Qaytarish sanasi/vaqti/manzili', daily_price: 'Bir kunlik ijara to‘lovi', total_price: 'Jami ijara to‘lovi', deposit: 'Garov/depozit',
};

// Bo'lim sarlavhasi: "9. QABUL QILISH-TOPSHIRISH DALOLATNOMASI"
const HEADING = /^(\d{1,2})\.\s+[A-ZА-ЯЎҚҒҲ][A-ZА-ЯЎҚҒҲ\s‘’'ʻ`,\-\/().]{5,}$/u;

module.exports = { RULES, CHECK_RULES, CHECK_KEYS, REQUIRED, KEY_LABELS, HEADING };
