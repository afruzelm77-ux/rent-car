'use strict';
/*
 * Shablon PDF ni o'qib, "[...]" joylarni (koordinatalari bilan) va shartnoma shartlarini
 * (kilometr limiti, ortiqcha km narxi, jarimalar jadvali) aniqlaydi.
 * Natija shablon versiyasi bilan birga bazada saqlanadi — keyin o'zgarsa ham eski shartnomalarga ta'sir qilmaydi.
 */
const { RULES, CHECK_RULES, REQUIRED, HEADING } = require('./rules');

let _lib;
const pdfjs = () => (_lib ||= import('pdfjs-dist/legacy/build/pdf.mjs'));
const norm = s => String(s).replace(/<\/?b>/gi, '').replace(/[\u00a0\s]+/g, ' ').trim();
const approx = (s, size) => String(s).length * size * 0.55;   // fontkit bo'lmasa taxminiy o'lchov (proporsiya bilan to'g'rilanadi)

async function readPages(buffer) {
  const lib = await pdfjs();
  const doc = await lib.getDocument({ data: new Uint8Array(buffer), isEvalSupported: false, disableFontFace: true, useSystemFonts: false, verbosity: 0 }).promise;
  const pages = [];
  for (let n = 1; n <= doc.numPages; n++) {
    const page = await doc.getPage(n);
    const vp = page.getViewport({ scale: 1 });
    const tc = await page.getTextContent();
    const items = tc.items.filter(i => typeof i.str === 'string' && i.str.trim())
      .map(i => ({ str: i.str, x: i.transform[4], base: i.transform[5], w: i.width, size: Math.hypot(i.transform[0], i.transform[1]) || i.height || 8 }));
    items.sort((a, b) => b.base - a.base || a.x - b.x);
    const lines = [];
    for (const it of items) {
      const ln = lines.find(l => Math.abs(l.base - it.base) < 1.2);
      if (ln) ln.items.push(it); else lines.push({ base: it.base, items: [it] });
    }
    lines.forEach(l => l.items.sort((a, b) => a.x - b.x));
    pages.push({ width: vp.width, height: vp.height, lines });
  }
  await doc.destroy();
  return pages;
}

function findRule(section, label, inner) {
  return RULES.find(r => (r.sec == null || r.sec === section) && (!r.label || r.label.test(label)) && (!r.br || r.br.test(inner)));
}

function parseTerms(lines) {
  const text = lines.map(l => l.text.replace(/\u00a0/g, ' ')).join('\n');
  const num = s => parseInt(String(s).replace(/\D/g, ''), 10);
  const km = /Sutkalik kilometr limiti[^\d\n]*(\d[\d ]*?)\s*km/i.exec(text);
  const xk = /Ortiqcha kilometr[^\d\n]*(\d[\d ]*?)\s*so.m\s*\/\s*km/i.exec(text);
  const fines = [];
  for (const l of lines) {
    if (l.sec !== 8) continue;
    const m = /^(\d{1,2})\s+(.+?)\s+(Xarajatlar\s*\+\s*)?(\d[\d ]*?)\s*so.m(\s*\/\s*soat)?\s*$/i.exec(l.text.replace(/\u00a0/g, ' '));
    if (!m) continue;
    fines.push({ n: +m[1], title: m[2].trim(), amount: num(m[4]), kind: m[5] ? 'per_hour' : m[3] ? 'plus_costs' : 'fixed' });
  }
  return { km_limit_day: km ? num(km[1]) : null, extra_km_price: xk ? num(xk[1]) : null, fines };
}

async function detect(buffer, { measure = approx } = {}) {
  const pages = await readPages(buffer);
  const fields = [], checks = [], unmapped = [], textLines = [];
  let section = 0;
  pages.forEach((pg, pi) => {
    pg.lines.forEach((ln, li) => {
      textLines.push({ page: pi, sec: section, text: ln.items.map(i => i.str).join(' ') });
      ln.items.forEach((it, ii) => {
        const t = norm(it.str);
        if (HEADING.test(t)) { section = parseInt(t, 10); textLines[textLines.length - 1].sec = section; }
        const k0 = it.w / (measure(it.str, it.size) || 1);
        const nextX = ln.items[ii + 1] ? ln.items[ii + 1].x : null;
        const limit = nextX != null ? nextX - 5 : pg.width - 42;
        const left = ii > 0 ? norm(ln.items[ii - 1].str) : '';

        // Rozilik belgisi ☐
        if (/^☐/.test(it.str)) {
          const ck = CHECK_RULES.find(c => c[1].test(it.str) || (pg.lines[li + 1] && c[1].test(pg.lines[li + 1].items.map(i => i.str).join(' ')) && false));
          const key = ck ? ck[0] : null;
          if (key) checks.push({ key, page: pi, x: it.x, base: it.base, size: it.size, w: measure('☐', it.size) * k0 });
          else unmapped.push({ page: pi, text: it.str.slice(0, 40) });
          return;
        }
        if (!it.str.includes('[')) return;

        const re = /\[[^\]]*\]/g; let m, any = false;
        while ((m = re.exec(it.str))) {
          any = true;
          const prefix = it.str.slice(0, m.index), br = m[0], tail = it.str.slice(m.index + br.length);
          const x0 = it.x + measure(prefix, it.size) * k0, wBr = measure(br, it.size) * k0;
          const tailTrim = tail.trim(), shortTail = tailTrim.length > 0 && tailTrim.length <= 12;
          const label = norm(prefix) || left, inner = norm(br.slice(1, -1));
          const rule = findRule(section, label, inner);
          if (!rule) { unmapped.push({ page: pi, text: br }); continue; }
          fields.push({ key: rule.key, page: pi, sec: section, x: x0, base: it.base, size: it.size, text0: br,
            w: (shortTail || !tailTrim) ? Math.max(limit - x0, wBr) : Math.max(wBr + 4, 24),
            mw: shortTail ? it.x + it.w - x0 : wBr, tail: shortTail ? tail.replace(/\]/g, '') : '', bg: rule.bg || null });
        }
        // Ko'p qatorli "[...\n...]" (masalan komplektatsiya ro'yxati)
        if (!any) {
          const open = it.str.lastIndexOf('['), nl = pg.lines[li + 1];
          const cont = nl && nl.items.find(j => Math.abs(j.x - it.x) < 1.5 && j.str.includes(']'));
          if (open >= 0 && cont) {
            const prefix = it.str.slice(0, open), inner = norm(it.str.slice(open + 1) + ' ' + cont.str.slice(0, cont.str.indexOf(']')));
            const x0 = it.x + measure(prefix, it.size) * k0, right = pg.width - 42;
            const rule = findRule(section, norm(prefix) || left, inner);
            if (!rule) { unmapped.push({ page: pi, text: '[' + inner + ']' }); return; }
            fields.push({ key: rule.key, page: pi, sec: section, x: x0, base: it.base, size: it.size, text0: '[' + inner + ']', w: right - x0, mw: right - x0, tail: '', bg: rule.bg || null,
              lines: [{ x: x0, base: it.base, w: right - x0 }, { x: cont.x, base: cont.base, w: right - cont.x }], lineMask: [[x0, it.base, it.x + it.w - x0], [cont.x, cont.base, cont.w + 1]] });
          }
        }
      });
    });
  });
  const terms = parseTerms(textLines);
  const have = new Set(fields.map(f => f.key));
  return { pages: pages.length, size: [pages[0].width, pages[0].height], fields, checks, unmapped, terms, missing: REQUIRED.filter(k => !have.has(k)) };
}

module.exports = { detect, readPages, parseTerms };
