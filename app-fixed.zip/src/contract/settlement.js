'use strict';
/* Yakuniy hisob-kitob (sof funksiyalar — bazaga bog'liq emas):
 *   ORTIQCHA KM + JARIMALAR + ZARAR + BOSHQA TO'LOVLAR = YAKUNIY HISOB-KITOB
 *   GAROV − USHLAB QOLISH = QAYTARILADIGAN GAROV
 */
const EQUIPMENT = ['Zapas balon', 'Kalpak', 'Aptechka', 'O‘t o‘chirgich', 'Jilet', 'Avariya belgisi', 'Domkrat', 'Kalit', 'GPS', 'Videoregistrator'];

const { AppError } = require('../util');
class SErr extends AppError { constructor(m) { super(400, m); } }
const int = (v, name, max = 1e11) => {
  if (v == null || v === '') return 0;
  const n = Number(v);
  if (!Number.isInteger(n) || n < 0 || n > max) throw new SErr(`${name}: musbat butun son kiriting`);
  return n;
};

// Tanlangan jarimalarni shartnoma jadvali (terms.fines) bo'yicha hisoblaydi.
function resolveFines(selected, terms) {
  const out = [];
  for (const s of Array.isArray(selected) ? selected.slice(0, 40) : []) {
    if (s == null) continue;
    if (s.n != null) {
      const t = (terms && terms.fines || []).find(f => f.n === Number(s.n));
      if (!t) throw new SErr(`Shartnomada ${s.n}-raqamli jarima topilmadi`);
      const qty = Math.max(1, int(s.qty || 1, 'Soni', 1000));
      let amount;
      if (t.kind === 'plus_costs') amount = t.amount * qty + int(s.extra, 'Xarajat summasi');
      else amount = t.amount * qty;          // fixed: dona; per_hour: soat
      out.push({ n: t.n, title: t.title, qty, unit: t.kind === 'per_hour' ? 'soat' : 'marta', amount, note: String(s.note || '').slice(0, 200) });
    } else {
      const title = String(s.title || '').trim().slice(0, 120);
      if (!title) throw new SErr('Jarima nomini kiriting');
      out.push({ n: null, title, qty: 1, unit: 'marta', amount: int(s.amount, 'Jarima summasi'), note: String(s.note || '').slice(0, 200) });
    }
  }
  return { lines: out, total: out.reduce((a, l) => a + l.amount, 0) };
}

function computeSettlement(i) {
  const start = int(i.start_km, 'Boshlang‘ich km'), end = int(i.end_km, 'Yakuniy km');
  if (end < start) throw new SErr(`Yakuniy kilometr boshlang‘ichdan (${start} km) kam bo‘lishi mumkin emas`);
  const days = Math.max(1, int(i.days || 1, 'Kunlar'));
  const limitDay = int(i.km_limit_day || 0, 'Km limiti'), price = int(i.extra_km_price || 0, 'Ortiqcha km narxi');
  const driven = end - start, limit = limitDay * days;
  const extraKm = limitDay > 0 ? Math.max(0, driven - limit) : 0;
  const extraKmFee = extraKm * price;
  const fines = resolveFines(i.fines, i.terms), damage = int(i.damage_fee, 'Zarar'), other = int(i.other_fee, 'Boshqa to‘lovlar'), late = int(i.late_fee, 'Kechikish haqi');
  const charges = extraKmFee + fines.total + damage + other + late;
  const held = int(i.deposit_held, 'Garov');
  const cap = Math.min(held, charges, i.cap == null ? Infinity : Math.max(0, int(i.cap, 'Chegara')));
  let deduct = cap;
  if (i.deduct != null && i.deduct !== '') {
    deduct = int(i.deduct, 'Ushlab qolinadigan summa');
    if (deduct > Math.min(held, charges)) throw new SErr('Ushlab qolinadigan summa garovdan ham, yakuniy hisob-kitobdan ham oshmasligi kerak');
  }
  return { start_km: start, end_km: end, driven_km: driven, days, km_limit_day: limitDay, km_limit_total: limit, extra_km: extraKm, extra_km_price: price, extra_km_fee: extraKmFee,
    fines: fines.lines, fines_total: fines.total, damage_fee: damage, other_fee: other, late_fee: late, charges_total: charges,
    deposit_held: held, deposit_deducted: deduct, deposit_refund: held - deduct, balance_due: charges - deduct };
}

module.exports = { EQUIPMENT, resolveFines, computeSettlement, SErr };
