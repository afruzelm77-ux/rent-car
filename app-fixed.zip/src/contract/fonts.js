'use strict';
// Shriftlar: DejaVu Sans (lotin, kirill, o‘ʻ belgilari bilan). pdf-lib uchun @pdf-lib/fontkit kerak.
const fs = require('fs');
const path = require('path');

const DIR = path.join(path.dirname(require.resolve('dejavu-fonts-ttf/package.json')), 'ttf');
const REG = path.join(DIR, 'DejaVuSans.ttf'), BOLD = path.join(DIR, 'DejaVuSans-Bold.ttf');
let _fk;
const fontkit = () => { if (!_fk) { const m = require('@pdf-lib/fontkit'); _fk = m.default || m; } return _fk; };

async function embed(doc) {
  doc.registerFontkit(fontkit());
  return { reg: await doc.embedFont(fs.readFileSync(REG), { subset: true }), bold: await doc.embedFont(fs.readFileSync(BOLD), { subset: true }) };
}
// Shablondagi so'z kengligini o'lchash (detect uchun). Bo'lmasa null — taxminiy o'lchov ishlatiladi.
function measurer() {
  try {
    const f = fontkit().create(fs.readFileSync(REG));
    return (s, size) => (f.layout(String(s)).advanceWidth / f.unitsPerEm) * size;
  } catch { return null; }
}
module.exports = { embed, measurer };
