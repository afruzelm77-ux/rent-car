'use strict';
/*
 * Shablon PDF ni O'ZGARTIRMASDAN, faqat qo'lda yoziladigan "[...]" joylarni tizim ma'lumotlari bilan to'ldiradi
 * (eski yozuv oq to'rtburchak bilan yopiladi, ustidan qiymat yoziladi). Shartnoma matni, bandlar va jarimalar saqlanadi.
 */
const { PDFDocument, rgb, degrees } = require('pdf-lib');

const INK = rgb(0.06, 0.2, 0.45);
const hex = h => { const m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(h || '#ffffff'); return rgb(parseInt(m[1], 16) / 255, parseInt(m[2], 16) / 255, parseInt(m[3], 16) / 255); };

// Matnni berilgan kenglikka sig'diradi: avval shriftni kichraytiradi, keyin qisqartiradi
function fit(font, text, size, maxW, min = 5.2) {
  let s = size;
  while (s > min && font.widthOfTextAtSize(text, s) > maxW) s -= 0.2;
  if (font.widthOfTextAtSize(text, s) <= maxW) return { text, size: s };
  let t = text;
  while (t.length > 1 && font.widthOfTextAtSize(t + '…', s) > maxW) t = t.slice(0, -1);
  return { text: t + '…', size: s };
}
function wrap(font, text, size, widths) {
  const words = String(text).split(/\s+/).filter(Boolean), lines = [''];
  for (const w of words) {
    const i = lines.length - 1, cand = lines[i] ? lines[i] + ' ' + w : w;
    if (font.widthOfTextAtSize(cand, size) <= widths[Math.min(i, widths.length - 1)] || !lines[i]) lines[i] = cand; else lines.push(w);
  }
  return lines;
}
const mask = (page, x, base, w, size, bg) => page.drawRectangle({ x: x - 0.8, y: base - 0.28 * size, width: w + 1.6, height: 1.25 * size, color: hex(bg), borderWidth: 0 });

function drawFields(pages, map, values, fonts, S) {
  for (const f of map.fields) {
    if (!(f.key in values)) continue;
    const page = pages[f.page]; if (!page) continue;
    const raw = values[f.key]; const v = S(raw == null || raw === '' ? '—' : String(raw));
    if (f.lines) {
      f.lineMask.forEach(([x, base, w]) => mask(page, x, base, w, f.size, f.bg));
      let size = Math.min(f.size, 7), L = wrap(fonts.reg, v, size, f.lines.map(l => l.w));
      while (L.length > f.lines.length && size > 5.2) { size -= 0.3; L = wrap(fonts.reg, v, size, f.lines.map(l => l.w)); }
      if (L.length > f.lines.length) { L = L.slice(0, f.lines.length); L[L.length - 1] = fit(fonts.reg, L[L.length - 1] + '…', size, f.lines[f.lines.length - 1].w).text; }
      L.forEach((t, i) => page.drawText(t, { x: f.lines[i].x, y: f.lines[i].base, size, font: fonts.reg, color: INK }));
      continue;
    }
    const { text, size } = fit(fonts.reg, v + S(f.tail || ''), f.size, f.w);
    mask(page, f.x, f.base, f.mw + 1.5, f.size, f.bg);
    page.drawText(text, { x: f.x, y: f.base, size, font: fonts.reg, color: INK });
  }
}

// opts: { templateBuf, map, values, checks:{key:true}, footer, watermark, keep:[pageIdx], fonts:(doc)=>({reg,bold}), sanitize }
async function renderTemplate(opts) {
  const S = opts.sanitize || (s => s);
  // Shablon inkremental yangilangan bo'lishi mumkin (pdf-lib to'g'ridan-to'g'ri saqlay olmaydi) — sahifalar yangi hujjatga ko'chiriladi
  const src = await PDFDocument.load(opts.templateBuf), doc = await PDFDocument.create();
  for (const pg of await doc.copyPages(src, src.getPageIndices())) doc.addPage(pg);
  doc.setTitle(opts.title || 'Elektron shartnoma'); doc.setCreator('RENT A CAR');
  const fonts = await opts.fonts(doc);
  const pages = doc.getPages();
  drawFields(pages, opts.map, opts.values || {}, fonts, S);
  for (const c of opts.map.checks || []) {
    if (!opts.checks || !opts.checks[c.key]) continue;
    const pg = pages[c.page];
    pg.drawRectangle({ x: c.x - 0.6, y: c.base - 0.28 * c.size, width: Math.max(c.w, c.size * 0.95) + 2, height: 1.25 * c.size, color: rgb(1, 1, 1), borderWidth: 0 });
    pg.drawText(S('☑'), { x: c.x, y: c.base, size: c.size, font: fonts.reg, color: INK });
  }
  pages.forEach((pg, i) => {
    if (opts.footer) pg.drawText(S(opts.footer), { x: 51, y: 15, size: 6, font: fonts.reg, color: rgb(0.42, 0.42, 0.42) });
    if (opts.watermark) {
      const w = pg.getWidth(), h = pg.getHeight(), size = 50, text = S(opts.watermark), tw = fonts.bold.widthOfTextAtSize(text, size), a = 40 * Math.PI / 180;
      pg.drawText(text, { x: w / 2 - (tw / 2) * Math.cos(a) + 0.35 * size * Math.sin(a), y: h / 2 - (tw / 2) * Math.sin(a) - 0.35 * size * Math.cos(a), size, font: fonts.bold, color: rgb(0.8, 0.1, 0.1), opacity: 0.1, rotate: degrees(40) });
    }
  });
  if (opts.keep) for (let i = pages.length - 1; i >= 0; i--) if (!opts.keep.includes(i)) doc.removePage(i);
  return { doc, fonts, S };
}

/* ---- Qo'shimcha sahifalar (dalolatnoma ilovalari) ---- */
const A4 = [595.2756, 841.8898];
function newPage(doc, fonts, S, title, sub) {
  const pg = doc.addPage(A4);
  pg.drawRectangle({ x: 0, y: A4[1] - 74, width: A4[0], height: 74, color: rgb(0.09, 0.07, 0.2) });
  pg.drawText(S(title), { x: 42, y: A4[1] - 40, size: 15, font: fonts.bold, color: rgb(1, 1, 1) });
  if (sub) pg.drawText(S(sub), { x: 42, y: A4[1] - 58, size: 8.5, font: fonts.reg, color: rgb(0.78, 0.72, 0.95) });
  return pg;
}
// rows: [[label, value, {bold, color:'red'|'green', head:true}]]
function addTablePage(doc, fonts, S, { title, sub, rows, footer }) {
  let pg = newPage(doc, fonts, S, title, sub), y = A4[1] - 104;
  for (const [k, v, o = {}] of rows) {
    if (y < 70) { pg = newPage(doc, fonts, S, title + ' (davomi)', sub); y = A4[1] - 104; }
    if (o.head) { y -= 8; pg.drawText(S(k), { x: 42, y, size: 10, font: fonts.bold, color: rgb(0.09, 0.07, 0.2) }); y -= 4; pg.drawLine({ start: { x: 42, y }, end: { x: 553, y }, thickness: 1.2, color: rgb(0.43, 0.2, 0.85) }); y -= 15; continue; }
    const font = o.bold ? fonts.bold : fonts.reg, col = o.color === 'red' ? rgb(0.7, 0.1, 0.1) : o.color === 'green' ? rgb(0.05, 0.45, 0.25) : rgb(0.1, 0.1, 0.15);
    const lines = wrap(font, S(v == null || v === '' ? '—' : String(v)), 9, [300]);
    pg.drawText(S(k), { x: 42, y, size: 9, font: fonts.reg, color: rgb(0.38, 0.38, 0.45) });
    lines.forEach((t, i) => { const tw = font.widthOfTextAtSize(t, 9); pg.drawText(t, { x: 553 - tw, y: y - i * 11, size: 9, font, color: col }); });
    y -= 13 + (lines.length - 1) * 11;
    pg.drawLine({ start: { x: 42, y: y + 8 }, end: { x: 553, y: y + 8 }, thickness: 0.3, color: rgb(0.85, 0.85, 0.88) });
    y -= 3;
  }
  if (footer) doc.getPages().slice(-1)[0].drawText(S(footer), { x: 42, y: 15, size: 6, font: fonts.reg, color: rgb(0.42, 0.42, 0.42) });
  return pg;
}
// images: [{ bytes, type:'jpg'|'png', caption }]
async function addPhotosPage(doc, fonts, S, { title, sub, images }) {
  if (!images.length) return;
  let pg = newPage(doc, fonts, S, title, sub), i = 0;
  const cw = 245, ch = 175;
  for (const im of images) {
    const col = i % 2, row = Math.floor(i / 2) % 4;
    if (i > 0 && i % 8 === 0) pg = newPage(doc, fonts, S, title + ' (davomi)', sub);
    let emb; try { emb = im.type === 'png' ? await doc.embedPng(im.bytes) : await doc.embedJpg(im.bytes); } catch { i++; continue; }
    const sc = Math.min(cw / emb.width, (ch - 14) / emb.height), w = emb.width * sc, h = emb.height * sc;
    const x = 42 + col * (cw + 20), yTop = A4[1] - 96 - row * (ch + 14);
    pg.drawImage(emb, { x: x + (cw - w) / 2, y: yTop - 14 - h, width: w, height: h });
    pg.drawText(S(im.caption || ''), { x, y: yTop - 10, size: 7, font: fonts.reg, color: rgb(0.4, 0.4, 0.45) });
    i++;
  }
}

module.exports = { renderTemplate, addTablePage, addPhotosPage, fit, wrap };
