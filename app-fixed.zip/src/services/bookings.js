const db = require('../db');
const settings = require('./settings');
const { notify, notifyDocument } = require('./notify');
const contracts = require('./contract');
const econtract = require('./econtract');
const { computeSettlement } = require('../contract/settlement');
const features = require('./features');
const { audit } = require('../audit');
const { AppError, fmtDate, fmtDT, money } = require('../util');

const ACTIVE_STATES = ['PENDING', 'CONFIRMED', 'ACTIVE', 'OVERDUE'];
const int = (v, name = 'Qiymat') => {
  const n = Number(v);
  if (!Number.isInteger(n) || n < 0) throw new AppError(400, `${name} musbat butun son bo'lishi kerak`);
  return n;
};

// ---------- NARX HISOBLASH (faqat backendda, butun sonlarda) ----------
const rentalDays = (pickup, ret) => Math.max(1, Math.ceil((ret - pickup) / 864e5));
// 3+/7+ kunlik narx kiritilmagan (0) bo'lsa — kunlik narx olinadi
const rateFor = (car, days) => { const d = Number(car.price_day) || 0, p3 = Number(car.price_3d) || d, p7 = Number(car.price_7d) || p3; return days >= 7 ? p7 : days >= 3 ? p3 : d; };

async function resolveExtras(items, days, trusted) {
  if (!Array.isArray(items) || !items.length || !(await features.enabled('extras'))) return [];
  const catalog = JSON.parse(await settings.get('extras_catalog'));
  return items.map(it => {
    const qty = Math.min(20, Math.max(1, parseInt(it.qty || 1, 10)));
    const cat = catalog.find(c => c.name === it.name);
    if (!cat && !trusted) throw new AppError(400, `Qo'shimcha xizmat topilmadi: ${it.name}`);
    const unit = cat ? cat.price : int(it.unit_price, 'Xizmat narxi');
    const mult = cat && cat.per === 'day' ? days : 1;
    return { name: String(it.name).slice(0, 80), qty, unit_price: unit * mult, total: unit * mult * qty };
  });
}

async function findPromo(client, code, days, rental) {
  if (!code) return { promo: null, discount: 0 };
  if (!(await features.enabled('promo'))) throw new AppError(400, 'Promo kodlar hozir ishlamaydi');
  const { rows } = await client.query(`SELECT * FROM promo_codes WHERE upper(code)=upper($1) AND is_active FOR UPDATE`, [String(code).trim()]);
  const p = rows[0];
  if (!p) throw new AppError(400, 'Promo kod topilmadi yoki faol emas');
  const today = new Date();
  if (p.valid_from && today < new Date(p.valid_from)) throw new AppError(400, 'Promo kod hali amal qilmaydi');
  if (p.valid_until && today > new Date(new Date(p.valid_until).getTime() + 864e5)) throw new AppError(400, 'Promo kod muddati tugagan');
  if (p.usage_limit != null && p.used_count >= p.usage_limit) throw new AppError(400, 'Promo kod limiti tugagan');
  if (days < p.min_days) throw new AppError(400, `Bu promo kod kamida ${p.min_days} kunlik ijara uchun`);
  let discount = p.percent ? Math.floor(rental * p.percent / 100) : Number(p.fixed_amount);
  discount = Math.min(discount, rental);
  return { promo: p, discount };
}

// Yetkazib berish narxi: sozlamada bo'sh bo'lsa xizmat o'chiq
async function deliveryFee() { const v = await settings.get('delivery_fee'); return v === '' || v == null || isNaN(Number(v)) ? null : Math.max(0, Math.round(Number(v))); }
async function quote(client, { car, pickup, ret, promo_code, extras, trusted = false, delivery = false, hourly = false, rental_override = null }) {
  if (!(ret > pickup)) throw new AppError(400, "Qaytarish vaqti olish vaqtidan keyin bo'lishi kerak");
  let days = rentalDays(pickup, ret);
  let rate = rateFor(car, days);
  let rental = rate * days;
  const hours = Math.max(1, Math.ceil((ret - pickup) / 36e5));
  // Soatbay ijara (tezkor shartnoma): 24 soatgacha — soatlik narx (kiritilmagan bo'lsa kunlik/24), lekin kunlik narxdan oshmaydi
  if (hourly && (ret - pickup) <= 864e5) {
    const day = Number(car.price_day) || 0, hr = Number(car.price_hour) || Math.round(day / 24);
    rental = hr * hours; if (day > 0) rental = Math.min(rental, day); rate = day || hr * 24; days = 1;
  }
  if (rental_override != null) rental = int(rental_override, 'Narx');
  const { promo, discount } = await findPromo(client, promo_code, days, rental);
  const items = await resolveExtras(extras, days, trusted);
  let dFee = 0;
  if (delivery) { const f = await deliveryFee(); if (f == null) throw new AppError(400, 'Yetkazib berish xizmati hozircha mavjud emas'); dFee = f; if (f > 0) items.push({ name: 'Yetkazib berish', qty: 1, unit_price: f, total: f }); }
  const extrasTotal = items.reduce((s, i) => s + i.total, 0);
  const total = rental - discount + extrasTotal;
  const deposit = Number(car.deposit);
  return { days, hours, rate, rental, discount, promo, items, delivery_fee: dFee, extras_amount: extrasTotal, total, deposit, grand_total: total + deposit };
}

// ---------- AVTOMOBIL HOLATI ----------
async function setCarStatus(client, carId, newStatus, user, note) {
  const { rows } = await client.query('SELECT status FROM cars WHERE id=$1 FOR UPDATE', [carId]);
  if (!rows[0] || rows[0].status === newStatus) return;
  await client.query('UPDATE cars SET status=$2 WHERE id=$1', [carId, newStatus]);
  await client.query('INSERT INTO car_status_history(car_id,old_status,new_status,changed_by,note) VALUES($1,$2,$3,$4,$5)',
    [carId, rows[0].status, newStatus, user?.id || null, note || null]);
  await audit(user, 'STATUS', 'car', carId, { status: rows[0].status }, { status: newStatus }, null, client);
}
// Yaqin 24 soatda tasdiqlangan bron bo'lsa RESERVED, bo'lmasa AVAILABLE (RENTED/MAINTENANCE/INACTIVE ga tegmaydi)
async function syncCarStatuses(client = db) {
  const toRes = await client.query(`SELECT c.id FROM cars c WHERE c.status='AVAILABLE' AND c.deleted_at IS NULL AND EXISTS
    (SELECT 1 FROM bookings b WHERE b.car_id=c.id AND b.status='CONFIRMED' AND b.deleted_at IS NULL AND b.pickup_at <= now()+interval '24 hours')`);
  const toAv = await client.query(`SELECT c.id FROM cars c WHERE c.status='RESERVED' AND c.deleted_at IS NULL AND NOT EXISTS
    (SELECT 1 FROM bookings b WHERE b.car_id=c.id AND b.status='CONFIRMED' AND b.deleted_at IS NULL AND b.pickup_at <= now()+interval '24 hours')`);
  for (const r of toRes.rows) await db.tx(c => setCarStatus(c, r.id, 'RESERVED', null, 'Avtomatik: bron yaqinlashdi'));
  for (const r of toAv.rows) await db.tx(c => setCarStatus(c, r.id, 'AVAILABLE', null, 'Avtomatik: bron yo\'q'));
}

// ---------- BRON YARATISH ----------
async function createBooking(input, user, req) {
  const { customer_id, car_id, pickup_at, return_at, location = null, promo_code, extras, source = 'ADMIN', notes = null, consent = null, hourly = false, rental_override = null, silent = false } = input;
  const delivery_address = input.delivery_address ? String(input.delivery_address).trim().slice(0, 250) : null;
  const trusted = source === 'ADMIN';
  // Mijoz o'zi bron qilsa (bot / Mini App) — shartnoma shartlariga rozilik MAJBURIY
  // Elektron shartnoma (FORM) faol bo'lsa: rozilik buyurtmadan KEYIN, shartnomani o'qib OTP bilan beriladi
  const tplActive = trusted ? await contracts.getActive() : await contracts.requireActive();
  const formFlow = !!tplActive && tplActive.kind === 'FORM';
  if (!trusted && !formFlow) {
    if (!consent || !consent.accepted) throw new AppError(400, "Davom etish uchun shartnoma shartlarini o'qib, rozilik bering", 'CONSENT_REQUIRED');
  }
  const pickup = new Date(pickup_at), ret = new Date(return_at);
  if (isNaN(pickup) || isNaN(ret)) throw new AppError(400, "Sana yoki vaqt noto'g'ri");
  if (pickup < new Date(Date.now() - 3600e3)) throw new AppError(400, "Olish vaqti o'tib ketgan");
  if ((ret - pickup) > 90 * 864e5) throw new AppError(400, "Ijara muddati 90 kundan oshmasligi kerak");

  const result = await db.tx(async c => {
    const car = (await c.query('SELECT * FROM cars WHERE id=$1 AND deleted_at IS NULL FOR UPDATE', [car_id])).rows[0];
    if (!car) throw new AppError(404, 'Mashina topilmadi');
    if (['INACTIVE', 'MAINTENANCE'].includes(car.status)) throw new AppError(409, `Mashina hozir ijaraga berilmaydi (${car.status === 'MAINTENANCE' ? "ta'mirda" : 'faol emas'})`);
    const cust = (await c.query('SELECT * FROM customers WHERE id=$1 AND deleted_at IS NULL', [customer_id])).rows[0];
    if (!cust) throw new AppError(404, 'Mijoz topilmadi');
    if (cust.is_blocked) throw new AppError(403, 'Mijoz bloklangan');

    const clash = (await c.query(`SELECT code,pickup_at,return_at FROM bookings WHERE car_id=$1 AND status = ANY($2)
      AND deleted_at IS NULL AND tstzrange(pickup_at,return_at,'[)') && tstzrange($3,$4,'[)') LIMIT 1`, [car_id, ACTIVE_STATES, pickup, ret])).rows[0];
    if (clash) throw new AppError(409, `Bu mashina tanlangan vaqtda band (${clash.code}: ${fmtDT(clash.pickup_at)} — ${fmtDT(clash.return_at)})`, 'DOUBLE_BOOKING');

    const q = await quote(c, { car, pickup, ret, promo_code, extras, trusted, delivery: !!delivery_address, hourly, rental_override });
    const id = (await c.query(`SELECT nextval(pg_get_serial_sequence('bookings','id')) id`)).rows[0].id;
    const code = 'BK-' + String(id).padStart(6, '0');
    try {
      await c.query(`INSERT INTO bookings(id,code,customer_id,car_id,pickup_at,return_at,pickup_location,days,daily_rate,rental_amount,discount,
        extras_amount,deposit_amount,total_amount,promo_id,source,created_by,notes,delivery_address,delivery_fee) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20)`,
        [id, code, customer_id, car_id, pickup, ret, location, q.days, q.rate, q.rental, q.discount, q.extras_amount, q.deposit, q.total,
          q.promo?.id || null, source, user?.id || null, notes, delivery_address, q.delivery_fee || 0]);
    } catch (e) {
      if (e.code === '23P01') throw new AppError(409, 'Bu mashina tanlangan vaqtda band', 'DOUBLE_BOOKING'); // DB darajasidagi himoya
      throw e;
    }
    if (!trusted && !formFlow) await contracts.recordConsent(c, { booking_id: id, customer_id, template_id: consent.template_id, channel: source === 'BOT' ? 'BOT' : 'MINIAPP', telegram_id: cust.telegram_id, ip: consent.ip, ua: consent.ua });
    for (const it of q.items) await c.query('INSERT INTO booking_items(booking_id,name,qty,unit_price,total) VALUES($1,$2,$3,$4,$5)', [id, it.name, it.qty, it.unit_price, it.total]);
    await c.query('INSERT INTO deposits(booking_id,amount) VALUES($1,$2)', [id, q.deposit]);
    if (formFlow) await econtract.createDraft(c, id);   // har bir buyurtmaga aniq bitta shartnoma
    if (q.promo) await c.query('UPDATE promo_codes SET used_count=used_count+1 WHERE id=$1', [q.promo.id]);
    await audit(user || { name: `Mijoz #${customer_id}` }, 'CREATE', 'booking', id, null, { code, car_id, total: q.total }, req, c);
    return { id, code, car, cust, q, pickup, ret };
  });

  const { car, cust, q } = result;
  if (!silent) await notify({
    audience: 'ADMIN', type: 'NEW_BOOKING', title: 'YANGI BUYURTMA', ref_key: `new:${result.id}`,
    body: `Mijoz: ${cust.first_name} ${cust.last_name}\nTelefon: ${cust.phone}\nMashina: ${car.brand} ${car.model} (${car.plate})\n${fmtDate(result.pickup)} — ${fmtDate(result.ret)}\nIjara: ${money(q.total)}\nDepozit: ${money(q.deposit)}${delivery_address ? '\n🚚 Yetkazib berish: ' + delivery_address : ''}`,
    keyboard: [[{ text: '✅ Tasdiqlash', callback_data: `bk:ok:${result.id}` }, { text: '❌ Rad etish', callback_data: `bk:no:${result.id}` }],
      [{ text: '💬 Mijoz bilan bog\'lanish', callback_data: `bk:ct:${result.id}` }]],
  });
  return getBooking(result.id);
}

async function getBooking(id) {
  const { rows } = await db.query(`SELECT b.*, c.first_name,c.last_name,c.phone,c.telegram_id customer_tg, car.brand,car.model,car.plate,car.image_url,
      d.held_amount dep_held,d.deducted_amount dep_deducted,d.returned_amount dep_returned,d.status dep_status,
      (b.total_amount-b.paid_amount) AS remaining
    FROM bookings b JOIN customers c ON c.id=b.customer_id JOIN cars car ON car.id=b.car_id LEFT JOIN deposits d ON d.booking_id=b.id
    WHERE b.id=$1 AND b.deleted_at IS NULL`, [id]);
  if (!rows[0]) throw new AppError(404, 'Buyurtma topilmadi');
  const b = rows[0];
  b.items = (await db.query('SELECT name,qty,unit_price,total FROM booking_items WHERE booking_id=$1 ORDER BY id', [id])).rows;
  b.payments = (await db.query('SELECT * FROM payments WHERE booking_id=$1 ORDER BY paid_at,id', [id])).rows;
  b.inspections = (await db.query('SELECT * FROM car_inspections WHERE booking_id=$1 ORDER BY inspected_at', [id])).rows;
  b.contract = (await db.query('SELECT number,generated_at FROM rental_contracts WHERE booking_id=$1', [id])).rows[0] || null;
  b.consent = await contracts.getConsent(id);
  b.econtract = await econtract.blockForBooking(id);
  b.settlement = (await db.query('SELECT data FROM return_settlements WHERE booking_id=$1', [id])).rows[0]?.data || null;
  return b;
}

async function lockBooking(c, id, statuses, msg) {
  const b = (await c.query('SELECT * FROM bookings WHERE id=$1 AND deleted_at IS NULL FOR UPDATE', [id])).rows[0];
  if (!b) throw new AppError(404, 'Buyurtma topilmadi');
  if (!statuses.includes(b.status)) throw new AppError(409, msg || `Buyurtma holati mos emas (${b.status})`);
  return b;
}

// ---------- TASDIQLASH / RAD ETISH ----------
async function confirmBooking(id, user, req) {
  await db.tx(async c => {
    const b = await lockBooking(c, id, ['PENDING'], 'Faqat PENDING buyurtmani tasdiqlash mumkin');
    const car = (await c.query('SELECT status FROM cars WHERE id=$1', [b.car_id])).rows[0];
    if (car.status === 'INACTIVE') throw new AppError(409, 'Mashina faol emas');
    await c.query(`UPDATE bookings SET status='CONFIRMED' WHERE id=$1`, [id]);
    await audit(user, 'CONFIRM', 'booking', id, { status: 'PENDING' }, { status: 'CONFIRMED' }, req, c);
  });
  await syncCarStatuses();
  const b = await getBooking(id);
  const MON = ['Yan', 'Fev', 'Mar', 'Apr', 'May', 'Iyn', 'Iyl', 'Avg', 'Sen', 'Okt', 'Noy', 'Dek'];
  const sh = d => { const t = new Date(new Date(d).getTime() + 5 * 3600e3); return `${t.getUTCDate()} ${MON[t.getUTCMonth()]}`; };
  await notify({ audience: 'CUSTOMER', customer_id: b.customer_id, type: 'BOOKING_CONFIRMED', title: '✅ BRON TASDIQLANDI',
    body: `━━━━━━━━━━━━━━━━\n\n🚗 ${b.brand} ${b.model}\n\n📅 ${sh(b.pickup_at)} — ${sh(b.return_at)}  (${fmtDT(b.pickup_at).slice(-5)})\n\n💰 Jami:\n${money(Number(b.total_amount) + Number(b.deposit_amount || 0))}  (depozit ${money(b.deposit_amount)} shu jumladan)\n\n🆔 #${b.code}\n\n━━━━━━━━━━━━━━━━`, ref_key: `conf:${id}`,
    keyboard: [[{ text: "📋 Buyurtmani ko'rish", callback_data: 'm:orders' }], [{ text: '🏠 Bosh sahifa', callback_data: 'm:home' }]] });
  const ec = await econtract.byBooking(id);
  if (ec) { if (ec.status !== 'APPROVED' && b.customer_tg) await requestSign(id).catch(e => console.error('Imzo so\'rovi yuborilmadi:', e.message)); }
  else {
    await deliverContract(id, 'doc').catch(e => console.error('Shartnoma yuborilmadi:', e.message));
    // Rozilik hali yo'q bo'lsa (admin yaratgan buyurtma) — mijozga shartlarni o'qib rozilik berish so'rovi yuboriladi
    if (!b.consent && b.customer_tg) await contracts.sendConsentRequest(id).catch(e => console.error('Rozilik so\'rovi yuborilmadi:', e.message));
  }
  return getBooking(id);
}
// Mijozga Telegramda: shartnomani Mini App da o'qib, OTP bilan tasdiqlash so'rovi
async function requestSign(bookingId) {
  const ec = await econtract.byBooking(bookingId); if (!ec) throw new AppError(404, 'Elektron shartnoma topilmadi');
  if (ec.status === 'APPROVED') throw new AppError(409, 'Shartnoma allaqachon tasdiqlangan');
  const base = require('../config').publicUrl;
  const kb = base.startsWith('https://') ? [[{ text: '📄 Shartnomani ochish va tasdiqlash', web_app: { url: `${base}/app/?contract=${ec.id}` } }]] : null;
  const b = await getBooking(bookingId);
  const id = await notify({ audience: 'CUSTOMER', customer_id: b.customer_id, type: 'ECONTRACT_SIGN', title: '📄 Shartnomani tasdiqlang', ref_key: `esign:${ec.id}:${Math.floor(Date.now() / 3600e3)}`,
    body: `${ec.number} · ${b.brand} ${b.model}\nShartnomani oxirigacha o'qib, rozilik belgilarini qo'ying va OTP kod bilan tasdiqlang. Mashina shundan keyin topshiriladi.`, keyboard: kb });
  if (id == null) throw new AppError(429, "Bu so'rov yaqinda yuborilgan");
  return { sent: true };
}
// PDF shartnomani yaratadi va mijozga Telegramda yuboradi
async function deliverContract(id, tag) {
  const g = await contracts.generate(id);
  const b = await getBooking(id);
  await notifyDocument({ customer_id: b.customer_id, filePath: g.file, ref_key: `${tag}:${id}`, caption: `📄 Ijara shartnomasi ${g.number}\n${b.brand} ${b.model} · ${fmtDT(b.pickup_at)} — ${fmtDT(b.return_at)}` });
  return g;
}
// Qog'ozda imzolangan rozilikni xodim qayd etadi (audit logga yoziladi)
async function recordPaperConsent(id, user, req) {
  const cust = await db.tx(async c => {
    const b = await lockBooking(c, id, ['PENDING', 'CONFIRMED'], "Rozilikni faqat tasdiqlanmagan yoki tasdiqlangan buyurtmaga qayd etish mumkin");
    const r = await contracts.recordConsent(c, { booking_id: id, customer_id: b.customer_id, channel: 'PAPER', recorded_by: user?.id || null });
    if (!r.created) throw new AppError(409, 'Rozilik allaqachon qayd etilgan');
    await audit(user, 'CONSENT_PAPER', 'booking', id, null, { template: r.template.version }, req, c);
    return b;
  });
  if (cust.status === 'CONFIRMED' && !(await econtract.byBooking(id))) await contracts.generate(id).catch(() => {});
  return getBooking(id);
}
// Mijoz botda «O'qidim, roziman» tugmasini bosdi
async function acceptViaBot(bookingId, templateId, tgId) {
  const res = await db.tx(async c => {
    const b = (await c.query(`SELECT b.*,cu.telegram_id FROM bookings b JOIN customers cu ON cu.id=b.customer_id WHERE b.id=$1 FOR UPDATE OF b`, [bookingId])).rows[0];
    if (!b || String(b.telegram_id) !== String(tgId)) throw new AppError(403, "Bu buyurtma sizga tegishli emas");
    if (!['PENDING', 'CONFIRMED'].includes(b.status)) throw new AppError(409, 'Buyurtma holati o\'zgargan');
    const r = await contracts.recordConsent(c, { booking_id: bookingId, customer_id: b.customer_id, template_id: templateId, channel: 'BOT', telegram_id: tgId });
    if (r.created) await audit({ name: `Mijoz #${b.customer_id}` }, 'CONSENT', 'booking', bookingId, null, { channel: 'BOT', template: r.template.version }, null, c);
    return { b, created: r.created };
  });
  if (res.created) {
    if (res.b.status === 'CONFIRMED') await deliverContract(bookingId, 'docc').catch(e => console.error(e.message));
    const full = await getBooking(bookingId);
    await notify({ audience: 'ADMIN', type: 'CONSENT', title: '✅ Mijoz shartnomaga rozilik berdi', ref_key: `consent:${bookingId}`, body: `${full.code} — ${full.first_name} ${full.last_name}\n${full.brand} ${full.model}` });
  }
  return res.created;
}

async function cancelBooking(id, user, req, { reason = '', refund_method = 'CASH', refund_paid = false } = {}) {
  await db.tx(async c => {
    const b = await lockBooking(c, id, ['PENDING', 'CONFIRMED'], "Faqat PENDING yoki CONFIRMED buyurtmani bekor qilish mumkin");
    await c.query(`UPDATE bookings SET status='CANCELLED', notes=CASE WHEN $2<>'' THEN COALESCE(notes||E'\\n','')||'Bekor: '||$2 ELSE notes END WHERE id=$1`, [id, reason]);
    if (b.promo_id) await c.query('UPDATE promo_codes SET used_count=GREATEST(used_count-1,0) WHERE id=$1', [b.promo_id]);
    const dep = (await c.query('SELECT * FROM deposits WHERE booking_id=$1 FOR UPDATE', [id])).rows[0];
    if (dep && Number(dep.held_amount) > 0) {
      await c.query(`INSERT INTO payments(booking_id,customer_id,amount,kind,method,created_by) VALUES($1,$2,$3,'REFUND',$4,$5)`, [id, b.customer_id, dep.held_amount, refund_method, user?.id || null]);
      await c.query(`UPDATE deposits SET returned_amount=held_amount,status='RETURNED',returned_at=now() WHERE id=$1`, [dep.id]);
    }
    if (Number(b.paid_amount) > 0 && refund_paid) {
      await c.query(`INSERT INTO payments(booking_id,customer_id,amount,kind,method,created_by) VALUES($1,$2,$3,'RENTAL_REFUND',$4,$5)`, [id, b.customer_id, b.paid_amount, refund_method, user?.id || null]);
      await c.query('UPDATE bookings SET paid_amount=0 WHERE id=$1', [id]);
    }
    await econtract.cancelForBooking(c, id, reason || 'Buyurtma bekor qilindi');
    await audit(user, 'CANCEL', 'booking', id, { status: b.status }, { status: 'CANCELLED', reason }, req, c);
  });
  await syncCarStatuses();
  const b = await getBooking(id);
  await notify({ audience: 'CUSTOMER', customer_id: b.customer_id, type: 'BOOKING_CANCELLED', title: 'Buyurtma bekor qilindi',
    body: `${b.code}: ${b.brand} ${b.model}${reason ? '\nSabab: ' + reason : ''}`, ref_key: `canc:${id}` });
  return b;
}

// ---------- TO'LOV ----------
async function addPayment(input, user, req) {
  const { booking_id, kind = 'RENTAL', method, provider = null, provider_txn_id = null, status = 'PAID' } = input;
  const amount = int(input.amount, "To'lov summasi");
  if (amount <= 0) throw new AppError(400, "To'lov summasi 0 dan katta bo'lishi kerak");
  if (!['CASH', 'CARD', 'ONLINE', 'BANK_TRANSFER'].includes(method)) throw new AppError(400, "To'lov usuli noto'g'ri");
  if (!['RENTAL', 'DEPOSIT', 'EXTRA'].includes(kind)) throw new AppError(400, "To'lov turi noto'g'ri");
  const pid = await db.tx(async c => {
    const b = await lockBooking(c, booking_id, ['PENDING', 'CONFIRMED', 'ACTIVE', 'OVERDUE', 'COMPLETED'], "Bekor qilingan buyurtmaga to'lov qabul qilinmaydi");
    if (kind === 'DEPOSIT') {
      const d = (await c.query('SELECT * FROM deposits WHERE booking_id=$1 FOR UPDATE', [booking_id])).rows[0];
      if (!d) throw new AppError(404, 'Depozit topilmadi');
      if (b.status === 'COMPLETED') throw new AppError(409, 'Ijara yakunlangan, depozit qabul qilinmaydi');
      if (status === 'PAID') {
        if (Number(d.held_amount) + amount > Number(d.amount)) throw new AppError(400, `Depozit summasidan oshib ketdi (qolgan: ${money(Number(d.amount) - Number(d.held_amount))})`);
        await c.query(`UPDATE deposits SET held_amount=held_amount+$2, status=CASE WHEN held_amount+$2>=amount THEN 'HELD' ELSE status END WHERE id=$1`, [d.id, amount]);
      }
    } else if (status === 'PAID') {
      const remaining = Number(b.total_amount) - Number(b.paid_amount);
      if (amount > remaining) throw new AppError(400, `To'lov qolgan summadan oshib ketdi (qolgan: ${money(remaining)})`);
      await c.query('UPDATE bookings SET paid_amount=paid_amount+$2 WHERE id=$1', [booking_id, amount]);
    }
    const p = (await c.query(`INSERT INTO payments(booking_id,customer_id,amount,kind,method,status,provider,provider_txn_id,created_by)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id`, [booking_id, b.customer_id, amount, kind, method, status, provider, provider_txn_id, user?.id || null])).rows[0];
    await audit(user, 'PAYMENT', 'payment', p.id, null, { booking_id, kind, method, amount }, req, c);
    return p.id;
  });
  const b = await getBooking(booking_id);
  await notify({ audience: 'CUSTOMER', customer_id: b.customer_id, type: 'PAYMENT_RECEIVED', title: "To'lov qabul qilindi 💰",
    body: `${b.code}: ${money(amount)} (${kind === 'DEPOSIT' ? 'depozit' : 'ijara'})\nQolgan: ${money(b.remaining)}`, ref_key: `pay:${pid}` });
  await notify({ audience: 'ADMIN', type: 'PAYMENT', title: "To'lov", body: `${b.code} — ${b.first_name} ${b.last_name}: ${money(amount)}`, ref_key: `apay:${pid}` });
  return { payment_id: pid, booking: b };
}

// ---------- MASHINA TOPSHIRISH ----------
async function handover(id, input, user, req) {
  await db.tx(async c => {
    const b = await lockBooking(c, id, ['CONFIRMED'], "Faqat tasdiqlangan (CONFIRMED) buyurtma bo'yicha mashina beriladi");
    const car = (await c.query('SELECT * FROM cars WHERE id=$1 FOR UPDATE', [b.car_id])).rows[0];
    if (!['AVAILABLE', 'RESERVED'].includes(car.status)) throw new AppError(409, `Mashina hozir topshirishga tayyor emas (${car.status})`);
    const ecx = await econtract.byBooking(id, c);
    if (ecx) {
      if (ecx.status !== 'APPROVED' && !(await contracts.getConsent(id, c))) throw new AppError(409, "Elektron shartnoma mijoz tomonidan OTP bilan tasdiqlanmagan. Mijozga imzo so'rovini yuboring (yoki qog'ozda imzolangan bo'lsa shuni qayd eting).", 'CONTRACT_NOT_SIGNED');
    } else if (!(await contracts.getConsent(id, c)) && (await contracts.getActive(c))) throw new AppError(409, "Mijoz shartnoma shartlari bilan rozilik bermagan. Rozilik so'rovini yuboring yoki qog'ozda imzolangan bo'lsa shuni qayd eting.", 'CONSENT_MISSING');
    const dep = (await c.query('SELECT * FROM deposits WHERE booking_id=$1', [id])).rows[0];
    if (dep && Number(dep.held_amount) < Number(dep.amount) && !input.force)
      throw new AppError(409, `Depozit to'liq qabul qilinmagan (${money(dep.held_amount)} / ${money(dep.amount)})`, 'DEPOSIT_MISSING');
    const mileage = input.mileage == null ? car.mileage : int(input.mileage, 'Kilometr');
    if (mileage < car.mileage) throw new AppError(400, `Kilometr mashinadagi ko'rsatkichdan (${car.mileage} km) kam bo'lishi mumkin emas`);
    const fuel = input.fuel_level == null ? car.fuel_level : Math.min(100, int(input.fuel_level, "Yoqilg'i"));
    await c.query(`INSERT INTO car_inspections(booking_id,car_id,stage,mileage,fuel_level,body_condition,interior_condition,damages,photos,video_url,staff_id,equipment,cleanliness,admin_note,customer_note,video_file)
      VALUES($1,$2,'HANDOVER',$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)`, [id, b.car_id, mileage, fuel, input.body_condition || null, input.interior_condition || null,
      input.damages || null, JSON.stringify(input.photos || []), input.video_url || null, user?.id || null, input.equipment ? JSON.stringify(input.equipment) : null,
      input.cleanliness == null ? null : !!input.cleanliness, input.admin_note || null, input.customer_note || null, input.video_file || null]);
    await c.query(`UPDATE bookings SET status='ACTIVE', actual_pickup_at=now() WHERE id=$1`, [id]);
    await c.query('UPDATE cars SET mileage=$2, fuel_level=$3 WHERE id=$1', [b.car_id, mileage, fuel]);
    await setCarStatus(c, b.car_id, 'RENTED', user, `Berildi: ${b.code}`);
    await audit(user, 'HANDOVER', 'booking', id, { status: 'CONFIRMED' }, { status: 'ACTIVE', mileage, fuel }, req, c);
  });
  const warnings = [];
  await econtract.createAct(id, 'HANDOVER', user).catch(e => { console.error('Topshirish dalolatnomasi:', e.message); warnings.push('Topshirish dalolatnomasi yaratilmadi: ' + e.message); });
  const b = await getBooking(id); b.warnings = warnings;
  await notify({ audience: 'CUSTOMER', customer_id: b.customer_id, type: 'RENTAL_STARTED', title: 'Ijara boshlandi 🚗',
    body: `${b.code}: ${b.brand} ${b.model}\nQaytarish: ${fmtDT(b.return_at)}`, ref_key: `start:${id}` });
  return b;
}

// ---------- MASHINA QAYTARISH ----------
async function returnCar(id, input, user, req) {
  const grace = await settings.getNum('late_grace_minutes');
  const perHour = await settings.getNum('late_fee_per_hour');
  let summary;
  await db.tx(async c => {
    const b = await lockBooking(c, id, ['ACTIVE', 'OVERDUE'], "Faqat ACTIVE yoki OVERDUE buyurtma qaytariladi");
    const start = (await c.query(`SELECT * FROM car_inspections WHERE booking_id=$1 AND stage='HANDOVER'`, [id])).rows[0];
    if (!start) throw new AppError(409, "Topshirish dalolatnomasi topilmadi");
    const mileage = int(input.mileage, 'Yakuniy kilometr');
    if (mileage < start.mileage) throw new AppError(400, `Yakuniy kilometr boshlang'ichdan (${start.mileage} km) kam bo'lishi mumkin emas`);
    const fuel = Math.min(100, int(input.fuel_level, "Yoqilg'i"));
    const damageFee = input.damage_fee ? int(input.damage_fee, 'Zarar summasi') : 0;

    const now = new Date();
    const lateMin = Math.max(0, Math.floor((now - new Date(b.return_at)) / 60000));
    const lateHours = lateMin > grace ? Math.ceil(lateMin / 60) : 0;
    const lateFee = lateHours * perHour;

    // Shartnoma shartlari (km limiti, ortiqcha km narxi, jarimalar) — mijoz imzolagan versiyadan olinadi
    const ec = await econtract.byBooking(id, c);
    const terms = ec ? ((await econtract.templateById(ec.template_id, c)).terms || {}) : {};
    const dep = (await c.query('SELECT * FROM deposits WHERE booking_id=$1 FOR UPDATE', [id])).rows[0];
    const held = Number(dep?.held_amount || 0);
    const base = { start_km: start.mileage, end_km: mileage, days: b.days, km_limit_day: terms.km_limit_day || 0, extra_km_price: terms.extra_km_price || 0, late_fee: lateFee, damage_fee: damageFee, fines: input.fines, terms, other_fee: input.other_fee };
    const pre = computeSettlement({ ...base, deposit_held: 0 });
    const total = Number(b.rental_amount) - Number(b.discount) + Number(b.extras_amount) + pre.charges_total;
    const outstanding = Math.max(0, total - Number(b.paid_amount));
    const st = computeSettlement({ ...base, deposit_held: held, cap: outstanding, deduct: input.use_deposit === false ? 0 : input.deduct });
    const deduct = st.deposit_deducted, refund = st.deposit_refund;

    await c.query(`INSERT INTO car_inspections(booking_id,car_id,stage,mileage,fuel_level,body_condition,interior_condition,damages,photos,video_url,staff_id,equipment,cleanliness,admin_note,customer_note,video_file)
      VALUES($1,$2,'RETURN',$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)`, [id, b.car_id, mileage, fuel, input.body_condition || null, input.interior_condition || null,
      input.damages || null, JSON.stringify(input.photos || []), input.video_url || null, user?.id || null, input.equipment ? JSON.stringify(input.equipment) : null,
      input.cleanliness == null ? null : !!input.cleanliness, input.admin_note || null, input.customer_note || null, input.video_file || null]);

    if (deduct > 0) {
      await c.query(`INSERT INTO payments(booking_id,customer_id,amount,kind,method,provider,created_by) VALUES($1,$2,$3,'DEPOSIT_DEDUCTION','CASH','deposit',$4)`, [id, b.customer_id, deduct, user?.id || null]);
    }
    if (refund > 0) {
      await c.query(`INSERT INTO payments(booking_id,customer_id,amount,kind,method,created_by) VALUES($1,$2,$3,'REFUND',$4,$5)`, [id, b.customer_id, refund, input.refund_method || 'CASH', user?.id || null]);
    }
    if (dep) {
      const status = deduct === 0 ? 'RETURNED' : refund > 0 ? 'PARTIALLY_RETURNED' : 'FORFEITED';
      const parts = [st.late_fee ? 'kechikish' : '', st.damage_fee ? 'zarar' : '', st.extra_km_fee ? 'ortiqcha km' : '', st.fines_total ? 'jarima' : '', st.other_fee ? 'boshqa' : ''].filter(Boolean).join(' + ');
      await c.query(`UPDATE deposits SET deducted_amount=$2, returned_amount=$3, status=$4, deduction_reason=$5, returned_at=now() WHERE id=$1`,
        [dep.id, deduct, refund, held === 0 ? dep.status : status, deduct > 0 ? (input.deduction_reason || parts) : null]);
    }
    const paid = Number(b.paid_amount) + deduct;
    await c.query(`UPDATE bookings SET status='COMPLETED', actual_return_at=$2, late_fee=$3, damage_fee=$4, extra_km_fee=$7, fines_fee=$8, other_fee=$9, total_amount=$5, paid_amount=$6 WHERE id=$1`,
      [id, now, lateFee, damageFee, total, paid, st.extra_km_fee, st.fines_total, st.other_fee]);
    await c.query(`INSERT INTO return_settlements(booking_id,data,charges_total,deposit_deducted,deposit_refund,balance_due,created_by) VALUES($1,$2,$3,$4,$5,$6,$7)`,
      [id, JSON.stringify({ ...st, other_note: String(input.other_note || '').slice(0, 300), contract_version: ec ? ec.version_label : null }), st.charges_total, deduct, refund, Math.max(0, total - paid), user?.id || null]);
    await c.query('UPDATE cars SET mileage=$2, fuel_level=$3 WHERE id=$1', [b.car_id, mileage, fuel]);
    await setCarStatus(c, b.car_id, input.send_to_maintenance ? 'MAINTENANCE' : 'AVAILABLE', user, `Qaytdi: ${b.code}`);
    if (lateFee > 0) await c.query('UPDATE customers SET late_count=late_count+1 WHERE id=$1', [b.customer_id]);
    if (damageFee > 0) await c.query('UPDATE customers SET damage_total=damage_total+$2 WHERE id=$1', [b.customer_id, damageFee]);
    await audit(user, 'RETURN', 'booking', id, { status: b.status }, { status: 'COMPLETED', lateMin, lateFee, damageFee, extra_km_fee: st.extra_km_fee, fines: st.fines_total, deduct, refund }, req, c);
    summary = { late_minutes: lateMin, late_fee: lateFee, damage_fee: damageFee, driven_km: st.driven_km, extra_km: st.extra_km, extra_km_fee: st.extra_km_fee, fines_total: st.fines_total, other_fee: st.other_fee,
      charges_total: st.charges_total, deposit_deducted: deduct, deposit_returned: refund, total, remaining: total - paid };
  });
  await syncCarStatuses();
  const warnings = [];
  await econtract.createAct(id, 'RETURN', user).catch(e => { console.error('Qaytarish dalolatnomasi:', e.message); warnings.push('Qaytarish dalolatnomasi yaratilmadi: ' + e.message); });
  const b = await getBooking(id);
  await notify({ audience: 'ADMIN', type: 'CAR_RETURNED', title: 'Mashina qaytdi', ref_key: `ret:${id}`,
    body: `${b.code}: ${b.brand} ${b.model} (${b.plate})\nYurilgan: ${summary.driven_km} km${summary.extra_km ? ` (ortiqcha ${summary.extra_km} km)` : ''}${summary.late_fee ? `\nKechikish haqi: ${money(summary.late_fee)}` : ''}${summary.remaining > 0 ? `\nQoldiq: ${money(summary.remaining)}` : ''}` });
  await notify({ audience: 'CUSTOMER', customer_id: b.customer_id, type: 'RENTAL_ENDED', title: 'Ijara yakunlandi', ref_key: `end:${id}`,
    body: `${b.code}: rahmat! Depozitdan qaytarildi: ${money(summary.deposit_returned)}${summary.remaining > 0 ? `\nQo'shimcha to'lov: ${money(summary.remaining)}` : ''}` });
  return { booking: b, summary, warnings };
}

// Qaytarish hisob-kitobini oldindan ko'rsatish (UI uchun, hech narsa saqlanmaydi)
async function previewReturn(id, input) {
  const b = (await db.query('SELECT * FROM bookings WHERE id=$1 AND deleted_at IS NULL', [id])).rows[0];
  if (!b) throw new AppError(404, 'Buyurtma topilmadi');
  const start = (await db.query(`SELECT mileage FROM car_inspections WHERE booking_id=$1 AND stage='HANDOVER'`, [id])).rows[0];
  if (!start) throw new AppError(409, 'Topshirish dalolatnomasi topilmadi');
  const ec = await econtract.byBooking(id); const terms = ec ? ((await econtract.templateById(ec.template_id)).terms || {}) : {};
  const li = await lateInfo(b); const dep = (await db.query('SELECT held_amount FROM deposits WHERE booking_id=$1', [id])).rows[0];
  return computeSettlement({ start_km: start.mileage, end_km: input.mileage, days: b.days, km_limit_day: terms.km_limit_day || 0, extra_km_price: terms.extra_km_price || 0, late_fee: li.late_fee, damage_fee: input.damage_fee, fines: input.fines, terms, other_fee: input.other_fee, deposit_held: Number(dep?.held_amount || 0), deduct: input.deduct });
}
// Kechikish haqini oldindan hisoblash (UI uchun)
async function lateInfo(b, at = new Date()) {
  const grace = await settings.getNum('late_grace_minutes');
  const perHour = await settings.getNum('late_fee_per_hour');
  const lateMin = Math.max(0, Math.floor((at - new Date(b.return_at)) / 60000));
  const hours = lateMin > grace ? Math.ceil(lateMin / 60) : 0;
  return { late_minutes: lateMin, late_fee: hours * perHour };
}

// ---------- TEZKOR SHARTNOMA: pasport + necha soat (+ mashina) ----------
const normPass = s => String(s || '').replace(/[\s-]+/g, '').toUpperCase();
async function customerByPassport({ passport, name, phone }, user, req) {
  const pass = normPass(passport);
  if (!/^[A-Z0-9]{6,15}$/.test(pass)) throw new AppError(400, "Pasport raqami noto'g'ri (masalan: AB1234567)");
  const { decrypt, encrypt } = require('../util');
  const cands = (await db.query(`SELECT id,is_blocked,passport_enc FROM customers WHERE deleted_at IS NULL AND upper(passport_last4)=$1`, [pass.slice(-3)])).rows;
  const found = cands.find(c => normPass(decrypt(c.passport_enc)) === pass);
  if (found) return found.id;
  const parts = String(name || '').trim().split(/\s+/).filter(Boolean);
  const first = parts[0] || 'Mijoz', last = parts.length > 1 ? parts.slice(1).join(' ') : (parts.length ? '' : '…' + pass.slice(-3));
  let ph = String(phone || '').replace(/\D/g, ''); ph = !ph ? '' : ph.length === 9 ? '+998' + ph : '+' + ph;
  const code = 'C' + Math.random().toString(36).slice(2, 8).toUpperCase();
  const { rows } = await db.query(`INSERT INTO customers(first_name,last_name,phone,passport_enc,passport_last4,referral_code) VALUES($1,$2,$3,$4,$5,$6) RETURNING id`,
    [first, last, ph, encrypt(pass), pass.slice(-3), code]);
  await audit(user, 'CREATE', 'customer', rows[0].id, null, { name: `${first} ${last}`.trim(), via: 'quick-contract' }, req);
  return rows[0].id;
}
async function quickQuote({ car_id, hours, amount }) {
  const car = (await db.query('SELECT * FROM cars WHERE id=$1 AND deleted_at IS NULL', [car_id])).rows[0];
  if (!car) throw new AppError(404, 'Mashina topilmadi');
  const pickup = new Date(Math.floor(Date.now() / 6e4) * 6e4), ret = new Date(pickup.getTime() + hours * 36e5);
  const q = await db.tx(c => quote(c, { car, pickup, ret, trusted: true, hourly: true, rental_override: amount ?? null }));
  delete q.promo; return { ...q, pickup_at: pickup, return_at: ret };
}
async function quickContract({ car_id, passport, hours, name, phone, amount }, user, req, canHandover = true) {
  const customer_id = await customerByPassport({ passport, name, phone }, user, req);
  const pickup = new Date(Math.floor(Date.now() / 6e4) * 6e4), ret = new Date(pickup.getTime() + hours * 36e5);
  const bk = await createBooking({ customer_id, car_id, pickup_at: pickup, return_at: ret, source: 'ADMIN', hourly: true, rental_override: amount ?? null, silent: true, notes: `Tezkor shartnoma (${hours} soat)` }, user, req);
  const warnings = [];
  try { await confirmBooking(bk.id, user, req); } catch (e) { warnings.push('Tasdiqlanmadi: ' + e.message); return { booking: await getBooking(bk.id), warnings }; }
  if (await contracts.getActive()) { try { await recordPaperConsent(bk.id, user, req); } catch (e) { if (e.status !== 409) warnings.push('Rozilik qayd etilmadi: ' + e.message); } }
  else warnings.push("Shartnoma shabloni yuklanmagan — PDF yaratilmadi (Sozlamalar → Shartnoma bo'limida yuklang)");
  if (canHandover) { try { await handover(bk.id, { force: true }, user, req); } catch (e) { warnings.push('Mashina topshirilmadi: ' + e.message); } }
  else warnings.push("Mashinani topshirish uchun sizda ruxsat yo'q");
  return { booking: await getBooking(bk.id), warnings };
}

module.exports = { previewReturn, requestSign, quickContract, quickQuote, ACTIVE_STATES, quote, createBooking, getBooking, confirmBooking, recordPaperConsent, acceptViaBot, deliverContract, cancelBooking, addPayment, handover, returnCar, syncCarStatuses, setCarStatus, lateInfo, rentalDays, rateFor, int };

module.exports.deliveryFee = deliveryFee;
