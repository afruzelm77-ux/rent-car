// SMS yuborish (Eskiz.uz). ESKIZ_EMAIL va ESKIZ_PASSWORD kiritilmasa — o'chiq (OTP faqat Telegram bot orqali boradi).
const API = (process.env.SMS_API || 'https://notify.eskiz.uz/api').replace(/\/$/, '');
let token = null, tokenAt = 0;

const enabled = () => !!(process.env.ESKIZ_EMAIL && process.env.ESKIZ_PASSWORD);
async function login() {
  const fd = new FormData(); fd.append('email', process.env.ESKIZ_EMAIL); fd.append('password', process.env.ESKIZ_PASSWORD);
  const r = await fetch(`${API}/auth/login`, { method: 'POST', body: fd }); const j = await r.json();
  token = j && j.data && j.data.token; tokenAt = Date.now();
  if (!token) throw new Error('SMS provayder: kirish xatosi');
}
async function send(phone, text) {
  if (!enabled()) return { ok: false, skipped: true };
  try {
    if (!token || Date.now() - tokenAt > 20 * 24 * 3600e3) await login();
    const body = () => { const fd = new FormData(); fd.append('mobile_phone', String(phone).replace(/\D/g, '')); fd.append('message', text); fd.append('from', process.env.SMS_FROM || '4546'); return fd; };
    let r = await fetch(`${API}/message/sms/send`, { method: 'POST', headers: { Authorization: 'Bearer ' + token }, body: body() });
    if (r.status === 401) { await login(); r = await fetch(`${API}/message/sms/send`, { method: 'POST', headers: { Authorization: 'Bearer ' + token }, body: body() }); }
    const j = await r.json().catch(() => ({}));
    if (!r.ok) console.error('SMS xato:', j.message || r.status);
    return { ok: r.ok };
  } catch (e) { console.error('SMS tarmoq xatosi:', e.message); return { ok: false, error: e.message }; }
}
module.exports = { send, enabled };
