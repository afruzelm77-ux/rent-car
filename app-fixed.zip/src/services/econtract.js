'use strict';
/*
 * ELEKTRON SHARTNOMA: buyurtma → shartnoma (rasmiy PDF shablon) → rozilik → OTP → tasdiqlash (muzlatish) →
 * topshirish dalolatnomasi → qaytarish dalolatnomasi. Barchasi bitta bazada, buyurtmaga bog'langan.
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const db = require('../db');
const cfg = require('../config');
const settings = require('./settings');
const sms = require('./sms');
const { tg, notify, notifyDocument } = require('./notify');
const { audit } = require('../audit');
const { AppError, encrypt, decrypt, fmtDate, fmtDT, fmtTime } = require('../util');
const { detect } = require('../contract/detect');
const { renderTemplate, addTablePage, addPhotosPage } = require('../contract/fill');
const fonts = require('../contract/fonts');
const { CHECK_KEYS, REQUIRED, KEY_LABELS } = require('../contract/rules');
const { EQUIPMENT } = require('../contract/settlement');
const up = require('../upload');

const ROOT = path.join(__dirname, '..', '..', 'uploads');
const FILES = path.join(ROOT, 'econtracts');         // yopiq papka: statik berilmaydi, faqat autentifikatsiya orqali
const TDIR = path.join(ROOT, 'contract-templates');
const BUNDLED = path.join(__dirname, '..', 'contract', 'templates', 'RENT_A_CAR_ELEKTRON_SHARTNOMA.pdf');
const OTP_TTL_MIN = Number(process.env.OTP_TTL_MINUTES) || 5;
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const stable = o => JSON.stringify(Object.keys(o).sort().reduce((a, k) => (a[k] = o[k], a), {}));
const num = n => String(Math.round(Number(n) || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
const pad2 = n => String(n).padStart(2, '0');
const fmtDTS = d => { const t = new Date(new Date(d).getTime() + 5 * 3600e3); return `${pad2(t.getUTCDate())}.${pad2(t.getUTCMonth() + 1)}.${t.getUTCFullYear()} ${pad2(t.getUTCHours())}:${pad2(t.getUTCMinutes())}:${pad2(t.getUTCSeconds())}`; };
const devEcho = () => process.env.OTP_DEV_ECHO === 'true' && !cfg.isProd;
const maskPhone = p => String(p || '').replace(/(\+?\d{3})\d+(\d{2})$/, '$1 •• ••• •• $2');
const esc = v => String(v ?? '').replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
const normPhone = p => { const d = String(p || '').replace(/\D/g, ''); return !d ? '' : d.length === 9 ? '+998' + d : '+' + d; };
const ensureDir = d => fs.mkdirSync(d, { recursive: true });

const STATUS_LABEL = { PENDING: 'Kutilmoqda', REVIEW: "Ko'rib chiqilmoqda", APPROVED: 'Tasdiqlangan', CANCELLED: 'Bekor qilingan', EXPIRED: 'Muddati tugagan' };

/* ===================== SHABLON (versiyalar) ===================== */
async function activeForm(client = db) {
  return (await client.query(`SELECT * FROM contract_templates WHERE is_active AND kind='FORM'`)).rows[0] || null;
}
const nextLabel = (prev, bump) => {
  if (!prev) return '1.0';
  const [a, b] = String(prev).split('.').map(Number);
  return bump === 'major' ? `${(a || 1) + 1}.0` : `${a || 1}.${(b || 0) + 1}`;
};
// Admin yangi shablon yuklaydi: maydonlar avtomatik aniqlanadi, versiya 1.0 → 1.1 (kichik) yoki 2.0 (katta) bo'ladi.
async function saveFormTemplate({ title, buffer, filename, bump = 'minor', changelog = '' }, user, req) {
  title = String(title || '').trim() || 'Yengil avtomobilni ijaraga berish elektron shartnomasi';
  if (!buffer || buffer.length < 500 || buffer.slice(0, 4).toString() !== '%PDF') throw new AppError(400, 'Faqat PDF fayl yuklash mumkin');
  if (buffer.length > 15 * 1024 * 1024) throw new AppError(400, 'PDF hajmi 15 MB dan oshmasligi kerak');
  let map;
  try { map = await detect(buffer, { measure: fonts.measurer() || undefined }); } catch (e) { throw new AppError(400, "PDF faylni o'qib bo'lmadi: " + e.message); }
  if (map.missing.length) throw new AppError(400, `Shablondan majburiy joylar topilmadi: ${map.missing.map(k => KEY_LABELS[k] || k).join(', ')}. Qo'lda yoziladigan joylar [avtomatik], [F.I.Sh.] ko'rinishida bo'lishi kerak.`);
  if (map.checks.length < CHECK_KEYS.length) throw new AppError(400, `Shablonda ${CHECK_KEYS.length} ta rozilik belgisi (☐) bo'lishi kerak, topildi: ${map.checks.length}`);
  const hash = sha(buffer);
  const cur = await activeForm();
  if (cur && cur.body_hash === hash) throw new AppError(409, 'Bu fayl allaqachon faol shartnoma sifatida yuklangan');
  ensureDir(TDIR);
  const file = path.join(TDIR, `${hash.slice(0, 24)}.pdf`);
  fs.writeFileSync(file, buffer, { mode: 0o640 });
  const safeName = String(filename || 'shartnoma.pdf').replace(/[^\w.\- ]+/g, '_').slice(0, 120);
  const warnings = [];
  if (!map.terms.km_limit_day) warnings.push('Kilometr limiti shablondan o‘qilmadi');
  if (!map.terms.extra_km_price) warnings.push('Ortiqcha kilometr narxi shablondan o‘qilmadi');
  if (!map.terms.fines.length) warnings.push('Jarimalar jadvali shablondan o‘qilmadi (qaytarishda jarimalarni qo‘lda kiritasiz)');
  if (map.unmapped.length) warnings.push(`Tanilmagan joylar (to'ldirilmaydi): ${map.unmapped.map(u => u.text).join(', ')}`);
  return db.tx(async c => {
    const prev = (await c.query(`SELECT version_label FROM contract_templates WHERE kind='FORM' ORDER BY version DESC LIMIT 1`)).rows[0];
    const label = nextLabel(prev && prev.version_label, bump);
    const v = (await c.query('SELECT COALESCE(MAX(version),0)+1 v FROM contract_templates')).rows[0].v;
    await c.query('UPDATE contract_templates SET is_active=false WHERE is_active');
    const r = await c.query(`INSERT INTO contract_templates(version,title,body,body_hash,kind,file_path,file_name,is_active,created_by,version_label,field_map,terms,page_count,changelog)
      VALUES($1,$2,'',$3,'FORM',$4,$5,true,$6,$7,$8,$9,$10,$11) RETURNING id,version`,
    [v, title, hash, file, safeName, user?.id || null, label, JSON.stringify(map), JSON.stringify(map.terms), map.pages, String(changelog || '').slice(0, 500)]);
    await audit(user, 'CONTRACT_VERSION', 'contract_template', r.rows[0].id, cur ? { version: cur.version_label } : null, { version: label, kind: 'FORM', pages: map.pages, fields: map.fields.length }, req, c);
    return { id: r.rows[0].id, version: r.rows[0].version, version_label: label, pages: map.pages, fields: map.fields.length, terms: map.terms, warnings };
  });
}
// Ishga tushishda: birorta ham elektron shablon bo'lmasa — mijoz yuborgan rasmiy PDF 1.0 versiya sifatida o'rnatiladi
async function ensureTemplate() {
  if (process.env.ECONTRACT_AUTOSEED === 'false') return null;   // masalan avtomatik testlar uchun
  if ((await db.query(`SELECT 1 FROM contract_templates WHERE kind='FORM' LIMIT 1`)).rows[0]) return null;
  const r = await saveFormTemplate({ title: 'Yengil avtomobilni ijaraga berish elektron shartnomasi', buffer: fs.readFileSync(BUNDLED), filename: 'RENT_A_CAR_ELEKTRON_SHARTNOMA.pdf', bump: 'major', changelog: 'Boshlang‘ich rasmiy versiya' }, null, null);
  console.log(`Elektron shartnoma shabloni o'rnatildi: v${r.version_label} (${r.fields} ta avtomatik maydon)`);
  return r;
}
async function templateById(id, client = db) {
  const t = (await client.query('SELECT * FROM contract_templates WHERE id=$1', [id])).rows[0];
  if (!t || t.kind !== 'FORM') throw new AppError(404, 'Shartnoma shabloni topilmadi');
  return t;
}
const tplBuf = t => { if (!t.file_path || !fs.existsSync(t.file_path)) throw new AppError(500, 'Shablon fayli topilmadi'); return fs.readFileSync(t.file_path); };

/* ===================== MA'LUMOTLARNI YIG'ISH ===================== */
// Buyurtma + mijoz profili + avtomobil → shartnoma maydonlari
async function buildData(client, bookingId, number, createdAt, terms) {
  const { rows } = await client.query(`SELECT b.*, c.first_name,c.last_name,c.phone,c.passport_enc,c.address,c.telegram_id,
      car.brand,car.model,car.plate,car.vin,car.year,car.color,car.tech_passport,car.car_value
    FROM bookings b JOIN customers c ON c.id=b.customer_id JOIN cars car ON car.id=b.car_id WHERE b.id=$1`, [bookingId]);
  const b = rows[0]; if (!b) throw new AppError(404, 'Buyurtma topilmadi');
  const place = b.delivery_address ? `manzilga yetkazish: ${b.delivery_address}` : (b.pickup_location || 'ofis');
  const plain = {
    contract_number: number, contract_date: fmtDate(createdAt), e_note: 'avtomatik',
    customer_id: b.customer_id, telegram_id: b.telegram_id ? String(b.telegram_id) : '',
    customer_name: `${b.first_name} ${b.last_name}`.trim(), customer_phone: b.phone || '', customer_passport: decrypt(b.passport_enc) || '', customer_address: b.address || '',
    car_model: `${b.brand} ${b.model}`.trim(), car_year: b.year || '', car_color: b.color || '', car_vin: b.vin || '', car_plate: b.plate || '', car_tech_passport: b.tech_passport || '',
    car_value: Number(b.car_value) > 0 ? num(b.car_value) : '', rental_period: `${fmtDate(b.pickup_at)} — ${fmtDate(b.return_at)} (${b.days} kun)`,
    pickup_info: `${fmtDT(b.pickup_at)} · ${place}`, return_info: `${fmtDT(b.return_at)} · ${b.delivery_address ? 'manzilda qabul qilinadi' : (b.pickup_location || 'ofis')}`,
    daily_price: num(b.daily_rate), total_price: num(b.total_amount), deposit: num(b.deposit_amount), delivery: b.delivery_address ? 'manzilga yetkazib berish' : (b.pickup_location || 'ofisdan olib ketish'),
    order_code: b.code, km_limit_day: terms && terms.km_limit_day || '', extra_km_price: terms && terms.extra_km_price || '',
  };
  const packed = { ...plain, customer_passport_enc: encrypt(plain.customer_passport) }; delete packed.customer_passport;
  return { plain, packed, hash: sha(stable(plain)) };
}
const unpack = d => { const p = { ...(d || {}) }; p.customer_passport = decrypt(p.customer_passport_enc) || ''; delete p.customer_passport_enc; return p; };
const missingOf = p => [['customer_name', 'F.I.Sh.'], ['customer_phone', 'Telefon'], ['customer_passport', 'Pasport/ID'], ['customer_address', 'Manzil']]
  .filter(([k]) => !String(p[k] || '').trim() || (k === 'customer_name' && !/\s/.test(p[k]))).map(([key, label]) => ({ key, label }));
const hashDoc = (t, number, plain) => sha(stable({ template: t.body_hash, number, version: t.version_label, data: plain }));

/* ===================== PDF ===================== */
function contractValues(plain, t, docHash, approval) {
  const v = { ...plain };
  for (const f of t.field_map.fields) if ((f.key.startsWith('ho_') || f.key.startsWith('rt_')) && !(f.key in v)) v[f.key] = '—';
  Object.assign(v, { version_label: t.version_label, doc_hash: docHash });
  if (approval) Object.assign(v, { audit_user: `${plain.customer_name} (profil #${plain.customer_id})`, otp_method: 'OTP (bir martalik kod) — tasdiqlangan', approved_at_text: approval.text + ' (server vaqti)',
    tech_log: `IP: ${approval.ip || '—'}; ${String(approval.ua || '—').slice(0, 60)}`, pdf_id: approval.pdfId, approval_stamp: `${approval.text} / OTP` });
  else Object.assign(v, { audit_user: '—', otp_method: 'OTP (kutilmoqda)', approved_at_text: 'tasdiqlangandan so‘ng', tech_log: '—', pdf_id: '—', approval_stamp: 'tasdiqlanmagan' });
  return v;
}
async function renderContract(c, t, plain, approval) {
  const docHash = hashDoc(t, c.number, plain);
  const checks = approval ? Object.fromEntries(CHECK_KEYS.map(k => [k, true])) : null;
  const footer = approval ? `${c.number} · ELEKTRON TASDIQLANGAN ${approval.text} · OTP · hujjat xeshi (SHA-256): ${docHash.slice(0, 32)}… · v${t.version_label}`
    : `${c.number} · NAMUNA: hali tasdiqlanmagan · v${t.version_label}`;
  const { doc } = await renderTemplate({ templateBuf: tplBuf(t), map: t.field_map, values: contractValues(plain, t, docHash, approval), checks, footer, watermark: approval ? null : 'TASDIQLANMAGAN', fonts: fonts.embed, title: `Shartnoma ${c.number}` });
  return { bytes: Buffer.from(await doc.save()), docHash };
}
// Namuna (admin shablonni tekshirishi uchun) — soxta ma'lumot bilan
async function previewTemplate(templateId) {
  const t = await templateById(templateId);
  const plain = { contract_number: 'SH-NAMUNA-000001', contract_date: fmtDate(new Date()), e_note: 'avtomatik', customer_id: 0, customer_name: 'Namuna Ijarachi', customer_phone: '+998901234567', customer_passport: 'AA1234567',
    customer_address: 'Buxoro shahri, Namuna ko‘chasi 1', car_model: 'Chevrolet Malibu', car_year: 2023, car_color: 'Oq', car_vin: 'XW8ZZZ61ZEG000000', car_plate: '80 A 000 AA', car_tech_passport: 'AAA 0000000',
    car_value: '300 000 000', rental_period: '01.01.2030 — 04.01.2030 (3 kun)', pickup_info: '01.01.2030 10:00 · ofis', return_info: '04.01.2030 10:00 · ofis', daily_price: '500 000', total_price: '1 500 000', deposit: '2 000 000', delivery: 'ofisdan olib ketish' };
  return (await renderContract({ number: plain.contract_number }, t, plain, null)).bytes;
}

/* ===================== YARATISH / YANGILASH ===================== */
async function logEvent(client, id, event, actor, details, ip) {
  await client.query('INSERT INTO econtract_events(contract_id,event,actor,details,ip) VALUES($1,$2,$3,$4,$5)', [id, event, actor || null, details ? JSON.stringify(details) : null, ip || null]);
}
async function createDraft(client, bookingId) {
  const t = await activeForm(client); if (!t) return null;
  const ex = (await client.query('SELECT id FROM econtracts WHERE booking_id=$1', [bookingId])).rows[0]; if (ex) return ex.id;
  const bk = (await client.query('SELECT customer_id FROM bookings WHERE id=$1', [bookingId])).rows[0]; if (!bk) throw new AppError(404, 'Buyurtma topilmadi');
  const number = `SH-${new Date().getFullYear()}-${String(bookingId).padStart(6, '0')}`;
  const now = new Date(), ttl = (await settings.getNum('econtract_ttl_hours')) || 48;
  const d = await buildData(client, bookingId, number, now, t.terms);
  const r = await client.query(`INSERT INTO econtracts(number,booking_id,customer_id,template_id,version_label,data,data_hash,page_count,expires_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id`,
    [number, bookingId, bk.customer_id, t.id, t.version_label, JSON.stringify(d.packed), d.hash, t.page_count, new Date(now.getTime() + ttl * 3600e3)]);
  await logEvent(client, r.rows[0].id, 'CREATED', 'tizim', { version: t.version_label });
  return r.rows[0].id;
}
const byBooking = async (bookingId, client = db) => (await client.query('SELECT * FROM econtracts WHERE booking_id=$1', [bookingId])).rows[0] || null;

// Qoralamani yangilaydi (mijoz profilini o'zgartirgan bo'lishi mumkin). Tasdiqlangan shartnoma o'zgarmaydi.
async function refresh(c) {
  if (c.frozen || !['PENDING', 'REVIEW'].includes(c.status)) return c;
  const t = await templateById(c.template_id);
  const d = await buildData(db, c.booking_id, c.number, c.created_at, t.terms);
  if (d.hash === c.data_hash) return c;
  return (await db.query('UPDATE econtracts SET data=$2, data_hash=$3 WHERE id=$1 AND NOT frozen RETURNING *', [c.id, JSON.stringify(d.packed), d.hash])).rows[0] || c;
}
async function mine(id, customerId) {
  const c = (await db.query(`SELECT e.*, b.status booking_status FROM econtracts e JOIN bookings b ON b.id=e.booking_id WHERE e.id=$1 AND e.customer_id=$2`, [id, customerId])).rows[0];
  if (!c) throw new AppError(404, 'Shartnoma topilmadi');   // boshqa mijozning shartnomasi ham "topilmadi" deb qaytadi
  return c;
}
async function expireIfNeeded(c) {
  if (['PENDING', 'REVIEW'].includes(c.status) && c.expires_at && new Date(c.expires_at) < new Date()) {
    await db.query(`UPDATE econtracts SET status='EXPIRED' WHERE id=$1 AND status IN ('PENDING','REVIEW')`, [c.id]);
    await logEvent(db, c.id, 'EXPIRED', 'tizim'); c.status = 'EXPIRED';
  }
  return c;
}
function view(c, plain) {
  const safe = { ...plain }; const pp = safe.customer_passport || ''; safe.customer_passport = pp ? pp.slice(0, 2) + ' ••••' + pp.slice(-3) : ''; delete safe.telegram_id;
  return { id: c.id, number: c.number, status: c.status, status_label: STATUS_LABEL[c.status], version: c.version_label, pages: c.page_count, max_page_seen: c.max_page_seen, order_id: c.booking_id,
    order_code: plain.order_code, booking_status: c.booking_status, expires_at: c.expires_at, approved_at: c.approved_at, created_at: c.created_at, data_hash: c.data_hash, doc_hash: c.doc_hash, pdf_sha256: c.pdf_sha256,
    summary: safe, missing: missingOf(plain), can_sign: ['PENDING', 'REVIEW'].includes(c.status) && ['PENDING', 'CONFIRMED'].includes(c.booking_status), frozen: c.frozen };
}
async function customerView(id, customerId) {
  let c = await expireIfNeeded(await mine(id, customerId)); c = Object.assign(c, { booking_status: c.booking_status });
  const bs = c.booking_status; c = { ...(await refresh(c)), booking_status: bs };
  return { c, v: view(c, unpack(c.data)) };
}
async function listForCustomer(customerId) {
  const { rows } = await db.query(`SELECT e.id,e.number,e.status,e.version_label,e.approved_at,e.created_at,e.expires_at,e.pdf_sha256,b.code,b.status booking_status,b.pickup_at,b.return_at,b.days,b.total_amount,b.deposit_amount,
      car.brand||' '||car.model car,car.plate,
      (SELECT COUNT(*)::int FROM econtract_acts a WHERE a.contract_id=e.id) acts
    FROM econtracts e JOIN bookings b ON b.id=e.booking_id JOIN cars car ON car.id=b.car_id WHERE e.customer_id=$1 AND b.deleted_at IS NULL ORDER BY e.id DESC LIMIT 100`, [customerId]);
  return rows.map(r => ({ ...r, status: ['PENDING', 'REVIEW'].includes(r.status) && r.expires_at && new Date(r.expires_at) < new Date() ? 'EXPIRED' : r.status, status_label: STATUS_LABEL[r.status] }));
}
async function progress(id, customerId, page) {
  const p = Math.max(0, Math.min(500, parseInt(page, 10) || 0));
  const r = await db.query(`UPDATE econtracts SET max_page_seen=GREATEST(max_page_seen, LEAST($3,page_count)), viewed_at=COALESCE(viewed_at,now()), status=CASE WHEN status='PENDING' THEN 'REVIEW' ELSE status END
    WHERE id=$1 AND customer_id=$2 AND status IN ('PENDING','REVIEW') AND NOT frozen RETURNING max_page_seen,page_count,status`, [id, customerId, p]);
  if (r.rows[0] && p === 1) await logEvent(db, id, 'VIEWED', 'mijoz');
  return r.rows[0] || null;
}
async function renew(id, customerId) {
  const c = await mine(id, customerId);
  if (c.status !== 'EXPIRED' && !(c.status !== 'APPROVED' && new Date(c.expires_at) < new Date())) throw new AppError(409, 'Shartnoma muddati tugamagan');
  if (!['PENDING', 'CONFIRMED'].includes(c.booking_status)) throw new AppError(409, 'Buyurtma holati shartnomani yangilashga ruxsat bermaydi');
  const ttl = (await settings.getNum('econtract_ttl_hours')) || 48;
  await db.query(`UPDATE econtracts SET status='PENDING', max_page_seen=0, expires_at=now()+($2||' hours')::interval WHERE id=$1 AND NOT frozen`, [id, String(ttl)]);
  await logEvent(db, id, 'RENEWED', 'mijoz'); return customerView(id, customerId);
}

/* ===================== OTP ===================== */
const otpHash = (contractId, code) => crypto.createHmac('sha256', cfg.jwtSecret).update(`econtract:${contractId}:${code}`).digest('hex');
async function sendOtp(id, customer, ip) {
  let c = await expireIfNeeded(await mine(id, customer.id));
  if (!['PENDING', 'REVIEW'].includes(c.status)) throw new AppError(409, c.status === 'APPROVED' ? 'Shartnoma allaqachon tasdiqlangan' : `Shartnoma holati: ${STATUS_LABEL[c.status]}`, 'NOT_SIGNABLE');
  if (!['PENDING', 'CONFIRMED'].includes(c.booking_status)) throw new AppError(409, 'Buyurtma bekor qilingan yoki yakunlangan');
  const phone = normPhone(customer.phone);
  if (phone.length < 12) throw new AppError(400, "Telefon raqamingizni to'liq kiriting (profilda)", 'NO_PHONE');
  if (c.max_page_seen < c.page_count) throw new AppError(409, "Avval shartnomani oxirigacha o'qing", 'NOT_READ');
  const last = (await db.query('SELECT created_at FROM econtract_otps WHERE contract_id=$1 ORDER BY id DESC LIMIT 1', [id])).rows[0];
  if (last) { const wait = 60 - Math.floor((Date.now() - new Date(last.created_at)) / 1000); if (wait > 0) throw new AppError(429, `Yangi kodni ${wait} soniyadan keyin so'rang`, 'OTP_WAIT'); }
  const hourly = (await db.query(`SELECT COUNT(*)::int n FROM econtract_otps WHERE contract_id=$1 AND created_at>now()-interval '1 hour'`, [id])).rows[0].n;
  if (hourly >= 5) throw new AppError(429, "Bir soatda ko'pi bilan 5 ta kod so'rash mumkin. Keyinroq urinib ko'ring", 'OTP_LIMIT');
  const code = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
  const text = `${process.env.SMS_OTP_TEXT || 'Rasmiy tasdiqlash kodi'}: ${code}. Shartnoma ${c.number}. Kodni hech kimga bermang.`;
  const channels = [];
  if ((await sms.send(phone, text)).ok) channels.push('sms');
  if (customer.telegram_id && (await tg.send(customer.telegram_id, `🔐 <b>Shartnomani tasdiqlash kodi</b>\n\n<code>${code}</code>\n\nShartnoma: ${esc(c.number)}\nKod ${OTP_TTL_MIN} daqiqa amal qiladi. Kodni hech kimga bermang.`)).ok) channels.push('telegram');
  if (!channels.length && !devEcho()) throw new AppError(502, "Kodni yuborib bo'lmadi. Telefon/Telegram bot ulanganini tekshiring yoki operator bilan bog'laning", 'OTP_SEND_FAILED');
  await db.query(`INSERT INTO econtract_otps(contract_id,phone,code_hash,channels,expires_at,ip) VALUES($1,$2,$3,$4,now()+($5||' minutes')::interval,$6)`, [id, phone, otpHash(id, code), channels.join(','), String(OTP_TTL_MIN), ip || null]);
  await db.query(`UPDATE econtracts SET status='REVIEW' WHERE id=$1 AND status='PENDING' AND NOT frozen`, [id]);
  await logEvent(db, id, 'OTP_SENT', 'mijoz', { channels }, ip);
  return { phone: maskPhone(phone), channels, ttl_seconds: OTP_TTL_MIN * 60, resend_after: 60, ...(devEcho() ? { dev_code: code } : {}) };
}
// Kodni tekshirish: urinishlar soni alohida tranzaksiyada saqlanadi (xato kodda ham hisoblanadi — brute-force oldi olinadi)
async function verifyOtp(id, code, ip) {
  const res = await db.tx(async cl => {
    const o = (await cl.query('SELECT * FROM econtract_otps WHERE contract_id=$1 AND NOT consumed ORDER BY id DESC LIMIT 1 FOR UPDATE', [id])).rows[0];
    if (!o) return { err: [400, 'Avval tasdiqlash kodini so\'rang', 'NO_OTP'] };
    if (o.verified_at) return { ok: true };
    if (new Date(o.expires_at) < new Date()) return { err: [400, "Kod muddati tugagan. Yangi kod so'rang", 'OTP_EXPIRED'] };
    if (o.attempts >= 5) return { err: [429, "Urinishlar tugadi. Yangi kod so'rang", 'OTP_ATTEMPTS'] };
    const given = otpHash(id, String(code || '').replace(/\D/g, '')), a = Buffer.from(given, 'hex'), b = Buffer.from(o.code_hash, 'hex');
    const ok = a.length === b.length && crypto.timingSafeEqual(a, b);
    await cl.query('UPDATE econtract_otps SET attempts=attempts+1, verified_at=CASE WHEN $2 THEN now() ELSE NULL END WHERE id=$1', [o.id, ok]);
    if (!ok) return { err: [400, `Kod noto'g'ri. Qolgan urinishlar: ${Math.max(0, 4 - o.attempts)}`, 'OTP_WRONG'], event: 'OTP_FAILED' };
    return { ok: true };
  });
  if (res.event) await logEvent(db, id, res.event, 'mijoz', null, ip);
  if (res.err) throw new AppError(...res.err);
}

/* ===================== TASDIQLASH (MUZLATISH) ===================== */
async function approve(id, customer, { code, consents, data_hash, ip, ua }) {
  for (const k of CHECK_KEYS) if (!consents || consents[k] !== true) throw new AppError(400, 'Barcha rozilik belgilarini belgilang', 'CONSENTS');
  let c0 = await expireIfNeeded(await mine(id, customer.id));
  if (c0.status === 'APPROVED') throw new AppError(409, 'Shartnoma allaqachon tasdiqlangan', 'ALREADY');
  await verifyOtp(id, code, ip);
  ensureDir(FILES);
  let written = null;
  try {
    const out = await db.tx(async cl => {
      const c = (await cl.query(`SELECT e.*, b.status booking_status, b.customer_id bcust FROM econtracts e JOIN bookings b ON b.id=e.booking_id WHERE e.id=$1 AND e.customer_id=$2 FOR UPDATE OF e`, [id, customer.id])).rows[0];
      if (!c) throw new AppError(404, 'Shartnoma topilmadi');
      if (!['PENDING', 'REVIEW'].includes(c.status)) throw new AppError(409, `Shartnoma holati: ${STATUS_LABEL[c.status]}`, 'NOT_SIGNABLE');
      if (new Date(c.expires_at) < new Date()) throw new AppError(409, 'Shartnoma muddati tugagan', 'EXPIRED');
      if (!['PENDING', 'CONFIRMED'].includes(c.booking_status)) throw new AppError(409, 'Buyurtma bekor qilingan yoki yakunlangan');
      if (c.max_page_seen < c.page_count) throw new AppError(409, "Shartnomani oxirigacha o'qing", 'NOT_READ');
      const o = (await cl.query(`SELECT id FROM econtract_otps WHERE contract_id=$1 AND NOT consumed AND verified_at>now()-interval '15 minutes' ORDER BY id DESC LIMIT 1 FOR UPDATE`, [id])).rows[0];
      if (!o) throw new AppError(400, 'OTP tasdiqlanmagan yoki muddati o‘tgan', 'NO_OTP');
      const t = await templateById(c.template_id, cl);
      const d = await buildData(cl, c.booking_id, c.number, c.created_at, t.terms);
      if (d.hash !== data_hash || d.hash !== c.data_hash) throw new AppError(409, "Shartnoma ma'lumotlari yangilangan. Shartnomani qayta ko'rib chiqing", 'DATA_CHANGED');
      const miss = missingOf(d.plain); if (miss.length) throw new AppError(400, `Profilda to'ldirilmagan: ${miss.map(m => m.label).join(', ')}`, 'PROFILE_INCOMPLETE');
      const approvedAt = new Date(), pdfId = crypto.randomUUID(), text = fmtDTS(approvedAt);
      const { bytes, docHash } = await renderContract(c, t, d.plain, { text, ip, ua, pdfId });
      const fileName = `${pdfId}.pdf`; fs.writeFileSync(path.join(FILES, fileName), bytes, { mode: 0o640 }); written = path.join(FILES, fileName);
      const pdfSha = sha(bytes);
      await cl.query(`UPDATE econtracts SET status='APPROVED', frozen=true, approved_at=$2, doc_hash=$3, pdf_id=$4, pdf_file=$5, pdf_sha256=$6, data=$7, data_hash=$8 WHERE id=$1`,
        [id, approvedAt, docHash, pdfId, fileName, pdfSha, JSON.stringify(d.packed), d.hash]);
      await cl.query('UPDATE econtract_otps SET consumed=true WHERE id=$1', [o.id]);
      await cl.query(`INSERT INTO econtract_audit(contract_id,order_id,customer_id,telegram_id,customer_name,phone,contract_version,approved_date,approved_time,approved_at,otp_status,pdf_id,pdf_sha256,doc_hash,ip,user_agent,consents)
        VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'VERIFIED',$11,$12,$13,$14,$15,$16)`,
      [id, c.booking_id, c.customer_id, customer.telegram_id || null, d.plain.customer_name, d.plain.customer_phone, c.version_label, fmtDate(approvedAt), fmtTime(approvedAt) + ':' + pad2(approvedAt.getUTCSeconds()), approvedAt, pdfId, pdfSha, docHash, ip || null, String(ua || '').slice(0, 300), JSON.stringify(consents)]);
      // Eski tizim (rozilik jadvali) bilan moslik: handover va hisobotlar shu yozuvni ham ko'radi
      await cl.query(`INSERT INTO contract_consents(booking_id,customer_id,template_id,body_hash,channel,telegram_id,ip,user_agent) VALUES($1,$2,$3,$4,'MINIAPP',$5,$6,$7) ON CONFLICT (booking_id) DO NOTHING`,
        [c.booking_id, c.customer_id, t.id, t.body_hash, customer.telegram_id || null, ip || null, String(ua || '').slice(0, 300)]);
      await logEvent(cl, id, 'APPROVED', 'mijoz', { otp: 'verified', pdf_sha256: pdfSha, version: c.version_label }, ip);
      await audit({ name: `Mijoz #${c.customer_id}` }, 'ECONTRACT_APPROVED', 'econtract', id, { status: c.status }, { status: 'APPROVED', pdf_sha256: pdfSha }, { ip }, cl);
      return { id, number: c.number, pdfSha, docHash, path: written, booking_id: c.booking_id, customer_id: c.customer_id, name: d.plain.customer_name };
    });
    notifyDocument({ customer_id: out.customer_id, filePath: out.path, ref_key: `econ:${id}`, caption: `✅ Shartnoma ${out.number} elektron tasdiqlandi (OTP).\nSHA-256: ${out.pdfSha.slice(0, 16)}…` }).catch(() => {});
    notify({ audience: 'ADMIN', type: 'ECONTRACT', title: '✅ Shartnoma tasdiqlandi', ref_key: `econa:${id}`, body: `${out.number} — ${out.name}\nOTP orqali elektron tasdiqlangan.` }).catch(() => {});
    return customerView(id, customer.id);
  } catch (e) { if (written) fs.rm(written, () => {}); throw e; }
}

/* ===================== BEKOR / MUDDAT ===================== */
async function cancelForBooking(client, bookingId, reason) {
  const r = await client.query(`UPDATE econtracts SET status='CANCELLED', cancelled_reason=$2 WHERE booking_id=$1 AND status IN ('PENDING','REVIEW','APPROVED') RETURNING id`, [bookingId, reason || 'Buyurtma bekor qilindi']);
  if (r.rows[0]) await logEvent(client, r.rows[0].id, 'CANCELLED', 'tizim', { reason });
}
async function cancelByAdmin(id, reason, user, req) {
  const c = (await db.query('SELECT * FROM econtracts WHERE id=$1', [id])).rows[0]; if (!c) throw new AppError(404, 'Shartnoma topilmadi');
  if (c.status === 'CANCELLED') throw new AppError(409, 'Shartnoma allaqachon bekor qilingan');
  if ((await db.query(`SELECT 1 FROM bookings WHERE id=$1 AND status IN ('ACTIVE','OVERDUE')`, [c.booking_id])).rows[0]) throw new AppError(409, 'Mashina ijarada — shartnomani bekor qilib bo‘lmaydi');
  await db.query(`UPDATE econtracts SET status='CANCELLED', cancelled_reason=$2 WHERE id=$1`, [id, String(reason || '').slice(0, 300) || 'Admin tomonidan']);
  await logEvent(db, id, 'CANCELLED', user?.full_name || 'admin', { reason }, req?.ip);
  await audit(user, 'ECONTRACT_CANCEL', 'econtract', id, { status: c.status }, { status: 'CANCELLED', reason }, req);
}
async function expireOld() {
  const { rows } = await db.query(`UPDATE econtracts SET status='EXPIRED' WHERE status IN ('PENDING','REVIEW') AND expires_at<now() AND NOT frozen RETURNING id,customer_id,number`);
  for (const r of rows) {
    await logEvent(db, r.id, 'EXPIRED', 'tizim');
    await notify({ audience: 'CUSTOMER', customer_id: r.customer_id, type: 'ECONTRACT_EXPIRED', title: '⚫ Shartnoma muddati tugadi', ref_key: `econe:${r.id}`, body: `${r.number}: tasdiqlash muddati o'tdi. Mini App → Shartnomalarim bo'limidan yangilab, qayta tasdiqlang.` });
  }
  return rows.length;
}

/* ===================== FAYLLAR ===================== */
// Tasdiqlangan PDF har ochilganda xeshi tekshiriladi — fayl o'zgartirilgan bo'lsa berilmaydi
async function pdfFor(c) {
  if (c.frozen && c.pdf_file) {
    const p = path.join(FILES, path.basename(c.pdf_file));
    if (!fs.existsSync(p)) throw new AppError(500, 'Shartnoma fayli topilmadi. Administratorga murojaat qiling');
    const bytes = fs.readFileSync(p);
    if (sha(bytes) !== c.pdf_sha256) { await logEvent(db, c.id, 'INTEGRITY_FAIL', 'tizim', { file: c.pdf_file }); throw new AppError(500, 'Shartnoma fayli yaxlitligi buzilgan (xesh mos kelmadi). Administratorga murojaat qiling', 'INTEGRITY'); }
    return { bytes, name: `${c.number}.pdf`, path: p };
  }
  const t = await templateById(c.template_id);
  return { bytes: (await renderContract(c, t, unpack(c.data), null)).bytes, name: `${c.number}-namuna.pdf`, path: null };
}
async function actPdf(bookingId, kind) {
  const a = (await db.query('SELECT a.* FROM econtract_acts a WHERE a.booking_id=$1 AND a.kind=$2', [bookingId, kind])).rows[0];
  if (!a) throw new AppError(404, 'Dalolatnoma topilmadi');
  const p = path.join(FILES, path.basename(a.pdf_file)); if (!fs.existsSync(p)) throw new AppError(500, 'Dalolatnoma fayli topilmadi');
  const bytes = fs.readFileSync(p); if (sha(bytes) !== a.pdf_sha256) throw new AppError(500, 'Dalolatnoma fayli yaxlitligi buzilgan', 'INTEGRITY');
  return { bytes, name: `${a.number}.pdf`, path: p, act: a };
}
async function sendToTelegram(c, customer) {
  if (!customer.telegram_id) throw new AppError(409, 'Telegram ulanmagan');
  const f = await pdfFor(c); if (!f.path) throw new AppError(409, 'Shartnoma hali tasdiqlanmagan');
  const r = await tg.sendDocument(customer.telegram_id, f.path, `📄 Shartnoma ${esc(c.number)}`);
  if (!r.ok) throw new AppError(502, "Telegramga yuborib bo'lmadi"); return true;
}

/* ===================== DALOLATNOMALAR ===================== */
const eqText = eq => {
  if (!eq || typeof eq !== 'object') return '—';
  const have = EQUIPMENT.filter(n => eq[n]), miss = EQUIPMENT.filter(n => !eq[n]);
  return miss.length ? `${have.join(', ') || '—'}. YO‘Q: ${miss.join(', ')}` : 'to‘liq: ' + have.join(', ');
};
const yn = v => (v == null ? '—' : v ? 'ha' : 'yo‘q');
function photoImages(urls) {
  const out = [];
  for (const u of urls || []) {
    const m = /^\/uploads\/public\/([a-f0-9]{32})\.(jpg|png)$/.exec(u || ''); if (!m) continue;     // webp pdf-lib da qo'llanmaydi
    const p = path.join(up.PUBLIC, `${m[1]}.${m[2]}`); if (fs.existsSync(p)) out.push({ bytes: fs.readFileSync(p), type: m[2], caption: path.basename(p) });
  }
  return out;
}
// kind: HANDOVER | RETURN. Dalolatnoma shartnoma shablonining 9/10-bo'limi (haqiqiy shakl) to'ldirilgan holda + ilovalar
async function createAct(bookingId, kind, user) {
  const c = await byBooking(bookingId); if (!c) return null;
  if ((await db.query('SELECT 1 FROM econtract_acts WHERE contract_id=$1 AND kind=$2', [c.id, kind])).rows[0]) return null;   // allaqachon yaratilgan
  const t = await templateById(c.template_id);
  const bk = (await db.query(`SELECT b.*,car.brand,car.model,car.plate FROM bookings b JOIN cars car ON car.id=b.car_id WHERE b.id=$1`, [bookingId])).rows[0];
  const ins = (await db.query('SELECT i.*,u.full_name staff FROM car_inspections i LEFT JOIN users u ON u.id=i.staff_id WHERE booking_id=$1', [bookingId])).rows;
  const ho = ins.find(i => i.stage === 'HANDOVER'), rt = ins.find(i => i.stage === 'RETURN');
  if (!ho || (kind === 'RETURN' && !rt)) throw new AppError(409, 'Dalolatnoma uchun ma\'lumot yetarli emas');
  const st = kind === 'RETURN' ? (await db.query('SELECT * FROM return_settlements WHERE booking_id=$1', [bookingId])).rows[0] : null;
  const plain = unpack(c.data), place = bk.delivery_address || bk.pickup_location || 'ofis';
  const photosOf = i => (Array.isArray(i.photos) ? i.photos : []);
  const v = {
    ho_car: `${bk.brand} ${bk.model} / ${bk.plate}`, ho_datetime: `${fmtDT(bk.actual_pickup_at || ho.inspected_at)} · ${place}`, ho_km: `${ho.mileage} km`, ho_fuel: `${ho.fuel_level}%`, ho_clean: yn(ho.cleanliness),
    ho_damages: `${ho.damages || 'shikast yo‘q'} (foto: ${photosOf(ho).length})`, ho_equipment: eqText(ho.equipment), ho_note: ho.customer_note || '—',
  };
  for (const k of ['rt_datetime', 'rt_km', 'rt_fuel', 'rt_extra_km', 'rt_clean', 'rt_damages', 'rt_equipment', 'rt_damage_total', 'rt_deduct', 'rt_final']) v[k] = '—';
  const seq = kind === 'HANDOVER' ? 'QT' : 'QQ', number = `${c.number}-${seq}`;
  const footer = `${number} · ${kind === 'HANDOVER' ? 'Qabul qilish-topshirish' : 'Qaytarish'} dalolatnomasi · shartnoma ${c.number} (v${c.version_label}) · ${fmtDT(new Date())}`;
  const rows = [];
  if (kind === 'RETURN') {
    const s = st.data, left = Math.max(0, s.deposit_refund);
    Object.assign(v, { rt_datetime: `${fmtDT(bk.actual_return_at || rt.inspected_at)} · ${place}`, rt_km: `${rt.mileage} km`, rt_fuel: `${rt.fuel_level}%`, rt_extra_km: `${s.extra_km} km`, rt_clean: yn(rt.cleanliness),
      rt_damages: `${rt.damages || 'yangi shikast yo‘q'} (foto: ${photosOf(rt).length})`, rt_equipment: eqText(rt.equipment), rt_damage_total: num(s.damage_fee + s.fines_total + s.extra_km_fee + s.other_fee + s.late_fee), rt_deduct: num(s.deposit_deducted),
      rt_final: s.balance_due > 0 ? `to‘lanadi: ${num(s.balance_due)} so‘m` : left > 0 ? `qaytariladi: ${num(left)} so‘m` : 'hisob-kitob yopildi' });
    rows.push(['ORTIQCHA KILOMETR', '', { head: true }], ['Yurilgan masofa', `${s.driven_km} km (${s.start_km} → ${s.end_km})`], ['Limit', `${s.km_limit_day} km/sutka × ${s.days} sutka = ${s.km_limit_total} km`],
      ['Ortiqcha kilometr', `${s.extra_km} km × ${num(s.extra_km_price)} so‘m = ${num(s.extra_km_fee)} so‘m`, { bold: true }], ['JARIMALAR', '', { head: true }]);
    if (s.fines.length) s.fines.forEach(f => rows.push([`${f.n ? f.n + '. ' : ''}${f.title}${f.qty > 1 ? ` × ${f.qty}` : ''}`, `${num(f.amount)} so‘m`]));
    else rows.push(['Jarimalar', 'yo‘q']);
    rows.push(['Jarimalar jami', `${num(s.fines_total)} so‘m`, { bold: true }], ['ZARAR VA BOSHQA TO‘LOVLAR', '', { head: true }], ['Zarar', `${num(s.damage_fee)} so‘m`], ['Kechikish haqi', `${num(s.late_fee)} so‘m`], ['Boshqa to‘lovlar', `${num(s.other_fee)} so‘m`],
      ['YAKUNIY HISOB-KITOB', '', { head: true }], ['Jami (ortiqcha km + jarimalar + zarar + boshqa)', `${num(s.charges_total)} so‘m`, { bold: true, color: s.charges_total > 0 ? 'red' : 'green' }],
      ['Garov', `${num(s.deposit_held)} so‘m`], ['Garovdan ushlab qolingan', `${num(s.deposit_deducted)} so‘m`], ['QAYTARILADIGAN GAROV', `${num(s.deposit_refund)} so‘m`, { bold: true, color: 'green' }],
      ['Qo‘shimcha to‘lanadigan summa', `${num(s.balance_due)} so‘m`, { bold: true, color: s.balance_due > 0 ? 'red' : 'green' }]);
  }
  const pageIdx = t.field_map.fields.find(f => f.key === 'ho_car').page;
  const { doc, fonts: F, S } = await renderTemplate({ templateBuf: tplBuf(t), map: t.field_map, values: v, footer, keep: [pageIdx], fonts: fonts.embed, title: `Dalolatnoma ${number}` });
  const sub = `Shartnoma ${c.number} · Buyurtma ${bk.code} · ${bk.brand} ${bk.model} (${bk.plate}) · Mijoz: ${plain.customer_name}`;
  if (rows.length) addTablePage(doc, F, S, { title: 'YAKUNIY HISOB-KITOB', sub, rows, footer });
  const insp = kind === 'HANDOVER' ? ho : rt;
  addTablePage(doc, F, S, { title: kind === 'HANDOVER' ? 'TOPSHIRISH: QO‘SHIMCHA MA’LUMOTLAR' : 'QAYTARISH: QO‘SHIMCHA MA’LUMOTLAR', sub, footer, rows: [
    ['Avtomobil holati (kuzov)', insp.body_condition], ['Salon holati', insp.interior_condition], ['Tashqi shikastlar', insp.damages || 'yo‘q'], ['Komplektatsiya', eqText(insp.equipment)], ['Tozaligi', yn(insp.cleanliness)],
    ['Mijoz izohi', insp.customer_note], ['Administrator izohi', insp.admin_note], ['Video', insp.video_file ? 'tizimda saqlangan (admin ko‘radi)' : insp.video_url || '—'], ['Rasmlar soni', photosOf(insp).length], ['Xodim', insp.staff]] });
  await addPhotosPage(doc, F, S, { title: (kind === 'HANDOVER' ? 'TOPSHIRISH' : 'QAYTARISH') + ': RASMLAR', sub, images: photoImages(photosOf(insp)) });
  const bytes = Buffer.from(await doc.save()); ensureDir(FILES);
  const fileName = `${crypto.randomUUID()}.pdf`; fs.writeFileSync(path.join(FILES, fileName), bytes, { mode: 0o640 });
  const dataSnap = { kind, inspection_id: insp.id, photos: photosOf(insp), equipment: insp.equipment || null, settlement: st ? st.data : null };
  const r = await db.query(`INSERT INTO econtract_acts(contract_id,booking_id,kind,number,data,pdf_file,pdf_sha256,created_by) VALUES($1,$2,$3,$4,$5,$6,$7,$8) ON CONFLICT DO NOTHING RETURNING *`,
    [c.id, bookingId, kind, number, JSON.stringify(dataSnap), fileName, sha(bytes), user?.id || null]);
  if (!r.rows[0]) { fs.rm(path.join(FILES, fileName), () => {}); return null; }
  await logEvent(db, c.id, kind === 'HANDOVER' ? 'HANDOVER_ACT' : 'RETURN_ACT', user?.full_name || 'tizim', { number });
  notifyDocument({ customer_id: bk.customer_id, filePath: path.join(FILES, fileName), ref_key: `act:${kind}:${bookingId}`, caption: `📄 ${kind === 'HANDOVER' ? 'Topshirish' : 'Qaytarish'} dalolatnomasi ${number}` }).catch(() => {});
  return r.rows[0];
}

/* ===================== ADMIN ===================== */
async function listAdmin({ status, q, from, to } = {}) {
  const w = ['b.deleted_at IS NULL'], p = [];
  if (status) { p.push(status); w.push(`e.status=$${p.length}`); }
  if (from) { p.push(from); w.push(`e.created_at>=$${p.length}::date`); }
  if (to) { p.push(to); w.push(`e.created_at<($${p.length}::date+1)`); }
  if (q) { p.push(`%${String(q).replace(/[\\%_]/g, m => '\\' + m)}%`); w.push(`(e.number ILIKE $${p.length} OR b.code ILIKE $${p.length} OR c.first_name||' '||c.last_name ILIKE $${p.length} OR c.phone ILIKE $${p.length} OR car.plate ILIKE $${p.length})`); }
  const { rows } = await db.query(`SELECT e.id,e.number,e.status,e.version_label,e.approved_at,e.created_at,e.expires_at,e.pdf_sha256,e.frozen,b.id booking_id,b.code,b.status booking_status,b.pickup_at,b.return_at,b.days,b.total_amount,b.deposit_amount,
      c.id customer_id,c.first_name||' '||c.last_name customer,c.phone,car.brand||' '||car.model car,car.plate,
      EXISTS(SELECT 1 FROM econtract_acts a WHERE a.contract_id=e.id AND a.kind='HANDOVER') has_handover,
      EXISTS(SELECT 1 FROM econtract_acts a WHERE a.contract_id=e.id AND a.kind='RETURN') has_return
    FROM econtracts e JOIN bookings b ON b.id=e.booking_id JOIN customers c ON c.id=e.customer_id JOIN cars car ON car.id=b.car_id
    WHERE ${w.join(' AND ')} ORDER BY e.id DESC LIMIT 300`, p);
  const counts = (await db.query('SELECT status,COUNT(*)::int n FROM econtracts GROUP BY status')).rows;
  return { items: rows.map(r => ({ ...r, status: ['PENDING', 'REVIEW'].includes(r.status) && new Date(r.expires_at) < new Date() ? 'EXPIRED' : r.status })), counts: Object.fromEntries(counts.map(x => [x.status, x.n])), labels: STATUS_LABEL };
}
async function detailAdmin(id) {
  const c = (await db.query(`SELECT e.*,b.code,b.status booking_status,b.pickup_at,b.return_at,b.days,b.total_amount,b.paid_amount,b.deposit_amount,car.brand||' '||car.model car,car.plate,cu.first_name||' '||cu.last_name customer,cu.phone
    FROM econtracts e JOIN bookings b ON b.id=e.booking_id JOIN cars car ON car.id=b.car_id JOIN customers cu ON cu.id=e.customer_id WHERE e.id=$1`, [id])).rows[0];
  if (!c) throw new AppError(404, 'Shartnoma topilmadi');
  const plain = unpack(c.data), pp = plain.customer_passport || '';
  const { data, ...row } = c;
  return { ...row, status_label: STATUS_LABEL[c.status], passport_masked: pp ? pp.slice(0, 2) + ' ••••' + pp.slice(-3) : '', address: plain.customer_address,
    audit: (await db.query('SELECT * FROM econtract_audit WHERE contract_id=$1', [id])).rows[0] || null,
    events: (await db.query('SELECT event,actor,details,ip,created_at FROM econtract_events WHERE contract_id=$1 ORDER BY id DESC LIMIT 60', [id])).rows,
    acts: (await db.query('SELECT id,kind,number,pdf_sha256,created_at FROM econtract_acts WHERE contract_id=$1 ORDER BY id', [id])).rows,
    settlement: (await db.query('SELECT data,charges_total,deposit_deducted,deposit_refund,balance_due FROM return_settlements WHERE booking_id=$1', [c.booking_id])).rows[0] || null };
}
// Buyurtma kartochkasi uchun qisqa blok
async function blockForBooking(bookingId, client = db) {
  const r = (await client.query(`SELECT id,number,status,version_label,approved_at,pdf_sha256,expires_at,frozen FROM econtracts WHERE booking_id=$1`, [bookingId])).rows[0];
  if (!r) return null;
  r.acts = (await client.query('SELECT kind,number,created_at FROM econtract_acts WHERE booking_id=$1 ORDER BY id', [bookingId])).rows;
  return r;
}
async function config() {
  const t = await activeForm();
  return { equipment: EQUIPMENT, terms: t ? t.terms : null, version: t ? t.version_label : null };
}

module.exports = { STATUS_LABEL, activeForm, saveFormTemplate, ensureTemplate, templateById, previewTemplate, createDraft, byBooking, customerView, listForCustomer, progress, renew, sendOtp, approve,
  cancelForBooking, cancelByAdmin, expireOld, pdfFor, actPdf, sendToTelegram, createAct, listAdmin, detailAdmin, blockForBooking, config, logEvent, mine, view, unpack };
