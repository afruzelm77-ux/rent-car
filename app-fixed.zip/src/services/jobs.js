// Fon ishlari (har daqiqa): kechikish, eslatmalar, mashina holatlari, ogohlantirishlar, zaxira nusxa
const db = require('../db');
const bookings = require('./bookings');
const reports = require('./reports');
const backup = require('./backup');
const settings = require('./settings');
const { notify } = require('./notify');
const { fmtDT, money, todayStr } = require('../util');

let lastBackup = 0;
const self = { lastTickAt: 0 };
async function tick() {
  self.lastTickAt = Date.now();
  await db.query("DELETE FROM bot_state WHERE updated_at < now() - interval '1 day'").catch(() => {});
  // 1) Kechikkan buyurtmalarni OVERDUE qilish
  const od = await db.query(`UPDATE bookings SET status='OVERDUE' WHERE status='ACTIVE' AND return_at<now() AND deleted_at IS NULL RETURNING id,code,customer_id,car_id`);
  for (const b of od.rows) {
    const full = await bookings.getBooking(b.id);
    const info = await bookings.lateInfo(full);
    await notify({ audience: 'ADMIN', type: 'OVERDUE', title: '⚠️ Kechikish', ref_key: `od:${b.id}`, body: `${full.brand} ${full.model} (${full.plate}) — ${full.first_name} ${full.last_name}, ${full.phone}\nQaytish vaqti: ${fmtDT(full.return_at)}` });
    await notify({ audience: 'CUSTOMER', customer_id: b.customer_id, type: 'OVERDUE', title: 'Qaytarish vaqti o\'tdi', ref_key: `codue:${b.id}`, body: `${full.code}: iltimos mashinani qaytaring. Kechikish uchun alohida tarif qo'llanadi.` });
  }
  // 2) Mijozga eslatmalar: ijara boshlanishidan oldin (3 soat), tugashidan oldin (2 soat)
  const soonStart = await db.query(`SELECT id,customer_id,code,pickup_at FROM bookings WHERE status='CONFIRMED' AND deleted_at IS NULL AND pickup_at BETWEEN now() AND now()+interval '3 hours'`);
  for (const b of soonStart.rows) await notify({ audience: 'CUSTOMER', customer_id: b.customer_id, type: 'REMIND_START', title: 'Ijara boshlanishi eslatmasi', ref_key: `rs:${b.id}`, body: `${b.code}: mashinani ${fmtDT(b.pickup_at)} da olib ketasiz.` });
  const soonEnd = await db.query(`SELECT id,customer_id,code,return_at FROM bookings WHERE status='ACTIVE' AND deleted_at IS NULL AND return_at BETWEEN now() AND now()+interval '2 hours'`);
  for (const b of soonEnd.rows) await notify({ audience: 'CUSTOMER', customer_id: b.customer_id, type: 'REMIND_RETURN', title: 'Qaytarish eslatmasi', ref_key: `re:${b.id}`, body: `${b.code}: mashinani ${fmtDT(b.return_at)} gacha qaytaring.` });
  const soonAdmin = await db.query(`SELECT b.id,b.code,b.return_at,car.brand||' '||car.model car FROM bookings b JOIN cars car ON car.id=b.car_id WHERE b.status='ACTIVE' AND b.deleted_at IS NULL AND b.return_at BETWEEN now() AND now()+interval '1 hour'`);
  for (const b of soonAdmin.rows) await notify({ audience: 'ADMIN', type: 'RETURN_SOON', title: 'Mashina qaytishi yaqin', ref_key: `ras:${b.id}`, body: `${b.car} — ${fmtDT(b.return_at)}` });
  // 2b) Tasdiqlanmagan elektron shartnomalar muddati
  await require('./econtract').expireOld().catch(e => console.error('Shartnoma muddati:', e.message));
  // 3) Mashina holatlarini sinxronlash
  await bookings.syncCarStatuses();
  // 4) Kunlik ogohlantirishlar (texnik xizmat, sug'urta, hujjatlar) — kuniga bir marta
  const day = todayStr();
  for (const a of await reports.alerts()) {
    await notify({ audience: 'ADMIN', type: a.type === 'MAINTENANCE' ? 'MAINTENANCE' : a.type === 'EXPIRY' ? 'EXPIRY' : 'DOC', title: a.title, body: a.text, ref_key: `al:${day}:${a.title}:${a.text}`.slice(0, 200) });
  }
  // 5) Zaxira nusxa
  const everyH = await settings.getNum('backup_every_hours');
  if (everyH > 0 && Date.now() - lastBackup > everyH * 3600e3) {
    lastBackup = Date.now();
    backup.run().then(r => console.log('Backup:', r.name)).catch(e => console.error('Backup xato:', e.message));
  }
}
function start() {
  const safe = () => tick().catch(e => console.error('Job xato:', e.message));
  setTimeout(safe, 5000);
  return setInterval(safe, 60 * 1000);
}
module.exports = Object.assign(self, { start, tick });
