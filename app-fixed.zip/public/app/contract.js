'use strict';
/* ===== Elektron shartnoma (Mini App) =====
   Buyurtma → Shartnoma → Rozilik → OTP → Tasdiqlash → Tayyor shartnoma → PDF.
   Globallar app.js dan: S, api, screen, loader, go, I, esc, money, fDT, fD, toast, haptic, guard, H, G, empty, fail, tg */
const CST = { PENDING: ['🟡', 'Kutilmoqda'], REVIEW: ['🔵', "Ko'rib chiqilmoqda"], APPROVED: ['🟢', 'Tasdiqlangan'], CANCELLED: ['🔴', 'Bekor qilingan'], EXPIRED: ['⚫', 'Muddati tugagan'] };
const cpill = s => `<span class="cpill ${s}">${(CST[s] || ['', s])[0]} ${(CST[s] || ['', s])[1]}</span>`;
const CHECKS = [['read', "Men shartnomani to'liq o'qidim."], ['understood', 'Shartnoma shartlarini tushundim va roziman.'], ['correct', "Kiritgan ma'lumotlarim to'g'ri."],
  ['personal', "Shaxsiy ma'lumotlarimdan shartnoma rasmiylashtirish maqsadida foydalanishga roziman."], ['media', 'Avtomobil topshirilishi va qaytarilishi foto/video orqali qayd etilishiga roziman.']];
const STEPS = ['Buyurtma', 'Shartnoma', 'Rozilik', 'OTP', 'Tasdiqlash', 'Tayyor', 'PDF'];

// Buyurtmalar ro'yxatidagi tugma
const ctBtn = b => {
  if (!b.contract_id) return '';
  const st = b.contract_status, sign = ['PENDING', 'REVIEW'].includes(st);
  return `<button class="btn ${sign ? '' : 'alt'} sm" style="width:100%" data-act="opencontract" data-id="${b.contract_id}">${I('doc')} ${sign ? 'Shartnomani ko\'rish va tasdiqlash' : st === 'APPROVED' ? 'Shartnoma (PDF)' : 'Shartnoma · ' + (CST[st] || ['', ''])[1]}</button>`;
};
G.opencontract = a => go(() => viewContract(+a.dataset.id));

/* ---- PDF ko'rsatgich (pdf.js, tashqi CDN siz). Fayl autentifikatsiya bilan olinadi, ochiq havola yo'q ---- */
let pdfjsP;
const loadPdfjs = () => (pdfjsP ||= import('/app/vendor/pdfjs/pdf.min.mjs').then(m => { m.GlobalWorkerOptions.workerSrc = '/app/vendor/pdfjs/pdf.worker.min.mjs'; return m; }));
async function fetchPdf(path) {
  const r = await fetch('/api/mini' + path, { headers: { Authorization: 'Bearer ' + S.token } });
  if (!r.ok) { const d = await r.json().catch(() => ({})); throw new Error(d.error || "Hujjatni yuklab bo'lmadi"); }
  return new Uint8Array(await r.arrayBuffer());
}
// onPage(n) — foydalanuvchi ko'rgan sahifa; qaytaradi { pages }
async function showPdf(box, path, onPage) {
  box.innerHTML = '<div class="pdfwait"><span class="spin"></span><div class="note">Shartnoma yuklanmoqda…</div></div>';
  try {
    const [lib, bytes] = await Promise.all([loadPdfjs(), fetchPdf(path)]);
    const doc = await lib.getDocument({ data: bytes }).promise;
    box.innerHTML = `<div class="pgind" id="pgind">Sahifa 1 / ${doc.numPages}</div><div class="pgs" id="pgs"></div>`;
    const host = box.querySelector('#pgs'), ind = box.querySelector('#pgind'), w = Math.max(280, host.clientWidth || box.clientWidth || 340);
    const io = 'IntersectionObserver' in window ? new IntersectionObserver(es => es.forEach(e => {
      if (e.isIntersecting) { const n = +e.target.dataset.n; ind.textContent = `Sahifa ${n} / ${doc.numPages}`; onPage && onPage(n); }
    }), { threshold: 0.35 }) : null;
    for (let n = 1; n <= doc.numPages; n++) {
      const page = await doc.getPage(n), v1 = page.getViewport({ scale: 1 }), sc = w / v1.width, dpr = Math.min(window.devicePixelRatio || 1, 2);
      const vp = page.getViewport({ scale: sc * dpr }), wrap = document.createElement('div'), cv = document.createElement('canvas');
      wrap.className = 'pg'; wrap.dataset.n = n; cv.width = vp.width; cv.height = vp.height; cv.style.width = '100%'; wrap.appendChild(cv); host.appendChild(wrap);
      await page.render({ canvasContext: cv.getContext('2d'), viewport: vp }).promise;
      io ? io.observe(wrap) : (onPage && onPage(n));
    }
    return { pages: doc.numPages };
  } catch (e) {
    box.innerHTML = `<div class="empty"><div class="ic">📄</div><b>Hujjatni ko'rsatib bo'lmadi</b><div class="note">${esc(e.message || '')}</div><button class="btn alt" data-act="pdfretry">${I('refresh')} Qayta urinish</button></div>`;
    G.pdfretry = () => showPdf(box, path, onPage);
    return { pages: 0, failed: true };
  }
}

const money0 = v => (v ? v + " so'm" : '—');
const head = (title, sub) => `<div class="top"><button class="ibtn" data-act="back" aria-label="Orqaga">${I('left')}</button><div class="brand"><h1 class="h1" style="font-size:20px">${title}</h1>${sub ? `<div class="sub">${sub}</div>` : ''}</div></div>`;
const stepper = i => `<div class="csteps">${STEPS.map((l, k) => `<span class="${k < i ? 'done' : k === i ? 'on' : ''}"><i>${k < i ? '✓' : k + 1}</i>${l}</span>`).join('')}</div>`;
const orderCard = v => { const s = v.summary || {}; return `<div class="card">
  <div class="kv"><span>Shartnoma №</span><b>${esc(v.number)}</b></div><div class="kv"><span>Buyurtma</span><b>#${esc(v.order_code || v.order_id)}</b></div>
  <div class="kv"><span>Avtomobil</span><b>${esc(s.car_model)} · ${esc(s.car_plate)}</b></div><div class="kv"><span>Ijara muddati</span><b style="text-align:right">${esc(s.rental_period)}</b></div>
  <div class="kv"><span>Kunlik narx</span><b>${money0(s.daily_price)}</b></div><div class="kv t"><span>Jami ijara</span><b>${money0(s.total_price)}</b></div>
  <div class="kv"><span>Garov (depozit)</span><b>${money0(s.deposit)}</b></div>
  ${s.km_limit_day ? `<div class="kv"><span>Kilometr limiti</span><b>${esc(s.km_limit_day)} km/sutka</b></div><div class="kv"><span>Ortiqcha kilometr</span><b>${money(s.extra_km_price)} / km</b></div>` : ''}
  <div class="kv"><span>Shablon versiyasi</span><b>v${esc(v.version)}</b></div></div>`; };

/* ======================= SHARTNOMA EKRANI ======================= */
async function viewContract(id, opts = {}) {
  loader();
  let v; try { v = await api('GET', `/contracts/${id}`); } catch (e) { return fail(e); }
  const st = { step: v.status === 'APPROVED' ? 'done' : 'order', seen: v.max_page_seen || 0, pages: v.pages || 0, sent: 0, otp: null };
  const finish = () => { st.step = 'done'; draw(); };

  /* --- 1. Buyurtma + mijoz ma'lumotlari --- */
  function drawOrder() {
    const s = v.summary, miss = v.missing || [], keys = miss.map(m => m.key);
    const inp = (k, lab, ph, extra = '') => keys.includes(k) ? `<label class="f">${lab} <span class="req">*</span></label><input id="m_${k}" ${extra} placeholder="${ph}">` : '';
    screen(`${head('Shartnoma', esc(v.number))}${stepper(0)}
      <div class="sec">1. Buyurtma</div>${orderCard(v)}
      <div class="sec">Ijarachi ma'lumotlari</div>
      <div class="card"><div class="kv"><span>F.I.Sh.</span><b>${esc(s.customer_name) || '—'}</b></div><div class="kv"><span>Telefon</span><b>${esc(s.customer_phone) || '—'}</b></div>
        <div class="kv"><span>Pasport/ID</span><b>${esc(s.customer_passport) || '—'}</b></div><div class="kv"><span>Manzil</span><b style="text-align:right">${esc(s.customer_address) || '—'}</b></div>
        ${miss.length ? `<div class="note warn">Shartnoma uchun quyidagi ma'lumotlarni to'ldiring:</div>
          ${inp('customer_name', 'Ism va familiya', 'Masalan: Azizbek Karimov')}${inp('customer_phone', 'Telefon', '+998 90 123 45 67', 'type="tel" inputmode="tel"')}${inp('customer_passport', 'Pasport / ID', 'AA1234567', 'autocomplete="off"')}${inp('customer_address', 'Yashash manzili', "Shahar, ko'cha, uy")}
          <div style="height:12px"></div><button class="btn alt" data-act="savemiss">${I('check')} SAQLASH</button>` : `<div class="note">Ma'lumotlar noto'g'ri bo'lsa, Profil bo'limida tuzating.</div>`}</div>
      <div id="er" class="err"></div>
      <button class="btn" data-act="toread" ${miss.length ? 'disabled' : ''}><span class="ci">${I('right')}</span>SHARTNOMANI O'QISH</button>`, false);
    H.savemiss = () => guard(async () => {
      const g = k => ($('#m_' + k) ? $('#m_' + k).value.trim() : '');
      const body = {}; const nm = g('customer_name'); if (nm) { const p = nm.split(/\s+/); body.first_name = p[0]; body.last_name = p.slice(1).join(' ') || '-'; }
      if (g('customer_phone')) body.phone = g('customer_phone'); if (g('customer_passport')) body.passport = g('customer_passport'); if (g('customer_address')) body.address = g('customer_address');
      if (!Object.keys(body).length) throw new Error("Ma'lumotlarni kiriting");
      S.me = await api('PATCH', '/me', body); v = await api('GET', `/contracts/${id}`); toast('Saqlandi ✓'); haptic('success'); drawOrder();
    });
    H.toread = () => { st.step = 'read'; draw(); };
  }

  /* --- 2-3. Shartnoma matni + rozilik belgilari --- */
  function drawRead() {
    screen(`${head('Shartnoma', esc(v.number))}${stepper(st.seen >= st.pages && st.pages ? 2 : 1)}
      <div class="note" id="rn">Shartnomani oxirgi sahifagacha varaqlang. Shundan keyin rozilik belgilari ochiladi.</div>
      <div class="pdfbox" id="pdfbox"></div>
      <div class="sec">Rozilik</div>
      <div class="card" id="chks">${CHECKS.map(([k, t]) => `<label class="chk"><input type="checkbox" class="cc" data-k="${k}" disabled><span>${esc(t)}</span></label>`).join('')}</div>
      <div id="er" class="err"></div>
      <button class="btn" id="accept" data-act="accept" disabled><span class="ci">${I('check')}</span>ROZIMAN VA SHARTNOMANI QABUL QILAMAN</button>
      <div style="height:10px"></div><button class="btn alt" data-act="toorder">${I('left')} Buyurtma ma'lumotlari</button>`, false);
    const gate = () => {
      const read = st.pages > 0 && st.seen >= st.pages;
      document.querySelectorAll('.cc').forEach(c => { c.disabled = !read; });
      $('#accept').disabled = !(read && [...document.querySelectorAll('.cc')].every(c => c.checked));
      const rn = $('#rn'); if (rn && read) rn.textContent = "Shartnoma oxirigacha ko'rildi ✓ Rozilik belgilarini qo'ying.";
    };
    app.onchange = e => { if (e.target.classList.contains('cc')) gate(); };
    let sending = 0;
    showPdf($('#pdfbox'), `/contracts/${id}/pdf`, n => {
      if (n > st.seen) { st.seen = n; if (n > sending) { sending = n; api('POST', `/contracts/${id}/progress`, { page: n }).catch(() => {}); } }
      gate();
    }).then(r => { st.pages = r.pages || st.pages; gate(); });
    H.toorder = () => { st.step = 'order'; draw(); };
    H.accept = () => guard(async () => {
      const b = $('#accept'); b.disabled = true;
      try { st.otp = await api('POST', `/contracts/${id}/otp`); st.consents = Object.fromEntries([...document.querySelectorAll('.cc')].map(c => [c.dataset.k, c.checked])); st.step = 'otp'; draw(); haptic('success'); }
      catch (e) { b.disabled = false; throw e; }
    });
  }

  /* --- 4-5. OTP --- */
  function drawOtp() {
    const o = st.otp || {}; let left = o.resend_after || 60, tm;
    screen(`${head('Tasdiqlash kodi', esc(v.number))}${stepper(3)}
      <div class="card" style="text-align:center"><div class="ticket" style="padding:6px 0"><div class="ok" style="background:var(--grad)">${I('phone')}</div></div>
        <b>Kod yuborildi</b><div class="note">${esc(o.phone || '')} raqamiga ${(o.channels || []).includes('sms') ? 'SMS' : ''}${(o.channels || []).length > 1 ? ' va ' : ''}${(o.channels || []).includes('telegram') ? 'Telegram bot' : ''} orqali 6 xonali kod yuborildi.</div>
        <input id="otp" class="otpin" inputmode="numeric" autocomplete="one-time-code" maxlength="6" placeholder="••••••">
        ${o.dev_code ? `<div class="note warn">Test rejimi: kod <b>${esc(o.dev_code)}</b></div>` : ''}
        <div id="er" class="err"></div></div>
      <button class="btn" id="verify" data-act="verify" disabled><span class="ci">${I('check')}</span>TASDIQLASH</button>
      <div style="height:10px"></div><button class="btn alt" id="resend" data-act="resend" disabled>Kodni qayta yuborish</button>
      <div style="height:10px"></div><button class="btn alt" data-act="toread2">${I('left')} Shartnomaga qaytish</button>`, false);
    const inp = $('#otp'); inp.focus();
    inp.oninput = () => { inp.value = inp.value.replace(/\D/g, '').slice(0, 6); $('#verify').disabled = inp.value.length !== 6; };
    const tick = () => { const b = $('#resend'); if (!b) return clearInterval(tm); b.textContent = left > 0 ? `Qayta yuborish (${left} s)` : 'Kodni qayta yuborish'; b.disabled = left > 0; left--; };
    tick(); tm = setInterval(tick, 1000);
    H.toread2 = () => { clearInterval(tm); st.step = 'read'; draw(); };
    H.resend = () => guard(async () => { st.otp = await api('POST', `/contracts/${id}/otp`); clearInterval(tm); drawOtp(); toast('Yangi kod yuborildi'); });
    H.verify = () => guard(async () => {
      const b = $('#verify'); b.disabled = true; b.textContent = 'Tekshirilmoqda…';
      try { v = await api('POST', `/contracts/${id}/approve`, { code: inp.value, data_hash: v.data_hash, consents: st.consents }); clearInterval(tm); haptic('success'); finish(); }
      catch (e) {
        b.disabled = false; b.innerHTML = `<span class="ci">${I('check')}</span>TASDIQLASH`;
        if (e.code === 'DATA_CHANGED') { v = await api('GET', `/contracts/${id}`); clearInterval(tm); st.step = 'order'; st.seen = 0; draw(); }
        const er = $('#er'); if (er) er.textContent = e.message; throw e;
      }
    });
  }

  /* --- 6-7. Tayyor shartnoma + PDF --- */
  function drawDone() {
    screen(`${head('Tayyor shartnoma', esc(v.number))}${stepper(6)}
      <div class="ticket"><div class="ok">${I('check')}</div><h2>SHARTNOMA TASDIQLANDI</h2><div class="sub">OTP orqali elektron tasdiqlangan</div><span class="code">${esc(v.number)}</span></div>
      ${orderCard(v)}
      <div class="card"><div class="kv"><span>Holat</span><b>${cpill(v.status)}</b></div><div class="kv"><span>Tasdiqlangan</span><b>${v.approved_at ? fDT(v.approved_at) : '—'}</b></div>
        <div class="kv"><span>Ijarachi</span><b>${esc(v.summary.customer_name)}</b></div>
        <div class="kv"><span>PDF xeshi (SHA-256)</span><b class="mono">${esc((v.pdf_sha256 || '').slice(0, 16))}…</b></div></div>
      <div class="pdfbox" id="pdfbox" style="display:none"></div>
      <button class="btn" data-act="viewpdf">${I('doc')} PDF KO'RISH</button><div style="height:10px"></div>
      <button class="btn alt" data-act="dlpdf">${I('copy')} YUKLAB OLISH</button><div style="height:10px"></div>
      <button class="btn alt" data-act="tgpdf">${I('right')} Telegramga yuborish</button>
      <div id="acts"></div>`, false);
    api('GET', '/contracts').then(list => {
      const me = list.find(x => x.id === id); if (!me || !me.acts) return;
      $('#acts').innerHTML = `<div class="sec">Dalolatnomalar</div><button class="btn alt sm" style="width:100%;margin-bottom:8px" data-act="act" data-k="HANDOVER">Topshirish dalolatnomasi</button><button class="btn alt sm" style="width:100%" data-act="act" data-k="RETURN">Qaytarish dalolatnomasi</button>`;
    }).catch(() => {});
    const open = path => { const b = $('#pdfbox'); b.style.display = 'block'; showPdf(b, path); b.scrollIntoView({ behavior: 'smooth' }); };
    H.viewpdf = () => open(`/contracts/${id}/pdf`);
    H.act = a => open(`/contracts/${id}/acts/${a.dataset.k}/pdf`);
    H.dlpdf = () => guard(async () => { const r = await api('POST', `/contracts/${id}/pdf-link`); const u = r.url + '?dl=1'; try { tg ? tg.openLink(u) : window.open(u, '_blank'); } catch { window.open(u, '_blank'); } });
    H.tgpdf = () => guard(async () => { await api('POST', `/contracts/${id}/telegram`); toast('PDF Telegram chatingizga yuborildi ✓'); haptic('success'); });
  }

  function drawClosed() {
    const exp = v.status === 'EXPIRED';
    screen(`${head('Shartnoma', esc(v.number))}<div class="card" style="text-align:center">${cpill(v.status)}<div class="note">${exp ? "Tasdiqlash muddati tugagan. Shartnomani yangilab, qayta tasdiqlashingiz mumkin." : 'Bu shartnoma bekor qilingan.'}</div></div>
      ${orderCard(v)}${exp && ['PENDING', 'CONFIRMED'].includes(v.booking_status) ? `<button class="btn" data-act="renew">${I('refresh')} SHARTNOMANI YANGILASH</button>` : ''}`, false);
    H.renew = () => guard(async () => { v = await api('POST', `/contracts/${id}/renew`); st.step = 'order'; draw(); toast('Shartnoma yangilandi'); });
  }
  function draw() {
    if (v.status === 'CANCELLED' || v.status === 'EXPIRED') return drawClosed();
    ({ order: drawOrder, read: drawRead, otp: drawOtp, done: drawDone })[st.step]();
  }
  draw();
}

/* ======================= MENING SHARTNOMALARIM ======================= */
async function viewMyContracts() {
  loader(); let list; try { list = await api('GET', '/contracts'); } catch (e) { return fail(e); }
  const tabs = [['active', 'Faol', c => c.status === 'APPROVED' && ['CONFIRMED', 'ACTIVE', 'OVERDUE'].includes(c.booking_status)], ['wait', 'Kutilmoqda', c => ['PENDING', 'REVIEW'].includes(c.status)],
    ['ok', 'Tasdiqlangan', c => c.status === 'APPROVED'], ['old', 'Eski', c => ['CANCELLED', 'EXPIRED'].includes(c.status) || c.booking_status === 'COMPLETED'], ['hist', 'Ijara tarixi', () => true]];
  S.ctab = S.ctab || 'active';
  const render = () => {
    const t = tabs.find(x => x[0] === S.ctab) || tabs[0], rows = list.filter(t[2]);
    screen(`${head('Mening shartnomalarim')}<div class="seg">${tabs.map(([k, l, f]) => `<button class="${S.ctab === k ? 'on' : ''}" data-act="ctab" data-v="${k}">${l} ${list.filter(f).length || ''}</button>`).join('')}</div>
      ${rows.length ? rows.map(c => `<div class="card"><div class="row"><b>${esc(c.car)}</b><span class="sp"></span>${cpill(c.status)}</div>
        <div class="kv"><span>№</span><b>${esc(c.number)}</b></div><div class="kv"><span>Muddat</span><b>${fD(c.pickup_at)} — ${fD(c.return_at)} · ${c.days} kun</b></div><div class="kv"><span>Summa</span><b>${money(c.total_amount)}</b></div>
        ${S.ctab === 'hist' ? `<div class="kv"><span>Buyurtma</span><b>#${esc(c.code)}</b></div>` : ''}
        <div style="height:10px"></div><button class="btn ${c.status === 'APPROVED' ? 'alt' : ''} sm" style="width:100%" data-act="opencontract" data-id="${c.id}">${I('doc')} ${['PENDING', 'REVIEW'].includes(c.status) ? "Ko'rish va tasdiqlash" : 'PDF / batafsil'}</button></div>`).join('')
      : empty('📄', "Bu bo'limda shartnoma yo'q.", '')}`, false);
  };
  render(); H.ctab = a => { S.ctab = a.dataset.v; render(); };
}
