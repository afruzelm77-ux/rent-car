'use strict';
/* ================= SUHBATLAR / JARIMALAR / GPS ================= */
const rel = d => { if (!d) return '—'; const m = Math.round((Date.now() - new Date(d).getTime()) / 60000); return m < 1 ? 'hozir' : m < 60 ? `${m} daqiqa oldin` : m < 1440 ? `${Math.round(m / 60)} soat oldin` : fDT(d); };
const mapLink = (lat, lng) => `https://maps.google.com/?q=${lat},${lng}`;

/* ---------- Suhbatlar: mijoz bilan bot orqali ikki tomonlama chat ---------- */
PAGES.chat = {
  title: 'Suhbatlar', icon: '💬', perm: 'messages.send',
  async render(el) {
    let cur = null, timer = null;
    el.innerHTML = `<div class="hello"><div><h1>Suhbatlar</h1><p>Mijozlar botga yozgan xabarlarga shu yerdan javob bering</p></div></div><div class="chat"><div class="cl" id="cl">${loading}</div><div class="cw" id="cw"><div class="empty"><b>Suhbat tanlang</b>Chapdan mijozni bosing.</div></div></div>`;
    const list = async () => {
      const d = await api('GET', '/chat/threads');
      $('#cl', el).innerHTML = d.items.length ? d.items.map(t => `<div class="ct ${cur === t.customer_id ? 'on' : ''}" data-id="${t.customer_id}"><div class="av">${esc((t.name || '?')[0])}</div><div class="ci"><b>${esc(t.name)}</b><span>${t.direction === 'OUT' ? 'Siz: ' : ''}${esc((t.body || '').slice(0, 48))}</span></div><div class="cm">${rel(t.created_at).replace(' oldin', '')}${t.unread ? `<i class="ub">${t.unread}</i>` : ''}</div></div>`).join('') : emptyState("Hali xabar yo'q", 'Mijoz botga yozganda shu yerda ko\'rinadi.');
    };
    const open = async (id, keepScroll) => {
      cur = id; const d = await api('GET', '/chat/' + id);
      const cw = $('#cw', el); const old = $('#cb', el);
      const atEnd = !old || old.scrollHeight - old.scrollTop - old.clientHeight < 80;
      cw.innerHTML = `<div class="ch"><div class="av">${esc((d.customer.name || '?')[0])}</div><div><b>${esc(d.customer.name)}</b><div class="small muted">${esc(d.customer.phone || '')}${d.customer.connected ? '' : ' · botga ulanmagan'}</div></div></div>
        <div class="cb" id="cb">${d.items.map(m => `<div class="bub ${m.direction === 'IN' ? 'in' : 'out'}"><div>${esc(m.body)}</div><span>${m.direction === 'OUT' && m.sent_by_name ? esc(m.sent_by_name) + ' · ' : ''}${fDT(m.created_at)}${m.status === 'FAILED' ? ' · ❌ yuborilmadi' : ''}</span></div>`).join('') || '<div class="muted small" style="text-align:center">Xabarlar yo\'q</div>'}</div>
        <div class="cx"><textarea id="ct" rows="1" maxlength="3500" placeholder="Javob yozing…"></textarea><button class="btn primary" id="cs">Yuborish ➤</button></div>`;
      const b = $('#cb', el); if (!keepScroll || atEnd) b.scrollTop = b.scrollHeight;
      const send = () => guard(async () => { const t = $('#ct', el).value.trim(); if (!t) return; await api('POST', '/chat/' + id, { text: t }); await open(id); await list(); }, $('#cs', el));
      $('#cs', el).addEventListener('click', send);
      $('#ct', el).addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } });
      await list();
    };
    await list();
    $('#cl', el).addEventListener('click', e => { const t = e.target.closest('[data-id]'); if (t) guard(() => open(+t.dataset.id)); });
    timer = setInterval(async () => { if (!document.body.contains(el) || !$('#cl', el)) return clearInterval(timer); try { await list(); if (cur && document.activeElement?.id !== 'ct') await open(cur, true); } catch {} }, 6000);
  },
};

/* ---------- Jarimalar ---------- */
const FINE_ST = { NEW: ['Yangi', 'PENDING'], PAID: ["To'langan", 'PAID'], CANCELLED: ['Bekor', 'CANCELLED'] };
PAGES.fines = {
  title: 'Jarimalar', icon: '🚨', perm: 'bookings.read',
  async render(el) {
    const st = { status: '', q: '' }; const w = can('payments.write');
    el.innerHTML = `<div class="hello"><div><h1>Jarimalar</h1><p>YHXB va boshqa jarimalar — ijara davridagi mijozga avtomatik biriktiriladi</p></div><span class="sp"></span>${w ? '<button class="btn primary" id="nf">＋ JARIMA QO\'SHISH</button>' : ''}</div>
      <div class="row" style="margin-bottom:14px"><div class="tabs" id="ft" style="margin:0">${[['', 'Barchasi'], ['NEW', 'Yangi'], ['PAID', "To'langan"], ['CANCELLED', 'Bekor']].map(([k, v]) => `<button class="tab ${k === '' ? 'on' : ''}" data-s="${k}">${v}</button>`).join('')}</div><span class="sp"></span><input id="fq" type="search" placeholder="Raqam, mijoz, hujjat..." style="max-width:260px"></div><div id="fl">${loading}</div>`;
    const load = async () => {
      const rows = await api('GET', '/fines' + qs(st));
      $('#fl', el).innerHTML = rows.length ? `<div class="tablewrap"><table><thead><tr><th>Sana</th><th>Mashina</th><th>Mijoz</th><th>Summa</th><th>Sabab</th><th>Holat</th><th></th></tr></thead><tbody>${rows.map(f => `<tr><td>${fDT(f.fine_date)}</td><td><b>${esc(f.brand)} ${esc(f.model)}</b><div class="small muted">${esc(f.plate)}</div></td>
        <td>${f.customer_id ? `${esc(f.first_name)} ${esc(f.last_name || '')}<div class="small muted">${esc(f.phone || '')} · ${esc(f.booking_code || '')}</div>` : '<span class="muted">Biriktirilmagan</span>'}</td>
        <td><b class="num">${money(f.amount)}</b></td><td>${esc(f.reason || '—')}${f.doc_no ? `<div class="small muted">№ ${esc(f.doc_no)}</div>` : ''}</td>
        <td><span class="pill ${FINE_ST[f.status][1]}">${FINE_ST[f.status][0]}</span></td>
        <td class="right">${w && f.status === 'NEW' ? `<button class="btn sm ok" data-st="PAID" data-id="${f.id}">To'landi</button> <button class="btn sm danger" data-st="CANCELLED" data-id="${f.id}">Bekor</button>` : ''}</td></tr>`).join('')}</tbody></table></div>` : emptyState("Jarima yo'q", '');
    };
    await load(); App.refresh = load;
    $('#ft', el).addEventListener('click', e => { const b = e.target.closest('[data-s]'); if (!b) return; st.status = b.dataset.s; $$('.tab', el).forEach(t => t.classList.toggle('on', t === b)); load(); });
    let tm; $('#fq', el).addEventListener('input', e => { clearTimeout(tm); tm = setTimeout(() => { st.q = e.target.value; load(); }, 250); });
    $('#fl', el).addEventListener('click', e => { const b = e.target.closest('[data-st]'); if (b) guard(async () => { await api('POST', `/fines/${b.dataset.id}/status`, { status: b.dataset.st }); toast('Yangilandi'); load(); }, b); });
    $('#nf', el)?.addEventListener('click', () => guard(async () => {
      const cars = await api('GET', '/cars');
      const m = modal('Yangi jarima', `<div class="grid g2"><div class="field"><label class="f">Mashina *</label><select id="f_car">${cars.map(c => `<option value="${c.id}">${esc(c.brand)} ${esc(c.model)} — ${esc(c.plate)}</option>`).join('')}</select></div>
        <div class="field"><label class="f">Jarima sanasi va vaqti *</label><input type="datetime-local" id="f_dt"></div>
        <div class="field"><label class="f">Summa (so'm) *</label><input type="number" id="f_am" min="1"></div><div class="field"><label class="f">Hujjat / qaror raqami</label><input id="f_doc"></div>
        <div class="field" style="grid-column:1/-1"><label class="f">Sabab</label><input id="f_re" placeholder="Masalan: tezlikni oshirish"></div></div><div class="small muted">Shu sanada mashina kimda bo'lgan bo'lsa, jarima o'sha mijozga avtomatik biriktiriladi va unga bot orqali xabar boradi.</div>`,
        { footer: '<button class="btn" data-close>Bekor qilish</button><button class="btn primary" data-go>Saqlash</button>' });
      $('[data-go]', m.el).addEventListener('click', ev => guard(async () => {
        const dt = $('#f_dt', m.el).value; if (!dt) throw new Error('Sanani kiriting');
        const r = await api('POST', '/fines', { car_id: +$('#f_car', m.el).value, fine_date: new Date(dt).toISOString(), amount: +$('#f_am', m.el).value, doc_no: $('#f_doc', m.el).value || null, reason: $('#f_re', m.el).value || null });
        toast(r.assigned ? `Mijozga biriktirildi (${r.booking_code}) va xabar yuborildi ✓` : "Saqlandi. Bu sanada ijara topilmadi — mijozga biriktirilmadi", !r.assigned); m.close(); load(); }, ev.target));
    }));
  },
};

/* ---------- GPS kuzatuv ---------- */
PAGES.gps = {
  title: 'GPS kuzatuv', icon: '📍', perm: 'cars.read',
  async render(el) {
    el.innerHTML = `<div class="hello"><div><h1>GPS kuzatuv</h1><p>Mashinalarning oxirgi joylashuvi, tezligi va yo'l izi</p></div></div><div id="gl">${loading}</div>
      <div class="card" style="margin-top:14px"><h3>Joylashuv qanday keladi?</h3><div class="small muted" style="line-height:1.6">• <b>Telegram orqali:</b> mijoz botga «Joylashuv → Jonli joylashuvni ulashish» yuboradi — faol ijaradagi mashina joylashuvi yangilanadi.<br>• <b>GPS qurilma / tracker:</b> «Ulash» tugmasini bosib, qurilmaga maxfiy manzilni kiriting.<br>• Tezlik va hudud limitlarini <b>Sozlamalar → Umumiy</b> bo'limida belgilang.</div></div>`;
    const load = async () => {
      const rows = await api('GET', '/gps/cars');
      $('#gl', el).innerHTML = `<div class="tablewrap"><table><thead><tr><th>Mashina</th><th>Holat</th><th>Mijoz</th><th>Oxirgi signal</th><th>Tezlik</th><th>Joy</th><th></th></tr></thead><tbody>${rows.map(c => {
        const on = c.seen_at && Date.now() - new Date(c.seen_at) < 10 * 60e3;
        return `<tr><td><b>${esc(c.brand)} ${esc(c.model)}</b><div class="small muted">${esc(c.plate)}</div></td><td>${carPill(c.status)}</td><td>${esc(c.customer || '—')}</td>
        <td>${c.seen_at ? `<span class="pill ${on ? 'PAID' : 'INACTIVE'}">${on ? '● Onlayn' : 'Oflayn'}</span><div class="small muted">${rel(c.seen_at)} · ${c.source === 'TELEGRAM' ? 'Telegram' : 'Qurilma'}</div>` : '<span class="muted">Signal yo\'q</span>'}</td>
        <td>${c.speed_kmh != null ? Math.round(c.speed_kmh) + ' km/s' : '—'}</td><td>${c.lat != null ? `<a href="${mapLink(c.lat, c.lng)}" target="_blank" rel="noopener">🗺 Xaritada</a>` : '—'}</td>
        <td class="right">${c.lat != null ? `<button class="btn sm" data-trk="${c.id}" data-n="${esc(c.brand + ' ' + c.model)}">Yo'l izi</button> ` : ''}${can('cars.write') ? `<button class="btn sm" data-tok="${c.id}" data-n="${esc(c.brand + ' ' + c.model)}">Ulash</button>` : ''}</td></tr>`; }).join('')}</tbody></table></div>`;
    };
    await load(); const iv = setInterval(() => { if (!document.body.contains(el)) return clearInterval(iv); load().catch(() => {}); }, 20000);
    el.addEventListener('click', e => {
      const t = e.target.closest('[data-trk]'), k = e.target.closest('[data-tok]');
      if (t) guard(async () => {
        const pts = await api('GET', `/gps/cars/${t.dataset.trk}/track?hours=24`);
        const lats = pts.map(p => p.lat), lngs = pts.map(p => p.lng); const mnA = Math.min(...lats), mxA = Math.max(...lats), mnO = Math.min(...lngs), mxO = Math.max(...lngs);
        const W = 560, H = 300, pad = 20, sx = v => pad + (mxO === mnO ? .5 : (v - mnO) / (mxO - mnO)) * (W - 2 * pad), sy = v => H - pad - (mxA === mnA ? .5 : (v - mnA) / (mxA - mnA)) * (H - 2 * pad);
        const line = pts.map(p => `${sx(p.lng).toFixed(1)},${sy(p.lat).toFixed(1)}`).join(' '); const last = pts[pts.length - 1];
        modal(`${t.dataset.n} — oxirgi 24 soat`, `<svg viewBox="0 0 ${W} ${H}" style="width:100%;background:#0D0C0A;border-radius:16px;border:1px solid var(--line)"><polyline points="${line}" fill="none" stroke="#D7AB3C" stroke-width="3" stroke-linejoin="round"/><circle cx="${sx(pts[0].lng)}" cy="${sy(pts[0].lat)}" r="6" fill="#20C77A"/><circle cx="${sx(last.lng)}" cy="${sy(last.lat)}" r="7" fill="#DEBA60" stroke="#fff" stroke-width="2"/></svg>
          <div class="small muted" style="margin-top:8px">${pts.length} ta nuqta · 🟢 boshlanish · 🟡 oxirgi joy. <a href="${mapLink(last.lat, last.lng)}" target="_blank" rel="noopener">Google Maps'da ochish</a></div>`, { size: 'lg' });
      });
      if (k) guard(async () => {
        const r = await api('POST', `/gps/cars/${k.dataset.tok}/token`, {}); const url = (location.origin) + '/api/gps/' + r.token;
        const m = modal(`GPS ulash — ${k.dataset.n}`, `<div class="small muted" style="margin-bottom:8px">Qurilmaga quyidagi manzilni kiriting (GET yoki POST). Parametrlar: <code>lat</code>, <code>lng</code> (yoki <code>lon</code>), <code>speed</code> (km/soat).</div><div class="autoname" style="word-break:break-all;user-select:all">${esc(url)}?lat={lat}&amp;lng={lng}&amp;speed={speed}</div><div class="small muted" style="margin-top:10px">⚠️ Bu manzil maxfiy. Boshqalarga bermang. Sizib chiqsa, «Yangilash» orqali almashtiring.</div>`,
          { footer: '<button class="btn danger" data-reset>Kalitni yangilash</button><button class="btn primary" data-close>Yopish</button>' });
        $('[data-reset]', m.el).addEventListener('click', ev => guard(async () => { if (!confirm('Eski manzil ishlamay qoladi. Davom etilsinmi?')) return; await api('POST', `/gps/cars/${k.dataset.tok}/token`, { reset: true }); toast('Yangi kalit yaratildi'); m.close(); load(); }, ev.target));
      });
    });
  },
};
